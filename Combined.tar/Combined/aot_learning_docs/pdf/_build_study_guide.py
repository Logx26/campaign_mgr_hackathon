"""
Build the single combined AOT Complete Study Guide PDF.

Reuses the CSS / HTML template / helper functions from _build_pdfs.py, but renders
one standalone markdown file (AOT_Complete_Study_Guide.md) with a custom title page.

Run from WSL:
    python3 /mnt/d/Zillow/MMM_Learning/aot_learning_docs/pdf/_build_study_guide.py
"""

from __future__ import annotations

import asyncio
import re
import sys
from pathlib import Path

import markdown

SCRIPT_DIR = Path(__file__).resolve().parent
sys.path.insert(0, str(SCRIPT_DIR))

import _build_pdfs as base  # reuse CSS, HTML_TEMPLATE, helpers, html_to_pdf

DOCS_DIR = SCRIPT_DIR.parent                      # aot_learning_docs/
PDF_DIR = SCRIPT_DIR                              # aot_learning_docs/pdf/
MD_FILE = DOCS_DIR / "AOT_Complete_Study_Guide.md"
OUT_PDF = DOCS_DIR / "AOT_Complete_Study_Guide.pdf"

TITLE_PAGE = r"""
<div class="title-page">
  <div class="series">Zillow AOT Learning Library</div>
  <div class="doc-id" style="font-size:64pt;">AOT</div>
  <div class="label">Complete Study Guide</div>
  <h1>{title}</h1>
  <div class="subtitle">{subtitle}</div>
  <div class="meta">
    <div><span class="meta-label">Covers:</span></div>
    <ul>
      <li>Causal-inference foundations (counterfactual, ATE, DiD, parallel trends)</li>
      <li>The statistical-validation toolkit (stratification, power, the test battery)</li>
      <li>Legacy systems — Email, Paid Social (Meta), SEM</li>
      <li>The new geo-stratification design (composite score -> 5-DMA holdouts)</li>
      <li>Dark-period TV testing</li>
      <li>The incrementality layer — fusing AOT with MMM</li>
    </ul>
  </div>
</div>
"""


def render() -> str:
    raw = MD_FILE.read_text(encoding="utf-8")
    fm, body_md = base.split_frontmatter(raw)

    body_md, mermaid_holders = base.protect_mermaid_blocks(body_md)
    body_md, math_holders = base.protect_math_blocks(body_md)

    md = markdown.Markdown(extensions=[
        "extra", "toc", "codehilite", "sane_lists",
        "pymdownx.tasklist", "pymdownx.superfences",
    ], extension_configs={
        "codehilite": {"css_class": "codehilite", "guess_lang": False, "noclasses": False},
        "toc": {"permalink": False},
    })
    body_html = md.convert(body_md)
    body_html = base.restore_math_blocks(body_html, math_holders)
    body_html = base.restore_mermaid_blocks(body_html, mermaid_holders)
    body_html = base.detect_ascii_pre_blocks(body_html)

    # strip the first H1 (used on the title page instead)
    body_html = re.sub(r"<h1[^>]*>.*?</h1>", "", body_html, count=1, flags=re.DOTALL)

    title = fm.get("title", "Zillow Always-On Testing — Complete Study Guide")
    subtitle = fm.get("description", "")

    title_page = TITLE_PAGE.format(title=title, subtitle=subtitle)
    toc_page = base.build_toc_html(body_html)

    html = base.HTML_TEMPLATE.format(
        title=title,
        css=base.CSS,
        title_page=title_page,
        toc_page=toc_page,
        body=body_html,
        footer="Zillow AOT — Complete Study Guide",
        doc_id_label="Zillow AOT Learning Library",
    )
    return html


async def main() -> None:
    html = render()
    html_path = PDF_DIR / "AOT_Complete_Study_Guide.html"
    html_path.write_text(html, encoding="utf-8")
    print(f"Wrote HTML: {html_path}", flush=True)
    await base.html_to_pdf(html_path, OUT_PDF)
    size_kb = OUT_PDF.stat().st_size // 1024
    print(f"Wrote PDF:  {OUT_PDF}  ({size_kb} KB)", flush=True)


if __name__ == "__main__":
    asyncio.run(main())
