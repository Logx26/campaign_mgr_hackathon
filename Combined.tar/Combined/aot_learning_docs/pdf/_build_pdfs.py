"""
Build professional PDFs from the 5 AOT Learning markdown docs.

Pipeline:
  markdown -> HTML (with custom CSS + KaTeX for math + Mermaid for diagrams +
                    Pygments-styled code blocks + title page + TOC)
        -> headless Chromium (Playwright) renders the HTML (JS executes for
           KaTeX + Mermaid) -> print-to-PDF with A4 + footer + page numbers
  -> aot_learning_docs/pdf/NN_title.pdf

Run from WSL:
    python3 /mnt/d/MMM_Learning/aot_learning_docs/pdf/_build_pdfs.py

The script is idempotent: re-running overwrites the existing PDFs.

This is adapted from learning_docs/pdf/_build_pdfs.py with three differences:
  - DOCS_DIR points at aot_learning_docs/
  - DOC_FILES tuple is the 5 AOT docs
  - Doc IDs are derived from filenames (first 2 chars) because the AOT
    frontmatter convention is title + description only — no doc_id field
"""

from __future__ import annotations

import asyncio
import re
import sys
import textwrap
from pathlib import Path

import markdown
from markdown.extensions import fenced_code, tables, toc, attr_list, codehilite

DOCS_DIR = Path("/mnt/d/MMM_Learning/aot_learning_docs")
PDF_DIR = DOCS_DIR / "pdf"

# -----------------------------------------------------------------------------
# Doc inventory in reading order
# -----------------------------------------------------------------------------

DOC_FILES = [
    ("00_aot_ecosystem_and_foundations.md",   "AOT Ecosystem Overview & Causal-Inference Foundations"),
    ("01_existing_aot_systems.md",            "Existing AOT Systems — Email, Paid Social, SEM"),
    ("02_geo_stratification_design.md",       "NEW Geo Stratification & Holdout Design"),
    ("03_dark_period_tv.md",                  "Dark-Period Testing for TV"),
    ("04_incrementality_and_forecasting.md",  "Incrementality Layer + Response Curves + Forecasting"),
]

# -----------------------------------------------------------------------------
# CSS — professional minimal style
# -----------------------------------------------------------------------------

CSS = r"""
:root {
  --primary:      #1e40af;        /* deep blue accent */
  --primary-soft: #dbeafe;
  --secondary:    #475569;        /* slate */
  --accent:       #ea580c;        /* warm orange for callouts */
  --text:         #1e293b;
  --text-muted:   #64748b;
  --bg:           #ffffff;
  --bg-soft:      #f8fafc;
  --border:       #e2e8f0;
  --code-bg:      #f1f5f9;
  --code-border:  #cbd5e1;
  --table-stripe: #f8fafc;
  --callout-bg:   #fef3c7;
  --callout-border: #f59e0b;
}

@page {
  size: A4;
  margin: 22mm 18mm 22mm 18mm;
  @bottom-left   { content: var(--doc-footer); font-size: 9pt; color: #64748b; font-family: 'Inter', sans-serif; }
  @bottom-right  { content: "Page " counter(page) " of " counter(pages); font-size: 9pt; color: #64748b; font-family: 'Inter', sans-serif; }
  @top-right     { content: var(--doc-id);     font-size: 9pt; color: #cbd5e1; font-family: 'Inter', sans-serif; }
}

@page:first {
  @bottom-left  { content: none; }
  @bottom-right { content: none; }
  @top-right    { content: none; }
}

* { box-sizing: border-box; }

html, body {
  font-family: 'Inter', 'Helvetica Neue', Helvetica, Arial, sans-serif;
  font-size:   10.5pt;
  line-height: 1.55;
  color:       var(--text);
  background:  var(--bg);
  margin: 0;
  padding: 0;
  -webkit-font-smoothing: antialiased;
}

/* ===== Title page ===== */
.title-page {
  page-break-after: always;
  display: flex;
  flex-direction: column;
  justify-content: center;
  align-items: flex-start;
  min-height: 240mm;
  padding: 0 6mm;
}
.title-page .label {
  color: var(--primary);
  font-size: 11pt;
  font-weight: 600;
  letter-spacing: 0.18em;
  text-transform: uppercase;
  margin-bottom: 8mm;
}
.title-page .doc-id {
  font-size: 110pt;
  font-weight: 700;
  color: var(--primary);
  line-height: 1;
  margin-bottom: 4mm;
  letter-spacing: -0.03em;
}
.title-page h1 {
  font-size: 32pt;
  line-height: 1.15;
  font-weight: 700;
  color: var(--text);
  border: none;
  margin: 0 0 10mm 0;
  padding: 0;
  max-width: 160mm;
}
.title-page .subtitle {
  font-size: 14pt;
  color: var(--text-muted);
  font-weight: 400;
  margin-bottom: 16mm;
  max-width: 150mm;
}
.title-page .meta {
  border-left: 4px solid var(--primary);
  padding: 4mm 0 4mm 6mm;
  margin-top: 10mm;
  font-size: 10pt;
  color: var(--secondary);
  max-width: 170mm;
}
.title-page .meta .meta-label {
  font-weight: 600;
  color: var(--text);
  margin-right: 4mm;
}
.title-page .meta ul { margin: 2mm 0 0 5mm; padding: 0; }
.title-page .meta li { margin: 1.5mm 0; list-style: disc; }
.title-page .series {
  margin-top: 16mm;
  font-size: 9.5pt;
  color: var(--text-muted);
  letter-spacing: 0.08em;
  text-transform: uppercase;
  font-weight: 500;
}

/* ===== TOC page ===== */
.toc-page { page-break-after: always; }
.toc-page h2 {
  color: var(--primary);
  border-bottom: 2px solid var(--primary);
  padding-bottom: 4mm;
  margin-bottom: 8mm;
  font-size: 20pt;
}
.toc { font-size: 10pt; }
.toc ul { list-style: none; padding-left: 0; margin: 0; }
.toc > ul > li { margin: 3mm 0; }
.toc > ul > li > a { font-weight: 600; color: var(--text); }
.toc ul ul { padding-left: 6mm; margin-top: 1mm; }
.toc ul ul li { margin: 1.5mm 0; font-weight: 400; color: var(--text-muted); }
.toc a { text-decoration: none; }
.toc a:hover { color: var(--primary); }

/* ===== Body content ===== */
.content { padding: 0; }

h1 {
  font-size: 24pt;
  font-weight: 700;
  color: var(--primary);
  border-bottom: 3px solid var(--primary);
  padding-bottom: 3mm;
  margin: 0 0 8mm 0;
  page-break-after: avoid;
  letter-spacing: -0.01em;
}

h2 {
  font-size: 17pt;
  font-weight: 600;
  color: var(--primary);
  border-bottom: 1.5px solid var(--border);
  padding-bottom: 2.5mm;
  margin: 12mm 0 5mm 0;
  page-break-after: avoid;
  letter-spacing: -0.005em;
}

h3 {
  font-size: 13pt;
  font-weight: 600;
  color: var(--secondary);
  margin: 8mm 0 3mm 0;
  page-break-after: avoid;
}

h4 {
  font-size: 11.5pt;
  font-weight: 600;
  color: var(--text);
  margin: 6mm 0 2mm 0;
  page-break-after: avoid;
}

p, ul, ol { margin: 0 0 3mm 0; }

ul, ol { padding-left: 6mm; }
li { margin: 1mm 0; }

a {
  color: var(--primary);
  text-decoration: none;
  border-bottom: 1px dotted var(--primary);
}

/* ===== Inline code + code blocks ===== */
code {
  font-family: 'JetBrains Mono', 'Source Code Pro', 'Consolas', 'Courier New', monospace;
  font-size: 9.2pt;
  background: var(--code-bg);
  color: #be123c;
  padding: 0.2mm 1.4mm;
  border-radius: 2px;
  border: 1px solid var(--code-border);
}

pre {
  background: #f8fafc;
  border: 1px solid var(--border);
  border-left: 4px solid var(--primary);
  border-radius: 4px;
  padding: 3mm 4mm;
  margin: 3mm 0;
  overflow-x: auto;
  font-size: 8.5pt;
  line-height: 1.45;
  white-space: pre;
  page-break-inside: avoid;
}
pre code {
  background: none;
  color: var(--text);
  padding: 0;
  border: none;
  font-size: 8.5pt;
  font-family: 'JetBrains Mono', 'Source Code Pro', 'Consolas', 'Courier New', monospace;
  display: block;
}

/* Pygments syntax highlighting — covers both .codehilite (legacy) and .highlight (pymdownx) wrappers */
.codehilite, .highlight { background: #f8fafc; border-radius: 4px; }
.codehilite pre, .highlight pre { background: #f8fafc; }
.codehilite .k, .highlight .k    { color: #7c3aed; font-weight: 600; }     /* keyword */
.codehilite .kn, .highlight .kn  { color: #7c3aed; font-weight: 600; }
.codehilite .kc, .highlight .kc  { color: #7c3aed; font-weight: 600; }
.codehilite .kd, .highlight .kd  { color: #7c3aed; font-weight: 600; }
.codehilite .kr, .highlight .kr  { color: #7c3aed; font-weight: 600; }
.codehilite .k, .highlight .ow   { color: #7c3aed; font-weight: 600; }
.codehilite .nf, .highlight .nf  { color: #2563eb; font-weight: 600; }     /* function name */
.codehilite .nc, .highlight .nc  { color: #db2777; font-weight: 600; }     /* class name */
.codehilite .nb, .highlight .nb  { color: #be123c; }                       /* builtin */
.codehilite .bp, .highlight .bp  { color: #be123c; font-style: italic; }   /* self */
.codehilite .s, .codehilite .s1, .codehilite .s2,
.highlight .s, .highlight .s1, .highlight .s2 { color: #16a34a; }          /* string */
.codehilite .n, .highlight .n    { color: var(--text); }                   /* name */
.codehilite .c, .codehilite .c1, .codehilite .cm,
.highlight .c, .highlight .c1, .highlight .cm { color: #94a3b8; font-style: italic; }
.codehilite .o, .highlight .o    { color: #475569; }                       /* operator */
.codehilite .mi, .codehilite .mf, .highlight .mi, .highlight .mf { color: #ea580c; }
.codehilite .p, .highlight .p    { color: #475569; }                       /* punctuation */

/* ===== ASCII diagrams: tighten the line height when content is box-drawing ===== */
pre.ascii-diagram,
.ascii-diagram-wrap pre {
  line-height: 1.18;
  font-size: 7.5pt;
  border-left-color: var(--secondary);
  background: var(--bg-soft);
}
pre.ascii-diagram code,
.ascii-diagram-wrap pre code {
  font-size: 7.5pt;
  line-height: 1.18;
  white-space: pre;
}
/* Don't apply Pygments colors inside ASCII wrappers — keep them monochrome */
.ascii-diagram-wrap .k, .ascii-diagram-wrap .n, .ascii-diagram-wrap .o,
.ascii-diagram-wrap .p, .ascii-diagram-wrap .s, .ascii-diagram-wrap .c {
  color: var(--text) !important;
  font-weight: normal !important;
  font-style: normal !important;
}

/* ===== Tables ===== */
table {
  border-collapse: collapse;
  margin: 4mm 0;
  width: 100%;
  font-size: 9pt;
  page-break-inside: avoid;
}
th {
  background: var(--primary-soft);
  color: var(--primary);
  font-weight: 600;
  padding: 2mm 3mm;
  border: 1px solid var(--border);
  text-align: left;
  vertical-align: top;
}
td {
  padding: 2mm 3mm;
  border: 1px solid var(--border);
  vertical-align: top;
}
tr:nth-child(even) td { background: var(--table-stripe); }

/* ===== Blockquotes (used heavily for "Interview angle" callouts) ===== */
blockquote {
  background: var(--callout-bg);
  border-left: 4px solid var(--callout-border);
  padding: 3mm 5mm;
  margin: 4mm 0;
  font-size: 9.8pt;
  color: var(--text);
  page-break-inside: avoid;
  border-radius: 0 3px 3px 0;
}
blockquote p { margin: 1mm 0; }
blockquote strong:first-child { color: #b45309; }

/* ===== Horizontal rule ===== */
hr {
  border: none;
  border-top: 1.5px solid var(--border);
  margin: 8mm 0;
}

/* ===== KaTeX math ===== */
.katex { font-size: 1em !important; }
.katex-display {
  margin: 3mm 0 !important;
  padding: 2mm 0;
  overflow-x: auto;
  page-break-inside: avoid;
}

/* ===== Mermaid diagrams ===== */
.mermaid {
  text-align: center;
  margin: 5mm 0;
  page-break-inside: avoid;
}
.mermaid svg { max-width: 100%; height: auto; }

/* ===== Headings inside blockquotes (no border) ===== */
blockquote h1, blockquote h2, blockquote h3, blockquote h4 {
  border: none;
  margin: 1mm 0;
  padding: 0;
  color: var(--text);
}

/* ===== Page-break helpers ===== */
.page-break { page-break-after: always; }
"""

# -----------------------------------------------------------------------------
# HTML template
# -----------------------------------------------------------------------------

HTML_TEMPLATE = r"""<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8">
<title>{title}</title>
<style>
:root {{
  --doc-footer: "{footer}";
  --doc-id:     "{doc_id_label}";
}}
{css}
</style>

<!-- KaTeX (math rendering) -- local assets to avoid firewall-blocked CDN -->
<link rel="stylesheet" href="_assets/katex.min.css">
<script src="_assets/katex.min.js"></script>
<script src="_assets/auto-render.min.js"></script>

<!-- Mermaid (diagram rendering) -- local asset -->
<script src="_assets/mermaid.min.js"></script>

<script>
document.addEventListener('DOMContentLoaded', function () {{
  // KaTeX auto-render
  if (window.renderMathInElement) {{
    renderMathInElement(document.body, {{
      delimiters: [
        {{left: "$$", right: "$$", display: true}},
        {{left: "$",  right: "$",  display: false}}
      ],
      throwOnError: false,
      strict: false
    }});
  }}
  // Mermaid init
  if (window.mermaid) {{
    mermaid.initialize({{
      startOnLoad: true,
      theme: 'default',
      themeVariables: {{
        primaryColor: '#dbeafe',
        primaryTextColor: '#1e293b',
        primaryBorderColor: '#1e40af',
        lineColor: '#475569',
        secondaryColor: '#fef3c7',
        tertiaryColor: '#f0fdf4',
        fontFamily: 'Inter, sans-serif'
      }}
    }});
  }}
}});
</script>
</head>
<body>
{title_page}
{toc_page}
<div class="content">
{body}
</div>
</body>
</html>
"""

TITLE_PAGE_TEMPLATE = r"""
<div class="title-page">
  <div class="series">Zillow AOT Learning Library</div>
  <div class="doc-id">{doc_id}</div>
  <div class="label">Document {doc_id}</div>
  <h1>{title}</h1>
  <div class="subtitle">{subtitle}</div>
  {meta_block}
</div>
"""

# -----------------------------------------------------------------------------
# Markdown -> HTML conversion
# -----------------------------------------------------------------------------

def split_frontmatter(text: str) -> tuple[dict, str]:
    """Strip YAML frontmatter; return (frontmatter_dict, body)."""
    if not text.startswith("---"):
        return {}, text
    end = text.find("\n---", 3)
    if end < 0:
        return {}, text
    fm_block = text[3:end].strip()
    body = text[end + 4 :].lstrip("\n")
    fm = {}
    current_key = None
    for line in fm_block.splitlines():
        if line.startswith("  - "):
            if current_key:
                fm.setdefault(current_key, []).append(line[4:].strip())
        elif ":" in line:
            k, _, v = line.partition(":")
            current_key = k.strip()
            v = v.strip()
            if v:
                fm[current_key] = v
            else:
                fm.setdefault(current_key, [])
    return fm, body


def protect_mermaid_blocks(md_text: str) -> tuple[str, dict[str, str]]:
    """Replace ```mermaid blocks with placeholders; restore as <div class="mermaid">."""
    placeholders = {}
    pattern = re.compile(r"```mermaid\n(.*?)```", re.DOTALL)
    def _sub(m):
        idx = len(placeholders)
        key = f"@@MERMAID_BLOCK_{idx}@@"
        placeholders[key] = m.group(1).rstrip()
        return key
    return pattern.sub(_sub, md_text), placeholders


def restore_mermaid_blocks(html: str, placeholders: dict[str, str]) -> str:
    """Restore Mermaid placeholders as <div class="mermaid"> for Mermaid.js."""
    for key, src in placeholders.items():
        replacement = f'<div class="mermaid">\n{src}\n</div>'
        html = html.replace(f"<p>{key}</p>", replacement)
        html = html.replace(key, replacement)
    return html


def protect_math_blocks(md_text: str) -> tuple[str, dict[str, str]]:
    """Replace $$...$$ blocks with placeholders so markdown doesn't mangle them."""
    placeholders = {}
    # display math
    pattern_block = re.compile(r"\$\$\n?(.+?)\n?\$\$", re.DOTALL)
    def _sub_block(m):
        idx = len(placeholders)
        key = f"@@MATHDISPLAY_{idx}@@"
        placeholders[key] = f"$${m.group(1)}$$"
        return key
    md_text = pattern_block.sub(_sub_block, md_text)
    return md_text, placeholders


def restore_math_blocks(html: str, placeholders: dict[str, str]) -> str:
    for key, expr in placeholders.items():
        # Display math should stand alone, not inside <p>
        html = html.replace(f"<p>{key}</p>", f'<div class="math-display">{expr}</div>')
        html = html.replace(key, expr)
    return html


def detect_ascii_pre_blocks(html: str) -> str:
    """Tag code blocks whose content is mostly box-drawing chars as ASCII diagrams.

    Handles both raw `<pre><code>...</code></pre>` and pymdownx's
    `<div class="highlight"><pre><span></span><code>...</code></pre></div>`.
    Adds `ascii-diagram` class to the outer wrapper so CSS can tighten it.
    """
    box_chars = set("─│┌┐└┘├┤┬┴┼━┃┏┓┗┛┣┫┳┻╋╔╗╚╝╠╣╦╩╬█▀▄▌▐▏▎▍▋▊▉◀▶▼▲╳→←↑↓⇒⇐━│")

    def _is_ascii_diagram(content: str) -> bool:
        # Strip HTML tags so we look at the actual text
        text = re.sub(r"<[^>]+>", "", content)
        # Decode the most common HTML entities Pygments emits
        text = text.replace("&lt;", "<").replace("&gt;", ">").replace("&amp;", "&")
        sample = text[:1500]
        if not sample:
            return False
        box_count = sum(1 for c in sample if c in box_chars)
        non_space = max(1, sum(1 for c in sample if not c.isspace()))
        return box_count / non_space > 0.10

    # Case 1: pymdownx wrapper `<div class="highlight"><pre>...<code>...</code></pre></div>`
    def _wrap_highlight(match):
        block = match.group(0)
        inner_code = match.group(1)
        if _is_ascii_diagram(inner_code):
            return block.replace(
                '<div class="highlight">',
                '<div class="highlight ascii-diagram-wrap">',
                1,
            )
        return block
    html = re.sub(
        r'<div class="highlight">\s*<pre>.*?<code>(.*?)</code>\s*</pre>\s*</div>',
        _wrap_highlight,
        html,
        flags=re.DOTALL,
    )

    # Case 2: bare `<pre><code>...</code></pre>` (legacy / unhighlighted)
    def _wrap_bare(match):
        content = match.group(1)
        if _is_ascii_diagram(content):
            return f'<pre class="ascii-diagram"><code>{content}</code></pre>'
        return match.group(0)
    html = re.sub(
        r'<pre><code>(.*?)</code></pre>',
        _wrap_bare,
        html,
        flags=re.DOTALL,
    )
    return html


def build_toc_html(html_body: str) -> str:
    """Extract h2/h3 headings from generated HTML and build a styled TOC."""
    pattern = re.compile(r'<h([23])(?: id="([^"]+)")?[^>]*>(.*?)</h\1>', re.DOTALL)
    items = []
    for m in pattern.finditer(html_body):
        level, hid, raw_title = m.group(1), m.group(2) or "", m.group(3)
        title = re.sub(r"<[^>]+>", "", raw_title).strip()
        if title:
            items.append((int(level), hid, title))
    if not items:
        return ""
    lines = ['<div class="toc-page"><h2>Contents</h2><nav class="toc"><ul>']
    in_sub = False
    for level, hid, title in items:
        anchor = f'#{hid}' if hid else ''
        if level == 2:
            if in_sub:
                lines.append("</ul></li>")
                in_sub = False
            lines.append(f'<li><a href="{anchor}">{title}</a>')
        elif level == 3:
            if not in_sub:
                lines.append("<ul>")
                in_sub = True
            lines.append(f'<li><a href="{anchor}">{title}</a></li>')
    if in_sub:
        lines.append("</ul></li>")
    lines.append("</ul></nav></div>")
    return "\n".join(lines)


def render_html(md_path: Path, title: str) -> str:
    """Render a single markdown file to a styled HTML string."""
    raw = md_path.read_text(encoding="utf-8")
    fm, body_md = split_frontmatter(raw)

    body_md, mermaid_holders = protect_mermaid_blocks(body_md)
    body_md, math_holders = protect_math_blocks(body_md)

    md = markdown.Markdown(extensions=[
        "extra",           # tables, fenced_code, attr_list, def_list, etc.
        "toc",
        "codehilite",
        "sane_lists",
        "pymdownx.tasklist",
        "pymdownx.superfences",
    ], extension_configs={
        "codehilite": {"css_class": "codehilite", "guess_lang": False, "noclasses": False},
        "toc": {"permalink": False},
    })
    body_html = md.convert(body_md)

    body_html = restore_math_blocks(body_html, math_holders)
    body_html = restore_mermaid_blocks(body_html, mermaid_holders)
    body_html = detect_ascii_pre_blocks(body_html)

    # AOT frontmatter is title + description only — no doc_id field.
    # Derive doc_id from the filename's leading 2 digits ("00", "01", ...).
    doc_id_match = re.match(r"^(\d{2})_", md_path.stem)
    doc_id = doc_id_match.group(1) if doc_id_match else fm.get("doc_id", "")
    doc_title_fm = fm.get("title", title)

    # Strip the first H1 from body (we'll use it in title page)
    body_html = re.sub(r"<h1[^>]*>.*?</h1>", "", body_html, count=1, flags=re.DOTALL)

    # Subtitle: pick a short description per doc — prefer frontmatter `description`,
    # fall back to the curated subtitle map below.
    subtitle = fm.get("description", "") or SUBTITLES.get(doc_id, "")

    # Companion docs as a meta block (AOT frontmatter doesn't carry these,
    # but the block stays for future-proofing if a doc adds them).
    companion = fm.get("companion_docs", [])
    if isinstance(companion, list) and companion:
        items = "".join(f"<li>{c}</li>" for c in companion)
        meta_block = (
            f'<div class="meta">'
            f'<div><span class="meta-label">Companion docs:</span></div>'
            f'<ul>{items}</ul>'
            f'</div>'
        )
    else:
        meta_block = ""

    title_page = TITLE_PAGE_TEMPLATE.format(
        doc_id=doc_id or "—",
        title=doc_title_fm,
        subtitle=subtitle,
        meta_block=meta_block,
    )

    toc_page = build_toc_html(body_html)

    footer = f"Doc {doc_id} — {doc_title_fm}" if doc_id else doc_title_fm
    doc_id_label = f"Zillow AOT Learning Library — Doc {doc_id}" if doc_id else ""

    html = HTML_TEMPLATE.format(
        title=doc_title_fm,
        css=CSS,
        title_page=title_page,
        toc_page=toc_page,
        body=body_html,
        footer=footer,
        doc_id_label=doc_id_label,
    )
    return html


# Curated short subtitles (fallback when frontmatter `description` is too long
# for a title page; the script will prefer the FM description if set).
SUBTITLES = {
    "00": "Foundations: DiD, stratified sampling, power analysis, ANOVA / SMD / parallel-trends — the toolkit every later doc assumes.",
    "01": "The three legacy AOT systems — Email (user-level), Paid Social FB (Meta-handled), SEM (DMA-level) — push/pull/measure side-by-side.",
    "02": "The deepest doc — composite scoring, K-means-elbow stratification, 5,000-trial cell assignment, Latin-square scheduling, power-driven 5-DMA holdouts, and the Causal Lab package that ships it.",
    "03": "Time-based testing for broadcast TV — the 40–60% dark-period mechanic, exclusion / min-gap scheduling, and the regression-based measurement.",
    "04": "How AOT and MMM marry — inverse adstock, 50/50 weighted cost-per, response-curve fitting with predict_stability, AOP-aligned forecasting.",
}


# -----------------------------------------------------------------------------
# Render with Playwright -> PDF
# -----------------------------------------------------------------------------

async def html_to_pdf(html_path: Path, output_pdf: Path) -> None:
    """Load the HTML file via file:// so local _assets/ resolve, then print to PDF."""
    from playwright.async_api import async_playwright

    async with async_playwright() as p:
        browser = await p.chromium.launch()
        page = await browser.new_page()
        await page.goto(f"file://{html_path}", wait_until="networkidle")
        # Wait for KaTeX + Mermaid to finish rendering
        await page.wait_for_timeout(3000)
        await page.emulate_media(media="print")
        await page.pdf(
            path=str(output_pdf),
            format="A4",
            print_background=True,
            margin={"top": "0", "right": "0", "bottom": "0", "left": "0"},
            prefer_css_page_size=True,
        )
        await browser.close()


async def build_all() -> None:
    PDF_DIR.mkdir(parents=True, exist_ok=True)
    for fname, title in DOC_FILES:
        md_path = DOCS_DIR / fname
        if not md_path.exists():
            print(f"  SKIP (missing): {fname}", flush=True)
            continue
        pdf_path = PDF_DIR / (md_path.stem + ".pdf")
        print(f"  Building {pdf_path.name} ... ", end="", flush=True)
        try:
            html = render_html(md_path, title)
            html_path = PDF_DIR / (md_path.stem + ".html")
            html_path.write_text(html, encoding="utf-8")
            await html_to_pdf(html_path, pdf_path)
            size_kb = pdf_path.stat().st_size // 1024
            print(f"OK ({size_kb} KB)", flush=True)
        except Exception as e:
            print(f"FAILED: {e}", flush=True)
            raise


if __name__ == "__main__":
    print(f"Building PDFs into {PDF_DIR}", flush=True)
    asyncio.run(build_all())
    print("Done.", flush=True)
