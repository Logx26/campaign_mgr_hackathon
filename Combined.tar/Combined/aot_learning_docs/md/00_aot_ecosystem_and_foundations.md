---
title: AOT Ecosystem Overview & Causal-Inference Foundations
description: The single map of Zillow's Always-On Testing (AOT) program — what it is, where it sits next to MMM, the three testing levels (user / geo / dark-period), and the causal-inference + statistical-validation toolkit (DiD, stratified sampling, power analysis, Welch's ANOVA, Levene, SMD, Mood's median, ICC, parallel trends) that every downstream AOT doc assumes.
---

# 00 — Zillow AOT Ecosystem: The Single Map

> **What this doc is.** The single map of Zillow's Always-On Testing (AOT)
> program — the *experimentation* counterpart to the MMM library you already
> know. Read it first. After reading, you should be able to answer in an
> interview: *what AOT measures, what its three testing levels are, when each
> applies, how its output combines with MMM via the incrementality layer, and
> the causal-inference toolkit (DiD, stratified sampling, power analysis,
> Welch's ANOVA, Levene, SMD, Mood's median, ICC, parallel trends) the rest of
> the docs use without re-defining.*
>
> **What this doc is not.** A walk-through of the existing email / Meta / SEM
> pipelines (→ [Doc 01](01_existing_aot_systems.md)), a deep dive on the new
> geo-stratification design (→ [Doc 02](02_geo_stratification_design.md)),
> a TV dark-period explanation (→ [Doc 03](03_dark_period_tv.md)), or
> the incrementality + response-curve layer that fuses AOT with MMM
> (→ [Doc 04](04_incrementality_and_forecasting.md)). Almost no code —
> we describe what each component does and why.

---

## 1. Executive summary

Zillow runs **Always-On Testing (AOT)** as a continuous, channel-level
incrementality measurement program that produces an independent, experiment-
based estimate of "**cost per incremental KPI**" for selected paid-media
channels. The output of AOT is a daily / weekly stream of
`(channel, network, LOB, campaign_super, date) → cost_per_incremental_visit`
(and the analogous lines for FS submits, ZHL submits, rental visits, and MF
submits) that is structurally aligned to the MMM output grain so the two can
be fused in the **incrementality layer**.

The system is being rebuilt. The **existing** AOT covers only three channels —
**Paid Social (Meta/Facebook)**, **Email**, and **SEM** — each with its own
holdout granularity and DiD-flavored measurement. Two of the three legacy
pieces are also in flux:

- **Email**: migrating off Simon Data onto Hightouch. Hightouch handles
  holdout construction internally, so the team's role shifts from setup to
  measurement only. A **stratified-sampling backup** is being prepared in case
  a future vendor lacks in-platform holdouts.
- **Paid Social**: Meta handles everything (setup, test, measurement). The
  team only cleans and re-grains the cumulative ad-account-level results.
- **SEM**: DMA-level push/pull, ~4–8% of US population held out per LOB per
  month, measured via year-over-year DiD using a counterfactual.

The **new** AOT — the production track this library spends most of its time
on — generalizes geo-experiments and adds a time-based design for channels
that can't be geo-held-out:

- **Geo-stratification + Latin-square holdouts** (→ [Doc 02](02_geo_stratification_design.md)) —
  a packaged design (the **Causal Lab** Python package) that stratifies the
  ~210 DMAs into 6 strata via a composite KPI+econ+population score, balances
  them into cells through a 5,000-shuffle balance-scoring assigner, and picks
  **5 holdout DMAs per LOB per quarter** through a Latin-square rotation that
  caps cross-quarter overlap at 10%. Power analysis sets the 5-DMA floor.
- **Dark-period testing for TV** (→ [Doc 03](03_dark_period_tv.md)) —
  for Linear TV and Connected TV, where you can't geo-hold-out (the broadcast
  is national), the design reduces spend by **40–60%** during scheduled
  exclusion weeks and measures incremental KPI lift via linear regression.

The fusion step — **the incrementality layer**
(→ [Doc 04](04_incrementality_and_forecasting.md)) — applies per-channel
transformations (inverse adstock, percentile capping, missing-date imputation),
combines AOT and MMM cost-per via a **50/50 weighted average** for AOT-covered
channels (100% MMM elsewhere), and recalibrates the MMM response curves. The
re-fit curves feed the budget allocator and a forecasting layer that targets
the marketing AOP.

> **Interview angle — "Why does Zillow run AOT if it already has MMM?"** MMM
> is a *correlational* model fit on aggregate observational data: it gives you
> the best linear-in-priors estimate of channel coefficients given the
> contemporaneous mix, but those coefficients are only as identified as the
> historical variation in spend allows. **AOT is causal by construction**: by
> deliberately creating treatment / holdout asymmetry (a user is in the
> holdout, a DMA goes dark, a TV channel spends 50% less for two weeks), it
> generates a randomized contrast that identifies incrementality directly. The
> two methods disagree most where MMM is least identified — long-tail
> channels, channels whose spend tracks each other, and channels with
> persistent recent spend levels where MMM has no off-week to learn from.
> Zillow uses **AOT to recalibrate MMM** on those channels (see [MMM Doc 01
> Section 11.3](../learning_docs/md/01_mmm_methodology_primer.md#113-email-simon-data-recalibration)
> for the Email Simon Data example).

> **Interview angle — "Where does AOT sit in the wider stack?"** Three layers:
> - **MMM** ([MMM Doc 00](../learning_docs/md/00_mmm_ecosystem_overview.md))
>   measures *everything* on a bi-weekly cadence at DMA-week grain and produces
>   the **budget allocator's primary input** (response curves).
> - **AOT** (this library) measures *selected channels* causally via
>   randomized holdouts / dark periods, producing the **ground-truth cost-per**
>   for those channels.
> - **The incrementality layer**
>   (→ [Doc 04](04_incrementality_and_forecasting.md)) **fuses the two**
>   — weighted average of AOT cost-per and MMM cost-per, used to rebuild the
>   response curves used by the allocator.

---

## 2. What AOT is — definitions and scope

**Always-On Testing** at Zillow is the policy that **a randomized
incrementality test is running for every supported channel continuously**
(not as an ad-hoc once-a-quarter project). Each test produces, at minimum,
the following row per supported channel per cadence (daily for SEM, daily-
windowed for Paid Social and Email, weekly for the new geo / dark-period
tests):

| Field | Meaning |
|---|---|
| `date` | Observation date (or week-Monday for the new tests) |
| `channel`, `network`, `lob`, `core_campaign_super` | Joinable grain — must match the MMM taxonomy (see [MMM Doc 06](../learning_docs/md/06_fs_submits_taxonomy_track.md)) |
| `metric` | One of `visits`, `fs_submits`, `zhl_submits`, `rental_visits`, `mf_submits` |
| `incremental_<metric>` | Causally-attributed lift in that metric for that test window |
| `lift_pct` | The lift as a % of counterfactual or as a regression coefficient |
| `cost_per_incremental_<metric>` | Spend in window ÷ incremental KPI |
| `confidence` | Statistical-significance signal (p-value, t-statistic, or significance flag) |
| `attribution_window` | 1 / 3 / 5 day window (legacy) or test-period (new) |

The 5 KPIs are **the same 5 KPIs the MMM models**
(see [MMM Doc 00 Section 2](../learning_docs/md/00_mmm_ecosystem_overview.md#2-the-five-kpis)
and [MMM Doc 08](../learning_docs/md/08_other_kpis_comparative.md)) — Visits,
FS Submits, ZHL Submits, Rental Visits, MF Submits — so the joins back to MMM
are clean by construction.

> **A small but important clarification.** "Always-On" refers to *cadence*,
> not to literal continuous experimentation — most AOT designs still run in
> distinct **test periods** (3-month windows for legacy email, 1-month windows
> for legacy SEM, 1-quarter Latin-square cycles for the new geo design). The
> "always-on" promise is that *as soon as one period ends, the next one
> starts* — there is never a gap.

---

## 3. The three testing levels

This is the conceptual backbone of the new AOT framework (Jesmma's framing,
KT 2026-03-20). Every channel falls into exactly one of three buckets based on
how its delivery can be controlled.

### 3.1 User-level testing

**When it applies.** You can target individual users (you have a user ID, an
email, a device, or a logged-in session) and you can withhold the marketing
asset from a chosen subset.

**Where Zillow uses it.** **Email** (the original AOT channel — the holdout
is just a list of `user_id`s that the email platform excludes). Conceptually
also Paid Social, except Meta hides the user-level mechanics behind their own
black-box "Conversion Lift" — so Zillow only sees the aggregated output.

**Holdout granularity.** A user.

**The setup mechanic.**

1. Pick a target population (e.g., the ~24M users who received emails in the
   previous test period for the *Buyer* campaign super).
2. Sample some fraction (Zillow uses **4%**) as the holdout group — they get
   no promotional emails for the full test period (90 days currently;
   originally 30 days).
3. The remaining ~96% is the eligible *treatment pool*. Each day, a subset of
   them actually receives an email — daily treatment groups can overlap.

**The measurement mechanic.** Difference-in-differences on the metric values
of *treatment-pool users who received mail today* vs *holdout users* (see
Section 5.2 for the math).

**The rotation rule.** A user must not stay in the holdout for two consecutive
test periods, because being excluded from all promotional email for 6+ months
materially increases churn risk. So the new holdout is drawn from the
*previous test's treatment group*.

> **Why this matters for measurement.** Because the holdout is sampled *from
> the previous treatment group*, the two arms are not just "users who haven't
> recently been blocked" — they're users we *knowingly emailed last quarter*.
> That's the only baseline we can fairly compare against, and it makes the
> DiD interpretation cleaner: we're measuring the lift from *continuing* to
> email people, not from emailing them for the first time.

### 3.2 Geo-level testing

**When it applies.** Delivery can be geo-targeted (you can run an ad in DMA A
and not in DMA B). This is true for almost all non-broadcast paid media:
SEM, Programmatic Display, Affiliate, Connected-TV-when-bought-via-DSPs, etc.

**Where Zillow uses it.** **SEM** (legacy, monthly cadence) and the **new
geo-stratification design** (quarterly cadence, covering all geo-targetable
channels). See [Doc 02](02_geo_stratification_design.md).

**Holdout granularity.** A DMA (Nielsen Designated Market Area; there are
~210 of them and they're the same DMAs MMM uses, see
[MMM Doc 04](../learning_docs/md/04_data_lineage_and_schemas.md)).

**The legacy SEM setup mechanic** (full walkthrough in
[Doc 01 Section 5](01_existing_aot_systems.md#section-5)):

1. For each `(core_campaign_super, core_lob)` combination, pick 4–6 DMAs as
   holdout, with the constraint that the **combined population of those DMAs
   is ≥ 4%** (sometimes 8%) **of the US population**.
2. Cross-LOB constraint: a DMA cannot be holdout for two different LOBs in
   the same month (otherwise you can't attribute the lift to one LOB).
3. Cross-time constraint: a DMA cannot be holdout for two consecutive months
   for the same LOB (drastic churn risk).
4. Business overrides: the channel team can manually exclude high-revenue
   regions (e.g., New York, Texas).

**The new geo setup mechanic** (full walkthrough in
[Doc 02](02_geo_stratification_design.md)): stratify the 210
DMAs into 6 strata using a composite KPI+econ+population score, balance into
cells through a 5,000-iteration shuffle assigner, run a Latin-square rotation
to schedule which cell is "off" for which LOB across the quarter (≤10%
cross-quarter overlap), and pick **5 holdout DMAs per LOB per quarter** — one
from each of 5 strata for diversification.

**The measurement mechanic.** Legacy SEM uses year-over-year DiD with a
**population-normalized** counterfactual (Section 5.2). The new geo design
will use stratified DiD with regression-adjusted controls; in v1 it falls
back to simple linear regression like the dark-period design (Section 3.3).

### 3.3 Dark-period (time-based) testing

**When it applies.** Delivery is **broadcast** — Linear TV, Connected TV
direct-buys, broadcast Radio, OOH. You can't geo-target meaningfully (the
broadcast goes everywhere) and you obviously can't user-target (no IDs).

**Where Zillow uses it.** **Linear TV, Connected TV** — the channels that
otherwise have no causal measurement. See
[Doc 03](03_dark_period_tv.md).

**Holdout granularity.** Time — specifically, a **week**. The design schedules
"dark weeks" where one or more TV LOBs run at **40–60% reduced spend** (not
zero, because going fully dark for one week from a continuous broadcast spend
profile is detectable to the channel team and the agency). Other LOBs stay
live in that same week; the next dark week rotates which LOB is reduced.

**Constraints baked into the schedule.**

- **Exclusion weeks**: weeks like Black Friday, Cyber Monday, Christmas are
  always *live* — going dark in these windows damages the business beyond the
  measurement value.
- **Minimum gap weeks**: between two dark weeks for the same LOB, to let the
  treatment effect decay and avoid contaminating successive treatment
  observations.
- **Latin-square rotation**: across LOBs, ensure each LOB has been dark in
  roughly equal numbers of weeks across the test period, no two LOBs are dark
  in the same week (so each dark week identifies one LOB's effect), and the
  spacing between any pair of LOBs' dark weeks is roughly balanced.

**The measurement mechanic.** Simple linear regression of the weekly KPI
(visits, fs_submits, etc.) on dark indicators for each LOB, with control
variables for seasonality, economics, and time trend. The coefficient on a
LOB's dark indicator (with sign flipped) is the lift estimate. v1 uses OLS;
the roadmap is a hierarchical Bayesian time-series model.

> **Interview angle — "Why do you reduce TV spend by 40–60% instead of zeroing
> it?"** Three reasons. (1) Going to zero would be operationally visible to
> the agency and the channel team — they would flag it and likely refuse, or
> at least introduce confounders by reallocating elsewhere. (2) The lift you
> can detect with a partial reduction is still econometrically identifiable
> as long as your sample size (weeks) is large enough — power analysis trades
> off effect size against weeks-needed. (3) From a risk perspective, a partial
> reduction caps the worst-case revenue hit per test, which keeps the
> "always-on" cadence acceptable to the business.

### 3.4 When to use which level — decision rules

| Channel characteristic | Use this level |
|---|---|
| Per-user delivery control (email, push, in-app messages) | **User-level** |
| Geo-targeted delivery, not broadcast (SEM, Programmatic, Display, paid social aggregated, geo-CTV) | **Geo-level** |
| Broadcast / no delivery control (Linear TV, broadcast CTV, broadcast radio, national OOH) | **Dark-period** |
| Vendor-managed black-box (Meta's Conversion Lift, Google's geo-experiments) | Effectively **user-level** for Meta, **geo-level** for Google — but Zillow only re-grains the vendor output |

**Goal state**: package all three (user-level stratified sampling backup,
geo-stratification holdout selection, dark-period scheduler) into a single
Python package — **Causal Lab** — modeled after the **rapidmmm** package
([MMM Doc 02](../learning_docs/md/02_rapidmmm_library_internals.md)) so that
all three levels share configuration, logging, and validation primitives.
The Causal Lab structure is covered in [Doc 02 Section 14](02_geo_stratification_design.md#section-14)
and [Doc 03 Section 8](03_dark_period_tv.md#section-8).

---

## 4. The three phases of any AOT test

Independent of which testing level you use, every AOT test has three logical
phases. Confluence calls them **push** (setup) and **pull** (measurement);
internally Tharun's framing is the trio below. Knowing this helps you read
the codebase — folders like `holdout_setup`, `metrics`, and `measurement`
map onto these phases.

```
┌─────────────────────────┐      ┌─────────────────────────┐      ┌─────────────────────────┐
│   1. SETUP              │      │   2. EXECUTION          │      │   3. MEASUREMENT        │
│   "the push"            │      │   (out of our hands)    │      │   "the pull"            │
├─────────────────────────┤      ├─────────────────────────┤      ├─────────────────────────┤
│ Define audience /       │      │ Channel team / vendor / │      │ Pull KPI metrics for    │
│ holdout grain (user,    │ ───▶ │ ad-server / TV agency   │ ───▶ │ holdout vs treatment    │
│ DMA, week)              │      │ runs the actual media.  │      │ (or pre vs post).       │
│ Push the holdout list   │      │ Zillow does not run     │      │ Compute DiD or          │
│ to the activation       │      │ media; we run the data  │      │ regression. Significance│
│ platform (Simon Data,   │      │ science around it.      │      │ tests. Cost-per-        │
│ Hightouch, SQL-DMA      │      │                         │      │ incremental.            │
│ table, dark-period      │      │                         │      │ Re-grain to             │
│ schedule).              │      │                         │      │ MMM taxonomy.           │
└─────────────────────────┘      └─────────────────────────┘      └─────────────────────────┘
```

LatentView's role is **Phase 1 + Phase 3**. We don't trigger the emails, we
don't run the TV buy, we don't bid in SEM. We construct holdouts (Phase 1),
push them to a table or platform, wait, then pull KPI data (Phase 3) and
measure. The Hightouch migration shifts even Phase 1 for Email away from us —
which is why the team is preparing the stratified-sampling backup
(Section 5.4) for if-and-when the next platform doesn't support in-platform
holdouts.

---

## 5. Causal-inference foundations

This is the toolkit the rest of the library uses. Every subsequent doc
references these concepts; if you're rusty on any of them, this section is
the one to commit to memory.

### 5.1 The counterfactual — the one idea everything rests on

Causal inference in marketing is fundamentally the question: *what would have
happened if we had not advertised?* That unobservable quantity is the
**counterfactual**.

Formally, let $Y_i(1)$ be the KPI value for unit $i$ (a user, a DMA, a week)
*if treated* (saw the ad), and $Y_i(0)$ the value *if not treated*. The
individual treatment effect is

$$\tau_i = Y_i(1) - Y_i(0).$$

For any single $i$ we can observe only one of $Y_i(1)$ or $Y_i(0)$ — the
**fundamental problem of causal inference**. What we instead estimate is the
**Average Treatment Effect** (ATE):

$$\text{ATE} = \mathbb{E}[Y_i(1) - Y_i(0)] = \mathbb{E}[Y_i(1)] - \mathbb{E}[Y_i(0)].$$

The two halves on the right come from different groups: treatment-group units
give us $\mathbb{E}[Y_i(1)]$, holdout-group units give us $\mathbb{E}[Y_i(0)]$.
This identification works **only if** the two groups are otherwise
exchangeable — i.e., if treatment was assigned randomly *or* if we have made
them comparable through stratification / matching / regression adjustment.
Almost every method in this library is some way of either creating that
exchangeability (stratified sampling, geo-stratification) or repairing it
when it isn't perfect (DiD, parallel-trends checks, regression controls).

### 5.2 Difference-in-Differences (DiD) — the workhorse estimator

DiD is what all three legacy AOT systems (Email, Paid Social aggregated, SEM)
ultimately reduce to. The setup:

- A pre-period (before the test) and a post-period (during the test).
- A treatment group and a control / holdout group.
- We observe each group in both periods. That's four numbers.

The DiD estimator is

$$\widehat{\tau}_{\text{DiD}} = \big(\bar{Y}_{T, \text{post}} - \bar{Y}_{T, \text{pre}}\big) - \big(\bar{Y}_{C, \text{post}} - \bar{Y}_{C, \text{pre}}\big).$$

Read as: take the treatment group's pre-to-post change, take the control
group's pre-to-post change, and subtract. The control's change is the
"natural drift" — seasonality, macro trend, organic growth — that would have
happened to the treatment group anyway. Subtracting it isolates the **causal
contribution of treatment**.

**The identifying assumption** is *parallel trends*: in the *absence* of
treatment, the treatment group would have evolved from pre to post at the
same rate as the control group. If that's true, DiD is unbiased even when
treatment and control have different absolute levels. If it's false (e.g.,
the treatment DMAs are growing faster than control DMAs for reasons
*unrelated* to marketing), DiD is biased — which is why every AOT
methodology in this library runs an explicit *parallel-trends check* before
trusting the result (Section 6.6).

#### The worked example — SEM, year-over-year (KT 2026-03-16)

The legacy SEM AOT uses a slight variant of textbook DiD: instead of comparing
pre-period to post-period in the same year, it compares the **same month this
year vs last year** (because SEM's seasonality is strong and last-year-same-
month is a cleaner baseline than last-month-same-year). And it doesn't compute
the DiD directly; it computes a **counterfactual** for the holdout, then
takes a percentage lift. Algebraically the two are equivalent; the
counterfactual phrasing is just more interpretable.

Take a single LOB and one month:

| Group | Last year (LY) | This year (TY) | YoY growth |
|---|---|---|---|
| **Treatment DMAs** (received marketing both years) | 100 visits | 150 visits | **+50%** |
| **Holdout DMAs** (received marketing LY, **dark TY**) | 100 visits | 120 visits | +20% |

Step 1 — compute YoY growth in the treatment group:
$$g_{\text{treat}} = \frac{150 - 100}{100} = 0.50 \quad (\text{i.e., } +50\%).$$

Step 2 — apply that growth to the holdout's LY level. This is the
counterfactual visit count for the holdout group — *what they would have
gotten this year if they had still been receiving marketing*:
$$Y_{\text{holdout, counterfactual}} = 100 \times (1 + 0.50) = 150.$$

Step 3 — the observed holdout TY is 120. The lift attributable to marketing
is the gap:
$$\widehat{\text{incremental visits}} = 150 - 120 = 30.$$

Step 4 — express as a percentage of the counterfactual:
$$\widehat{\text{lift }\%} = \frac{Y_{\text{counterfactual}} - Y_{\text{actual}}}{Y_{\text{counterfactual}}} = \frac{150 - 120}{150} = 20\%.$$

> **Inline flag — a transcript slip in the source.** The KT 03-16 recording
> verbally calls this "around 30%." The arithmetic above is correct: the lift
> is **20%** of counterfactual (30 incremental visits out of 150). The "30"
> in the recording almost certainly refers to the **30 incremental visits**
> being conflated with "30 percent." Use 20% as the percentage; use 30 as the
> absolute incremental count. The cost-per is built from the absolute count
> (spend ÷ 30), so the downstream cost-per number is unaffected by the slip.

#### Why this *is* DiD, just phrased as a counterfactual

If you expand the textbook DiD form for the same numbers:

$$\widehat{\tau}_{\text{DiD}} = (150 - 100) - (120 - 100) = 50 - 20 = 30 \text{ incremental visits},$$

you get the same 30. The counterfactual phrasing $Y_{\text{counterfactual}} -
Y_{\text{actual}}$ rearranges to $(\bar{Y}_T^{\text{TY}}/\bar{Y}_T^{\text{LY}})
\cdot \bar{Y}_C^{\text{LY}} - \bar{Y}_C^{\text{TY}}$, which is DiD under
the *multiplicative* parallel-trends assumption (same growth rate, not same
absolute change). The multiplicative form is preferred for marketing
metrics because absolute differences scale with DMA size while *growth rates*
do not — which is also why the legacy SEM code **normalizes by DMA
population** before comparing, so two DMAs of very different sizes can be
averaged together meaningfully.

#### Population normalization (the SEM-specific twist)

Because the SEM holdout aggregates 4–6 DMAs with hugely different population
sizes (Boston vs Boise), the metrics are **divided by DMA population** before
DiD. Conceptually you can think of the comparison as *visits per capita*
rather than *visits*. This matters because if you average raw visit counts
across DMAs, the big DMAs dominate and small-DMA holdouts would look
mechanically smaller. Per-capita comparison removes that.

#### The attribution-window concept

A single day's KPI count is noisy. So for every test-day, the legacy systems
also store **3-day** and **5-day** rolling versions of the metric — the same
DiD calculation re-run with the window extended. (Originally these were
1 / 7 / 14 days; they were tightened to 1 / 3 / 5 to give finer cost-per-
day-granularity once Zillow stabilized.) The 3- and 5-day variants smooth
out daily noise without inflating false positives in the significance test.

### 5.3 Why random sampling is biased for holdouts

The legacy Email AOT picks a holdout by **random 4% of users**, and the legacy
SEM AOT initially generates DMA holdouts by **shuffling 210 DMAs**. Both are
random sampling and both have a problem: *a single random draw is rarely
representative on every dimension that matters*.

The mechanics are easy to state. Suppose your population has $K$ relevant
strata — high-engagement users vs low-engagement, large DMAs vs small DMAs,
buyer-intent users vs rental-intent users — and the strata have wildly
different conversion rates. If you take a *simple random sample* of 4%, the
fraction of each stratum in your sample is a binomial random variable with
expectation equal to the population fraction. The expectation is fine —
random sampling is **unbiased on average over many draws**. The problem is
the **variance**: any one draw can over-represent some strata and under-
represent others. In a 4% sample, a stratum that's 5% of the population
might end up at 2% or 9% of your sample, and your measured "ATE" inherits
all that compositional noise.

This isn't even Zillow's worst case. Tharun's KT framing ("if you take 4% of
India randomly, you could easily get all of north India") is the *correlated-
random-sampling* version of the problem: if the sampling has any spatial
clustering (e.g., the random seed happens to pick recent users in one region
disproportionately), the variance is even larger than i.i.d. binomial.

**The fix is stratification.** And conceptually the fix is even more general —
*the fewer dimensions you leave to chance, the lower the variance of your
estimator*. Stratification is one way; matching, regression adjustment, and
the geo-design's composite-score-based balancing are others.

### 5.4 Stratified sampling — the rescue

Stratified sampling splits the population into $K$ disjoint **strata** —
groups where within-group variance on the relevant dimension is small and
between-group variance is large — then takes a fixed fraction from each
stratum. The total sample is the union.

For a population of $N$ units, with stratum sizes $N_1, \dots, N_K$ and a
target sampling rate $f$ (Zillow's 4% or 8%), you sample $f \cdot N_k$ units
from each stratum. Your total is exactly $f \cdot N$, but you have a
guarantee that each stratum is represented at its true population fraction —
the binomial variance from Section 5.3 is collapsed away on the
*stratification dimension*.

**The variance argument.** Let the population mean be $\mu$ and within-
stratum variance be $\sigma_k^2$. The variance of the stratified sample mean
is

$$\text{Var}(\bar{Y}_{\text{strat}}) = \sum_{k=1}^{K} \left(\frac{N_k}{N}\right)^2 \frac{\sigma_k^2}{n_k}$$

where $n_k$ is the sample size from stratum $k$. Compare to the SRS
(simple random sample) variance:

$$\text{Var}(\bar{Y}_{\text{SRS}}) = \frac{\sigma^2}{n}.$$

By the **law of total variance**, $\sigma^2 = \mathbb{E}_k[\sigma_k^2] +
\text{Var}_k(\mu_k)$. The between-strata variance term is what stratified
sampling *eliminates* from the sampling-mean variance — exactly the gain you
hope for when your strata genuinely differ in mean. This is the formal reason
the Zillow team picked stratification, and it's why the **Variance
Reduction Factor** (VRF, defined in Section 6.7) is the metric they monitor
in the new geo design — a VRF close to 1 means stratification is fully
absorbing the between-strata variance, and your DiD estimator's standard
error shrinks accordingly.

**How Zillow stratifies — two flavors, same idea:**

- **Email backup plan (Tharun, KT 03-17)**: for each user, compute past-28-day
  and past-84-day engagement metrics (visits, FS submits, ZHL submits, rental
  visits), build a composite *engagement score* (weighted toward
  buyer-metrics for the Buyer campaign super, weighted toward rental-metrics
  for the Rental campaign super), and run `NTILE(20) OVER (ORDER BY score)`
  to split users into 20 strata. Sample 4% (or 8%) from each.
- **New geo design (Jesmma, KT 03-20)**: for each DMA, compute a composite
  KPI+econ+population score, split into **6 strata** by quantile (the
  count of strata is set by the K-means elbow point, Section 5.5 of
  [Doc 02](02_geo_stratification_design.md#section-5)), and use
  that as the input to cell assignment.

### 5.5 Power analysis — why 5 DMAs per LOB

Once you have a sampling scheme, the next question is **how big does the
holdout need to be**. The new geo design had an initial proposal of 6 cells
× ~28 DMAs/cell ≈ 168 DMAs, which the client correctly rejected as
operationally absurd — holding out that many DMAs would crater revenue. So
Jesmma ran a **power analysis** that came back with **5 DMAs per LOB**.

A power analysis answers: *given an effect size I want to detect and a
significance threshold and a desired statistical power, how many units do I
need?* The four moving parts:

| Quantity | Symbol | What it controls |
|---|---|---|
| Effect size (the lift I want to detect) | $\delta$ or Cohen's $d$ | Smaller minimum-detectable effects need more units |
| Significance level (false-positive rate) | $\alpha$ (usually 0.05) | Lower $\alpha$ needs more units |
| Power (1 − false-negative rate) | $1 - \beta$ (usually 0.80) | Higher power needs more units |
| Per-unit variance | $\sigma^2$ | Noisier units need more units |

For a two-sample t-test, the required sample size per arm is approximately

$$n \approx \frac{2 \sigma^2 (z_{1-\alpha/2} + z_{1-\beta})^2}{\delta^2}.$$

For $\alpha = 0.05$ two-sided and $1 - \beta = 0.80$, the $(z + z)^2$ term is
$(1.96 + 0.84)^2 \approx 7.84$. So $n \approx 15.7 \cdot \sigma^2 / \delta^2$.

**For Zillow's geo design**, $\sigma^2$ is the cross-DMA variance of
visits-per-capita (or per the composite-score-residualized metric) and
$\delta$ is the lift the business cares about detecting — somewhere in the
~5–15% range for medium channels. Plugging realistic numbers in produces a
floor around **5 DMAs per arm per LOB**, which is what the team adopted.
This 5 is *per cell* — and because there are several cells acting as control
in a given test window, the *effective* control sample size in the DiD
estimator is much higher than 5.

> **Inline flag — an assumption I'm making.** The KT notes report "power
> analysis came back with 5 DMAs per LOB" but do not state the exact
> effect-size and variance inputs Jesmma plugged in. The 5–15% lift band
> above is a reasonable industry default for paid-media incrementality (it
> matches the typical lift-test minimum-detectable-effect targets) — confirm
> with Jesmma before quoting the specific MDE in an interview.

### 5.6 Where these foundations show up later in the library

| Concept | Where it's used |
|---|---|
| Counterfactual (5.1) | Legacy SEM measurement ([Doc 01 Section 5](01_existing_aot_systems.md#section-5)); new geo holdout-vs-control validation ([Doc 02 Section 11](02_geo_stratification_design.md#section-11)) |
| DiD (5.2) | All three legacy systems ([Doc 01](01_existing_aot_systems.md)); the new geo design's holdout-vs-control balance step ([Doc 02 Section 11](02_geo_stratification_design.md#section-11)) |
| Random vs stratified sampling (5.3, 5.4) | Email backup plan ([Doc 01 Section 3.10](01_existing_aot_systems.md#section-3)); the geo-stratification core ([Doc 02 Sections 4–6](02_geo_stratification_design.md#section-4)) |
| Power analysis (5.5) | The 5-DMA decision ([Doc 02 Section 9](02_geo_stratification_design.md#section-9)); dark-period min-gap derivation ([Doc 03 Section 3](03_dark_period_tv.md#section-3)) |

---

## 6. The statistical-validation toolkit

The new AOT design — both geo and dark-period — applies a battery of
statistical checks at every step (stratum validity, cell-balance validity,
holdout-vs-control comparability). They're standard tests but applied for
specific purposes; this section is the cheat sheet so the per-test
references in Docs 02 and 03 land cleanly. Each subsection: what the test
does, the formula, what you're hoping for, and where it appears in AOT.

### 6.1 ANOVA (and why we use Welch's variant)

**One-way ANOVA** (Analysis of Variance) tests whether the means of $k \geq 2$
groups are equal:

$$H_0: \mu_1 = \mu_2 = \dots = \mu_k \quad \text{vs} \quad H_1: \text{at least one differs}.$$

It compares the **between-group variance** (how spread out the group means
are around the overall mean) to the **within-group variance** (how spread out
observations are around their own group's mean):

$$F = \frac{\text{between-group MS}}{\text{within-group MS}} = \frac{\sum_k n_k (\bar{Y}_k - \bar{Y})^2 / (k - 1)}{\sum_k \sum_i (Y_{ki} - \bar{Y}_k)^2 / (N - k)}.$$

A high $F$ means the group means are spread far apart relative to within-
group noise — reject $H_0$.

**Why "Welch's" specifically.** Classical ANOVA assumes the groups all have
the **same variance** (homoscedasticity). DMAs do not — NYC's visit-count
variance is many times Boise's because the levels are so different. Welch's
ANOVA relaxes the equal-variance assumption by weighting each group by its
inverse variance and adjusting the degrees of freedom (the
Welch–Satterthwaite correction). The formula is messier but the
interpretation of $F$ and its $p$-value is the same.

**Two opposite uses in AOT:**

1. **At stratification time (geo design, Doc 02 Section 5)**: we *want* ANOVA
   to **reject** $H_0$. The strata exist *because* their composite-score
   means differ — if ANOVA can't reject equality of means, the strata aren't
   doing their job and we should re-stratify.
2. **After cell assignment (Doc 02 Section 6)**: we *want* ANOVA to **fail to
   reject** $H_0$ — i.e., a high $p$-value (>0.05, ideally close to 1). The
   cells are supposed to be balanced replicas of the full distribution, so
   their means should be statistically indistinguishable.

This sign flip is a frequent gotcha; the validation engine logs both
expectations explicitly to avoid confusion.

> **Inline flag — formula source.** The Welch-W formula in the synthesized
> `Overview of 24 and 23rd KT.txt` is transcription-mangled. The
> Welch–Satterthwaite ANOVA test statistic, in standard form, is
> $W = \frac{\sum_k w_k (\bar{Y}_k - \tilde{Y})^2 / (k - 1)}{1 + \frac{2(k-2)}{k^2 - 1} \sum_k \frac{1}{n_k - 1}\left(1 - \frac{w_k}{w}\right)^2}$,
> where $w_k = n_k / s_k^2$ and $\tilde{Y} = \sum_k w_k \bar{Y}_k / \sum_k w_k$.
> The codebase calls `scipy.stats` for this — we don't reimplement.

### 6.2 Levene's test — checking equal variance

Welch's ANOVA handles unequal variance, but the team also runs
**Levene's test** as a direct check of *whether* variances are equal —
useful both as a diagnostic and for choosing between Welch's and classical
ANOVA. Levene's null hypothesis:

$$H_0: \sigma_1^2 = \sigma_2^2 = \dots = \sigma_k^2.$$

The procedure transforms each observation to its **absolute deviation from
the group median** (Levene originally used the mean; the median-based
**Brown–Forsythe variant** is more robust and is what `scipy.stats.levene`
uses by default) and then runs a one-way ANOVA on those deviations. If the
groups have similar variability, the deviation means are similar.

**In AOT**, Levene is applied at the same two stages as ANOVA — at
stratification (we don't actually require equal variance across strata; we
just want to *know*) and after cell assignment (we *do* want equal variance
across cells, so Levene should *fail to reject*). A pass = high $p$-value =
no evidence of unequal variance.

### 6.3 Standardized Mean Difference (SMD) — the headline balance metric

Pure significance tests aren't great for balance checking because they
*depend on sample size* — a tiny mean difference can become "statistically
significant" with enough observations, and a huge one can fail to reach
significance with too few. So the geo design's primary balance metric is
**SMD**, also known as **Cohen's $d$** when applied to two groups:

$$\text{SMD} = \frac{\bar{Y}_{\text{holdout}} - \bar{Y}_{\text{control}}}{\sqrt{\frac{\sigma_{\text{holdout}}^2 + \sigma_{\text{control}}^2}{2}}}.$$

It is the **mean difference standardized by the pooled standard deviation** —
a unit-free effect size. Conventions:

| |SMD| | Interpretation (Cohen) |
|---|---|
| < 0.1 | **Negligible** — groups are well balanced |
| 0.1 – 0.2 | Small but worth noting |
| 0.2 – 0.5 | Moderate imbalance — investigate |
| > 0.5 | Large — re-balance |

The new geo design treats **|SMD| < 0.1 across all KPIs and economic
covariates** as the balance pass condition. SMD is checked both between
cells (after cell assignment) and between holdout DMAs and control DMAs
(after the final 5-DMA pick).

### 6.4 Mood's median test — robust between-group comparison

ANOVA and Levene's both lean on the data being approximately normal (or at
least non-heavy-tailed). DMA-level KPI distributions are heavily skewed —
big DMAs dominate the right tail and small DMAs cluster near zero. **Mood's
median test** is the non-parametric analog: it tests whether $k$ groups have
the same **population median**.

The mechanics: pool all observations across groups, compute the overall
median $M$, then for each group count how many observations are above $M$
and how many are at-or-below. Build the $2 \times k$ contingency table and
run a chi-squared test:

$$\chi^2 = \sum_{i, j} \frac{(O_{ij} - E_{ij})^2}{E_{ij}}.$$

Low $p$ → group medians differ. **In AOT**, Mood's runs alongside SMD and
ANOVA as a robustness check — if the data is heavily skewed even after
log-transform, Mood's gives you a comparison that doesn't depend on
distributional assumptions. The team calls this the "surrender validation"
informally (the slip in KT 03-23 says "surrender validation" — that's a
transcription error for **median validation** via Mood's; the codebase has
it under `validation_engine.py`).

### 6.5 ICC — Intraclass Correlation Coefficient

The **Intraclass Correlation Coefficient** measures how much of the total
variance in a metric is *between groups* vs *within groups*. Range $[0, 1]$:

$$\text{ICC} = \frac{\sigma^2_{\text{between}}}{\sigma^2_{\text{between}} + \sigma^2_{\text{within}}}.$$

If ICC is high (say > 0.5), units within the same group are very similar to
each other relative to overall variance — strong clustering. If ICC is low
(say < 0.1), the group structure barely matters.

**Why AOT cares.** In the geo design, you want **high ICC after
stratification** (within-stratum DMAs are similar to each other on the
composite score — that's literally what stratification is supposed to
produce) and you want **low ICC between cells** (cells are supposed to be
exchangeable replicas, so the cell-membership label shouldn't explain
between-cell variance). ICC is essentially the reverse of VRF (Section 6.7)
and the two are reported together.

In statistical software, ICC is usually computed via a one-way random-
effects model:

$$Y_{ki} = \mu + \alpha_k + \epsilon_{ki}, \quad \alpha_k \sim \mathcal{N}(0, \tau^2), \quad \epsilon_{ki} \sim \mathcal{N}(0, \sigma^2),$$

with $\text{ICC} = \tau^2 / (\tau^2 + \sigma^2)$. The codebase uses
`pingouin.intraclass_corr` or the equivalent custom function.

### 6.6 Parallel-trends test — checking the DiD assumption

DiD's identifying assumption (Section 5.2) is that, absent treatment, the
treatment and control groups would have moved in parallel. You can't test
this for the *post*-period (that's the unobservable counterfactual), but you
can test it for the *pre*-period: if the two groups had parallel trends
*before* the test, the assumption is at least plausible.

**The mechanic** (geo design and dark-period both use a variant):

1. Take the metric series for the holdout group and the control group over
   $T$ pre-test weeks.
2. Fit one of:
   - A linear regression with `metric ~ week + group + week:group`.
     The `week:group` coefficient is the *trend differential*. If it's
     significantly nonzero, parallel-trends is rejected.
   - Or, for the geo design's monthly-level visual check, a paired t-test on
     monthly differences.
3. Plot the two series and eyeball them — the visual check is in fact what
   ends up convincing the team most often.

**Pass condition**: the trend-differential coefficient's 95% CI includes 0
(or, looser, $p > 0.10$). Geo's `validation_engine` runs this at three
horizons: **daily, weekly, monthly** — the multi-horizon check guards
against a borderline pass at one resolution from being driven by aggregation
artifacts.

### 6.7 Coefficient of Variation (CV) and Variance Reduction Factor (VRF)

These are the **summary-balance metrics** the cell assignment loop
(Doc 02 Section 6) optimizes against.

**Coefficient of Variation** of a stratum or cell:

$$\text{CV}_k = \frac{\sigma_k}{\bar{Y}_k}.$$

Unit-free, scale-invariant measure of relative dispersion. Within a single
stratum, *low* CV means the stratum is internally homogeneous — which is
what stratification is for. The geo design checks that each stratum's CV is
below a configured threshold (e.g., 0.30); strata with high CV indicate the
stratification boundary was drawn in the wrong place.

**Variance Reduction Factor**:

$$\text{VRF} = 1 - \frac{\sigma^2_{\text{within-strata}}}{\sigma^2_{\text{total}}} = \frac{\sigma^2_{\text{between-strata}}}{\sigma^2_{\text{total}}}.$$

Range $[0, 1]$. VRF close to 1 means almost all variance is captured by the
stratum labels — the strata are doing maximal work. VRF close to 0 means the
strata are random — they explain no variance. The team's pass target is
**VRF > 0.6** (configurable), checked both at stratification and after cell
assignment.

You'll notice VRF is the same quantity as ICC under the one-way random-
effects model — the two are interchangeable. The geo codebase reports both
because different audiences are used to seeing different names.

### 6.8 Cohen's $d$ — same as SMD, different name

Cohen's $d$ is exactly SMD (Section 6.3) under a different name (and with a
slightly different pooled-variance denominator in some textbooks). When the
KT notes say "Cohen's $d$ tracking effect size," they mean SMD. The codebase
uses one or the other depending on whose function it borrows from; the
numbers are equivalent for our purposes.

### 6.9 The validation engine — what gets run when

`causallab/holdout_setup/validation_engine.py` runs all of the above on a
schedule keyed to the pipeline stage. Approximate order in the geo design:

| Stage | Tests run | Pass condition (geo design) |
|---|---|---|
| After stratification | ANOVA, Levene, CV per stratum, VRF | ANOVA $p$ < 0.05 (means *do* differ); CV < 0.30 per stratum; VRF > 0.6 |
| After cell assignment | ANOVA, Levene, SMD between cells, ICC, CV per cell, VRF, parallel-trends (3 horizons) | ANOVA $p$ > 0.05 (means *don't* differ); Levene $p$ > 0.05; \|SMD\| < 0.1; ICC low between cells; parallel-trends pass at all 3 horizons |
| After 5-DMA holdout pick | SMD holdout-vs-control, Mood's median, parallel-trends | \|SMD\| < 0.1; Mood's $p$ > 0.05; parallel-trends pass |

The full per-test reading is in
[Doc 02 Sections 5–7](02_geo_stratification_design.md#section-5).

---

## 7. AOT × MMM — how the two systems combine

This section is the bridge between this library and the MMM library. The
short version: **MMM is the production budget allocator. AOT is the
calibration ground truth on selected channels.** The incrementality layer
welds them together by recomputing the cost-per for AOT-covered channels as a
50/50 weighted average and feeding that back into the response curves.

### 7.1 Why combine? Because neither is right alone.

**MMM weaknesses** (where AOT helps):
- Many channels' spend levels are *too stable* for MMM to identify their
  coefficients well — there is no off-week to learn from. AOT *creates* the
  off-week.
- MMM's hierarchical prior pools coefficients across DMAs, which is useful
  for stability but can mask channel-specific surprises. AOT's per-channel
  test catches those.
- MMM doesn't handle structural breaks well within a training window. AOT's
  short test cadence (~3 months) is more responsive.

**AOT weaknesses** (where MMM helps):
- AOT covers only 3 (legacy) → ~6+ (target) channels. MMM covers ~25.
- AOT's holdout creates real revenue cost — you can't scale it to every
  channel, every week.
- AOT measures total channel effect but not the response curve's shape (top,
  bottom, slope, saturation). MMM owns curve fitting.

The compromise: AOT pins the *level* of cost-per for covered channels; MMM
provides the *shape* of the response curve. Together they re-fit the curve
calibrated to AOT's level.

### 7.2 The 50/50 weighting rule

For each AOT-covered channel and each KPI, the legacy weighting is:

$$\text{cost\_per}_{\text{final}} = 0.5 \cdot \text{cost\_per}_{\text{AOT}} + 0.5 \cdot \text{cost\_per}_{\text{MMM}}.$$

For all other channels:

$$\text{cost\_per}_{\text{final}} = 1.0 \cdot \text{cost\_per}_{\text{MMM}}.$$

> **Inline flag — the 50/50 weighting.** This is what Tharun called out in
> KT 03-16 ("I guess it's 50/50") but he was not 100% certain on the exact
> split. The codebase has the per-channel weight pulled from a config file,
> so the actual number could be different (e.g., 40/60 or 60/40 for some
> channels). Confirm against the production `config.yaml` before quoting a
> specific weight to a stakeholder — but the *concept* of a weighted average
> between AOT cost-per and MMM cost-per is firm.

**Why a weighted average and not just AOT?** Because AOT, despite being
causal, is noisy at the level of a single test period — 5 DMAs per LOB or a
handful of dark weeks is a small sample. MMM is correlational but is fit on
~104 weeks of data; its variance is much lower. The weighted average trades
some causal purity for variance reduction. Over time, as AOT accumulates
more test periods, the AOT weight can be increased (and the codebase
supports a per-channel weight that defaults to 0.5 but can be tuned).

### 7.3 The incrementality layer — the production fusion path

The incrementality layer is a downstream package (separate from `rapidmmm`)
that runs **after** each MMM job and consumes both MMM gold outputs and the
AOT tables. Sucharitha walks through it in KT 2026-04-01 / 04-02; full
detail in [Doc 04](04_incrementality_and_forecasting.md). The high-
level flow:

```
┌──────────────────┐       ┌─────────────────────────┐
│  AOT gold outputs│       │   MMM gold outputs       │
│  (per-channel    │       │  (mmm_response_curves_   │
│   cost-per,      │       │   overall_level,         │
│   1 year window) │       │   mmm_model_combined_    │
│                  │       │   output_overall_level)  │
└────────┬─────────┘       └──────────┬──────────────┘
         │ inverse adstock,           │
         │ percentile capping,        │
         │ missing-date imputation,   │
         │ outlier flagging           │
         ▼                            ▼
    ┌──────────────────────────────────────┐
    │  Weighted combination                │
    │  cp_final = w * cp_AOT + (1-w) * cp_MMM
    │  (50/50 for AOT-covered channels,    │
    │   100% MMM otherwise)                │
    └────────────────┬─────────────────────┘
                     │
                     ▼
    ┌──────────────────────────────────────┐
    │  Refit response curves with the      │
    │  calibrated cost-per as a fixed point.│
    │  Stability check (predict_stability).│
    │  Scale factor + bias correction.     │
    └────────────────┬─────────────────────┘
                     │
                     ▼
    ┌──────────────────────────────────────┐
    │  Forecasting layer: project          │
    │  cost-per-submit for AOP horizons.   │
    │  Merge with budget plan.             │
    └──────────────────────────────────────┘
```

Two notable subtleties:

- **Inverse adstock** before combination — AOT cost-per is measured on
  *delivered impressions* and reflects the carryover effect over the test
  window. MMM's coefficients are on *adstocked* impressions. So before
  combining, the AOT cost-per is divided by the adstock decay factor to
  bring it to the same effective-impressions space as MMM. The adstock
  parameters used here are the same ones from MMM's feature engineering —
  see [MMM Doc 02](../learning_docs/md/02_rapidmmm_library_internals.md)
  Section 3 for the math.
- **Brand-edition temp notebook** — new brand-core campaigns that started
  spending in 2026 have too few weeks for either MMM or AOT to fit, so the
  team built a one-off TVPA-flavored notebook that attributes 5% of
  baseline Visits to those channels as a placeholder. This is a transitional
  hack and will be folded back into the main pipeline when data accumulates;
  full description in
  [Doc 04 Section 6](04_incrementality_and_forecasting.md#section-6).

### 7.4 The symmetric MMM-side hook — Email Simon Data recalibration

The MMM library has its own AOT-integration touchpoint. Specifically,
[MMM Doc 05 NB2's recalibration step](../learning_docs/md/05_fs_submits_overall_model_track.md)
recomputes Email's elasticity using the AOT-measured rate directly, rather
than trusting MMM's posterior — Email is one of the channels where MMM is
chronically wrong, and the AOT measurement is treated as the source of
truth. The full math for that recalibration is in
[MMM Doc 01 Section 11.3](../learning_docs/md/01_mmm_methodology_primer.md#113-email-simon-data-recalibration).

That is the *only* point where AOT data flows *into* the MMM training pipeline
directly. Everywhere else, the dependency goes the other way (MMM → AOT
fusion → curves).

> **Interview angle — "What's the difference between MMM and AOT?"** MMM is
> a model. AOT is an experiment. MMM produces an estimate for every channel
> from one bi-weekly run on the entire mix; AOT produces a causal measurement
> for one or a few channels per test period. MMM is fast and broad and
> low-cost; AOT is slow and narrow and high-cost (you forgo revenue in the
> holdout). They're complements, and Zillow operates them together — MMM for
> coverage, AOT for ground-truth calibration on the channels that matter
> most.

---

## 8. The Causal Lab package — production home of the new AOT

The new geo-stratification design and the new dark-period TV design are
packaged into a Python package named **Causal Lab** (similar in spirit to
how `rapidmmm` packages the MMM primitives — see
[MMM Doc 02](../learning_docs/md/02_rapidmmm_library_internals.md)). The
package is still in development; the snapshot below reflects the structure
as of KT 2026-03-23.

```
causallab/
├── pyproject.toml           # poetry build
├── Dockerfile               # for Databricks runtime parity
├── causallab/
│   ├── __init__.py
│   ├── config.py            # YAML loader for KPI list, weights, date ranges
│   ├── logger.py            # structured logger; replaces print in packaged code
│   ├── metrics/             # KPI pull helpers (SQL → DataFrame)
│   ├── holdout_setup/
│   │   ├── assignment.py    # composite-score, stratification, cell assignment,
│   │   │                    # holdout selection — end-to-end DMA certification
│   │   ├── latin_square.py  # Latin-square matrix construction + overlap check
│   │   ├── dark_period.py   # time-based dark-week scheduling for TV (→ Doc 03)
│   │   └── validation_engine.py # all the tests from Section 6
│   └── measurement/         # WIP — DiD / regression-based measurement
└── notebooks/
    └── geo_holdout_tactic.ipynb  # the canonical 110-cell walkthrough
                                  # (Sections 1–7: Load Config → Data Prep →
                                  #  Distribution Analysis → Composite Scoring
                                  #  → Stratification → Cell Assignment →
                                  #  Holdout Selection → Final Matrix Write)
```

**Three things to know about how Causal Lab is engineered:**

- **Config-driven**. The KPI list, the composite-score weights (70/25/5
  defaults), the number of strata, the number of holdout DMAs per LOB, the
  exclusion list, and the dark-period parameters all live in YAML. The
  modeling code never sees a hardcoded number.
- **Logger over print**. Once code is in a package, you can't `print` inside
  a Databricks notebook cell and see the output the same way. Every module
  uses a configured logger that routes to MLflow and to stderr.
- **SQL stays as SQL**. Tharun's design rule (KT 03-24): the metric-pull
  functions return DataFrames built from SQL strings — they do not embed
  Spark or pandas read paths. This keeps the data-access boundary explicit
  and lets the same code run in dev, stage, and prod with only the catalog
  swap.

The Causal Lab walkthrough — module by module, function by function — is in
[Doc 02 Section 14](02_geo_stratification_design.md#section-14)
(geo) and [Doc 03 Section 8](03_dark_period_tv.md#section-8) (dark).

---

## 9. Data layers in AOT — bronze / silver / transient / gold

The legacy AOT systems (Email, Paid Social, SEM) follow a four-layer Delta
table pattern, mirrored from the broader Zillow analytics architecture:

| Layer | Purpose | Examples (from the Confluence pages) |
|---|---|---|
| **Bronze** | Raw vendor or system pulls — Facebook's cumulative ad-account-level table, Simon Data's send logs, the SEM session table, the metric library | `fb_ads_results_part`, Simon Data sends raw, `marketing_metric_library` |
| **Silver** | Cleaned, joined to the campaign-super / LOB mapping, gapped-filled. The cumulative-to-daily SQL for Facebook lives here. | Per-channel silver tables (one per channel) |
| **Transient** | Intermediate calculation steps — the year-over-year flagged version, the population-normalized version, the attribution-window aggregation. Not persisted long-term. | Per-channel transient temp tables (one per stage of measurement; ~20–25 per channel) |
| **Gold** | The final output table, structured to match MMM's grain: `date × channel × network × LOB × core_campaign_super × metric × attribution_window`. Read by the incrementality layer. | `aot_email_gold`, `aot_fb_gold`, `aot_sem_gold` (names vary; see Doc 01) |

The new geo + dark-period AOT will follow the same shape, though the
intermediate steps are different (stratification → cell assignment →
holdout selection → measurement, rather than raw → daily → DiD).

Full table-by-table inventory with column names is in the per-channel
table-architecture subsections of [Doc 01 Sections 3, 4, and 5](01_existing_aot_systems.md#section-3)
(Email, Facebook, SEM respectively).

---

## 10. The 5-doc reading roadmap

Read in order; each doc builds on the previous one.

| Doc | Title | Source materials it draws on | Why now |
|---|---|---|---|
| **00** | AOT Ecosystem Overview & Causal-Inference Foundations | KT 03-16 (DiD example), KT 03-17 (Hightouch + stratified backup), KT 03-20 (3 levels), intro framing of `Overview of 24 and 23rd KT.txt` | You're here |
| **01** | Existing AOT Systems — Email, Paid Social Meta, SEM | All 6 Confluence PDFs (Email Overview + Architecture, FB Overview + Architecture, SEM Overview + Architecture); KT 03-16 (SEM DMA holdout + counterfactual); KT 03-17 (paid-social, Simon→Hightouch); KT 03-23 (Hightouch 50% migration status) | Once causal-inference foundations are in hand, see how the legacy systems implement them |
| **02** | NEW Geo Stratification & Holdout Design | KT 03-20 (Jesmma's canonical walkthrough), KT 03-23 (Tharun's Causal Lab code tour); `geo_holdout_tactic.ipynb` Sections 1–7 + every validation sub-block; `Overview of 24 and 23rd KT.txt` formulas (flagged where transcription-mangled) | The heart of the new system — six-strata composite-score design, Latin square, power analysis, validation engine |
| **03** | Dark-Period Testing for TV | KT 03-24 (canonical: 40–60% spend reduction, exclusion weeks, regression measurement); KT 03-23 (Latin-square mentions); `Overview of 24 and 23rd KT.txt` Latin-square math (textbook fallback where mangled) | The time-based generalization for broadcast channels |
| **04** | Incrementality Layer + Response Curves + Forecasting (AOT × MMM) | KT 04-01 (incrementality architecture, per-channel transforms, inverse adstock, brand-edition notebook); KT 04-02 (response-curve build, `predict_stability`, scale factor + bias, AOP merge); MMM Docs 01, 02, 07 for the curve-fitting symmetry | How AOT lands back in MMM and ultimately in budget decisions |

---

## 11. Companion-doc index — within and outside the library

**Within this library** (AOT):

- [01_existing_aot_systems.md](01_existing_aot_systems.md) — Email, Paid Social Meta, SEM walkthroughs
- [02_geo_stratification_design.md](02_geo_stratification_design.md) — Jesmma's new geo design + Causal Lab walkthrough
- [03_dark_period_tv.md](03_dark_period_tv.md) — TV dark-period scheduling and measurement
- [04_incrementality_and_forecasting.md](04_incrementality_and_forecasting.md) — AOT × MMM fusion, response-curve recalibration, AOP forecast

**Across to the MMM library** (frequently cross-referenced):

- [MMM Doc 00 — Ecosystem Overview](../learning_docs/md/00_mmm_ecosystem_overview.md) — the bigger picture; AOT sits next to it
- [MMM Doc 01 — Methodology Primer](../learning_docs/md/01_mmm_methodology_primer.md) — adstock, Hill, Bayesian hierarchy. Section 11.3 is the AOT recalibration math.
- [MMM Doc 02 — rapidmmm Library Internals](../learning_docs/md/02_rapidmmm_library_internals.md) — adstock & saturation math the incrementality layer reuses
- [MMM Doc 04 — Data Lineage and Schemas](../learning_docs/md/04_data_lineage_and_schemas.md) — DMA-level data sources, region mapping, calendar
- [MMM Doc 05 — FS Submits Overall Model Track](../learning_docs/md/05_fs_submits_overall_model_track.md) — NB2's AOT recalibration step
- [MMM Doc 06 — FS Submits Taxonomy Track](../learning_docs/md/06_fs_submits_taxonomy_track.md) — the channel × network × LOB × campaign_super grain AOT outputs must match
- [MMM Doc 07 — Response Curves and Stability](../learning_docs/md/07_fs_submits_response_curves_and_stability.md) — the curve-fitting machinery AOT's layer reuses
- [MMM Doc 08 — Other KPIs Comparative](../learning_docs/md/08_other_kpis_comparative.md) — the same 5 KPIs AOT measures
- [MMM Doc 09 — Operations and Interview Capstone](../learning_docs/md/09_operations_and_interview_capstone.md) — DAB deployment patterns Causal Lab is being modeled after

---

## 12. Glossary refresher

| Term | Definition |
|---|---|
| **AOT** | Always-On Testing — Zillow's continuous experimentation program; produces causal cost-per measurements for selected channels |
| **DMA** | Designated Market Area — Nielsen US TV market, ~210 of them; the geo-holdout grain |
| **LOB** | Line of Business — PA, Rentals, ZHL, Seller, etc. (see [MMM Doc 00 glossary](../learning_docs/md/00_mmm_ecosystem_overview.md)) |
| **Campaign super** | Marketing-campaign category — Buyer, Brand, Rental, Agent, Elevate, NonMarketing |
| **Holdout** | The group withheld from receiving the treatment — users not emailed, DMAs without ads, weeks with TV spend reduced |
| **Treatment** | The group that receives the treatment — users emailed, DMAs with ads, weeks with normal TV spend |
| **DiD** | Difference-in-Differences — the canonical causal estimator that subtracts the control's pre-to-post change from the treatment's, isolating the treatment effect under the parallel-trends assumption |
| **Counterfactual** | What the KPI value *would have been* in the holdout group if it had received treatment; estimated by applying the treatment group's growth rate to the holdout's pre-period level |
| **Lift / Incremental** | The causal increase in the KPI attributable to the treatment — absolute (incremental visits) or percentage (lift %) |
| **Attribution window** | The number of days a given test-day's data is rolled up over (1 / 3 / 5 in legacy SEM/Email AOT) |
| **Stratified sampling** | Splitting the population into homogeneous strata, then sampling a fixed fraction from each — reduces variance vs simple random sampling |
| **Power analysis** | The calculation that determines the minimum sample size needed to detect a given effect size at a chosen significance level and power |
| **Welch's ANOVA** | ANOVA variant that does not assume equal variance across groups; uses Welch–Satterthwaite-adjusted degrees of freedom |
| **Levene's test** | Test for whether $k$ groups have equal variance |
| **SMD / Cohen's $d$** | Standardized Mean Difference — mean difference standardized by pooled SD; the headline balance metric (target \|SMD\| < 0.1) |
| **Mood's median test** | Non-parametric test for whether $k$ groups share a common population median; robust to skew |
| **ICC** | Intraclass Correlation Coefficient — fraction of total variance that is between-group; high within-stratum ICC = strata are doing their job |
| **Parallel-trends test** | Pre-period check that treatment and control had the same trend; necessary for DiD's identifying assumption to be plausible |
| **CV** | Coefficient of Variation — $\sigma / \mu$; unit-free dispersion measure |
| **VRF** | Variance Reduction Factor — fraction of total variance explained by stratum labels; target > 0.6 |
| **Latin square** | An $n \times n$ arrangement where each row and column contains each of $n$ symbols exactly once; used here to schedule LOB-week dark-period rotations such that no two LOBs share a dark week and overlap with the prior quarter is bounded |
| **Causal Lab** | The new in-house Python package that packages the geo-stratification + Latin-square + dark-period designs, modeled after `rapidmmm` |
| **Incrementality layer** | The post-MMM, post-AOT fusion step that combines the two cost-per estimates and recalibrates the response curves |
| **Inverse adstock** | The de-carryover transform that converts an AOT-measured cost-per on raw impressions back to the adstocked-impression space MMM operates in |

> **Common interview questions you should be able to answer cold after this
> doc:**
> 1. *"Why does Zillow run AOT alongside MMM?"* — Section 1, Section 7.1.
> 2. *"Explain DiD and the counterfactual in one breath."* — Section 5.1, 5.2,
>    with the 100→150 vs 100→120 worked example.
> 3. *"What's wrong with picking a holdout by random sampling?"* — Section 5.3:
>    variance of any single draw on stratum-membership; the "all of North
>    India" analogy.
> 4. *"Why 5 DMAs per LOB? Where does that number come from?"* — Section 5.5
>    power analysis logic.
> 5. *"What's the difference between ANOVA at stratification time vs ANOVA
>    after cell assignment?"* — Section 6.1: we *want* rejection at
>    stratification (the strata should differ); we *want* failure-to-reject
>    after cell assignment (the cells should be balanced replicas).
> 6. *"What test do you actually monitor to decide if two groups are
>    balanced — significance or effect size?"* — Section 6.3: SMD, because
>    significance tests are sample-size-dependent and a tiny mean difference
>    can be 'significant' with enough rows. \|SMD\| < 0.1 is the operational
>    pass condition.
> 7. *"How are AOT and MMM combined?"* — Section 7: 50/50 weighted average on
>    cost-per for AOT-covered channels, 100% MMM elsewhere; the combined
>    cost-per is the calibration anchor for the recomputed response curves.
> 8. *"What changes for TV?"* — Section 3.3: TV is broadcast, so you can't
>    geo-hold-out; you switch from cross-section to time-series identification
>    via dark periods (40–60% spend reduction, scheduled in a Latin square,
>    measured by regression).

---

**Next:** Read [01_existing_aot_systems.md](01_existing_aot_systems.md) for
the production walkthrough of Email (user-level), Paid Social Meta
(vendor-managed), and SEM (DMA-level) — the three legacy AOT pipelines you
need in your head before the new design in Doc 02 makes sense.
