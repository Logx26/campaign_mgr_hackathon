---
title: Dark-Period Testing for TV
description: Time-based incrementality testing for broadcast TV (Linear TV, Connected TV) — where neither user nor geo holdouts are available. Covers why TV needs a time-axis design, the 40–60% spend-reduction mechanic, the week-level scheduler with exclusion weeks and minimum-gap constraints, the regression-based measurement methodology, the overlap-with-other-channels problem, and where this lives in the Causal Lab package.
---

# 03 — Dark-Period Testing for TV

> **What this doc is.** The TV-specific testing design — the third of the
> three "levels" introduced in
> [Doc 00 Section 3](00_aot_ecosystem_and_foundations.md#section-3). When you
> can't user-target (no IDs in broadcast) and you can't geo-target (Linear TV
> reaches every DMA at once), the remaining axis is **time** — schedule
> deliberate spend-reduced weeks across LOBs and infer lift via regression.
> This doc covers the schedule construction, the measurement layer, the
> overlap-with-other-channels accounting, and the Causal Lab module that
> ships it (`dark_period/`).
>
> **What this doc is not.** A re-explanation of foundations (→ Doc 00) or
> a re-derivation of the Latin-square / validation machinery already covered
> for geo (→ [Doc 02](02_geo_stratification_design.md)). Dark-period reuses
> the same `latin_square.py` and the same `ValidationEngine`; this doc
> focuses on what's *different* — the time-axis logic and the regression
> measurement.
>
> **Primary sources.** Tharun's 2026-03-24 KT (canonical narrative for
> the dark-period design + the SQL/config refactor rules);
> `Overview of 24 and 23rd KT.txt` Section 4.1 (the `create_schedule` code,
> walked through in prose in Section 4 below — formulas flagged where
> transcription-mangled). Cross-links to
> [MMM Doc 01](../learning_docs/md/01_mmm_methodology_primer.md) for the
> adstock/Hill math the future Bayesian measurement layer will reuse,
> [MMM Doc 07](../learning_docs/md/07_fs_submits_response_curves_and_stability.md)
> for the response-curve consumers downstream, and
> [Doc 04](04_incrementality_and_forecasting.md) for the
> incrementality-layer fusion.

---

## 1. Why TV needs a time-axis design

The geo design in [Doc 02](02_geo_stratification_design.md) works for any
channel where Zillow can decide *not to advertise in DMA X this quarter*.
That's most channels — SEM, Display, Programmatic, Affiliate, geo-targeted
Connected TV via DSPs. But not all.

**Linear TV** is a broadcast medium: a 30-second spot on a national cable
network plays in every DMA simultaneously. There's no purchase mechanism
that lets you say "show this ad in the Pittsburgh DMA but not the
Cleveland DMA" — the agency buys airtime, the network broadcasts, every
DMA receives the signal. Geo-holdout is mechanically impossible.

**Connected TV** (CTV) — when bought as a direct-buy with the network
(Hulu, Netflix with Ads, broadcast streaming apps) — has the same property
at the *campaign* level. Some CTV inventory is bought through DSPs
(Demand-Side Platforms) where you *can* set geo-targeting, but the
"premium" CTV inventory that contributes the most spend is direct-buy and
geographically unaddressable.

User-level holdout is also off the table for TV. Broadcast TV has no
user-IDs to exclude; even when a viewer is identifiable in another system
(logged-in Hulu account), the network doesn't let Zillow target the ad at
a holdout list within the broadcast. There's no Hightouch or Simon Data
equivalent for "skip this user in the TV broadcast."

So the experimental contrast must come from the **time axis**. Instead of
"DMA A gets the ad, DMA B doesn't, both in the same week," the contrast
becomes "the *whole country* gets the ad in weeks 1–2, *nobody* gets it
in week 3, *everyone* again in weeks 4–5." Pre/post comparison within a
single nationally-aggregated time series, with the dark week as the
treatment.

The methodological terminology shifts accordingly:

| Geo design (Doc 02) | Dark-period design (this doc) |
|---|---|
| **Cross-sectional** identification (DMA × DMA contrast in the same period) | **Time-series** identification (period × period contrast across the country) |
| Holdout = a set of **DMAs** going dark | Holdout = a set of **weeks** with reduced spend |
| ~5 holdout DMAs per LOB per quarter | ~5–8 dark weeks per LOB per year (depends on min gap, exclusion count, year length) |
| Measurement: DiD across DMAs | Measurement: regression on time series with dark-week dummies |
| Threat: parallel-trends violation across DMAs | Threat: omitted-variable bias from confounders moving with time (seasonality, macro shocks, parallel non-TV campaigns) |

> **Interview angle — "Why not just look at MMM's TV coefficient?"** MMM's
> TV coefficient comes from observational variation in spend, and most weeks
> Zillow's TV spend is at a steady level — there's almost no off-weeks for
> MMM to learn from. Dark-period testing **deliberately creates the
> contrast** that MMM otherwise has to wait for the calendar to provide.
> Once enough dark weeks accumulate, the regression in Section 5 produces a
> directly causal estimate that recalibrates MMM's TV coefficient via the
> incrementality layer (Doc 04).

---

## 2. The 40–60% spend reduction — why not zero

The first non-obvious design choice: dark weeks aren't fully dark. The
schedule reduces spend on the chosen LOB by **40–60%**, not to zero.

### 2.1 Three reasons against full-zero

**Operational visibility.** Going to zero on a continuous TV spend profile
is loud. The agency notices, the network notices, the channel-lead team
inside Zillow notices. Each of those parties can react in ways that
contaminate the measurement: the agency may renegotiate, the network may
reshuffle inventory, the channel team may launch other campaigns to
compensate. A partial reduction is *quiet* — it looks like normal spend
variation and doesn't trigger compensating behavior.

**Revenue protection.** Zillow's TV spend is large enough that a full-zero
week measurably drags the business. Even with a small number of dark weeks
per year, the cumulative revenue impact of full-zero outweighs the
measurement value. A 40–60% reduction caps the worst-case revenue impact
per dark week and keeps the always-on cadence acceptable to the business.

**Detection still works at partial.** The lift estimator (Section 5) only
needs *enough variation in spend* to identify the coefficient. With
$\sim$50% of spend removed, the implied impression drop is roughly
proportional, and the KPI change — if TV has real incrementality — is
detectable with the time series we have. Power analysis (sketched in
Section 7) confirms that 50% reduction is enough at typical lift levels.

### 2.2 How the reduction is operationalized

The reduction is implemented by the **channel-activation team** (not by
the DS team). The AOT-side deliverable is a schedule that says, for each
dark week and each LOB:

```
2026-W18 | CTV Brand | DARK (-50% spend) | Linear, CTV Rental, ... | LIVE
2026-W19 | CTV Rental | DARK (-50%)      | Linear, CTV Brand, ... | LIVE
...
```

The channel team translates "CTV Brand dark" into "halve the CTV-Brand
weekly buy with the network and the agency." How they do that operationally
varies by channel and agency, but typically:

- For Linear TV: reduce gross rating points (GRPs) booked for the week by
  ~50%, dropping the lowest-priority spots.
- For CTV direct-buy: reduce impression target with the network by ~50%
  for that flight.
- For CTV programmatic: lower the daily budget on the DSP by ~50% for the
  week.

The 40–60% range gives the channel team flexibility based on what's
operationally clean per channel. The schedule logs the *intended*
reduction; the realized reduction is read back at measurement time from the
actual spend table.

> **Inline flag — "should we vary the reduction percentage per channel?"**
> The KT notes mention "40% to 60%" without resolving per-channel choice.
> The codebase currently treats this as a single parameter — 50% is the
> typical operating point. The flexibility exists in case a channel
> reports operational issues with a clean 50% cut; in practice that
> rarely happens. For interview purposes, "around 50%, 40–60% acceptable
> range" is the right answer.

### 2.3 The handoff contract

The schedule that AOT produces is a **forward-looking declaration**:
"here's what we're asking you to dark over the next year." The channel
team commits, the schedule lands in a config-managed table, and
measurement (Section 5) reads both the declared schedule and the realized
spend to do its calculation. The contract is no different from the
geo-design `holdout_schedule` table from
[Doc 02 Section 12](02_geo_stratification_design.md#section-12) — same
pattern, different content.

---

## 3. Schedule construction — week-level grain

The dark-period scheduler runs **once per year** and produces a 52-week (or
53-week) schedule. Three parameters drive it:

1. **The set of LOB-channel combinations** to schedule. For TV, typical:
   `{Linear_Brand, CTV_Brand, CTV_Rental}`. Future expansion to more
   combinations is straightforward — the scheduler is parameterized.
2. **The exclusion weeks** — periods where everything must stay live.
3. **The minimum gap weeks** — minimum spacing between two dark weeks for
   the same LOB.

### 3.1 The week-Monday convention

Every dark week is anchored to **Monday**. The schedule lists Mondays;
dark weeks run Monday through Sunday, matching the marketing weekly cadence
and the MMM training grain
([MMM Doc 00 Section 2](../learning_docs/md/00_mmm_ecosystem_overview.md#section-2)).
This single convention buys two things: alignment with MMM (so the
incrementality layer can join cleanly) and alignment with TV-buying weeks
(networks bill in week-Monday units).

### 3.2 Exclusion weeks

Some weeks are **never** dark. These are weeks where the marginal revenue
impact of any holdout would dominate the measurement value. The canonical
list (read from `config.yaml`):

| Exclusion period | Why excluded |
|---|---|
| Black Friday week | Highest-revenue retail week of the year; cutting TV spend would crater the business |
| Cyber Monday week | Same logic — peak conversion |
| Christmas week | Holiday season for-sale conversions + brand-awareness gains |
| New Year's week | Post-holiday refinance window for ZHL + rental search surge |
| Super Bowl week | High-impact ad placements with rare brand-awareness reach; agency-side mandates often require live |
| Major event weeks (e.g., FIFA World Cup) | Per Tharun's KT, channel team explicitly flags these. Mid-year window varies by sports calendar. |
| Major housing-cycle weeks (e.g., spring buying season peak — typically last week of March / first week of April) | High conversion-rate windows the business doesn't want to dampen |

The exclusion list is a config-driven, business-blessed input — the
scheduler enforces it but doesn't decide it. When an exclusion week is
hit, **every LOB is live**, regardless of any "this LOB is due to go
dark" considerations.

> **Inline flag — exact list per year.** The KT mentions Cyber Monday,
> Christmas, and the FIFA World Cup explicitly. The other items above are
> reasonable inferences from how the channel team operates in the
> broader Zillow context. The active list per year is in `config.yaml`;
> if you're quoting a specific exclusion to a stakeholder, read the
> config rather than this list.

### 3.3 Minimum gap weeks

For each LOB, define **`min_gap_weeks`** — the minimum number of weeks
between two consecutive dark weeks *for the same LOB*. Typical value:
**4 weeks**. The reason:

- **Treatment-effect decay.** After a dark week, the KPI takes time to
  return to baseline (advertising has carryover — see
  [MMM Doc 01 Section 3](../learning_docs/md/01_mmm_methodology_primer.md#section-3)
  for adstock decay). If the next dark week starts before the previous
  one's effect has fully decayed, the two observations are contaminated
  by each other and you can't fit clean coefficients on each.
- **Operational fatigue.** The agency can't easily run a "dark-light-dark"
  cycle every two weeks — there's a planning cadence the channel team
  needs to respect.

`min_gap_weeks` is a per-LOB knob in config; some LOBs may need wider gaps
(8 weeks for Brand TV, 4 weeks for Rental CTV). The scheduler enforces
the constraint per LOB independently.

### 3.4 The sequential walk — what `create_schedule` does, in prose

The schedule-construction function (`create_schedule` in the Overview text
Section 4.1, lives in `causallab/dark_period/scheduler.py`) walks through
the year a week at a time, deciding for each week whether to mark an LOB
dark or not. The loop body — described in prose, not code:

**Initialization.** Set the current week to `start_date`'s Monday. Load
`available_channels` = a copy of the LOB list (e.g., `[Linear_Brand,
CTV_Brand, CTV_Rental]`). Randomly shuffle it. Initialize
`weeks_since_last_dark` to the minimum-gap value (so the very first week
is eligible to be a dark week if appropriate). Initialize an empty
records list.

**Each week iteration.** For the current Monday:

1. **Check exclusion.** If the current week's label (e.g., `"2026-12"` for
   the 12th ISO week) is in the exclusion set: append one record per
   channel marked `"LIVE"`, increment `weeks_since_last_dark`, advance to
   the next week, and continue. Do not consume a channel from the
   shuffled list.

2. **Eligibility check.** If `weeks_since_last_dark >= min_gap_weeks` **and**
   `available_channels` is non-empty: this is a dark-week candidate.
   - Pop the next channel from the shuffled `available_channels` list —
     that channel is the dark channel for this week.
   - Append records for the chosen dark channel marked `"DARK"`, and the
     remaining channels marked `"LIVE"`.
   - Reset `weeks_since_last_dark` to 0.
   - If `available_channels` is now empty, refill it: copy the LOB list,
     shuffle again. (The shuffle ensures the cycle through LOBs isn't
     deterministic and isn't always the same order.)

3. **No-dark week.** If the eligibility check fails (`weeks_since_last_dark
   < min_gap_weeks` or the available list is empty mid-cycle just before
   a refill): append all channels as `"LIVE"`, increment
   `weeks_since_last_dark`, advance.

4. **Advance:** add 7 days to current Monday, loop.

When the loop reaches `end_date`, the records list is converted into a
pandas DataFrame with columns `(week, channel, status)` and that becomes
the schedule. Subsequent steps attach metadata (LOB code, intended spend-
reduction %, etc.) via config-driven mappings.

### 3.5 Why this isn't a strict Latin square

The geo design (Doc 02 Section 8) uses a Latin square because the rows
(slots) and columns (quarters) are both finite, balanced dimensions and
strict orthogonality is achievable. Here, the rows are LOBs (3–6 of them)
but the columns are **52 weeks**, and the exclusion-week + min-gap
constraints make strict Latin-square structure impossible. Instead, the
design uses what you might call a **balanced rotation with constraints**:
each LOB goes dark approximately the same number of times across the year
(via the round-robin pop from `available_channels`), but the specific
weeks are determined by greedy left-to-right assignment under the gap
constraint, with exclusion weeks forced live.

The resulting matrix at week × channel level:

```
            W01  W02  W03  W04  W05  W06  ...  W47 (Black Fri)  W48 (Cyber Mon)  W49  W50 (Xmas)  ...
Linear_Brand DARK LIVE LIVE LIVE LIVE DARK ...     LIVE              LIVE          LIVE  LIVE      ...
CTV_Brand    LIVE DARK LIVE LIVE LIVE LIVE ...     LIVE              LIVE          DARK  LIVE      ...
CTV_Rental   LIVE LIVE LIVE DARK LIVE LIVE ...     LIVE              LIVE          LIVE  LIVE      ...
```

Key invariants the scheduler enforces:

- **At most one LOB DARK per week.** This isn't a Latin-square axiom —
  the scheduler enforces it explicitly so that any week's KPI residual
  can be attributed to the single dark LOB (Section 5's regression
  identifying assumption).
- **Exclusion weeks have all LIVE.** Universal across LOBs.
- **Min-gap between dark weeks per LOB.** Per LOB, enforced.
- **Approximate balance across LOBs.** With 3 LOBs and ~12 eligible dark
  weeks per year (52 minus ~6 exclusion weeks, minus ~10 gap-blocked
  weeks), each LOB gets ~4 dark weeks. Exact balance isn't guaranteed —
  the constraint-walking can leave one LOB with 5 darks and another with
  3 — but it's close.

> **Why "at most one LOB DARK per week" and not "exactly one"?** When the
> gap constraint forces a no-dark week (or when the exclusion list is
> long enough that some weeks have to be skipped), exactly-one isn't
> achievable. "At most one" is the operationally correct constraint:
> identifiability comes from being able to attribute the residual to a
> single LOB, which "at most one" preserves. "Zero" weeks just provide
> baseline observations for the regression.

---

## 4. The schedule output — what it looks like, what it joins to

The scheduler writes a Delta table — by convention
`{catalog}.{gold_schema}.dark_period_schedule` — with one row per (week,
channel) combination. The schema:

| Column | Type | Meaning |
|---|---|---|
| `week_monday` | date | The Monday anchor for the week |
| `channel` | string | E.g., "Linear TV", "Connected TV" |
| `network` | string | Network within the channel |
| `core_lob` | string | LOB code, joinable to MMM taxonomy |
| `core_campaign_super` | string | E.g., "Brand", "Rental" |
| `status` | string | `"DARK"` or `"LIVE"` |
| `intended_reduction_pct` | float | E.g., 0.50 for a 50% reduction (only meaningful for `DARK` rows; `LIVE` rows have 0.0) |
| `is_exclusion_week` | boolean | Convenience flag for downstream filters |
| `experiment_id` | string | Identifier for the design run |
| `year` | int | For partitioning |
| `p_data_date` | date | Date of run |

The table is **overwritten annually**; historical schedules are recovered
via Delta time travel.

### 4.1 Joins downstream

| Consumer | Join key |
|---|---|
| Channel activation systems | `(week_monday, channel, network, core_lob, core_campaign_super)` — the activation team reads the next 4-week window and acts on `DARK` rows |
| Measurement layer (Section 5) | `(week_monday, channel, network, core_lob)` joined to the weekly KPI panel and the weekly spend table |
| MMM incrementality layer ([Doc 04](04_incrementality_and_forecasting.md)) | Same — used to assemble the AOT-side cost-per to combine with MMM |
| Reporting / Tableau | `(week_monday, status)` — show stakeholders which LOB is dark when |

---

## 5. Measurement — regression with dark-week dummies

This is the part that's **still in design** as of the KT 03-24 snapshot
("the measurement part is still in design stage"). The v1 design is a
simple linear regression at national-weekly grain; the roadmap is a
Bayesian hierarchical time-series model (Section 7).

### 5.1 The setup

After the year of dark weeks has actually run, the measurement code
pulls:

- **Weekly KPI series.** Visits, FS Submits, ZHL Submits, Rental Visits,
  MF Submits — same 5 KPIs as everywhere else. Aggregated to the national
  level by week-Monday.
- **Weekly TV impressions / spend.** From the marketing fact table,
  filtered to Linear TV + CTV channels, aggregated to weekly.
- **The dark-period schedule** (the table from Section 4) — provides the
  `DARK` flag per (LOB, week).
- **Control variables.** Seasonality (week-of-year), holiday indicators
  (Memorial Day, Independence Day, etc.), macro indicators (mortgage rate
  index, unemployment, Google Trends for `zillow`). Same set MMM uses;
  see [MMM Doc 04](../learning_docs/md/04_data_lineage_and_schemas.md)
  for the feature store.

### 5.2 The v1 regression

For a chosen KPI $Y_t$ (say weekly national FS Submits in week $t$):

$$
Y_t = \alpha + \sum_{\ell} \beta_\ell \cdot \mathbb{1}[\text{LOB } \ell \text{ dark in week } t] + \gamma \cdot \text{TV\_imps}_t + \boldsymbol{\delta}^\top \mathbf{X}_t + \epsilon_t
$$

where:

- The first sum runs over LOBs ($\ell \in \{\text{Linear\_Brand},
  \text{CTV\_Brand}, \text{CTV\_Rental}\}$). $\beta_\ell$ is the
  **lift coefficient** for LOB $\ell$ — the average KPI change in weeks
  where LOB $\ell$ is dark, holding other variables constant.
- `TV_imps` is the weekly TV impression count (across all LOBs), included
  to absorb the level effect of TV being live.
- $\mathbf{X}_t$ is the control vector (seasonality, holidays, macros).
- $\epsilon_t$ is the residual.

The estimate $-\beta_\ell$ (with sign flipped because dark = absence of
spend) is interpreted as **the incremental KPI contribution of LOB $\ell$
when it's live**. Divide by the LOB's average weekly spend to get a
**cost-per-incremental-KPI** estimate that's directly comparable to MMM's
and joinable into the incrementality layer.

> **Sign convention.** In the regression, $\beta_\ell$ is the coefficient
> on the *dark indicator* — so a negative coefficient means "KPI is lower
> when LOB $\ell$ is dark." For a real-incrementality channel,
> $\beta_\ell < 0$. The reported lift is $-\beta_\ell / \bar{Y}$ in
> percentage terms.

### 5.3 Why the controls matter

The single biggest threat to identification in time-series-only data is
**omitted-variable bias from confounders that move with time**. The
controls handle:

- **Seasonality.** FS Submits has a strong weekly and yearly cycle. Without
  seasonality controls, the regression confuses "we went dark in a
  low-season week" with "TV drives FS Submits."
- **Holidays.** The exclusion-week constraint already prevents dark weeks
  during major holidays, but the *non-excluded* weeks bordering holidays
  still have unusual behavior. Holiday-adjacency indicators capture this.
- **Macros.** Mortgage rate movements, unemployment, Google search trends
  — all move slowly week to week and can drift across the year. Without
  them, the slow drift gets absorbed into whichever LOB happens to be
  dark in those weeks, biasing $\beta_\ell$.

The control set is borrowed from MMM's exogenous feature store
(see [MMM Doc 04 Section 4](../learning_docs/md/04_data_lineage_and_schemas.md#section-4)).
That mutual reliance is intentional — same controls, same
preprocessing, so AOT and MMM speak the same language about what
"adjusted for macros" means.

### 5.4 Limitations of the v1 regression

The v1 OLS is the simplest defensible thing. Its limitations:

- **Adstock not modeled.** TV's effect carries forward — a Linear-Brand ad
  in week $t$ still drives Visits in weeks $t+1, t+2$. The dark indicator
  is binary in week $t$, but the *effect* persists. OLS without an
  adstock-transformed dark indicator underestimates the true
  contribution. The fix is to transform the dark indicator via the same
  geometric adstock the MMM uses
  ([MMM Doc 01 Section 3](../learning_docs/md/01_mmm_methodology_primer.md#section-3))
  before regressing.
- **Saturation not modeled.** OLS is linear in impressions. TV at
  high spend levels exhibits diminishing returns (Hill saturation —
  [MMM Doc 01 Section 4](../learning_docs/md/01_mmm_methodology_primer.md#section-4)).
  Linear extrapolation from a 50%-reduced week to "what if zero" or
  "what if double" is unreliable.
- **No hierarchy.** A pooled national regression doesn't have a
  per-DMA structure. MMM's hierarchical Bayesian structure
  ([MMM Doc 01 Section 6](../learning_docs/md/01_mmm_methodology_primer.md#section-6))
  lets each DMA have its own coefficient while borrowing strength. The
  dark-period regression is national-only, so it estimates one
  $\beta_\ell$ for all DMAs — a strong constant-effect assumption.
- **Small sample size.** With ~4 dark weeks per LOB per year, the
  coefficient has wide standard errors. Two or three years of dark
  weeks accumulated will help; the first year produces directional but
  noisy estimates.

These are exactly the limitations the Bayesian hierarchical roadmap
(Section 7) is designed to address.

---

## 6. Overlap with non-TV channels — feature, not bug

A subtle issue: during a TV-dark week, **non-TV channels keep running**.
SEM keeps bidding, Display keeps serving impressions, Paid Social keeps
running its own AOT experiments. If TV being dark in week $t$ coincides
with SEM having a big push that week, the regression sees a partial KPI
recovery from SEM that gets attributed somewhere — possibly to TV's
coefficient if the model is misspecified.

Tharun's KT framing is the right way to think about this: the overlap is
**a feature of the system, not a bug we should engineer away**. The whole
point of running AOT is to measure each channel in the context of all the
others running normally. A "TV dark while everything else also dark"
experiment would tell us about the *isolated* TV effect, which (a) we
can't operationally achieve and (b) isn't actually what we want — the
*real-world* TV effect in the presence of other channels is the
counterfactual that matters for budget allocation.

### 6.1 What the regression can and can't say

What the dark-period regression **can** say:

- "In the average week when LOB $\ell$ is dark, KPI is X% lower than the
  baseline week, after controlling for seasonality, macros, and TV
  impressions." That's a valid causal estimate of TV-LOB-$\ell$'s
  contribution *given the current marketing mix*.

What it **can't** say without more structure:

- "TV by itself drives X% of FS Submits." The regression's coefficient is
  conditional on every other channel running, so it's a *partial*
  contribution.
- "If we cut TV by 70%, FS Submits would drop by Y%." That's an
  extrapolation outside the support of the observed data (we only have
  ~50% reductions). MMM's response curves handle extrapolation; AOT's
  regression doesn't.
- "How much of SEM's measured FS Submits is actually attributable to TV's
  awareness-driving effect?" That's a funnel-effect question that
  requires a structural model. The dark-period regression sees this only
  through the residual; MMM's funnel-effect machinery
  ([MMM Doc 01 Section 8](../learning_docs/md/01_mmm_methodology_primer.md#section-8))
  is what disentangles it.

The discipline: when reporting dark-period results to stakeholders, frame
the estimate as **"TV $\ell$'s incrementality conditional on the current
marketing mix"** — never as the isolated, standalone TV effect. The
incrementality layer (Doc 04) uses the conditional estimate to recalibrate
the MMM coefficient, and MMM's structural model takes care of the rest.

### 6.2 Cross-experiment contamination — the geo AOT side

A parallel concern: while TV is dark in a given week, the geo AOT
experiments (Doc 02) are still running their own per-channel DMA
holdouts. So in week $t$:

- All US DMAs see TV at 50% reduced (TV dark, LOB $\ell$).
- 5 DMAs see SEM dark (geo AOT, slot $k$, this quarter).
- 5 DMAs see Display dark (geo AOT, slot $j$).
- Etc.

Are the geo holdouts contaminating the dark-period regression? In
principle yes — the 5 SEM-dark DMAs have a slightly lower KPI than they
would otherwise, which lowers national-weekly KPI by a tiny amount that
might bleed into TV's coefficient. In practice no — the 5 DMAs are
$\sim$3% of the US population, the SEM lift is a few percent, so the
national-aggregate distortion is sub-0.2%, far below the noise floor of
the regression.

Symmetric concern about TV dark weeks contaminating geo AOT measurements:
same logic, even more attenuated (geo AOT compares 5 DMAs to 175, so the
shared TV reduction nets out across both arms cleanly under DiD).

---

## 7. Future direction — Bayesian hierarchical

The v1 OLS is a placeholder. The methodological roadmap (per KT 03-24)
points at a **hierarchical Bayesian time-series model**, structurally
similar to MMM's per-KPI Bayesian regression but with the dark indicators
as the focal covariates.

### 7.1 What the v2 would look like

The minimal upgrades over Section 5.2's OLS:

- **Adstock the dark indicators.** Transform $\mathbb{1}[\text{dark}_t]$
  to a geometric-decay carryover series using the same adstock parameters
  the MMM uses for TV
  ([MMM Doc 01 Section 3.2](../learning_docs/md/01_mmm_methodology_primer.md#section-3-2)).
  This lets the regression credit dark-week effects to the weeks they
  actually affect.
- **Hill-saturate the impression covariate.** Wrap `TV_imps_t` in a Hill
  transform with parameters from MMM
  ([MMM Doc 01 Section 4.2](../learning_docs/md/01_mmm_methodology_primer.md#section-4-2)).
  Provides correct extrapolation behavior at near-zero and high spend.
- **Bayesian priors on $\beta_\ell$.** Informed by MMM's posterior on the
  same LOB. Specifically, $\beta_\ell \sim
  \mathcal{N}(\beta^{\text{MMM}}_\ell, \tau^2_\ell)$ with $\tau$ tuned to
  reflect how much we trust MMM vs. data. This is the same prior pattern
  MMM uses for previously-calibrated channels — see
  [MMM Doc 01 Section 6.6](../learning_docs/md/01_mmm_methodology_primer.md#section-6-6).
- **Hierarchy over DMAs.** Move from national-weekly to DMA-week panel,
  with a hierarchical prior: $\beta^{(d)}_\ell \sim \mathcal{N}(\bar{\beta}_\ell,
  \tau^2)$, $\bar{\beta}_\ell$ the population mean across DMAs. This is
  the same hierarchical structure
  [MMM Doc 01 Section 6.3](../learning_docs/md/01_mmm_methodology_primer.md#section-6-3)
  uses for media coefficients.
- **NUTS via numpyro.** Same sampler MMM uses — reuse the `rapidmmm`
  primitives to avoid building this from scratch. The Causal Lab
  measurement module
  ([Section 14 of Doc 02](02_geo_stratification_design.md#section-14))
  is wired to import from `rapidmmm` where useful.

### 7.2 Why v1 first

The v1 OLS exists because the team needs to ship *something* now, even
if imperfect. The first year's dark-period schedule has just been
deployed; the regression runs on the data that comes back. By the time
the v2 is ready, the v1 will have produced one year of validated lift
estimates that the v2 can be calibrated against. Standard incremental-
shipping discipline.

---

## 8. Where this lives in Causal Lab

The dark-period code lives at `causallab/dark_period/` — a sibling of
`holdout_setup/` in the package tree (see
[Doc 02 Section 14.1](02_geo_stratification_design.md#section-14)).

### 8.1 Module structure

```
causallab/
├── holdout_setup/      # The geo design from Doc 02
└── dark_period/
    ├── __init__.py
    ├── scheduler.py    # create_schedule + constraint-walking logic
    ├── config.py       # Year-specific config (exclusion list, gaps, channels)
    └── (measurement WIP — currently in a notebook, will land here)
```

Same patterns as the geo side:

- **Config-driven.** Every parameter — channel list, exclusion weeks,
  `min_gap_weeks` per LOB, intended reduction %, schedule horizon —
  comes from `config.yaml`. The scheduler has no hardcoded numbers.
- **Logger over print.** Same `casuallab_logger` pattern from
  [Doc 02 Section 14.4](02_geo_stratification_design.md#section-14-4).
- **Latin-square reuse.** Even though dark-period doesn't use a strict
  Latin square (Section 3.5), it imports `latin_square.py` for the
  overlap-checking utility — when a new year's schedule is built, it
  compares against the previous year's `dark_period_schedule` to verify
  no LOB ends up dark in the same week two years in a row.
- **ValidationEngine reuse.** The measurement-side validation (parallel-
  trends for the pre-period of each LOB before going dark) reuses the
  same `ValidationEngine` from `holdout_setup/assignment.py`. Same
  Levene + ANOVA + Mood's + parallel-trends test infrastructure.

### 8.2 Notebook → module split

In the current snapshot, **scheduling is in `dark_period/scheduler.py`**
and **measurement is still in a development notebook**. The plan is to
move measurement into `dark_period/measurement.py` once v1 OLS stabilizes
and the v2 Bayesian model is sketched. Same trajectory as the geo design
went through.

### 8.3 The orchestration notebook

A companion notebook — call it `dark_period_schedule.ipynb` — performs
the year-start orchestration:

1. Read `config.yaml`.
2. Read the previous year's `dark_period_schedule` (if any) for the
   year-over-year overlap sanity check.
3. Instantiate `Scheduler` from `dark_period.scheduler`.
4. Call `Scheduler.create_schedule(start_date, end_date, exclusions,
   channels, min_gap_weeks)` — produces a DataFrame.
5. Run validation: count dark weeks per LOB (should be approximately
   balanced); confirm no exclusion week has any DARK row; confirm
   min-gap is satisfied per LOB.
6. Write to `{catalog}.{gold_schema}.dark_period_schedule`
   with `overwrite`.
7. Log to MLflow: the schedule itself + a heatmap visualization.

The measurement notebook is invoked **weekly** (or whenever a dark week
completes) — it reads the schedule, pulls KPI + impressions + controls,
fits the regression, and writes the lift estimates to a separate
`dark_period_measurement` gold table that Doc 04's incrementality layer
consumes.

---

## 9. Closing — interview questions

> 1. **"Why does TV need a different design from SEM?"** Section 1.
>    Broadcast nature means no geo control; no IDs means no user control.
>    The only remaining axis is time.
> 2. **"Why 40–60% spend reduction instead of zero?"** Section 2.1.
>    Operational visibility, revenue protection, and detection still
>    works at partial reduction with enough weeks.
> 3. **"How do exclusion weeks affect the schedule?"** Section 3.2.
>    Force every LOB live in those weeks, regardless of the round-robin
>    rotation. Examples: Black Friday, Cyber Monday, Christmas, Super
>    Bowl, FIFA World Cup. The list is config-driven.
> 4. **"Why a minimum gap between dark weeks?"** Section 3.3. Two
>    reasons: ad effects carry over (treatment-effect decay needs time);
>    agency operational constraints don't accommodate rapid on/off
>    cycling.
> 5. **"Why not strict Latin square here?"** Section 3.5. Columns are
>    weeks (52 of them, with exclusions and gap constraints), so strict
>    Latin-square structure isn't achievable. The scheduler uses
>    constrained greedy assignment with shuffled round-robin — the
>    result is "at most one LOB dark per week, approximate balance
>    across LOBs."
> 6. **"How does measurement work without channel-level reads on TV?"**
>    Section 5. Linear regression of weekly national KPI on dark-LOB
>    indicators, TV impressions, seasonality, and macro controls. The
>    coefficient on the dark indicator (with sign flipped) is the lift
>    estimate.
> 7. **"What are the limitations of the v1 OLS measurement?"**
>    Section 5.4. No adstock on the dark indicator, no saturation on
>    impressions, no DMA hierarchy, wide standard errors from few dark
>    weeks per LOB. The v2 Bayesian roadmap (Section 7) addresses all of
>    these by reusing MMM's primitives.
> 8. **"Other channels keep running while TV is dark — doesn't that
>    contaminate the measurement?"** Section 6. It's a feature, not a
>    bug. The estimate is conditional on the current marketing mix,
>    which is exactly what we want for budget allocation — not an
>    isolated TV-only counterfactual. Phrase results accordingly when
>    reporting.
> 9. **"What goes in the gold table?"** Section 4. One row per
>    (week, channel, network, LOB, campaign_super) with `status`,
>    `intended_reduction_pct`, `is_exclusion_week`, plus standard
>    metadata. Same grain MMM uses, so joins are clean.
> 10. **"How does this connect to MMM?"** The lift estimate becomes an
>     AOT cost-per for the LOB; the incrementality layer
>     ([Doc 04](04_incrementality_and_forecasting.md)) combines
>     it with MMM's cost-per via the 50/50 weighting and rebuilds the
>     response curves used by the budget allocator
>     ([MMM Doc 07](../learning_docs/md/07_fs_submits_response_curves_and_stability.md)).

---

**Next:** Read [04_incrementality_and_forecasting.md](04_incrementality_and_forecasting.md)
— how the per-channel AOT cost-pers (from this doc for TV, from
[Doc 02](02_geo_stratification_design.md) for geo-targetable channels, and
from [Doc 01](01_existing_aot_systems.md) for the legacy three) fuse with
MMM cost-pers, propagate through inverse adstock, rebuild response
curves, and produce the forecast that lands in the marketing AOP.
