---
title: Incrementality Layer + Response Curves + Forecasting (AOT × MMM Marriage)
description: The post-MMM, post-AOT fusion pipeline that turns per-channel AOT cost-pers into recalibrated MMM-style response curves and forecast cost-per-submits aligned to the marketing AOP. Walks through the seven notebooks end-to-end — AOT data collection with per-channel transformations, MMM-output processing with inverse adstock and daily proportioning, 50/50-weighted cost-per combination, direct-vs-halo attribution, the temporary brand-edition TVPA notebook, response-curve fitting with predict_stability + scale-factor + bias calibration, and the forecasting layer with AOP merge and historical-retention rule.
---

# 04 — Incrementality Layer + Response Curves + Forecasting

> **What this doc is.** The end-of-pipeline doc. After AOT has measured
> what it can ([Doc 01](01_existing_aot_systems.md) +
> [Doc 02](02_geo_stratification_design.md) +
> [Doc 03](03_dark_period_tv.md)) and MMM has fit its bi-weekly
> hierarchical Bayesian model
> ([MMM Doc 00](../learning_docs/md/00_mmm_ecosystem_overview.md)), the
> **incrementality layer** takes both outputs, weights them, recalibrates
> response curves, and produces a **forecast cost-per-submit** that the
> marketing AOP can be built against. This is the doc that explains how
> the two systems actually marry into a single set of budget-allocation
> inputs.
>
> **What this doc is not.** A re-derivation of adstock, Hill, or
> hierarchical Bayes — those are in
> [MMM Doc 01](../learning_docs/md/01_mmm_methodology_primer.md). A
> walkthrough of the MMM response-curve fitting — that's in
> [MMM Doc 07](../learning_docs/md/07_fs_submits_response_curves_and_stability.md).
> This doc cross-links liberally rather than re-explaining.
>
> **Primary sources.** Sucharitha's 2026-04-01 KT (incrementality layer
> architecture, per-channel transformations, brand-edition notebook) and
> 2026-04-02 KT (response-curve build, `predict_stability`, scale-factor +
> bias calibration, forecasting layer, historical retention rule).
> Cross-links to [MMM Doc 01 Section 11.3](../learning_docs/md/01_mmm_methodology_primer.md#113-email-simon-data-recalibration)
> for the recalibration concept, [MMM Doc 05](../learning_docs/md/05_fs_submits_overall_model_track.md)
> for the MMM-side AOT hook, [MMM Doc 02](../learning_docs/md/02_rapidmmm_library_internals.md)
> for the adstock math being inverted, and
> [MMM Doc 07](../learning_docs/md/07_fs_submits_response_curves_and_stability.md)
> for the response-curve fitting machinery being mirrored.

---

## 1. The pipeline — seven notebooks at a glance

The incrementality layer is **seven sequential notebooks**, each writing an
intermediate table that the next reads. The cadence: runs **after each MMM
version** (i.e., bi-weekly), version-aware so older versions don't get
re-computed.

```
┌──────────────────────────────────────────────────────────────────────────┐
│                     INCREMENTALITY LAYER PIPELINE                        │
├──────────────────────────────────────────────────────────────────────────┤
│                                                                          │
│ NB1 — AOT data collection                                                │
│   ├─ Pull AOT pooled-results for Email, Paid Social FB, SEM Google       │
│   ├─ Join with B2C measurement fact for planned spend                    │
│   ├─ Expand Email to all LOBs (legacy: only at campaign-super)           │
│   └─ Write marketing.incrementality_combined (raw AOT, overwritten)      │
│                                                                          │
│ NB2 — AOT transformations                                                │
│   ├─ Per-channel: impute dates, smooth nulls (MA), zero invalids,        │
│   │  cap [p0, p95]                                                       │
│   ├─ Union three channels → sort → final 7-day MA → write                │
│   └─ Visualize before/after for sanity                                   │
│                                                                          │
│ NB3 — MMM output processing + cost-per combination                       │
│   ├─ Read MMM taxonomy output for current version                        │
│   ├─ Inverse adstock the MMM predictions                                 │
│   ├─ Proportion weekly → daily via impressions ratio                     │
│   ├─ Compute day-level MMM cost-per, smooth 7-day window                 │
│   ├─ Read AOT intermediate; for non-AOT channels set AOT cost-per = 0    │
│   ├─ Apply 50/50 (or config-driven) weights → final cost-per             │
│   ├─ Compute incrementals (imps/cp for email+OMP, spend/cp others)       │
│   ├─ Apply Direct vs Halo flag from config                               │
│   └─ Append 2 weeks of new data to marketing.incrementality_output       │
│                                                                          │
│ NB4 — Brand edition (TEMPORARY)                                          │
│   ├─ Read MMM scaled IDVs + intercept                                    │
│   ├─ Fit TVPA model with 95% intercept prior, 5% brand split             │
│   ├─ Inverse adstock + daily proportioning                               │
│   ├─ Exclude channel-networks already in MMM brand output                │
│   └─ Append to marketing.incrementality_output (visits KPI only)         │
│                                                                          │
│ NB5 — Response curve fitting (× 5 KPIs)                                  │
│   ├─ Aggregate to channel × network × campaign_super                     │
│   ├─ Filter combinations with too few points                             │
│   ├─ Fit Hill curve (bottom, top, slope, saturation)                     │
│   ├─ Run predict_stability — flag unstable curves                        │
│   ├─ Compute scale_factor (clipped [0.75, 1.5]) + bias                   │
│   └─ Write to ratio table for forecasting                                │
│                                                                          │
│ NB6 — Forecasting                                                        │
│   ├─ Read 2026 planned-budget table (often month-level)                  │
│   ├─ Re-grain to weekly                                                  │
│   ├─ Apply response curve → raw cost-per-submit forecast                 │
│   ├─ Calibrate with scale_factor (mult) and bias (add) from NB5          │
│   ├─ Multiply by multiplier table (currently all 1s)                     │
│   ├─ Apply Direct vs Halo flag                                           │
│   ├─ Apply historical-retention rule (don't overwrite past months)       │
│   ├─ For unstable curves: substitute incrementals from NB3               │
│   └─ Merge with AOP targets → final forecast table                       │
│                                                                          │
└──────────────────────────────────────────────────────────────────────────┘
```

Parts 1–7 of this doc match the bullet points above one-for-one, in order.
The structure mirrors how Sucharitha walked through the code in
KT 2026-04-01 and 04-02.

### 1.1 Where this sits relative to MMM

The incrementality layer is **downstream of MMM**, not part of MMM. The
MMM job (see [MMM Doc 00 Section 4](../learning_docs/md/00_mmm_ecosystem_overview.md#section-4))
writes its 10 gold tables and stops. Then the incrementality layer reads
those tables — by version number — and produces a separate gold artifact
that the marketing team's downstream consumers (budget allocator,
forecasting dashboards, AOP planning) actually use.

The intuition: **MMM produces the *model* of how spend drives KPIs. The
incrementality layer produces the *decision input* the marketing team
acts on.** They're different artifacts with different audiences; keeping
them as separate pipelines means the AOT side can iterate on calibration
methodology without re-running the (expensive) MMM training.

### 1.2 Why version-aware incremental loading

The full one-year window is recomputed each version to get the smoothing
and outlier treatment right, but **only the most recent ~2 weeks are
written to the output table**. The earlier rows are already there from
prior versions and weren't recomputed against new data, so they stay.
This is what "incremental load" means in this context — it's about
appending new dates, not about reprocessing history.

The team specifically marks **v15** as the cutoff: from v15 onward, the
incrementality layer was rebuilt with this pattern. Pre-v15 history was
backfilled once; everything since is append-only. Mechanically: every
incrementality-layer NB3 run reads the max date in the output table for
that KPI and only appends rows with dates strictly greater.

---

## 2. Part 1 — AOT data collection + transformation

The first two notebooks pull and clean AOT data. They run in series and
write a shared intermediate table that NB3 (Part 3) reads.

### 2.1 Sources by channel

Three channels have AOT data: **Email, Paid Social Facebook, SEM Google
Search**. Each has its own pooled-results table from the legacy systems
(see the table-architecture subsections of [Doc 01 Sections 3, 4, and 5](01_existing_aot_systems.md#section-3)
for the canonical per-channel table inventory):

| Channel | Source table | Grain |
|---|---|---|
| Email | `marketing.always_on_testing_gold.email_pooled_results` | `(date, campaign_super, attribution_window)` — no LOB |
| Paid Social FB | `marketing.always_on_testing_gold.fb_pooled_results` | `(date, channel, network, campaign_super, LOB)` |
| SEM Google | `marketing.always_on_testing_gold.sem_pooled_results` | `(date, channel, network, campaign_super, LOB)` |

The B2C measurement fact table — `marketing.marketingde_gold.b2c_measurement_fact`
(or the analogous Zillow internal name) — provides planned spend per
channel-day to convert raw AOT lift into a cost-per. Same join pattern as
the legacy AOT pull dashboards (Tharun confirmed during the KT).

### 2.2 The Email LOB expansion

A specific quirk: **Email AOT is set up at the core-campaign-super level,
not the LOB level** (see [Doc 01 Section 3](01_existing_aot_systems.md#section-3)).
But downstream tables in MMM and the incrementality output need
LOB-grained rows.

The fix is a **data expansion**: replicate each campaign-super row across
every LOB that belongs to that campaign super. So if Email has one row for
`campaign_super = Buyer` with cost-per $X$ on day $d$, the expanded form
emits one row per (Buyer-LOB, day) all with the same cost-per $X$. The
"true" Email lift at LOB grain is unmeasured — the replication is a
practical accommodation, not a measurement.

> **Inline flag — replication side effects.** Replicating a single
> measurement across multiple LOBs means that if you aggregate Email
> incrementals across LOBs naively, you'll multi-count. The codebase
> handles this by deduping at the campaign-super grain *before* any
> cross-LOB rollup. If you're writing a new consumer of the
> `incrementality_output` table that touches Email, be careful with
> the LOB dimension.

### 2.3 The combined raw AOT table (NB1 output)

After pulling the three channels, joining each to B2C measurement fact for
spend, expanding Email to LOB, renaming columns to a common schema, and
concatenating, NB1 writes:

```
marketing.incrementality_combined  -- (intermediate, overwritten each run)
```

Schema (illustrative):

| Column | Meaning |
|---|---|
| `date` | Daily |
| `channel`, `network`, `core_lob`, `core_campaign_super` | Standard MMM taxonomy ([MMM Doc 06](../learning_docs/md/06_fs_submits_taxonomy_track.md)) |
| `business_kpi` | One of Visits, FS Submits, ZHL Submits, Rental Visits, MF Submits |
| `aot_incremental` | Lift from the AOT measurement |
| `aot_cost_per` | Spend (or impressions for Email) ÷ incremental |
| `attribution_window` | Carried through from the AOT pooled results (1/3/5-day) |
| `spend` | From B2C measurement fact |
| `impressions` | From B2C measurement fact |
| `source` | "Email", "FB", "SEM" — for downstream channel-specific logic |

This table is **overwritten every run**. It's the staging ground for the
transformations in NB2.

### 2.4 NB2 — per-channel transformations

The transformations differ by channel because the data-quality issues
differ. Sucharitha walked through this channel-by-channel in KT 04-01.

#### 2.4.1 Email transformation pipeline

1. **Impute missing dates.** Email occasionally has gaps in the daily
   series — the holdout pull failed, or a date legitimately had no sends.
   Build the full date range from `min(date)` to `max(date)` and outer-
   join, so every day has a row even if its values are null.
2. **Smooth nulls with moving average.** For each (channel, network,
   campaign_super, LOB, KPI) group, apply a centered 7-day moving average
   to the cost-per series, using only non-null values in the window.
   This converts most nulls to interpolated values.
3. **Zero-out invalid cost-per.** AOT lift can occasionally be negative
   (when the holdout outperformed the treatment by chance — within
   sampling variance, but not a usable measurement). Negative lift →
   negative or infinite cost-per. Per the rule (KT 04-01): any
   `cost_per <= 0` OR `cost_per = inf` OR `cost_per is null` (after the
   MA pass) → set to **0**.
4. **Percentile cap [p0, p95].** Compute the 95th percentile of cost-per
   across the year for each (channel, network, campaign_super, LOB, KPI)
   group; clip values above to that p95.

   > Worth pausing on the asymmetry: the *lower* bound is p0 (i.e., no
   > lower clipping — though step 3 already floors at 0), and the *upper*
   > bound is p95 rather than p99 or higher. This is more aggressive than
   > the geo design's p99 (Doc 02 Section 3.1) because the AOT
   > pooled-results have a known long-tail of spurious high cost-pers
   > from low-incremental days, and the team has empirically found p95
   > to be the right operating point.

5. **Visualize before/after.** Each cap step logs a before-vs-after plot
   to MLflow.

#### 2.4.2 Paid Social Facebook transformation pipeline

Almost the same as Email, with **two differences**:

- **No date imputation needed.** Meta returns daily results without gaps
  (other than the cumulative → daily conversion problem already handled
  upstream in the legacy FB pull — see
  [Doc 01 Section 3.4](01_existing_aot_systems.md#section-3)).
- **Smooth first, then zero-fill residual nulls.** Apply MA smoothing
  directly; if a value remains null after MA (because the smoothing
  window had >7 consecutive null days — usually means a pipeline outage),
  replace with 0. The same logic: a real null where smoothing can't
  recover is treated as "no measurement," which becomes "no incremental,"
  which becomes "cost-per = 0" (signaling the incrementality layer to
  fall back to 100% MMM weight).

Then the same percentile cap [p0, p95] and visualization.

#### 2.4.3 SEM Google Search — passthrough

For SEM, **no transformations apply**. The legacy SEM AOT already produces
clean cost-pers via its year-over-year DiD pipeline (see
[Doc 01 Section 5](01_existing_aot_systems.md#section-5)), so the
incrementality layer trusts the SEM input as-is. The visualization step
still runs for sanity, but no clipping or smoothing.

> **Why the asymmetry across channels?** Each channel's AOT pipeline has
> different failure modes and different upstream cleaning. Email's
> holdout-vs-treatment computation can produce negative lift (and so
> negative cost-pers) frequently enough that explicit zeroing is needed.
> Facebook's Meta-handled lift is generally clean but has impression-
> gap issues from the Meta API. SEM's DMA-DiD is the most mature and
> least noisy. The transformations are tuned to where each channel's
> bias lives — exactly the kind of channel-by-channel heuristic that
> looks ad-hoc but reflects accumulated operational experience.

#### 2.4.4 Final union + global moving average

After per-channel transformations:

1. Concatenate the three channel DataFrames into one.
2. Sort by `(channel, network, core_lob, core_campaign_super, business_kpi, date)`.
3. Apply **a final 7-day moving average** on cost-per across the unioned
   data — the same smoothing window, applied to the post-cleaning data,
   produces the smoother time series the response curves will be fit on.
4. Write to `marketing.incrementality_combined_transformed` (or however
   the intermediate is named in the live code; the KT calls it the "AOT
   intermediate table" but doesn't name it precisely).

The NB2 output is **the canonical AOT cost-per time series**, ready to be
weighted against MMM in NB3.

---

## 3. Part 2 — MMM output processing (NB3 first half)

NB3 has two distinct halves: process MMM outputs (this Part) and combine
with the AOT intermediate via weighting (Part 3). This part is the more
methodologically interesting half.

### 3.1 Reading the MMM taxonomy output

Input: `marketing.rapidmmm_gold.mmm_model_combined_output_taxonomy_level`
filtered to the current version $v$. This is the table that holds **both
direct effect and funnel effect** rows per `(business_kpi, dma, week_monday,
channel, network, lob, campaign_super)` — see
[MMM Doc 00 Section 6.4](../learning_docs/md/00_mmm_ecosystem_overview.md#section-6-4)
for the canonical schema description.

The version number $v$ is **passed as a pipeline input parameter** — the
job that triggers the incrementality layer hands it down from MMM's
auto-versioning step. So the incrementality layer never has to guess
what's current; it's always told.

### 3.2 Inverse adstock — undoing the MMM transformation

This is the step that catches readers most by surprise.

**The problem.** MMM's `predicted` column is the predicted KPI in the
**adstocked-impression** space. That is, before fitting, the MMM
preprocessor transformed `impressions_raw` via geometric (or delayed)
adstock to `impressions_adstocked` and fit the coefficients on those (see
[MMM Doc 02 Section 3](../learning_docs/md/02_rapidmmm_library_internals.md#section-3)
for the adstock primitives). MMM's `predicted` therefore represents "the
predicted KPI given the adstocked impression history," which is *not*
the same as "the KPI we expect on this particular week from this week's
raw impressions."

**Why this matters for incrementality.** When we compute cost-per as
`spend / incremental`, we want the incremental in **raw-impression space**
— "for this week's spend, this week's marginal KPI lift." Pulling
adstocked predictions and dividing by raw spend gives a cost-per that's
inflated by the adstock decay history. Concretely: if last week's spend
is still contributing 60% to this week's adstocked impressions, then
this week's `predicted` includes lift from last week's spend — but we're
dividing by *this* week's spend, not last week's. Cost-per comes out
artificially low.

**The fix — inverse adstock.** Apply the same adstock parameters MMM
used (read from MMM's coefficient registry per channel-network) in
*reverse*: given the adstocked-prediction time series, recover the
implied raw-impression-driven prediction. For geometric adstock with
decay $\lambda$ and length $L$:

$$\tilde{Y}_t = \sum_{\ell=0}^{L-1} \lambda^{\ell} \cdot Y_{t-\ell}$$

where $Y_t$ is the raw-impression-equivalent prediction and $\tilde{Y}_t$
is the adstocked. To invert:

$$Y_t = \tilde{Y}_t - \sum_{\ell=1}^{L-1} \lambda^{\ell} \cdot Y_{t-\ell}$$

— a recursive subtraction. The codebase applies this per
`(channel, network)` because each has its own adstock parameters.

> **Inline flag — inverse-adstock numerics.** Inverse adstock can be
> numerically unstable: small errors in the input can amplify through
> the recursive subtraction. The codebase clips negative outputs to
> zero (an adstock-decayed prediction shouldn't go negative in raw
> space) and logs warnings when this happens. For most channels with
> moderate decay (~0.3–0.6), inverse adstock is well-behaved; for the
> high-decay channels (Linear TV at $\lambda \sim 0.8$), watch the
> warnings.

The class that does this lives next to the existing MMM preprocessor; the
codebase reuses the adstock-parameter dictionary already maintained per
KPI (see [MMM Doc 01 Section 3.5](../learning_docs/md/01_mmm_methodology_primer.md#section-3-5)
for the "full production adstock map" example).

### 3.3 Weekly → daily proportioning

After inverse adstock, MMM's predictions are still at **weekly grain**
(MMM trains on DMA-week). But AOT cost-pers are at **daily grain**. To
combine them in NB3's second half, we need them on the same grid.

**The mechanic.** For each week $w$, find the daily impressions ratios:

$$r_{d, w} = \frac{\text{impressions}_d}{\sum_{d' \in w} \text{impressions}_{d'}}$$

where $d$ ranges over the days in week $w$. The seven ratios sum to 1.0.
Then split the weekly prediction:

$$\text{predicted}_d = r_{d, w} \cdot \text{predicted}_w$$

Sucharitha's framing: *"each day's contribution to the week is the same
fraction as that day's impressions are of the week's impressions."* The
implied assumption: KPIs scale linearly with impressions *within a week*.
That's a stronger assumption than the model itself makes (the model has
Hill saturation on impressions, which is non-linear), but at the
within-week resolution and given the size of weekly impression variation,
the approximation is operationally fine.

**The data source for impressions** is the same `mmm_marketing_metrics`
table MMM reads (see
[MMM Doc 04 Section 2.1](../learning_docs/md/04_data_lineage_and_schemas.md)).
Daily impressions are already there at `(date, channel, network)` grain;
the proportioning just builds the ratio and applies it to each row.

#### The OMP / ZHL exception

A specific exception: **OMP (Owned Marketing Pages) for ZHL Submits uses
clickstream data**, not the marketing-metrics table, for daily impressions.
This is because OMP doesn't have a paid-impression count in the same way;
the equivalent measure is clickstream-derived visits to the OMP page. The
NB3 code has a parallel branch that swaps in the clickstream source for
that one channel-KPI combination and applies the same proportioning logic.
See [MMM Doc 00 Section 5.3](../learning_docs/md/00_mmm_ecosystem_overview.md#section-5-3)
for why ZHL is structurally different in MMM as well.

### 3.4 Day-level MMM cost-per

With daily predictions and daily spend (also from `mmm_marketing_metrics`),
compute:

$$\text{mmm\_cost\_per}_d = \frac{\text{spend}_d}{\text{predicted}_d}$$

For Email and OMP (which don't have spend in the same way),
**impressions** is substituted on the denominator's *spend* slot:

$$\text{cost\_per}^{\text{Email}}_d = \frac{\text{impressions}_d}{\text{predicted}_d}$$

This gives a "cost per incremental visit per impression" — comparable
across channels in the same way MMM uses impressions as the channel
dimension for non-spend channels.

Then apply a **7-day centered moving average** on the daily cost-per
series. Smoothing serves the same purpose here as in Part 1: kill daily
noise so the response-curve fit in Part 6 sees a clean signal.

#### 3.5 Cleaning channels not of interest

The codebase explicitly drops:
- "Others" — the catch-all for non-marketing channels (microeconomic
  variables, seasonality dummies) that aren't part of media
  measurement.
- LOBs that aren't part of the marketing pipeline (anything the team
  doesn't want to report on).

These are config-driven. They exist in the MMM output for modeling
completeness; the incrementality layer filters them out as the last step
before handing off to Part 3.

---

## 4. Part 3 — Weighted combination of AOT and MMM cost-pers (NB3 second half)

This is the **single most important step in the entire pipeline** — where
AOT calibration actually happens.

### 4.1 The weight CSV

The team maintains a CSV file (the "weight table") with one row per
(channel, network, business_kpi) combination:

```
channel,network,business_kpi,weight_mmm,weight_aot
Email,Simon Data,Visits,0.50,0.50
Email,Simon Data,FS Submits,0.50,0.50
Paid Social,Meta,Visits,0.50,0.50
Paid Social,Meta,FS Submits,0.50,0.50
SEM,Google,Visits,0.50,0.50
SEM,Google,FS Submits,0.50,0.50
Linear TV,*,Visits,1.00,0.00   <-- not currently AOT-covered
Programmatic,*,Visits,1.00,0.00
...
```

Default rule (matching the legacy 50/50 rule from
[Doc 00 Section 7.2](00_aot_ecosystem_and_foundations.md#section-7-2)):
**0.5 weight to MMM, 0.5 to AOT** for the three AOT-covered channels;
**1.0 weight to MMM, 0.0 to AOT** for everyone else.

The fact that this is a CSV — not a hardcoded constant — is the key
operational lever. When MMM's coefficient for a channel goes wrong (e.g.,
the model gives Email an unreasonable cost-per because the prior was too
broad), the team can **adjust the weight upward toward AOT** for that
specific channel-KPI combination without retraining MMM. That's the
recalibration mechanism in practice.

### 4.2 The combination formula

Per (date, channel, network, lob, campaign_super, business_kpi):

$$\text{cost\_per}_{\text{final}} = w_{\text{mmm}} \cdot \text{cost\_per}_{\text{mmm}} + w_{\text{aot}} \cdot \text{cost\_per}_{\text{aot}}$$

with $w_{\text{mmm}} + w_{\text{aot}} = 1$. If AOT cost-per is null (the
channel doesn't have an AOT measurement that day), the row gets
$w_{\text{mmm}} = 1, w_{\text{aot}} = 0$ automatically and the final =
MMM's. If AOT is available, the weight CSV's row decides the split.

### 4.3 Why this is exactly MMM Doc 01 Section 11.3

The Email Simon Data recalibration described in
[MMM Doc 01 Section 11.3](../learning_docs/md/01_mmm_methodology_primer.md#113-email-simon-data-recalibration)
is a *special case* of this combination formula with weight set to give
AOT the dominant share. The MMM-side doc explains the recalibration
math for one channel; this doc shows the **generalized weighting system**
for all AOT-covered channels.

Two ways to think about it:

- From the MMM side: "we recalibrate certain channels by replacing the
  model's prediction with the AOT measurement." MMM Doc 01's framing.
- From the AOT side: "we combine our causal measurement with MMM's broad
  coverage via a weighted average." This doc's framing.

Same operation, different name from each side.

### 4.4 When the weights deviate from 50/50

Per KT 04-01: *"if in case any particular channel hasn't been adjusted
into the expected range in MM... they'll try to adjust it in the
incrementality layer."* Concretely, this means:

- If MMM over-credits a channel (cost-per too low, model says it's a
  great channel but business knowledge says it's not), nudge the weight
  toward AOT (e.g., 0.30 MMM / 0.70 AOT) so AOT's typically-higher
  cost-per dominates.
- If MMM under-credits a channel and AOT is clearly noisy for it,
  nudge the weight toward MMM.
- For channels without AOT, the weight is 1.0/0.0 by definition.

The weight CSV gets **reviewed and adjusted bi-weekly** by the AOT team
in collaboration with the channel leads, alongside the MMM version
rollout. It's an operational lever, not a fixed configuration.

> **Interview angle — "What stops this from being arbitrary?"** Two
> things. (1) The default is 50/50, and any deviation requires written
> rationale (channel-lead alignment, MMM diagnostic flag). (2) The
> weight history is logged — every quarter's weight CSV is committed to
> git, so changes are auditable. The system is not preventing the
> business from over-riding MMM; it's documenting how they do.

---

## 5. Part 4 — Incrementals + Direct vs Halo (NB3 final write)

After computing `cost_per_final`, NB3 calculates incrementals and applies
the direct/halo classification before writing.

### 5.1 The incrementals formula

The "incremental KPI" is the inverse of cost-per. The denominator-vs-
numerator depends on the channel:

| Channel type | Incremental formula |
|---|---|
| Email, OMP | $\text{incremental} = \text{impressions} / \text{cost\_per}$ |
| All other channels | $\text{incremental} = \text{spend} / \text{cost\_per}$ |

The same Email/OMP exception from Section 3.4 — these channels use
impressions because they don't have meaningful per-day spend. For
everything else, dollars-of-spend divided by cost-per gives KPI units
("for $X spend at $Y per KPI, you get $X/Y incremental KPI").

Symmetric "AOT predicted" columns are also computed: $\text{aot\_predicted}
= \text{impressions or spend} / \text{aot\_cost\_per}$. These mostly aren't
consumed downstream (the final cost-per is what matters) but they're
written for transparency and ad-hoc analysis.

### 5.2 The direct vs halo flag

A **halo effect** is when a campaign intended for KPI A *also* drives
KPI B incidentally. Example (from KT 04-01): a Zillow-Home-Loans
campaign aimed at ZHL Submits *also* drives some Rental Visits — same
users sometimes browse rentals after seeing a ZHL ad. That cross-KPI
contribution is a halo effect; it's real, MMM measures it, but the
business cares about it differently than the *direct* contribution.

**The classification rule** is in a config file. Per business KPI, the
config declares which (LOB, campaign_super) combinations are direct
vs halo:

```yaml
direct_halo_mapping:
  Visits:
    direct:
      - {core_campaign_super: Brand}
    # everything else: halo
  FS_Submits:
    direct:
      - {core_campaign_super: Buyer}
    # everything else: halo
  Rental_Visits:
    direct:
      - {core_lob: Rentals Customer, core_campaign_super: Rental}
    # everything else: halo
  ...
```

NB3 reads the config, joins it against each row, and writes the boolean
flag `is_direct_effect` to the output.

### 5.3 Why both are kept

Most stakeholders care about **direct effect** — that's the marketing
budget's primary purpose, and it's what shows in the executive
dashboards. But Zillow is increasingly looking at **halo effects too**
for cross-LOB attribution work. Keeping both in the output table lets
each audience filter to what they need, instead of forcing a single
view.

> **Connection to MMM funnel effects.** The direct/halo distinction here
> is conceptually different from MMM's
> direct-effect-vs-funnel-effect distinction (see
> [MMM Doc 01 Section 8](../learning_docs/md/01_mmm_methodology_primer.md#section-8)).
> MMM's funnel effect is the propagation **between two KPIs sequentially**
> (Visits → FS Submits via the upstream-KPI parent relationship). Direct
> vs halo in *this* doc is about **intent within a KPI** — was the
> campaign aimed at this KPI directly, or did it land on this KPI
> incidentally. The two distinctions can coexist: a Brand campaign's
> contribution to FS Submits via the Visits funnel is a "funnel + direct"
> row (since Brand is the direct campaign type for the parent Visits KPI),
> and a Rental Customer campaign's contribution to FS Submits is a
> "direct + halo" row in *some* operational definitions (rare, but
> possible).

### 5.4 The output write — incremental append, not full overwrite

After all the above, NB3 writes to
`marketing.incrementality_output` (the canonical name) **append-only**
for new dates:

1. Read `MAX(date)` from the table for the current `business_kpi`.
2. Filter the current run's DataFrame to dates > `MAX(date)`.
3. Append those rows.

This is what makes the layer "version-aware incremental" — every version
of MMM produces ~2 weeks of new data; that's what gets written.
Historical rows from prior versions stay frozen in the table.

The exception is the **first-time-build path**, used when a new
table needs to be initialized in a fresh environment. That path reads
the full year and writes everything; it's run once per env, then never
again.

---

## 6. Part 5 — Brand Edition Notebook (TEMPORARY)

NB4 is explicitly flagged as **temporary** — "we'll be using maybe coming
two to three versions only." It exists to patch a specific data-volume
problem and will be removed once enough data accumulates.

### 6.1 The problem

In 2026 the team added new **Brand core campaigns** — a new dimension in
the marketing taxonomy. These campaigns have only ~1–2 months of spend
data by the time the v15+ MMM runs. With so few observations, the
hierarchical Bayesian model can't reliably estimate coefficients for
these new (channel, network, Brand-campaign_super) combinations —
the posterior reverts essentially to the prior, which means the model
predicts approximately **zero contribution** from Brand.

But the channel-lead team and the business *know* Brand has at least
some contribution. The team's prior belief: roughly **5% of baseline
Visits** should attribute to the new Brand channels collectively.

### 6.2 The TVPA model — what it is

"TVPA" in this context appears to refer to a **Time-Varying Parameter
Attribution** model — a lightweight regression that fits brand attribution
on the scaled IDV (independent variable) matrix from MMM. Specifically:

1. Take the **scaled independent variables** that MMM uses (the adstocked-
   and-Hill-saturated impression columns).
2. Take the **MMM intercept** posterior (the baseline KPI level driven by
   non-marketing factors — seasonality, macros, organic).
3. Fit a fresh regression with:
   - **Intercept prior at 95%** of baseline visits → almost all baseline
     stays where MMM put it.
   - **Brand prior at 5%** of baseline visits → 5% of what MMM attributed
     to baseline gets reattributed to Brand.
   - The 5% is **split equally** across all (channel, network)
     combinations under the Brand campaign super, unless the config
     specifies a non-uniform split (e.g., 0.1 weight to Brand-Linear-TV,
     0.05 elsewhere).

> **Inline flag — "TVPA" definition.** The KT transcript says "TVPA
> model" without spelling out the acronym; my reading "Time-Varying
> Parameter Attribution" is inferred from the methodology described. The
> codebase imports it from a separate Python script. If you're using the
> term in front of stakeholders, the safe phrasing is "the
> brand-attribution model" — the acronym is internal jargon.

### 6.3 The output processing

Once the TVPA model produces brand contribution estimates per
(channel, network, day), the notebook applies **the same
post-processing as NB3**:

1. Inverse adstock the predictions (same per-channel decay parameters).
2. Daily proportioning from weekly via impressions ratio (same logic as
   Section 3.3).
3. Apply 7-day moving average for smoothing.
4. Construct a row schema **identical to NB3's output** so the result
   can be appended to `marketing.incrementality_output`.
5. Set `weight_mmm = 1.0, weight_aot = 0.0` (there's no AOT for Brand;
   the TVPA-derived contribution acts as the MMM contribution for these
   rows).

The incremental column is computed from the brand-attributed
contribution; the cost-per becomes spend ÷ brand-contribution, joined to
the marketing-metrics table for actual spend.

### 6.4 The exclusion logic — don't overwrite MMM

The critical guardrail: **if a (channel, network) combination already
has a Brand prediction in the MMM output**, NB4 must NOT overwrite it.
The MMM output is the source of truth where it has signal; NB4 only fills
the gap for the new-2026 channels that MMM couldn't fit.

Mechanically:

1. Before writing, read all `(channel, network)` combinations in
   `marketing.incrementality_output` for the current version that have
   `core_campaign_super = "Brand"` and non-null predictions.
2. Filter the NB4 output to exclude those combinations.
3. Append only the rows for combinations not yet present.

The same `replaceWhere` semantics used elsewhere in the MMM pipeline (see
[MMM Doc 00 Section 7](../learning_docs/md/00_mmm_ecosystem_overview.md#section-7)
for idempotent-write patterns) prevent double-writes during reruns.

### 6.5 Scope limitation — Visits KPI only

As of the KT snapshot, NB4 is wired up **only for the Visits KPI**. The
team hasn't yet extended it to FS Submits, ZHL Submits, Rental Visits,
or MF Submits — partly because those KPIs already get a small
brand-contribution via funnel effects from Visits (see
[MMM Doc 01 Section 8](../learning_docs/md/01_mmm_methodology_primer.md#section-8)),
and partly because the model fit gets unstable with smaller per-KPI
data. The 5% direct-Brand attribution to Visits propagates to lower-funnel
KPIs via MMM's funnel-effect rows in `mmm_model_combined_output_overall_level`,
so the impact lands downstream.

### 6.6 The sunset plan

The notebook is **temporary**. The plan: as Brand spend accumulates
across 2026 and into 2027, MMM's standard hierarchical Bayesian model
will eventually have enough data to learn the Brand coefficients
properly. Once it does — measured by Brand's standard error in the MMM
posterior dropping below a threshold — NB4 is decommissioned. Until
then, it patches the gap.

> **Interview angle — "Why not just use a stronger prior in MMM
> instead?"** Could you set an informative prior on Brand coefficients
> in MMM directly? Yes, but it requires retraining MMM, which is the
> expensive step you want to keep fixed across runs. The incrementality
> layer is the right place for these patches because it operates on MMM
> *outputs*, can be iterated quickly, and is the audited "calibration"
> stage that already has documented adjustment authority. Embedding the
> 5% Brand assumption in MMM priors would mean every prior calibration
> change requires re-fitting; embedding it in NB4 means it's a config
> change.

---

## 7. Part 6 — Response Curves (NB5)

NB5 takes the calibrated cost-per from NB3+NB4 and **fits a Hill response
curve** per (KPI, channel, network, campaign_super), mirroring exactly
what MMM does in its own response-curve notebook (see
[MMM Doc 07 Part A](../learning_docs/md/07_fs_submits_response_curves_and_stability.md#part-a-notebook-7-overall-response-curves)).
The structure is the same; the *inputs* are the recalibrated
incrementality-layer predictions rather than the raw MMM ones.

### 7.1 What gets fit

Per (KPI, channel, network, campaign_super), a Hill function:

$$f(x) = \text{bottom} + \frac{(\text{top} - \text{bottom}) \cdot x^{\text{slope}}}{x^{\text{slope}} + \text{saturation}^{\text{slope}}}$$

where $x$ is spend (or impressions for Email and OMP), and $f(x)$ is the
predicted KPI. The four parameters — **bottom, top, slope, saturation**
— are fit by `scipy.optimize.curve_fit` against the (spend, predicted)
data points from the past year of incrementality-layer output.

For the math behind why this functional form (S-shape with floor and
ceiling, monotone increasing, concave at high spend) is right for
marketing, see
[MMM Doc 01 Section 4.2](../learning_docs/md/01_mmm_methodology_primer.md#section-4-2)
and
[MMM Doc 07 Section A2](../learning_docs/md/07_fs_submits_response_curves_and_stability.md#a2-input-data--reading-the-combined-gold-table).

### 7.2 Aggregation grain

Aggregated to `(channel, network, campaign_super)` — *not* per-DMA. The
incrementality layer's job is to produce a **national-level** calibrated
response curve, not the DMA-level curves MMM also produces. (DMA-level
curves stay in the MMM output and aren't recalibrated here; only the
national rollup is.)

### 7.3 Filtering combinations with too few points

Channels with sparse data (e.g., a channel that just started spending,
or one that has only a handful of weeks of meaningful spend) are
**excluded from the curve fit**. The rule (per KT 04-02): a minimum count
of data points is required, configurable, typically ~52 weeks worth at
weekly grain ≈ 52 rows, or ~365 at daily. Combinations below the
threshold are flagged in the output with a "insufficient_data" status
and don't have a curve fit. Downstream consumers handle these by falling
back to the raw incrementals (Section 8.5).

### 7.4 `predict_stability` — the curve-quality gate

After fitting, the codebase calls **`predict_stability`** (the same
function name MMM Doc 07 uses — see
[MMM Doc 07 Section A5](../learning_docs/md/07_fs_submits_response_curves_and_stability.md#a5-the-numerical-stability-sanity-check)).
The check:

1. Generate a grid of test spend values (typically 150 points from 0 to
   1.5 × max observed spend).
2. Run the fitted Hill function on each.
3. Compare the predicted values to the actual observed predictions on
   the same spend levels (where they overlap).
4. Compute the **mean ratio** of predicted-curve-value to actual-input:

   $$\rho = \frac{1}{n} \sum_i \frac{f(\text{spend}_i)}{\text{predicted}_i}$$

5. Check: if $\rho$ is within a tolerance band of 1.0 (say [0.9, 1.1]),
   the curve is "stable." Otherwise, the curve is flagged "unstable" and
   the team applies the scale factor + bias correction below.

> **Why this matters.** Hill-fitting on noisy or limited data can produce
> mathematically valid parameters that nevertheless don't reproduce the
> input — extreme `slope` values, saturation points orders of magnitude
> outside observed spend, etc. `predict_stability` is the empirical
> sanity check: does the fitted curve actually behave like the data it
> was fit to? When it doesn't, downstream forecasting needs to know.

### 7.5 Scale factor and bias adjustments

For curves that fail `predict_stability`, two corrections are applied
before the curve is sent to forecasting:

#### Scale factor (multiplicative)

$$\text{scale\_factor} = \frac{1}{\rho}$$

— the inverse of the mean predicted/actual ratio. This is then **clipped
to [0.75, 1.5]**:

- If $\rho > 1.33$ (curve predicts way higher than actual) → raw scale
  factor < 0.75, clipped to 0.75. Curve predictions get scaled down by
  25% rather than infinity.
- If $\rho < 0.67$ (curve predicts way lower) → raw scale factor > 1.5,
  clipped to 1.5. Predictions scaled up by 50% rather than infinity.
- In between: scale factor applied as-is.

The clipping prevents pathological corrections from dominating the
forecast; if a curve needs more than a 1.5x correction, the team would
rather flag the curve as broken and fall back to raw incrementals than
apply a 5x scaling factor that's almost certainly wrong.

#### Bias (additive)

After the multiplicative scale is applied, a residual additive bias
might remain. Compute:

$$\text{bias} = \overline{\text{predicted}_i} - \overline{\text{scale\_factor} \cdot f(\text{spend}_i)}$$

— the residual offset that makes the calibrated curve's *average* match
the actual prediction's average. This is **not clipped** (additive
corrections are inherently bounded by the data scale).

#### Why both?

Multiplicative scaling matches the *shape* of the curve to the data;
additive bias matches the *level*. The two together calibrate both axes
of mismatch without one having to do the work of the other. Order
matters: apply scale factor first (multiplicative), then bias (additive)
to what's left.

#### Storage

Both values are written to a **ratio table** — call it
`marketing.incrementality_response_curve_ratios`:

| Column | Meaning |
|---|---|
| `business_kpi` | Visits, FS Submits, etc. |
| `channel`, `network`, `core_campaign_super` | Aggregation grain |
| `bottom`, `top`, `slope`, `saturation` | Hill parameters from fit |
| `is_stable` | Boolean from `predict_stability` |
| `scale_factor` | Multiplicative, clipped to [0.75, 1.5] |
| `bias` | Additive |
| `version` | MMM version this curve was fit for |
| `p_data_date` | When written |

The forecasting layer reads this table and applies both corrections in
the order above.

### 7.6 Run-once-per-KPI

NB5 runs **5 times** — once per KPI — because each KPI has its own
response-curve set. The same notebook code runs with the KPI passed as
a widget parameter, the same way MMM's per-KPI notebooks parameterize.
The output writes per KPI to the ratio table.

---

## 8. Part 7 — Forecasting (NB6)

The final notebook. NB6 takes the response curves (Hill parameters + scale
factor + bias) and projects forward into 2026 (or whatever the planning
horizon is) using the marketing team's **planned budget** as input.

### 8.1 The inputs

Two main inputs:

1. **Planned budget table** — `marketing.aop_planned_budget` (or similar).
   The marketing team's forward-looking budget plan. Typically at
   **month-level** grain by `(channel, network, lob, campaign_super)`. Email
   and OMP are at impression-target grain, not spend.
2. **Response-curve ratio table** from NB5 — the Hill parameters + scale
   factor + bias.

### 8.2 Re-graining month → week

The planned budget is monthly; the forecast operates at weekly grain to
match everything else. Mechanically, each month's budget is split into
its constituent weeks **proportional to the number of days each week
contributes to the month**. A week that crosses a month boundary gets
prorated.

Example: a $1M monthly budget for January where January has 4 weeks of 7
days each and 3 leftover days that fall into the last week of December
or the first week of February:

- Weeks fully inside January get $1M × (7/31).
- The week ending in early February gets a partial share.

Same logic as MMM's planning-week-Monday conversion — see
[MMM Doc 04 Section 1](../learning_docs/md/04_data_lineage_and_schemas.md)
for the calendar table that drives the proration.

### 8.3 Apply the response curve

For each (week, channel, network, campaign_super, KPI):

$$\text{raw\_prediction}_w = \text{bottom} + \frac{(\text{top} - \text{bottom}) \cdot \text{spend}_w^{\text{slope}}}{\text{spend}_w^{\text{slope}} + \text{saturation}^{\text{slope}}}$$

— direct Hill evaluation at the planned spend. This is the
**uncalibrated** forecast.

### 8.4 Calibrate with scale factor and bias

$$\text{forecast}_w = \text{scale\_factor} \cdot \text{raw\_prediction}_w + \text{bias}$$

Then divide by spend to get **cost-per-submit forecast**:

$$\text{cost\_per\_submit}_w = \frac{\text{spend}_w}{\text{forecast}_w}$$

For Email and OMP, substitute impressions on the denominator the same way.

### 8.5 The multiplier table

A separate config table — `marketing.forecast_multipliers` — allows
**manual per-channel multiplicative adjustments**. Per KT 04-02, the
multiplier is currently set to 1.0 everywhere — i.e., not used in
production today — but the infrastructure exists so the channel-lead
team can apply business-knowledge corrections without code changes.
Example: "we're launching a major creative refresh in Q3, expect 1.15x
performance on Display."

Formula:

$$\text{forecast}_w^{\text{final}} = m_{\text{multiplier}} \cdot (\text{scale\_factor} \cdot \text{raw\_prediction}_w + \text{bias})$$

Currently $m_{\text{multiplier}} = 1$ for all rows; the column is reserved
for future use.

### 8.6 Direct vs Halo at the forecast level

Same flag as NB3 (Section 5.2). The forecast table inherits the
direct/halo classification from the same config so the forecast can be
filtered to direct-effect-only rows for the primary dashboard view, and
halo rows are available for cross-LOB attribution work.

### 8.7 The historical-retention rule

This is the most operationally important rule in NB6: **previous
months' forecast values must not change when a new MMM version reruns**.

The scenario: it's March 15. The marketing team has already published
January and February forecasts based on v29's response curves. Now v30
runs. The new response curves are slightly different (model is updated
with two more weeks of data, posterior shifted slightly). If the
forecasting layer naively recomputes everything from v30's curves, the
Jan/Feb forecast numbers will change — even though those months are
already in the past and the team has committed to them.

**The fix.** Before writing the new forecast, NB6 reads the **existing
forecast table** for the prior version. For any month whose end date
is before the run date (i.e., already completed), it pulls the prior
table's values **unchanged**. Only future months get the new computation
applied. The two are concatenated and written.

Mechanically:

```text
existing = read marketing.forecast_output FROM v_prev
new_runs = compute from v_curr response curves
output = concat:
  existing where month_end < today
  new_runs where month_end >= today
write to marketing.forecast_output FOR v_curr
```

Operationally important: this protects the AOP narrative from
appearing "revisionist" — the team can't seem to be revising past
forecasts every two weeks when MMM reruns. Past months are frozen the
moment they pass.

### 8.8 Unstable-curve fallback

For (channel, network, campaign_super) combinations where NB5 flagged
the response curve as **unstable** (`is_stable = False` in the ratio
table), the forecasting code **doesn't use the curve at all**. Instead,
it falls back to **the raw incrementals from NB3** — taking the
historical average cost-per from the past year and projecting it forward
flat. Less sophisticated than a fitted curve, but more reliable than a
bad curve.

The decision tree per row:

```text
if curve is stable:
    use Hill curve + scale_factor + bias
else:
    use historical mean incrementals (flat)
```

This makes the forecasting layer **robust to the worst case where the
curve fit goes wrong** — the system always produces *some* forecast, and
unstable curves degrade gracefully rather than producing extreme values.

### 8.9 Merge with AOP targets

The last step: merge the forecast against the **Annual Operating Plan
(AOP) targets** the marketing team has manually set based on business
goals. The AOP target table:

| Column | Meaning |
|---|---|
| `business_kpi` | The KPI |
| `month` | Year-month |
| `aop_target` | The marketing team's manually-set target value for that month |
| `core_lob`, etc. | Standard grain |

The merge produces a row per (forecast date, KPI, channel, ..., AOP-target)
that the visualization layer can plot as "predicted vs target" — the
go-to view for marketing leadership reviews.

### 8.10 The final write

```text
marketing.forecast_output  -- the final consumer artifact
```

Schema includes all the standard taxonomy columns + `forecast_cost_per`,
`forecast_predicted_KPI`, `forecast_planned_spend`, `aop_target`,
`is_direct_effect`, `is_stable_curve`, `version`, `p_data_date`.

This is the table that downstream Tableau dashboards, the budget
allocator, and the AOP planning team all read. It's the **terminal
artifact** of the whole AOT + MMM pipeline.

---

## 9. The full end-to-end picture — what it means in practice

To pull everything together, walk through one example: **what does
Email's recalibrated forecast look like for Q3 2026?**

1. **Doc 01's Email AOT** has been running quarterly all year. The
   `email_pooled_results` table has daily cost-pers for Email at
   campaign-super grain since Jan 2024.
2. **MMM v30** runs in late March 2026, producing a posterior over
   Email's adstock-Hill coefficients via NUTS.
3. **NB1+NB2** (Part 1 of this doc) pull the past year of Email AOT,
   apply the cleaning pipeline (date imputation → MA → zero invalid
   → cap p95), expand to LOB level, write the AOT intermediate table.
4. **NB3** (Part 2 + 3) reads MMM v30's Email predictions, inverse
   adstocks them, proportions to daily, computes day-level MMM
   cost-per. Then combines 50/50 (weight CSV row for Email) with the
   AOT cost-per from step 3. Result: a single daily Email cost-per per
   (LOB, KPI) for the past year.
5. **NB5** (Part 6) reads the past year of Email cost-pers from NB3,
   fits a Hill curve at `(Email, Simon Data, campaign_super)` grain
   for each of the 5 KPIs, runs `predict_stability`, computes scale
   factor and bias.
6. **NB6** (Part 7) reads the planned Email budget for Q3 2026, applies
   the calibrated Hill curve, multiplies by the (currently 1.0)
   multiplier, applies the direct/halo flag, applies the historical-
   retention rule (Jan/Feb forecasts unchanged from v29), and merges
   with the AOP targets.
7. The result lands in `marketing.forecast_output` as rows like:

   ```
   week=2026-07-06, channel=Email, network=Simon Data, lob=Rentals,
   campaign_super=Rental, business_kpi=Rental_Visits,
   forecast_planned_spend=null (impressions=X for email),
   forecast_predicted=12,400 rental visits,
   forecast_cost_per_impression=0.0024,
   aop_target=11,500, is_direct_effect=True, version=v30
   ```

8. The Tableau dashboard plots predicted (12,400) vs target (11,500)
   for the Rentals Customer team to review. They see Email is forecast
   to overshoot target — good news. The budget allocator (downstream of
   this output) uses the response curve to suggest reallocating ~5%
   of Email's Q3 budget to channels currently underperforming target.

That whole chain — AOT data quality, AOT-MMM weighted combination,
inverse adstock, daily proportioning, response-curve fit with
stability check, scale-factor + bias correction, AOP merge — is what
"the incrementality layer" means in production.

---

## 10. Operations + interview prep

### 10.1 What runs when

The incrementality layer runs **bi-weekly, immediately after the MMM job
completes**. Same Databricks Asset Bundle (DAB) deployment pattern as
MMM (see
[MMM Doc 09](../learning_docs/md/09_operations_and_interview_capstone.md)):

| Notebook | Cadence | Cluster |
|---|---|---|
| NB1 (AOT collect) | Bi-weekly after MMM | CPU (Spark SQL) |
| NB2 (AOT transform) | Bi-weekly after NB1 | CPU |
| NB3 (combine) | Bi-weekly after NB2 + MMM | CPU |
| NB4 (brand edition) | Bi-weekly after NB3 | CPU |
| NB5 (response curves × 5 KPIs) | Bi-weekly after NB4 | CPU |
| NB6 (forecasting) | Bi-weekly after NB5 | CPU |

All CPU — no NUTS sampling here. The Hill curve fits via `scipy.curve_fit`
are negligible compute compared to MMM's NUTS, so the whole layer
finishes in ~10 minutes.

### 10.2 Where the artifacts live

| Table | Layer | Role |
|---|---|---|
| `marketing.incrementality_combined` | Intermediate | Raw AOT, overwritten each run |
| `marketing.incrementality_combined_transformed` | Intermediate | After per-channel transforms |
| `marketing.incrementality_output` | Gold | The headline incrementals + cost-pers table; append-only after v15 |
| `marketing.incrementality_response_curve_ratios` | Gold | Hill params + scale factor + bias per (KPI, channel, network, campaign_super) |
| `marketing.forecast_output` | Gold | The final forecast vs AOP table — the "single source of truth" for marketing |

### 10.3 Interview-style questions

> 1. **"Walk me through the incrementality layer end-to-end."** Use
>    Section 1's flow diagram. Hit AOT collection → per-channel
>    transforms → MMM read with inverse adstock → daily proportioning
>    → 50/50 weighting → incrementals → direct/halo → response-curve
>    fit with stability check → scale-factor and bias → forecasting
>    with historical retention.
> 2. **"Why inverse adstock?"** Section 3.2. MMM predicts in adstocked-
>    impression space; cost-per needs raw-impression space to be
>    comparable to spend.
> 3. **"Why weight CSV instead of hardcoded 50/50?"** Section 4. The
>    weight is an operational lever for recalibrating channels MMM
>    hasn't fit well, without retraining MMM. Default 50/50 for
>    AOT-covered channels, 1.0/0.0 for others, tunable per channel.
> 4. **"Direct vs halo — what's the difference?"** Section 5.2. Direct
>    = campaign intended for this KPI; halo = campaign intended for
>    another KPI but lands incidentally on this one. Different from
>    MMM's direct-vs-funnel distinction.
> 5. **"What's the brand-edition notebook and why is it temporary?"**
>    Section 6. Patches the data-volume problem for newly-added 2026
>    Brand campaigns. 95/5 prior split, equally distributed across
>    Brand channels. Excludes channels MMM has already fit. Wired only
>    for Visits. Decommissioned when Brand spend history accumulates
>    enough for MMM to fit it directly.
> 6. **"How are response curves built here different from MMM Doc 07's?"**
>    Same Hill fit, same machinery. The *difference* is the input data:
>    here we use the post-recalibration combined cost-pers, not MMM's
>    raw output. The fitted curve is the **calibrated response curve**,
>    not MMM's raw one.
> 7. **"What does `predict_stability` actually check?"** Section 7.4.
>    Mean ratio of curve-predicted to actual-input on the historical
>    spend. Within [0.9, 1.1] → stable; outside → flag and apply
>    correction.
> 8. **"Scale factor clipped at [0.75, 1.5] — why?"** Section 7.5. Bounds
>    how much the calibration can adjust the curve. If a curve needs
>    more than a 1.5x correction, it's broken and the forecasting
>    layer falls back to raw incrementals rather than applying an
>    extreme multiplier.
> 9. **"Why doesn't NB6 recompute past months' forecasts?"** Section 8.7.
>    Historical-retention rule: the marketing team has committed to
>    past forecasts; revising them every two weeks would erode trust
>    and produce revisionist-looking dashboards.
> 10. **"How does the unstable-curve fallback work?"** Section 8.8.
>     Where `predict_stability` flagged a curve as unstable, NB6 uses
>     the historical mean incrementals from NB3 instead of the curve.
>     Degrades gracefully — always produces *some* forecast.

---

## 11. Where this connects back

You've now walked the entire AOT library. To zoom out:

- **[Doc 00](00_aot_ecosystem_and_foundations.md)** — the foundations
  (DiD, stratified sampling, power analysis, the validation toolkit).
- **[Doc 01](01_existing_aot_systems.md)** — the three legacy AOT
  systems (Email, Paid Social FB, SEM) whose pooled-results feed
  this layer's NB1.
- **[Doc 02](02_geo_stratification_design.md)** — the new geo-
  stratification design that will (over time) replace the legacy
  per-channel SEM AOT and extend to more channels.
- **[Doc 03](03_dark_period_tv.md)** — TV dark-period testing for
  channels where neither user nor geo holdouts work.
- **This doc** — the post-pipeline fusion: take all of the above, weight
  against MMM, produce response curves, produce forecasts, deliver to
  the budget allocator and AOP planning team.

And to the MMM library:

- **MMM Doc 00** for the bigger picture.
- **MMM Doc 01 Section 11.3** for the Email Simon Data recalibration
  that's a special case of this doc's 50/50 weighting.
- **MMM Doc 05 NB2** for the upstream MMM-side AOT hook.
- **MMM Doc 07** for the response-curve fitting that NB5 mirrors.
- **MMM Doc 08** for the per-KPI differences (all 5 KPIs go through
  this layer).
- **MMM Doc 09** for the DAB deployment pattern this layer reuses.

The end of one library is the start of the next. AOT measures; MMM
models; the incrementality layer marries them; the budget allocator and
AOP planning team decide. That's the whole picture.

---

**Next:** There is no Doc 05. This is the terminal doc of the AOT
library. From here, the natural follow-ups are:
- The **budget allocator** that consumes `forecast_output` — outside
  this library's scope; lives in a separate repo.
- The **measurement notebooks** for the new geo design (Doc 02) and
  dark-period design (Doc 03) — still WIP in Causal Lab as of the KT
  snapshot. When they ship, this doc gets revised to consume their
  outputs alongside the legacy three.
- The **dashboards** built on top of `forecast_output` —
  Tableau-side artifacts the Aishwaria thread covers separately.

Welcome to the end of the library. Go review your interview answers.
