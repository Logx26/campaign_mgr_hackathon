---
title: NEW Geo Stratification & Holdout Design (Jesmma's Track)
description: The canonical deep dive on Zillow's new AOT geo-stratification design — composite scoring, K-means-elbow stratification into 6 tiers, 5,000-trial balanced cell assignment, the full Levene + ANOVA + Mood's + ICC + parallel-trends validation suite, Latin-square rotation with 10% overlap cap, power-driven 5-DMA-per-LOB holdout selection, and the Causal Lab package that operationalizes all of it.
---

# 02 — NEW Geo Stratification & Holdout Design

> **What this doc is.** The deepest doc in the library. A step-by-step
> walkthrough of the new geo-experiment design that replaces the legacy SEM
> push/pull described in [Doc 01 Section 5](01_existing_aot_systems.md#section-5)
> with a properly stratified, statistically validated, Latin-square-scheduled
> holdout-selection pipeline — and the Python package (Causal Lab) that ships it.
>
> **What this doc is not.** A re-derivation of the foundations. We assume
> you've read [Doc 00 Sections 5–6](00_aot_ecosystem_and_foundations.md#section-5)
> for DiD, stratified sampling, power analysis, ANOVA / Welch / Levene / SMD /
> Mood's / ICC, VRF — those are the toolkit; this doc applies the toolkit. If
> any concept feels thin, jump back to Doc 00 first.
>
> **Primary sources.** Jesmma's 2026-03-20 KT (the canonical narrative);
> Tharun's 2026-03-23 KT (the Causal Lab code walkthrough); the
> `geo_holdout_tactic.ipynb` notebook (110 cells, the canonical
> implementation); `Overview of 24 and 23rd KT.txt` (formulas — flagged where
> transcription-mangled). Cross-link to
> [MMM Doc 06](../learning_docs/md/06_fs_submits_taxonomy_track.md) for the
> taxonomy grain the final matrix must align to and
> [MMM Doc 04](../learning_docs/md/04_data_lineage_and_schemas.md) for the
> source tables.

---

## 1. Motivation — why a new design

The legacy SEM AOT (Doc 01 Section 4) and the legacy Email AOT (Doc 01
Section 2) both work fine for one thing each — SEM is geo-targetable and
Email is user-targetable — but they share three structural weaknesses that the
new design exists to fix.

**Weakness 1: only three channels are covered, and the rest of the spend has
no causal measurement at all.** Zillow spends across ~25 channel-networks (see
[MMM Doc 00 Section 6](../learning_docs/md/00_mmm_ecosystem_overview.md#6-table-inventory)).
Outside of SEM, Paid Social, and Email, the only measurement is MMM — which is
correlational, fit on aggregated observational data, and structurally weakest
on channels whose spend levels rarely move. The new design is built to scale
geo-experimentation to *every* geo-targetable channel: Programmatic Display,
Affiliate, geo-targeted Connected TV, and so on.

**Weakness 2: legacy SEM holdouts aren't actually comparable.** The legacy
DMA selection is "shuffle the 210 DMAs randomly, pick 4–6 whose population
sums to roughly 4% of the US, manually swap out NY / TX on channel-team
request." That gives you a holdout that satisfies a population constraint but
nothing else — the holdout DMAs might be systematically higher-conversion,
lower-conversion, or differently-seasonal than the control DMAs, and the DiD
estimator will silently inherit all of that as bias. The new design enforces
*demonstrable comparability* of holdout and control on every dimension the
team cares about: KPI levels, economic environment, population, and
pre-period trends.

**Weakness 3: legacy SEM holdout-size is set by population, not by power.**
Holding out 4–6 DMAs because their population sums to 4% is a *cost*
constraint dressed up as a statistical one. The new design starts from the
question that should drive holdout sizing: *what's the smallest holdout that
still detects the lift effect-size we care about with adequate power?* The
answer — derived from formal power analysis (Section 9) — is **5 DMAs per
LOB**, not 4–6 chosen for population.

**The design goals** that follow from those three weaknesses:

1. **Generalizable across channels.** Same design ought to support SEM, Paid
   Social (the geo-aggregable parts), Display, Affiliate, and geo-CTV.
2. **Statistically defensible comparability** — every holdout vs control
   comparison passes a battery of tests (SMD, ANOVA, Mood's, parallel-trends
   at three time horizons), and those tests are run *before* the experiment
   starts.
3. **Power-driven sizing.** 5 DMAs per LOB per quarter, justified by
   $n \approx 2\sigma^2 (z_{1-\alpha/2} + z_{1-\beta})^2 / \delta^2$ for a
   target minimum-detectable lift (see Section 9 for the derivation).
4. **Latin-square rotation** that prevents the same DMA from being the
   holdout DMA for the same LOB in consecutive quarters (>10% overlap is
   rejected) — without which the holdout DMAs would "starve" and the
   business would push back on operating losses.
5. **Packaged, config-driven, MLflow-tracked** — modeled on `rapidmmm`
   ([MMM Doc 02](../learning_docs/md/02_rapidmmm_library_internals.md)), so
   that any per-quarter run is reproducible and the per-quarter outputs are
   traced back to a parameter snapshot.

The rest of the doc walks the pipeline end-to-end. The big picture, before
the details:

```
┌─────────────────────┐
│ 1. Pull DMA-week    │   marketing.marketingde_gold.mmm_business_metrics
│    metrics + pop    │   marketing.marketingde_silver.mmm_regionmapping
└──────────┬──────────┘
           │
           ▼
┌─────────────────────┐
│ 2. Pre-process      │   non-zero filter → outlier cap p99 → log1p
│                     │   skewness check, distribution plots
└──────────┬──────────┘
           │
           ▼
┌─────────────────────┐
│ 3. Composite score  │   0.70 × KPI-mean + 0.25 × econ-mean + 0.05 × pop
│                     │   (after normalization to [0, 1])
└──────────┬──────────┘
           │
           ▼
┌─────────────────────┐
│ 4. Stratify         │   K-means elbow on composite → 6 strata
│                     │   quantile-cut on score, ordered by mean
│  Validate:          │   monotonicity, CV per stratum, VRF,
│                     │   ANOVA (want REJECT), Levene, Mood's, ICC
└──────────┬──────────┘
           │
           ▼
┌─────────────────────┐
│ 5. Cell-assign      │   5,000 trials shuffling within strata → pick
│                     │   the trial with the lowest balance score
│  Validate:          │   CV across cells, SMD, ANOVA (want FAIL TO REJECT),
│                     │   Levene, Mood's, ICC, parallel-trends (monthly,
│                     │   weekly, daily — all KPIs)
└──────────┬──────────┘
           │
           ▼
┌─────────────────────┐
│ 6. Latin square     │   n_slots × n_cells assignment, max_overlap_pct=10
│    over LOB × slot  │   vs prior quarter, up to 1000 attempts
└──────────┬──────────┘
           │
           ▼
┌─────────────────────┐
│ 7. Apply exclusions │   business-driven DMA-LOB exclusions (NY for X,
│                     │   TX for Y) from config
└──────────┬──────────┘
           │
           ▼
┌─────────────────────┐
│ 8. Holdout select   │   one DMA from each stratum within the holdout
│                     │   cell → 5 DMAs/LOB; control = all non-holdout
│  Validate:          │   pooled SMD (Cohen's d) per (cell, KPI); Welch /
│                     │   Kruskal-Wallis / Mood's per slot×KPI with
│                     │   Bonferroni and FDR-BH corrections; parallel-
│                     │   trends (monthly, weekly, daily — holdout vs
│                     │   control)
└──────────┬──────────┘
           │
           ▼
┌─────────────────────┐
│ 9. Write final      │   {catalog}.{gold_schema}.holdout_schedule
│    matrix           │   one row per slot × LOB with holdout_dmas,
│                     │   control_dmas, start/end dates, experiment_id
└─────────────────────┘
```

Pin that picture; the rest of the doc fills in each box.

---

## 2. Inputs — what goes into the design

The design works on a **DMA-level snapshot** of three categories of metric,
aggregated over a recent window (typically 2–3 months ending at the design
date). Notebook cell 17 calls `data_prep.load_and_prepare` with
`start_date='2025-12-01', end_date='2026-02-28'` — a three-month window
ending at the quarter boundary.

### 2.1 Business KPIs (70% weight)

The same five KPIs the MMM models — see
[MMM Doc 08](../learning_docs/md/08_other_kpis_comparative.md):

| KPI | Source column | Why included |
|---|---|---|
| **Visits** | `value\|visits\|visits` | The broadest top-of-funnel signal; sets the size of the consumer pool we're measuring against |
| **FS Submits** | `value\|leads\|fs_submits` | The primary monetizable Zillow conversion (Premier Agent connections) |
| **ZHL Submits** | (ZHL contact table) | Zillow Home Loans — separate revenue line, separate response curve |
| **Rental Visits** | `value\|rentalsmetrics_zillowbrand\|rental_visits` | Independent top-of-funnel for the Rentals business |
| **MF Submits** | `value\|rentalsmetrics_zillowbrand\|fr_bdp_submits` | Multi-Family rental conversions |

Source table is the same `marketing.marketingde_gold.mmm_business_metrics`
that MMM reads, pivoted long → wide so each DMA is one row with the five KPI
columns. The non-zero filter in cell 21 drops DMAs with any zero KPI in the
window — small DMAs where Zillow has effectively no presence — leaving
**~180 of the 210 Nielsen DMAs**. Jesmma's KT calls this "180+ DMAs" because
the exact count varies slightly window-to-window.

> **Why 70% weight to KPIs?** The composite score's job is to stratify DMAs
> so that *DMAs in the same stratum produce similar measurements during the
> experiment*. The KPIs *are* the measurements, so they get the dominant
> weight. Two DMAs with identical KPI levels but different econ profiles will
> still likely produce similar visit/submit counts in the test — they belong
> in the same stratum. Two DMAs with identical econ profiles but very
> different KPI levels will not — they belong in different strata.

### 2.2 Economic variables (25% weight)

These are the macro controls the MMM also uses as exogenous covariates (see
[MMM Doc 04 Section 4](../learning_docs/md/04_data_lineage_and_schemas.md#section-4)
for the feature store). Concretely they include:

- **Median household income** per DMA
- **Mortgage rate environment** (national, but the response is DMA-modulated)
- **Unemployment rate** per DMA
- **Google Trends** indices for `zillow`, `homes for sale`, etc.

> **Inline flag — exact list.** The KT transcript names "confirmed economic
> metrics" but doesn't enumerate them. The list above is what the codebase
> reads from `customer.metrics.library` and the exogenous feature store. The
> precise variable set per quarter is in the YAML config — see Section 14.2.
> Treat the variable list above as the typical set rather than canonical.

**Why econ matters for stratification.** Macroeconomic conditions move
together within a DMA (Boston is always a high-income, low-unemployment DMA;
McAllen-Brownsville is the opposite) but they explain a meaningful share of
the residual variance in KPIs *after* you control for the KPIs themselves.
That's why econ gets a non-trivial 25% — not as much as KPIs, but enough to
break ties between DMAs that look identical on KPIs.

### 2.3 Population (5% weight)

A single number per DMA — `populationcnt` from
`marketing.marketingde_silver.mmm_regionmapping` (the same table MMM uses for
DMA-name lookup; see
[MMM Doc 04 Section 1](../learning_docs/md/04_data_lineage_and_schemas.md)).
Cell 19 pulls it via the SQL filter `p_data_date = (SELECT MAX(p_data_date)
FROM ...)` so we always get the most recent population snapshot.

**Why population gets the lowest weight.** Population is *highly correlated*
with the KPI levels — bigger DMAs have more visits — so including it at high
weight would double-count what KPIs already capture. The 5% serves as a
tiebreaker: when two DMAs are similar on KPIs and similar on econ but one is
markedly larger than the other, population steers them into different
strata. Without that tiebreaker, the stratification can put a 5M-person DMA
and a 500K-person DMA in the same stratum if their per-capita KPIs happen to
match, and the experiment's variance will be dominated by the big DMA.

### 2.4 The grain — DMA-level aggregate, not DMA-week

Critically, **stratification is done on a DMA-level aggregate over the window,
not on the DMA-week panel**. The notebook builds `df` (the aggregated, one-
row-per-DMA snapshot) for stratification, and separately `input_df` (DMA-week
weekly panel) and `input_df_daily` (DMA-day daily panel) which are used only
for the parallel-trends validation in Section 7. Three different
representations of the same data, used for three different purposes:

| DataFrame | Grain | Used for |
|---|---|---|
| `df` | DMA (one row per DMA) | Composite score, stratification, cell assignment, holdout selection |
| `input_df` | DMA × week | Weekly parallel-trends check |
| `input_df_daily` | DMA × day | Daily parallel-trends check |

---

## 3. Pre-processing — outliers and skewness

DMA-level KPI data is heavily right-skewed: a few big DMAs (LA, NYC) sit far
above the median and an even smaller number of huge ones (the top 5%) sit
above those. Two standard fixes — applied in that order:

### 3.1 Outlier capping at the 99th percentile

Cell 24 calls `data_prep.cap_at_percentile_df(df, lower_percentile=0,
upper_percentile=99)`. Mechanically, for each metric column, compute the
99th-percentile value across DMAs and `np.clip` everything above to that
value. The lower bound is 0 (we don't cap the floor).

> **Why cap, and why at p99?** Two reasons. (1) The composite score
> normalizes each metric to a 0–1 range, and an extreme outlier would
> compress the rest of the DMAs into a tiny portion of that range —
> destroying the discriminating power of the score for the 99% of DMAs
> that aren't NYC. (2) K-means clustering and quantile-cut stratification
> are both sensitive to outliers; without capping, you would get strata
> like "NYC and 1 other DMA" and "everyone else." p99 is conservative
> enough not to distort the median behavior but aggressive enough to
> control the worst tail. (Doc 00 Section 5 explained why p99 over p95
> — Zillow has a small handful of genuinely unique DMAs and we don't
> want to compress *those* down to mid-tier levels; p95 would.)

### 3.2 Smart log transform

Cell 25 calls `data_prep.apply_smart_log_transform(df, business_kpis +
econ_variables + population_metric)`. "Smart" here means *per-column
skewness-conditional*: for each metric, check skewness; if it exceeds a
threshold (typical 1.0), apply `np.log1p` (i.e., $\log(1 + x)$); else leave
as is. The new columns are named `<metric>_log` and are what feeds the
composite score.

The reason for `log1p` rather than plain `log`: it handles zero values
gracefully ($\log(1 + 0) = 0$, no $-\infty$). And it's the right transform
shape for marketing data, which is bounded below at 0 and unbounded above
— the same family as the adstock-saturation Hill transforms in MMM (see
[MMM Doc 01 Section 4](../learning_docs/md/01_mmm_methodology_primer.md#section-4)).

### 3.3 Skewness check — before and after

Cells 22 and 27 both instantiate `DataDistribution(df)` and call
`.check_distribution()`. The pre-transform pass (cell 22) flags every
metric as skewed; the post-transform pass (cell 27) should show most
metrics as "approximately normal" or "mildly skewed."

The skewness statistic for each column is

$$\text{skew} = \frac{\mathbb{E}[(X - \mu)^3]}{\sigma^3},$$

the standardized third central moment. Values:

| \|skew\| | Interpretation |
|---|---|
| < 0.5 | Approximately symmetric |
| 0.5 – 1.0 | Moderately skewed |
| > 1.0 | Highly skewed (recommend transform) |

The post-transform pass should bring most metrics under 1.0 — that's the
operational pass condition.

### 3.4 Distribution plots

Cell 28 produces histograms + box plots per metric, both pre- and post-
transform. The visual reads are: (a) the histograms should *look*
roughly symmetric after log1p (a long right tail collapsing to a more
symmetric shape), and (b) the box plots should show fewer outliers
beyond the whiskers post-cap. These plots are logged to MLflow via
`mlflow.log_figure` for later audit.

### 3.5 What "passes" looks like — concrete pattern

From a typical run on the December 2025 – February 2026 window:

| Metric | Pre-log skewness | Post-log skewness | Cap @ p99 applied? |
|---|---|---|---|
| Visits | ~2.5 | ~0.4 | Yes |
| FS_Submits | ~3.1 | ~0.6 | Yes |
| ZHL_Submits | ~2.8 | ~0.5 | Yes |
| Rental_Visits | ~2.4 | ~0.4 | Yes |
| MF_Submits | ~3.0 | ~0.5 | Yes |
| `<econ>` | 0.2–0.8 typically | unchanged | Sometimes (mortgage rate: no) |
| `population_cnt` | ~2.1 | ~0.3 | Yes |

> **Inline flag — exact numbers.** These ranges are typical orders of
> magnitude inferred from the notebook structure; the precise values vary by
> snapshot. For the *current quarter's* numbers, run the notebook through
> cell 30 and inspect the `recommendations` DataFrame from
> `check_distribution()`. The codebase logs these to MLflow under
> `distribution_check/before` and `_after`.

---

## 4. Composite scoring

The composite score is a single number per DMA, in roughly $[0, 1]$, that
ranks DMAs by "market importance" — combining KPI levels, economic
environment, and population. Stratification operates on this single number,
so it needs to be a faithful one-dimensional summary of all three input
dimensions.

### 4.1 The formula

For each DMA $i$:

$$
\text{CompositeScore}_i = 0.70 \cdot \bar{\mu}^{\text{KPI}}_i \;+\; 0.25 \cdot \bar{\mu}^{\text{Econ}}_i \;+\; 0.05 \cdot \bar{\mu}^{\text{Pop}}_i
$$

where each $\bar{\mu}^{(\cdot)}_i$ is the **average of the [0,1]-normalized
log-transformed metrics in that group** for DMA $i$. That is, for each metric
column individually:

1. Take the log-transformed column (`<metric>_log` from Section 3.2).
2. Min–max normalize across DMAs: $x'_i = (x_i - \min_j x_j) / (\max_j x_j -
   \min_j x_j)$, so the column is in $[0, 1]$.
3. Average the normalized columns within each group (KPI, Econ, Pop).
4. Apply the 70/25/5 weights and sum.

The result is bounded in $[0, 1]$, with 0 = the DMA at the bottom of every
metric, 1 = the DMA at the top of every metric. In practice the realized
range is narrower (Jesmma's KT mentions typical ranges of $\sim$0.2–0.8)
because no DMA is the bottom — or top — of *every* dimension.

> **Inline flag — weights 70/25/5 vs 70/20/10.** Jesmma stated 70/25/5 in
> KT 03-20 and Tharun confirmed in KT 03-23. The synthesized
> `Overview of 24 and 23rd KT.txt` shows 70/20/10 — almost certainly a
> transcription slip. The codebase reads the weights from `config.yaml`, so
> the active number is whatever's in config at run time. The 70/25/5 reading
> is what we'll use throughout this doc; if your config disagrees, your
> config wins.

### 4.2 Why normalize *before* weighting

Two reasons:

- **Unit invariance.** The KPI columns are counts (visits in the millions),
  econ columns are mixed (income in dollars, unemployment in %), and
  population is a count in the hundreds of thousands. Without
  normalization, the population column would dominate any unweighted
  average just because it has the biggest numbers, even after log
  transformation. Min-max normalization collapses everything onto the same
  $[0, 1]$ scale so the **weights are the only thing that controls
  relative influence**.
- **Composability across re-runs.** The 70/25/5 weights are interpretable
  ("KPIs get 14× more influence than population") only when the underlying
  numbers are on the same scale.

### 4.3 The `CompositeScorer` class

Cell 32 instantiates `scorer = CompositeScorer()` and calls
`scorer.composite_score(df)`. Internally:

```text
1. Identify the log-transformed columns for KPI, Econ, Pop groups.
2. Min-max normalize each column (writing <metric>_norm).
3. Compute mean of normalized KPI columns → kpi_composite.
4. Compute mean of normalized Econ columns → econ_composite.
5. Population normalized → pop_composite (just one column).
6. composite_score = 0.70 * kpi_composite + 0.25 * econ_composite + 0.05 * pop_composite.
7. Return df with composite_score appended.
```

The class is in `holdout_setup/assignment.py` (cell 9 imports it from
`holdout.assignment`).

### 4.4 Validation of the composite score

Cell 34 calls `scorer.validate_score_distribution(df)`, which:

- Prints **mean** of the composite score (should be near the midpoint of the
  realized range; e.g., ~0.45 for a typical [0.2, 0.8] range).
- Prints **min and max** (the range — sanity check that no DMA is at the
  hard 0 or 1 boundary, otherwise normalization is broken).
- Plots the **histogram and KDE** of the score across DMAs. The plot
  should be unimodal, ideally roughly bell-shaped — multimodal scores
  indicate the input metrics are themselves multimodal and the
  stratification will mechanically segregate the modes rather than smooth
  through them.

Cell 35's `score_distribution_plot` produces the visual that gets logged to
MLflow.

> **Interview angle — "Why a weighted composite instead of multi-dimensional
> clustering?"** Two answers. (1) Stratification needs a **scalar** to
> threshold on — quantile cuts only work on a 1-D variable. You could
> cluster in the multi-dimensional space (which is what naive K-means on the
> raw normalized vectors would do), but then the strata aren't ordered, and
> you lose the monotonicity property the design relies on
> (Section 5.2.2). (2) The composite score is **interpretable to
> stakeholders** in a way that high-dimensional cluster IDs aren't. The
> business-side leads can ask "where does Sacramento fall on the composite
> score?" and get a single number; "Sacramento is in cluster 4" answers
> nothing.

---

## 5. Stratification

This is the longest section in the doc. The job of stratification is to
partition the ~180 DMAs into $K$ disjoint, internally-homogeneous,
ordered-by-composite-score groups — the **strata** — such that randomization
*within* a stratum produces balanced cells. Get this right and the rest of
the pipeline mostly works on autopilot; get it wrong and every downstream
validation will struggle.

### 5.1 Choosing K — the K-means elbow

The first question is **how many strata**. The team uses K-means clustering
on the composite score *as a diagnostic* to choose $K$, then *throws away the
cluster assignments* and re-stratifies via quantile cuts. The K-means
clustering is only used to find the elbow in the within-cluster-sum-of-
squares (WCSS) curve.

#### 5.1.1 What K-means does

K-means iteratively partitions data into $K$ clusters by minimizing

$$\text{WCSS}(K) = \sum_{k=1}^{K} \sum_{i \in C_k} (y_i - \bar{y}_{C_k})^2,$$

where $\bar{y}_{C_k}$ is the centroid (here, the mean composite score) of
cluster $C_k$. As $K$ increases, WCSS necessarily decreases — at $K = N$
(one cluster per point) WCSS is zero. The interesting question is where
WCSS *stops dropping quickly* and starts leveling off; that's the **elbow**
of the WCSS-vs-$K$ curve. Heuristically the elbow is the $K$ where adding
one more cluster gives diminishing returns.

#### 5.1.2 The notebook's elbow evaluation

Cell 37 calls `stratifier.number_of_strata(df, score_col="composite_score")`,
which iterates $K$ over a reasonable range (typically 2–10) and for each
$K$ reports:

- **VRF** (Variance Reduction Factor, Section 6.7 of
  [Doc 00](00_aot_ecosystem_and_foundations.md#section-6-7)). Higher is
  better; range $[0, 1]$.
- **Min group size** — the size of the smallest cluster at that $K$. We
  want this to stay above a floor (typically ~15 DMAs) so each stratum
  has enough DMAs to randomize into cells.

The print loop produces lines like:

```text
Strata evaluation results:
  k=2 | VRF=0.412 | Min Group=58
  k=3 | VRF=0.589 | Min Group=37
  k=4 | VRF=0.713 | Min Group=29
  k=5 | VRF=0.812 | Min Group=24
  k=6 | VRF=0.876 | Min Group=21
  k=7 | VRF=0.898 | Min Group=15
  k=8 | VRF=0.915 | Min Group=11
```

The "elbow" is the row where VRF gains start shrinking dramatically — in this
hypothetical, K=5 or K=6 (VRF jumps 0.81 → 0.88, then only 0.88 → 0.90 at
K=7). The team picks **K = 6** (Jesmma's KT explicitly mentions "five or six,
leading to the creation of six strata"). Six gives one more degree of
granularity than five at the cost of slightly smaller strata; with ~180 DMAs
and K=6, each stratum is ~30 DMAs.

> **Inline flag — exact numbers.** The VRF / min-group values above are
> illustrative orders of magnitude. The actual numbers depend on the
> window; for the current quarter, run cell 37 and read the printed
> values. The qualitative pattern — VRF leveling off around K=5–6 with
> ~180 input DMAs — is what's stable.

#### 5.1.3 Why quantile-cut, not the K-means assignment

Now the subtlety: the team uses K-means to *pick* $K$, then **runs a fresh
quantile-cut stratification** on the composite score (cell 38). Why not
just use the K-means clusters directly?

Two reasons:

- **Equal-size groups for power.** K-means tends to produce uneven cluster
  sizes — three big strata and three small ones is common when the
  underlying distribution isn't perfectly symmetric. Quantile-cut
  guarantees each stratum has roughly $N / K$ DMAs, which makes the
  downstream cell assignment (Section 6) much cleaner — you don't have one
  cell drawing 30 DMAs from stratum 1 and another drawing 12 from
  stratum 5.
- **Ordered strata.** Quantile-cut produces strata that are *guaranteed to
  be ordered by composite score* — stratum 0 has the lowest composite
  scores, stratum 5 has the highest. K-means clusters are unordered (it's
  partitioning, not ranking). Ordered strata are what the
  *monotonicity validation* (Section 5.2.2) checks for, and they're what
  the holdout-selection step (Section 11) uses to pick "one DMA from each
  stratum within the cell" — that diversification rule only makes sense if
  strata are ordered.

`stratifier.create_strata(df, score_col="composite_score")` does the
quantile-cut. Mechanically: `pd.qcut(df['composite_score'], q=n_strata,
labels=False)`, with `n_strata` from config (= 6). The resulting `stratum`
column has integer values 0..5, with 0 = lowest composite score quantile, 5
= highest.

### 5.2 Stratification validation suite

Once strata are assigned, the team runs five validations. The first three
are stratifier-internal sanity checks; the last two are statistical hypothesis
tests delegated to the `ValidationEngine`. **All five must pass before the
pipeline proceeds.**

#### 5.2.1 Monotonicity check — composite score increases by stratum

Cell 43 calls `stratifier.validate_stratification(df, stratum_col="stratum",
score_col="composite_score")`. The check: for $k = 0, 1, \dots, K-2$, the
mean composite score in stratum $k$ must be **strictly less than** the mean
in stratum $k+1$.

This is essentially a definitional check after quantile-cut, but it's a
safety net: if somewhere in the pipeline a stratum's membership got
re-shuffled (e.g., a downstream join introduced duplicates), monotonicity
breaks immediately. Pass condition: returns `True`. Cell 42 prints the
per-stratum mean KPI table as a human-readable companion — KPI means should
also trend upward by stratum (a corollary, since KPI is 70% of the
composite).

#### 5.2.2 Coefficient of Variation per stratum (CV < 20%)

Cell 44 calls `stratifier.validate_within_stratum_homogeneity(df,
stratum_col="stratum", score_col="composite_score")`. For each stratum, it
computes

$$\text{CV}_k = \frac{\sigma_k}{\bar{\mu}_k}$$

where the $\sigma$ and $\bar{\mu}$ are over the composite score values within
that stratum. **Pass condition: CV < 20% for every stratum.**

The interpretation: CV is a scale-invariant measure of relative dispersion.
A stratum with $\bar{\mu} = 0.5$ and $\sigma = 0.05$ has CV = 10% — quite
tight. A stratum with the same mean but $\sigma = 0.15$ has CV = 30% — too
heterogeneous; the DMAs aren't actually similar to each other and the
stratification boundary was probably drawn in the wrong place.

A typical output (from Tharun's KT) looks like:

```text
       mean       std       cv
0   0.234     0.034      0.145
1   0.348     0.029      0.083
2   0.439     0.027      0.062
3   0.523     0.031      0.059
4   0.617     0.029      0.047
5   0.747     0.057      0.076
```

Mean monotonically increases (5.2.1 ✓), all CVs are under 0.20 (5.2.2 ✓). The
top stratum (5) has slightly higher CV because the tail is wider — that's
expected and acceptable as long as it's still under 0.20.

#### 5.2.3 Variance Reduction Factor (VRF close to 1)

Cell 45 calls `stratifier.variance_reduction_check(df, ...)`. This computes

$$\text{VRF} = 1 - \frac{\sigma^2_{\text{within-strata}}}{\sigma^2_{\text{total}}} = \frac{\sigma^2_{\text{between-strata}}}{\sigma^2_{\text{total}}}$$

— the fraction of total variance in composite score explained by stratum
labels. **Pass condition: VRF > 0.6** (typically 0.85+ when strata are
working well).

VRF and the K-means-elbow are *the same quantity* viewed two different ways.
The elbow finds the K beyond which VRF gains slow down. The
variance-reduction check confirms that the chosen K achieves a high enough
VRF. So if Section 5.1.2's elbow analysis reports K=6 → VRF=0.876, this
check is restating the same fact.

#### 5.2.4 Levene + Welch's ANOVA across strata

Cell 48 calls `validator.levens_anova_test(df, 'dmacode', 'stratum')`,
returning two DataFrames — one for Levene's test, one for ANOVA — both
run *per metric* across strata. Cells 49 and 50 display them.

**Levene's test** (Doc 00 Section 6.2): null hypothesis is that all strata
have equal variance on a given metric. We **don't strictly require equal
variances** at the stratification stage — DMAs in the top stratum are
different from DMAs in the bottom one, including in their variance — but
Levene's result tells us whether we should be reading the ANOVA as
classical or as Welch's.

**ANOVA across strata** (Doc 00 Section 6.1): null hypothesis is that all
strata have equal mean on a given metric. **At the stratification stage, we
want to REJECT this null** — the whole point of stratification is to create
groups that differ in their means. The pass condition flips from cell to
stratum:

| Stage | Levene's p-value | ANOVA p-value | Reason |
|---|---|---|---|
| Stratification (here) | Low or high — informational | **Low (< 0.05)** | We want strata that differ in mean — that's what stratification means |
| Cell assignment (Section 7.2) | Want high (≥ 0.05) | **Want high (≥ 0.05)** | We want cells to look like exchangeable replicas |

So at this stage, the expected output is: ANOVA p-values across all metrics
are well below 0.05 (often $< 10^{-10}$ with $\sim$180 DMAs and clearly
separated strata). If a metric's ANOVA p-value is *above* 0.05 here, that
metric isn't being discriminated by the stratification, and you need to ask
whether it should have been included in the composite at all.

#### 5.2.5 Mood's median test

Cell 51 calls `validator.moods_test(df, 'stratum')`. Mood's median test (Doc
00 Section 6.4) is the non-parametric analog of ANOVA — it tests whether
all $K$ strata have the same median, not the same mean. **Same pass
condition as ANOVA here: we want to REJECT** (p < 0.05).

Why include Mood's *in addition* to ANOVA at this stage? Because some
metrics (notably ZHL_Submits and MF_Submits, which are heavily zero-inflated
in small DMAs) are skewed enough that the ANOVA F-statistic can be driven
by a handful of outliers in the top stratum even after log-transformation.
A failing Mood's test where ANOVA passes is a flag that the difference in
means is being carried by the tail rather than by a population-wide shift
between strata.

#### 5.2.6 ICC across strata

Cell 52 calls `validator.icc_test(df, 'stratum')`. ICC (Doc 00 Section 6.5)
measures the fraction of total variance that's between groups vs within
groups under a one-way random-effects model. **At stratification: we want
ICC high** — high ICC means within-stratum DMAs are similar relative to
between-stratum differences.

ICC and VRF are computed slightly differently (VRF is an ANOVA-style sum-of-
squares decomposition; ICC fits a random-effects model and reports
$\tau^2 / (\tau^2 + \sigma^2)$), but the substance is the same.
Conventionally:

| ICC | Reading |
|---|---|
| 0.0 – 0.3 | Low — clustering does little |
| 0.3 – 0.6 | Moderate |
| 0.6 – 0.8 | High |
| 0.8 – 1.0 | Very high (strata mostly explain the variance) |

For composite-score-based stratification with K=6 and ~180 DMAs, expect
ICC > 0.8 — anything substantially lower says the strata aren't doing their
job.

> **Quick interview note.** "At the stratification stage you want ANOVA /
> Mood's / ICC to **reject equality** — strata exist *because* groups
> differ. At the cell-assignment stage (Section 7) the same three tests are
> re-run with the *opposite* pass condition — we now want them to **fail to
> reject** equality. Same machinery, opposite expectation. The
> `ValidationEngine` writes both the test result and the expected direction
> to MLflow so that nobody has to remember which way they're rooting."

#### 5.2.7 Heatmap

Cell 53 plots a stratum × metric heatmap of mean values. A passing
stratification produces a smooth gradient — values increase or decrease
monotonically across rows for every column. A failing one has visible
"jumps" or non-monotone patterns. The heatmap is logged to MLflow and gets
attached to the run-summary report.

### 5.3 What if stratification fails?

If any of the five core checks fails — non-monotonic, CV > 20% somewhere,
VRF < 0.6, ANOVA fails to reject across the board, Mood's fails to reject —
the recourses are:

- **Re-examine input filters.** A common cause is a too-restrictive
  non-zero filter that drops too many DMAs from the lower end, distorting
  the composite distribution.
- **Re-examine weights.** If a particular metric is the only one passing
  ANOVA, its weight may be too dominant. If none are passing, weights are
  probably too even.
- **Try K = 5 or K = 7.** Sometimes the K-means elbow is genuinely flat
  and either of two adjacent K values would work; quantile-cut at the
  alternative may pass cleanly.

The team's experience (per KT 03-20) is that with the current 70/25/5 weights
and K=6, stratification passes on essentially every reasonable input
window — failures historically have been driven by data quality issues
upstream, not stratification methodology.

---

## 6. Cell assignment — randomization within strata

After stratification, each of the ~180 DMAs has a `stratum` label in
$\{0, 1, \dots, 5\}$. The next step partitions them into **cells** — groups
that will be the unit of holdout vs control assignment downstream.

### 6.1 What a cell is, and how many there are

A **cell** is a group of DMAs constructed to be **comparable to every other
cell** on all the dimensions we care about (KPIs, econ, population). One
cell will eventually be the *holdout cell* for a given LOB — meaning the 5
holdout DMAs picked for that LOB will come *from within that cell* (one per
stratum, Section 11). The remaining cells contribute their DMAs to the
control pool.

The number of cells is `n_slots` from config — typically **6 cells** to
match the 6 strata in a square Latin square (Section 8). Cell IDs are
$\{0, 1, \dots, 5\}$ (Python convention) or $\{1, 2, \dots, 6\}$ depending on
context — the codebase uses 1-indexed externally for human readability.

With 6 cells and 6 strata, each cell receives **5 DMAs from each stratum** —
so each cell has ~30 DMAs (5 × 6 strata). And those 5 DMAs per stratum per
cell are exactly the 5 holdout DMAs if that cell becomes the holdout cell —
one from each of the 5 lowest-CV strata, with the top stratum reserved for
top-tier representation. (The actual selection rule is "one from each
stratum," Section 11.)

### 6.2 The 5,000-trial balanced shuffle

Cell 60 calls `cell_assigner.assign_cells(df, normalised_variables)`.
Mechanically:

```text
For trial = 1, 2, ..., 5000:
    1. Within each stratum, randomly shuffle the DMAs.
    2. Deal them round-robin into the n_cells cells.
    3. For each KPI and econ variable, compute the cell-level mean
       and the across-cell CV of those means.
    4. The trial's "balance score" is a weighted sum of those CVs
       (lower = more balanced).

Return the trial assignment with the LOWEST balance score.
```

The 5,000 trials is overkill in the sense that for ~30 DMAs per cell, even
a few hundred trials would find a passing assignment; but it's cheap (a
few seconds total) and it virtually guarantees finding a near-optimal
balance.

The **balance score** is the key quantity. Conceptually it answers: *across
all the cells, how variable are the cell-level means of every KPI and econ
variable?* If the variance of cell means is high (one cell averages 1.2M
visits per DMA, another averages 0.8M), the cells aren't exchangeable. If
it's low (all cells average 1.0M ± 0.05M), they are. The trial that
minimizes that across-cell variance is the one we keep.

Mathematically, if $\bar{\mu}^{(j)}_c$ is the mean of normalized metric $j$ in
cell $c$, then

$$\text{BalanceScore} = \sum_j w_j \cdot \text{CV}_c(\bar{\mu}^{(j)}_c)$$

where the inner CV is taken across cells (not within), and $w_j$ are
configurable per-metric weights (KPIs typically weighted higher than econ).
The chosen trial minimizes this sum.

> **Why within-stratum shuffling and not free shuffling?** If we shuffled all
> 180 DMAs into cells without regard to stratum, we'd lose all the work the
> stratification step did. The within-stratum shuffle preserves the property
> that *each cell contains one representative from each stratum tier* —
> which is exactly what makes cells exchangeable. The shuffle is only
> deciding *which* representative from each stratum each cell gets.

### 6.3 Why the normalized columns matter for the balance score

Cell 55 builds `normalised_variables` — the `<metric>_norm` columns from the
composite-score pipeline. These are the columns the balance score's CV is
computed on, not the raw values. Same reason as the composite score
(Section 4.2): you want each metric to contribute equally to the balance,
not have population dominate because its raw scale is huge.

### 6.4 The `CellAssigner` class — implementation sketch

`cell_assigner = CellAssigner()` (cell 60), defined in
`holdout_setup/assignment.py`. Roughly:

```python
class CellAssigner:
    def __init__(self, n_trials=5000, n_cells=6, random_seed=None):
        self.n_trials = n_trials
        self.n_cells = n_cells

    def assign_cells(self, df, metric_cols):
        best_score = float('inf')
        best_assignment = None
        for trial in range(self.n_trials):
            assignment = self._shuffle_within_strata(df)
            score = self._balance_score(df, assignment, metric_cols)
            if score < best_score:
                best_score = score
                best_assignment = assignment
        df['cell'] = best_assignment
        return df
```

Roughly being the operative word — the actual implementation has the
balance-score calculation vectorized in NumPy and uses a fixed random seed
from config for reproducibility, so the same input produces the same output
across re-runs (an important property for production).

> **Inline flag — fixed seed.** The notebook calls `assign_cells` with no
> seed argument, suggesting the seed is set in `CellAssigner.__init__` from
> config or hard-coded. If a downstream caller wants a different
> assignment for sensitivity testing, they pass `random_seed=...` — but in
> production runs this is fixed.

### 6.5 The 5-DMAs-per-stratum-per-cell arithmetic

A small but important arithmetic check: with **180 DMAs**, **6 strata**, and
**6 cells**, each stratum has 180/6 = 30 DMAs, and each cell gets 30/6 = 5
DMAs from each stratum, so each cell has 30 DMAs total. Those 5 DMAs per
stratum are the candidates for the 5 holdout DMAs if the cell is selected
as a holdout cell. The math lines up cleanly — which is why $n\_strata =
n\_cells = 6$ is the conventional choice. If the K-means elbow had clearly
favored K=5 instead, the team would re-tune $n\_cells$ to 5 and accept 6
DMAs per stratum per cell, picking 5 of them.

> **Inline flag — what if cells aren't divisible.** When the DMA count
> isn't perfectly divisible by $n\_strata \cdot n\_cells$, some strata
> contribute one extra DMA to some cells via the round-robin deal. The
> `cell_size_summary` from `balance_score_validation` (cell 66) shows
> per-cell sizes; small imbalances (1–2 DMAs) are normal and tolerated.

---

## 7. Cell-level validation — the opposite expectation

This is where the test-direction flip from Section 5.2 happens. The same
statistical machinery is run, but now the **pass condition is "fail to
reject equality"** because cells are supposed to be exchangeable.

### 7.1 Balance-score validation

Cell 64 calls `validator.balance_score_validation(df)`, returning three
DataFrames: overall summary, per-cell sizes, and a cell × metric mean table.
Cells 65 and 66 display them. What you're looking for:

- `cell_size_summary` — all cells have similar size (e.g., 29–31 DMAs each;
  the round-robin from Section 6.5).
- `cell_summary` — cell × metric means are visibly similar across rows.
  Visual sanity check; the formal tests come next.
- **Across-cell CV per metric < 5%**, ideally < 3%. Higher than that and the
  balance-score optimization didn't converge well — typically a re-run with
  a different random seed fixes it.

### 7.2 SMD across cells

Cell 67 calls `validator.check_smd_std(df)`. For each metric, it computes
the **standardized mean difference between each cell and the overall
population**:

$$\text{SMD}_c^{(j)} = \frac{\bar{\mu}_c^{(j)} - \bar{\mu}^{(j)}}{\sigma^{(j)}}$$

(the across-DMA SD of the metric is in the denominator). Then it returns the
**maximum absolute SMD across cells** for each metric — that's the worst-case
cell-population deviation.

**Pass condition: max \|SMD\| < 0.1 for every metric.** That's the
operational definition of "well-balanced cells."

A typical pass looks like:

```text
   Metric              Max_SMD   Status    Worst_Cell
   Visits_log_norm     0.038     Pass      2
   FS_Submits_log_norm 0.041     Pass      4
   ZHL_Submits_log_norm 0.053    Pass      0
   Rental_Visits_log_norm 0.029  Pass      5
   MF_Submits_log_norm 0.046     Pass      3
   median_income_norm  0.034     Pass      1
   ...
```

All under 0.1, "Pass" for all. If any metric exceeds 0.1, the
`CellAssigner` is re-run with a different seed or `n_trials` is bumped to
10,000.

### 7.3 KDE distribution plots

Cell 68 loops `validator.plot_as_curve(df, metric, group_col="cell")` over
each KPI, producing a kernel-density-estimate plot showing the distribution
of each KPI **within each cell**. Visually, all six curves on each plot
should overlap closely — same shape, same location. Any cell whose curve is
visibly shifted (right or left) corresponds to an imbalanced cell on that
metric. These plots go to MLflow under `kde_<metric>_by_cell`.

### 7.4 Levene + ANOVA across cells

Cell 69 re-runs `validator.levens_anova_test(df, 'dmacode', 'cell')`. The
key flip from Section 5.2.4:

- **Levene's p-value: want ≥ 0.05** (cells have equal variance — they
  should, since they're replicas).
- **ANOVA p-value: want ≥ 0.05** (cells have equal means — that's literally
  what "balanced" means).

A typical pass:

```text
                Metric  Levene_p   ANOVA_p   Pass
        Visits_log_norm   0.847     0.692   ✓
   FS_Submits_log_norm   0.793     0.781   ✓
  ZHL_Submits_log_norm   0.642     0.534   ✓
 Rental_Visits_log_norm   0.589     0.612   ✓
   MF_Submits_log_norm   0.731     0.704   ✓
        median_income    0.812     0.823   ✓
   ...
```

Every p-value comfortably above 0.05. If ANOVA on any KPI dips below 0.05,
the cell assignment is rejected and re-run.

### 7.5 Mood's median test across cells

Cell 72: `validator.moods_test(df, 'cell')`. Same flip — **want p ≥ 0.05** —
medians equal across cells. Robust to skew, so passes here are slightly
weaker confirmation than ANOVA passes but still required.

### 7.6 ICC across cells

Cell 73: `validator.icc_test(df, 'cell')`. **Want ICC low** at the cell level
— cells aren't supposed to explain variance; if ICC > 0.1 across cells,
something's wrong (cell membership is meaningful, which it shouldn't be in a
properly balanced design).

### 7.7 Parallel-trends check — three time horizons

This is the **single most important check** in the doc, because it directly
tests the DiD assumption that justifies the downstream measurement.

Cells 74, 75, 76 call:

- `validator.parallel_kpi_trends_check(input_df, input_df_daily, df,
  'monthly')`
- `parallel_kpi_trends_check(..., 'weekly')`
- `parallel_kpi_trends_check(..., 'daily')`

For each cell and each KPI, plot the time series at the chosen granularity.
The six cells' lines should:

1. **Track each other in shape** — peaks and troughs at the same times.
2. **Have similar levels** (the cells *are* balanced on level by
   construction; this is the test that confirms it pre-experiment).
3. **Diverge by no more than a small constant** — slope differences over
   time matter most; absolute level shifts a little are OK because they
   wash out in DiD.

The three time horizons exist because parallel-trends violations show up at
different scales. **Monthly** smooths over weekly noise and reveals seasonal
divergence (e.g., one cell over-indexed on summer markets). **Weekly** is
the granularity at which most decisions happen and at which Latin-square
holdouts are scheduled. **Daily** can catch within-week patterns (e.g.,
one cell happens to have more weekend-skewed traffic).

A pass at all three horizons is required. A failure at any one horizon
typically traces back to the cell-assignment step — re-running with a
different seed usually clears it. If it doesn't, the typical recourse is
to **add a parallel-trends-aware term to the balance score** so the
shuffle directly optimizes against trend divergence (this is on the
roadmap as of KT 2026-03-23 but not yet implemented as of the snapshot).

> **Interview angle — "Why isn't parallel-trends in the balance score?"**
> Two reasons. (1) Compute: parallel-trends is on the weekly panel of
> $180 \text{ DMAs} \times \sim 12 \text{ weeks} = 2{,}160$ rows × 5 KPIs;
> doing that 5,000 times would dominate run time. (2) The balance score's
> static-snapshot CV is usually enough — when stratification is good, the
> cells inherit similar trends automatically. The team treats
> parallel-trends as a *validation* of the post-hoc assignment rather than
> a *driver*, which is operationally cheaper and almost always sufficient.

---

## 8. Latin square — scheduling LOBs across cells and quarters

We now have 6 balanced cells. The question is **which cell becomes the
holdout cell for which LOB in which quarter**. With $n$ LOBs (or "slots" —
the codebase uses `slot` for the LOB×channel slot in the holdout schedule)
and $n$ cells, a Latin square is the canonical assignment.

### 8.1 What a Latin square is

An $n \times n$ Latin square is an $n \times n$ matrix where each row
contains each of $n$ symbols exactly once, and each column also contains
each of $n$ symbols exactly once. Classic example (n=3):

```
A B C
B C A
C A B
```

Every row has {A, B, C}, every column has {A, B, C}. In AOT, rows are
**slots** (channel × LOB combinations being measured) and columns are
**quarters** (or experiment cycles). The entry is the **cell index** chosen
as the holdout for that (slot, quarter) pair.

So for $n = 6$ (slots) over four consecutive quarters Q1–Q4, you might have:

```
       Q1  Q2  Q3  Q4
Slot 1  2   4   1   5
Slot 2  4   2   5   1
Slot 3  1   5   2   4
Slot 4  5   1   4   2
Slot 5  3   6   3   6
Slot 6  6   3   6   3
```

Each quarter, every slot gets exactly one cell as its holdout, and the same
cell isn't used twice in the same quarter.

> **Subtlety.** In a strict Latin square each cell would appear in each row
> exactly once across 6 quarters (`n` columns). The codebase generates a
> sub-Latin matrix matching the available number of cells and slots
> dynamically, then re-randomizes if the **cross-quarter overlap with the
> previous quarter's matrix exceeds 10%** (next subsection).

### 8.2 The `Latinsquarecreation` class

Cell 78: `ls = Latinsquarecreation()`, imported from
`holdout.latin_square`. Cell 79:

```python
latin_square, best_order = ls.generate_simple_matrix(
    previous_orders=None,
    max_overlap_pct=10,
    max_attempts=1000
)
```

The function attempts up to 1,000 random Latin-square generations and returns
the first one whose **overlap with `previous_orders`** is at most
`max_overlap_pct = 10` percent. The first quarter of a new design run gets
`previous_orders=None` (no overlap constraint); subsequent quarters pass in
the previous quarter's matrix.

### 8.3 The overlap constraint and why 10%

For two Latin squares $L^{(t)}$ and $L^{(t-1)}$, define the overlap as

$$\text{Overlap} = \frac{1}{n^2} \sum_{i, j} \mathbb{1}[L^{(t)}_{i,j} = L^{(t-1)}_{i,j}].$$

That is, the fraction of (slot, quarter) cells where the holdout-cell
assignment is identical to the previous quarter. **The codebase caps this at
10%** (`max_overlap_pct=10`).

The reason for the cap is rotation fairness. If quarter $t-1$ assigned cell
4 as the SEM-Buyer holdout *and* quarter $t$ also assigns cell 4 as the SEM-
Buyer holdout, the **same 5 DMAs** (the 5 holdout DMAs picked from cell 4 by
the stratum-diverse rule) are dark for SEM-Buyer marketing for *two
consecutive quarters*. Two quarters = ~180 days of no SEM-Buyer marketing in
those DMAs — which damages the business in those regions and (separately)
biases the DiD measurement because those DMAs' baselines drift.

A 10% cap means at most ~6/60 of the slot-quarter cells repeat — so
roughly 1 in 17 (slot, quarter) pairs maintains the same holdout cell across
quarters, and the rest rotate. Operationally: any DMA is in the holdout for
a particular slot at most once per ~10 quarters, easily within the "don't
darken the same region more than every ~6 months" rule.

> **Mathematical note — exact-Latin-square is over-constrained.** A "true"
> $n \times n$ Latin square forces every cell to appear once per row and once
> per column — strict orthogonality. The codebase's
> `generate_simple_matrix` produces a *permutation-of-rows* design (each
> column is a random permutation of cell IDs, and the rows aren't
> independently constrained), which is technically a Latin rectangle. That's
> sufficient for the rotation property the team cares about and is the
> easier object to sample randomly.

### 8.4 Slot ↔ LOB ↔ channel mapping

The `slot_dict` in config (cell 83) maps each slot number to a list of
channel-network-tactic strings. Example:

```yaml
slot_dict:
  1: [SEM_Google_Buyer]
  2: [SEM_Google_Rental]
  3: [Display_Programmatic_Buyer]
  4: [Display_Programmatic_Rental]
  5: [PaidSocial_Meta_Buyer]
  6: [PaidSocial_Meta_Rental]
```

Cell 100 expands this into a long-form `slot_channel_df` with columns
`(slot, channel, network, tactic)` that the final-matrix step (Section 12)
joins back to attach the channel taxonomy.

Similarly, `lob_mapping` in config maps slot indices to LOB names. The
Latin-square + slot-dict combination is what lets one quarterly Latin matrix
serve simultaneously as the schedule for 6 LOB×channel slots.

> **Interview angle — "Could you use a Bayesian optimization or genetic
> algorithm instead of random Latin-square sampling?"** Yes, but it's
> overkill. The Latin-square constraint is permissive (~1000 attempts almost
> always succeed within the 10% overlap cap), the search space is small
> enough that random sampling is competitive with optimization, and the
> objective (overlap %) is non-smooth and doesn't benefit from gradient
> methods. The simplest random-rejection sampler is the right tool.

---

## 9. Power analysis — deriving the 5-DMA holdout size

Section 5.5 of [Doc 00](00_aot_ecosystem_and_foundations.md#section-5-5)
laid out the textbook power-analysis formula. This section applies it to
Zillow's specific situation and shows how the team converged on 5 DMAs per
LOB.

### 9.1 The initial proposal of ~28 DMAs per cell

Jesmma's first design proposal was 6 strata × 6 cells = 36 cells, with each
cell holding ~5 DMAs from each of 6 strata = ~30 DMAs per cell. The
implication: when one cell becomes the holdout for an LOB, all ~30 DMAs in
that cell go dark for that LOB in that quarter.

The business pushback was immediate: 30 DMAs of ~210 is ~14% of the US
population by DMA count and approximately 15–20% by *actual* population —
i.e., 15–20% of revenue lost on that LOB for a full quarter, every quarter,
just for measurement. Not affordable.

### 9.2 The power formula, applied

The two-sample-t-test approximation:

$$n \approx \frac{2 \sigma^2 (z_{1-\alpha/2} + z_{1-\beta})^2}{\delta^2}.$$

For Zillow's target detection (per KT 03-20):

- $\alpha = 0.05$ (two-sided) → $z_{1-\alpha/2} \approx 1.96$
- $1 - \beta = 0.80$ → $z_{1-\beta} \approx 0.84$
- $(z + z)^2 = (1.96 + 0.84)^2 \approx 7.84$

So $n \approx 15.7 \cdot \sigma^2 / \delta^2$.

The numbers that matter:

- $\sigma^2$ — the **per-DMA variance in the measured metric** within a
  stratum or balanced cell. After log-normalization, this is in the range
  of $\sim$0.05–0.15 squared (i.e., SD on the log-normalized scale
  ~0.05–0.15). Picking the upper end: $\sigma^2 \approx 0.022$.
- $\delta$ — the **minimum detectable lift** the team wants to detect.
  Industry-standard lift-test MDE for paid-media incrementality is 5–15%.
  On the log-normalized scale a 10% lift corresponds to roughly
  $\delta \approx 0.10$.

Plugging in:

$$n \approx 15.7 \cdot \frac{0.022}{0.10^2} \approx 3.5$$

— rounded up and with a safety margin, **5 DMAs per arm**.

### 9.3 Why 5 *per cell* doesn't mean 5 *total* controls

A subtlety worth pinning down: the "5 DMAs per LOB" is the *holdout* arm
size. The control arm — all the non-holdout DMAs in the other cells — is
much bigger (~175 DMAs total). For a two-sample t-test, the **effective
sample size** is the harmonic mean of the two arms:

$$n_{\text{eff}} = \frac{2 n_1 n_2}{n_1 + n_2}.$$

With $n_1 = 5$ and $n_2 = 175$, $n_{\text{eff}} \approx 9.7$ — almost
doubling the headline 5. So the power is even better than the per-arm
formula suggests, and the 5-DMA floor is comfortable.

### 9.4 Why not 4 or 6?

- **4 would be tight.** Plugging the formula back: power at $n=4$ falls to
  ~72%, below the 80% target. One bad DMA-outlier in the holdout would
  blow the test.
- **6 is OK but costlier.** $n=6$ gives ~88% power, which is more
  comfortable, but it means 6 DMAs out of ~180 are dark per LOB — 17%
  more holdout volume for marginal power gain. The business prefers 5.
- **Operational symmetry.** 5 DMAs per cell = one DMA from each of 5 strata
  (with the 6th stratum's representative either skipped or sampled
  conditionally), which dovetails with the "one DMA per stratum"
  diversification rule (Section 11). 6 DMAs would require two from some
  stratum, which complicates the rule.

> **Inline flag — formal power-analysis source.** The KT notes report "the
> power analysis came back with 5 DMAs per LOB" but don't show the exact
> $\sigma^2, \delta$ inputs. The numbers in Section 9.2 are reasonable
> reconstructions matching industry standards; for the canonical record,
> ask Jesmma for the original power-analysis notebook (separate from the
> `geo_holdout_tactic.ipynb` file, not in the repo as of KT snapshot).

---

## 10. Exclusion rules

Even after stratification + cell assignment + Latin square, there's one
more business-driven step: certain (DMA, LOB) pairs **must not** be in the
holdout, no matter what the design says. The classic examples (from KT
03-16 and re-confirmed in 03-23):

- **New York DMA** as holdout for Buyer marketing — the channel-lead team
  considers NYC too revenue-critical to dark.
- **Texas DMAs** (Dallas, Houston) for rental marketing — major rental
  markets where any holdout would have outsize revenue impact.
- **California DMAs** (LA, SF) for some Brand campaigns — similar logic.

### 10.1 The config schema

Cell 81 reads `config["exclusion_rules"]` into a DataFrame. A typical row:

```yaml
exclusion_rules:
  - slot_restricted: SEM_Google_Buyer
    lob_restricted: PA
    dma_restricted: 501  # New York
  - slot_restricted: PaidSocial_Meta_Rental
    lob_restricted: Rentals
    dma_restricted: 623  # Dallas-Ft. Worth
  ...
```

Cell 84 enriches the rules with `slot_number` (from `slot_dict`) and
`lob_code` (from `lob_mapping`) so they're joinable in the next step.

### 10.2 Enforcement during holdout selection

The `HoldoutSelectorClass` (cell 85) takes `exclusion_rules` and the Latin
square as inputs and applies them as a **filter on the within-cell DMA
candidates** when picking the 5 holdouts. If DMA 501 is excluded for the
Buyer slot, and DMA 501 happens to be in stratum 3 of the holdout cell for
Buyer, then the algorithm picks a *different* DMA from stratum 3 — falling
back to the next-best candidate within that stratum.

The selector logs whenever an exclusion forces a substitution, so the team
can audit how often the business overrides bite.

### 10.3 Why these are runtime config, not part of the score

The instinct might be to bake exclusions into the composite score directly
(e.g., put NYC at the extreme top stratum so it never gets selected). The
team chose runtime-config exclusions because:

- **Exclusions are LOB-specific** — NYC is excluded for Buyer but not for
  Brand. A score-based approach can't represent that.
- **Exclusions change quarterly** based on channel-lead asks. Re-running
  stratification every time a rule changes would defeat the design's
  reproducibility.
- **Exclusions are exceptions, not rules.** The composite score *should*
  treat NYC like any other DMA in terms of where it lands stratum-wise —
  the override only kicks in at selection time.

---

## 11. Holdout selection — picking the 5 DMAs

This is the final selection step. Given (a) which cell is the holdout cell
for slot $s$ (from the Latin square), and (b) the exclusion rules, pick **5
DMAs from that cell**, one per stratum (diversification rule).

### 11.1 The selection algorithm

Cell 86: `df = holdout_selector.apply_to_allcells(df)`. For each slot:

1. Look up which cell is the holdout for this slot (from `latin_square`).
2. Filter the cell's ~30 DMAs to those *not* excluded for this slot.
3. For each of the 5 selected strata (typically 1, 2, 3, 4, 5 — top
   stratum sometimes held back), pick **the DMA with the median composite
   score in that stratum from within the cell**. The median is the most
   "representative" pick — avoids the extreme tails within the stratum.
4. The 5 picked DMAs become the holdout for that slot. The remaining ~25
   DMAs in the cell (plus all DMAs in other cells) are the control pool.

A small operational subtlety: the algorithm doesn't just pick the median;
it tries **multiple combinations of one-per-stratum** picks (5,000 trials
analogous to the cell assignment) and chooses the one that maximizes
balance against the control pool — SMD-minimizing.

### 11.2 The control pool

Cell 87: `control_dmas_str, control_dmas =
holdout_selector.get_control_dmas(df)`. Returns:

- `control_dmas` — a Python list of DMA codes that are *not* holdouts for
  *any* slot in this quarter.
- `control_dmas_str` — a comma-separated string version, used for the
  downstream gold-table write (Section 12).

Note: "control" here means "not in any holdout." Some DMAs are in the
holdout for slot A but not slot B; from slot B's perspective those DMAs are
in the control pool *for slot B's measurement*. The Tableau-friendly
`control_dmas_str` field is the conservative "this DMA is in no holdout
anywhere" subset, useful for visualizations and ad-hoc analysis.

### 11.3 Holdout-vs-control validation — the final battery

Once the 5 holdouts are picked per slot, the team runs **another full
validation battery** — holdout vs control balance, per slot, per KPI.

#### 11.3.1 Pooled SMD

Cell 89: For each (cell, KPI), compute the pooled Cohen's $d$ between
holdout (5 DMAs) and control (the rest of the cell). The pooled-SD
denominator is the standard

$$\sigma_{\text{pooled}} = \sqrt{\frac{(n_1 - 1)\sigma_1^2 + (n_2 - 1)\sigma_2^2}{n_1 + n_2 - 2}}$$

and the SMD is the mean difference standardized by it. **Pass condition:
\|SMD\| < 0.2** here — a slightly looser threshold than the cell-balance
\|SMD\| < 0.1 because we're working with smaller samples (5 vs ~25 in the
cell), and 0.1 is too tight to consistently achieve with only 5 holdout
DMAs. 0.2 is "small effect" by Cohen's convention and is the operationally
chosen pass condition.

#### 11.3.2 Within-cell ANOVA — holdout vs control

Cell 91: `validator.within_cell_anova(df, 'cell', 'is_holdout',
selected_kpi, 0.05)`. Within each cell, compare the 5 holdouts vs the
remaining ~25 DMAs on the chosen KPI. **Want p ≥ 0.05** (holdouts and
control are exchangeable within the cell).

This is run per KPI; the wrapper aggregates across all KPIs and reports a
pass/fail per cell.

#### 11.3.3 The slot-level multi-test summary

Cell 92 is the **most statistically sophisticated cell in the notebook**. It
runs three tests per (slot, KPI) and applies two multiple-testing
corrections:

```python
results = [
    validator.run_holdout_validation(df, kpi, 'is_holdout', slot_num)
    for slot_num in range(1, config['n_slots'] + 1)
    for kpi in business_kpis
]
```

`run_holdout_validation` returns, per (slot, KPI):

- **`welch_p`** — Welch's two-sample t-test p-value (holdout vs control).
  Welch's because we don't assume equal variances between a 5-DMA holdout
  and a ~25-DMA control.
- **`kw_p`** — Kruskal-Wallis test p-value. This is the **rank-based
  non-parametric analog** of ANOVA — it tests whether the *ranks* of
  values across groups have the same distribution. Same null hypothesis
  as ANOVA (no group difference) but doesn't assume normality. With only
  5 DMAs in the holdout, normality is suspect; KW protects against that.
- **`mood_p`** — Mood's median test p-value.

Then **for each slot** (across the 5 KPIs), the code applies
`multipletests` from `statsmodels.stats.multitest` with two corrections:

- **Bonferroni** (`method='bonferroni'`): the strict, conservative
  correction. Multiplies each p-value by the number of tests. Pass rate
  is the lowest of any correction.
- **FDR–Benjamini–Hochberg** (`method='fdr_bh'`): the modern False Discovery
  Rate correction. Ranks p-values, applies a stepwise threshold that
  controls the *expected proportion of false rejections* at $\alpha$
  rather than the *probability of any false rejection*. More powerful
  than Bonferroni for $k > 5$.

**Why two corrections?** Bonferroni is the textbook conservative choice;
FDR-BH is the modern preferred choice for genomic-scale multiple testing.
Reporting both gives different audiences what they want. The codebase's
operational pass condition is **`fdr_bh > 0.05` for all 5 KPIs in each
slot** (the `welch_pass`, `kw_pass`, `mood_pass` columns in the summary).

A passing slot looks like:

```text
SUMMARY • SLOT 3 | ALL KPIs
 slot  kpi              welch_p  welch_bonf  welch_fdr  welch_pass  kw_p   kw_fdr  kw_pass  mood_p  mood_fdr  mood_pass
    3  Visits             0.412      1.000      0.687    Pass     0.534   0.668    Pass    0.482   0.671   Pass
    3  FS_Submits         0.318      1.000      0.530    Pass     0.296   0.495    Pass    0.412   0.660   Pass
    3  ZHL_Submits        0.587      1.000      0.734    Pass     0.612   0.612    Pass    0.531   0.671   Pass
    3  Rental_Visits      0.234      1.000      0.530    Pass     0.412   0.668    Pass    0.367   0.660   Pass
    3  MF_Submits         0.689      1.000      0.734    Pass     0.781   0.781    Pass    0.612   0.671   Pass
```

All `_pass` columns Pass; Bonferroni-adjusted p-values all 1.000 (the
"capped at 1" behavior when raw p × k > 1 — strict but not informative
once you're well above threshold); FDR-BH p-values comfortably above 0.05.
This slot is balanced.

> **Why both Bonferroni and FDR?** Bonferroni controls the **family-wise
> error rate** — the probability that *any* test in the family is a false
> positive. FDR-BH controls the **expected proportion** of false positives
> *among rejections* — different statistical concept, more powerful when
> there are real differences to find. For balance-checking, where you're
> hoping to *not* reject anywhere, FDR-BH is the better operational gate.
> Bonferroni is reported alongside for stakeholders who want the
> stricter view.

#### 11.3.4 Parallel-trends for holdout vs control

Cells 94, 95, 96 re-run parallel-trends at monthly, weekly, and daily
horizons, this time grouping by `is_holdout` (0/1) rather than `cell`. The
two-arm version — same pass condition as Section 7.7 (parallel evolution
through the pre-period) — confirms that the **smaller, more
intensively-validated holdout vs control split** also satisfies the DiD
identifying assumption.

If any horizon fails here, the operational recovery is to **re-run holdout
selection with a different random seed** — usually one of the 5,000-trial
alternatives at the selection step satisfies parallel-trends while still
satisfying SMD < 0.2.

### 11.4 The final picture per slot

After Section 11, for each slot you have:

| Field | Example value |
|---|---|
| `slot` | 3 |
| `channel` | Display |
| `network` | Programmatic |
| `core_lob` | PA |
| `core_campaign_super` | Buyer |
| `cell` | 4 (the cell that became the holdout cell for slot 3 in this quarter) |
| `n_holdout` | 5 |
| `n_control` | ~175 |
| `holdout_dmas` | `"501,602,623,710,807"` (comma-joined codes) |
| `control_dmas` | the long list of non-holdout codes |

And every (slot, KPI) pair has passed Welch, KW, Mood's all under FDR-BH at
0.05, plus parallel-trends at monthly, weekly, and daily horizons.

---

## 12. Final matrix output — the schema and write

Cell 99 calls `holdout_selector.write_final_matrix(df, config['start_date'],
config['end_date'], current_year, date_of_run, control_dmas,
control_dmas_str)`, producing the canonical output table.

### 12.1 The schema

Per cell 106:

| Column | Type | Meaning |
|---|---|---|
| `slot` | int | 1..n_slots, indexes into `slot_dict` |
| `cell` | int | Which of the n_cells was selected as the holdout cell for this slot |
| `channel` | string | From the slot-dict expansion (cell 100) |
| `network` | string | From the slot-dict expansion |
| `core_lob` | string | From `lob_mapping` |
| `core_campaign_super` | string | From config |
| `n_holdout` | int | Always 5 (the power-derived size) |
| `n_control` | int | Count of non-holdout DMAs |
| `holdout_dmas` | string | Comma-joined DMA codes |
| `control_dmas` | string | Comma-joined DMA codes (the long one) |
| `cadence` | string | "quarterly" by default |
| `start_date` | date | Holdout start, from config |
| `end_date` | date | Holdout end |
| `year` | int | Year for partitioning |
| `experiment_id` | string | Identifier for the experiment (currently a literal `1` in the snapshot; commented-out logic constructs `EXP_<year>_Q<n>_GEO_<channel>_<network>_<lob>_<campaign_super>_<job_run_id>`) |
| `tactic` | string | From slot-dict expansion, default `"None"` |
| `p_data_date` | date | Date the row was produced, for downstream version filtering |

### 12.2 The write

Cell 108:

```python
spark_final_df = spark.createDataFrame(final_df)
spark_final_df.write \
    .mode("overwrite") \
    .saveAsTable(f"{catalog}.{gold_schema}.holdout_schedule")
```

Overwrite (not append) — the table holds the **current quarter's** schedule.
Historical schedules are recovered via Delta Lake time travel:
`SELECT * FROM ... VERSION AS OF <n>`. This is intentional: the schedule is
a forward-looking artifact (here's what's dark next quarter), not a log of
past quarters; downstream consumers should always read the current state.

### 12.3 The Causal Lab → activation handoff

The `holdout_schedule` table is the **handoff** between AOT and the channel-
activation systems. Downstream:

- For SEM, an SQL job reads the row for the SEM slot and produces the DMA-
  exclusion list that gets pushed to Google Ads via the existing legacy
  push mechanism (Doc 01 Section 4).
- For Paid Social — vendor-managed; we publish the schedule for awareness
  but Meta doesn't read it (Doc 01 Section 3).
- For new channels (Display, Affiliate), the channel-team-side pipelines
  consume `holdout_schedule` directly to skip ad serving in the listed
  DMAs.

The contract: the AOT side writes; the activation side reads — same pattern
as MMM's `mmm_model_combined_output_overall_level` → budget-allocator
handoff
([MMM Doc 07](../learning_docs/md/07_fs_submits_response_curves_and_stability.md)).

---

## 13. Notebook walkthrough — the 110-cell sweep

This section maps every block of the `geo_holdout_tactic.ipynb` notebook to
the methodology sections above, naming the operative function and what each
block's output reveals. Use this as a reading guide — open the notebook on
one screen and this section on the other.

### 13.1 Cells 0–12: setup

| Cells | What happens | Methodology link |
|---|---|---|
| 0 | `%load_ext autoreload` — IDE convenience | — |
| 1 | `%pip install /Workspace/Shared/causal_lab/causallab-0.1.0-py3-none-any.whl` (commented out — the wheel is already installed in the prod cluster) | The Causal Lab packaging — Section 14 |
| 2 | `%pip install pingouin` — required by ICC test | Section 6.5 of [Doc 00](00_aot_ecosystem_and_foundations.md#section-6-5) |
| 3 | `%pip install kaleido==0.2.1` — Plotly image export | For MLflow figure logging |
| 5 | Commented-out `%run /shared_utils/common_functions` — would import MMM-side shared utilities; presently unused, so the geo design is self-contained | — |
| 6–7 | Define and read Databricks widgets: `catalog`, `silver_schema`, `gold_schema`, `environment`, `ml_experiment_path`, `holdout_start_date`, `holdout_end_date` | Same DAB widget pattern as MMM ([MMM Doc 09](../learning_docs/md/09_operations_and_interview_capstone.md)) |
| 8 | Logger setup (Py4J warning level) | Causal Lab's logger pattern, Section 14.4 |
| 9 | **Key imports** from the Causal Lab package: `DataPreparation, DataDistribution, CompositeScorer, Stratifier, CellAssigner, HoldoutSelectorClass, ValidationEngine` from `holdout.assignment`, and `Latinsquarecreation` from `holdout.latin_square`. Also `casuallab_logger.CausalLab` for run logging | Causal Lab structure — Section 14 |
| 10 | Standard imports + OpenBLAS/MKL/OMP thread-count constraints (set to 1 each — common pattern in Spark workloads to prevent thread contention). Imports `KMeans` from sklearn, `MarketingMetricsData` / `BusinessMetricsData` from `rapidmmm` — the geo design **reuses rapidmmm's preprocessing primitives** | The rapidmmm reuse mirrors how MMM and AOT share schemas |
| 11–12 | Commented-out dev-env bootstrap (creates a per-user schema in lab) and MLflow parent-run setup | Operational; not core to the methodology |

### 13.2 Cells 13–15: config load

| Cell | What happens |
|---|---|
| 13 (md) | `## 1. LOAD CONFIG` — section marker |
| 14 | `with open('config.yaml', 'r') as f: config = yaml.safe_load(f)` |
| 15 | Pulls the three input lists out of config: `business_kpis`, `econ_variables`, `population_metric` |

The `config.yaml` is co-located with the notebook in the Causal Lab repo
and is the **single source of truth** for every tunable parameter
(Section 14.2). Key keys: `business_kpis`, `econ_variables`,
`population_metric`, `composite_weights`, `n_strata`, `n_slots`,
`balance_score_n_trials`, `max_overlap_pct`, `exclusion_rules`, `slot_dict`,
`lob_mapping`, `start_date`, `end_date`.

### 13.3 Cells 16–25: data preparation

| Cell | What happens | Methodology link |
|---|---|---|
| 16 (md) | `## 2. DATA PREPARATION` |
| 17 | `data_prep = DataPreparation(); df, input_df, input_df_daily = data_prep.load_and_prepare('marketing.marketingde_gold.mmm_business_metrics', start_date='2025-12-01', end_date='2026-02-28')`. Returns the DMA-aggregated `df`, the DMA-week panel `input_df`, the DMA-day panel `input_df_daily`. | Section 2.4 — three representations |
| 18 | `display(df)` — visual check |
| 19 | Spark SQL to pull latest `population_cnt` per DMA from `marketing.marketingde_silver.mmm_regionmapping` (the same table MMM uses, see [MMM Doc 04](../learning_docs/md/04_data_lineage_and_schemas.md)) | Section 2.3 |
| 20 | `df = df.merge(population_cnt_df, on='dma_regionid', how='left')` |
| 21 | **Non-zero filter** — keep only DMAs where every KPI > 0 in the window. This is the step that drops ~30 small DMAs and leaves ~180 | Section 2.1 |
| 22 | First skewness pass: `DataDistribution(df).check_distribution()` → DataFrame of recommendations | Section 3.3 |
| 23 | Skewness check across all metrics | Section 3.3 |
| 24 | **Outlier cap at p99**: `data_prep.cap_at_percentile_df(df, lower_percentile=0, upper_percentile=99)` | Section 3.1 |
| 25 | **Smart log transform**: `data_prep.apply_smart_log_transform(df, business_kpis+econ_variables+population_metric)` | Section 3.2 |

### 13.4 Cells 26–30: distribution analysis post-transform

| Cell | What happens |
|---|---|
| 26 (md) | `## 3. DATA DISTRIBUTION ANALYSIS` |
| 27 | Post-transform `dist.check_distribution()` — most metrics should now show "approximately normal" |
| 28 | `dist.plot_distribution()` — histograms + box plots, logged to MLflow |
| 29 | Build `log_variables = [col + "_log" for col in business_kpis + econ_variables + population_metric]` — the names the composite score will use |
| 30 | Secondary skewness check on the log-transformed columns |

### 13.5 Cells 31–35: composite scoring

| Cell | What happens | Section |
|---|---|---|
| 31 (md) | `## 4. COMPOSITE SCORING` |
| 32 | `scorer = CompositeScorer(); df = scorer.composite_score(df)` — normalizes and applies the 70/25/5 weights, writes `composite_score` column | Section 4.1, 4.3 |
| 33 (md) | `### Validation` |
| 34 | `scorer.validate_score_distribution(df)` — prints mean, range, plots histogram | Section 4.4 |
| 35 | `scorer.score_distribution_plot(df, 'composite_score')` — Plotly figure logged to MLflow |

### 13.6 Cells 36–53: stratification + validation

The biggest block — five validations on six strata.

| Cell | What happens | Section |
|---|---|---|
| 36 (md) | `## 5. STRATIFICATION` |
| 37 | `stratifier = Stratifier(); stratifier.number_of_strata(df, score_col="composite_score")` — K-means elbow evaluation, prints VRF and min-group size per K from 2 to ~10. | Section 5.1 |
| 38 | `df = stratifier.create_strata(df, score_col="composite_score")` — quantile-cut into 6 strata, writes `stratum` column | Section 5.1.3 |
| 39 | `display(df)` |
| 40 | Per-stratum DMA listing — useful for ad-hoc inspection |
| 41 (md) | `### Validation` |
| 42 | `df.groupby('stratum')[business_kpis].mean()` — KPI means by stratum, should trend upward | Section 5.2.1 |
| 43 | **Monotonicity**: `stratifier.validate_stratification(df, ...)` → `is_monotonic = True` | Section 5.2.1 |
| 44 | **CV per stratum**: `stratifier.validate_within_stratum_homogeneity(df, ...)` → DataFrame, want CV < 0.20 each | Section 5.2.2 |
| 45 | **VRF**: `stratifier.variance_reduction_check(df, ...)` → want > 0.6 (typically 0.85+) | Section 5.2.3 |
| 46 | `import sys` — operational |
| 47 | `validator = ValidationEngine()` |
| 48 | **Levene + ANOVA across strata**: `validator.levens_anova_test(df, 'dmacode', 'stratum')` returns both DFs | Section 5.2.4 |
| 49 | `levens_df` — display |
| 50 | `anova_df` — display, want every metric's p < 0.05 |
| 51 | **Mood's median across strata**: `validator.moods_test(df, 'stratum')` — want p < 0.05 | Section 5.2.5 |
| 52 | **ICC across strata**: `validator.icc_test(df, 'stratum')` — want high (> 0.6) | Section 5.2.6 |
| 53 | Heatmap stratum × metric — visual monotonicity check | Section 5.2.7 |

### 13.7 Cells 54–76: cell assignment + validation

| Cell | What happens | Section |
|---|---|---|
| 54 (md) | `## 6. CELL ASSIGNMENT` |
| 55 | Build `normalised_variables` — the `<metric>_norm` columns from the composite-score pipeline, used as the balance-score inputs | Section 6.3 |
| 56 | Sort by `(dmacode, stratum)` for deterministic balance-score behavior |
| 57–59 | Display + sanity-check `MF_Submits` distribution |
| 60 | **The 5,000-trial balanced assignment**: `cell_assigner = CellAssigner(); df = cell_assigner.assign_cells(df, normalised_variables)`. Writes `cell` column | Section 6.2 |
| 61 | `display(df)` |
| 62 | Cell-1's DMA list — visual spot-check |
| 63 (md) | `### Validation` |
| 64 | **Balance score**: `validator.balance_score_validation(df)` returns three DFs (overall, cell-size, cell × metric mean) | Section 7.1 |
| 65 | `display(cell_summary)` — cell × metric means |
| 66 | `display(cell_size_summary)` — cells have similar sizes |
| 67 | **SMD across cells**: `validator.check_smd_std(df)` — want max \|SMD\| < 0.1 per metric | Section 7.2 |
| 68 | KDE distribution plots per KPI by cell | Section 7.3 |
| 69 | **Levene + ANOVA across cells**: `validator.levens_anova_test(df, 'dmacode', 'cell')` | Section 7.4 |
| 70 | `levene_df` |
| 71 | `anova_df` — now want p ≥ 0.05 |
| 72 | **Mood's across cells** — want p ≥ 0.05 | Section 7.5 |
| 73 | **ICC across cells** — want LOW | Section 7.6 |
| 74 | **Parallel-trends monthly** | Section 7.7 |
| 75 | **Parallel-trends weekly** | Section 7.7 |
| 76 | **Parallel-trends daily** | Section 7.7 |

### 13.8 Cells 77–96: holdout selection + final validation

| Cell | What happens | Section |
|---|---|---|
| 77 (md) | `## 7. HOLDOUT SELECTION` |
| 78 | `ls = Latinsquarecreation()` | Section 8.2 |
| 79 | `ls.generate_simple_matrix(previous_orders=None, max_overlap_pct=10, max_attempts=1000)` — produces the Latin matrix | Section 8.2 |
| 80 | `latin_square` — display the matrix |
| 81 | Read `config["exclusion_rules"]` into DataFrame | Section 10.1 |
| 82 | `exclusion_rules` — display |
| 83 | `business_to_slot = config['slot_dict']` — the slot dict | Section 8.4 |
| 84 | Build inverse mappings + enrich exclusion rules with slot/LOB codes |
| 85 | `holdout_selector = HoldoutSelectorClass(exclusion_rules, latin_square)` | Section 11.1 |
| 86 | **The selection itself**: `df = holdout_selector.apply_to_allcells(df)` — writes `is_holdout` per (DMA, slot) | Section 11.1 |
| 87 | `control_dmas_str, control_dmas = holdout_selector.get_control_dmas(df)` | Section 11.2 |
| 88 (md) | `### Validation` |
| 89 | **Pooled SMD** per cell per KPI: `validator.check_smd_pooled(df, cell_id, metric, holdout_col='is_holdout')` | Section 11.3.1 |
| 90 | Select KPI for within-cell ANOVA |
| 91 | `validator.within_cell_anova(df, 'cell', 'is_holdout', selected_kpi, 0.05)` | Section 11.3.2 |
| 92 | **The big multi-test cell** — Welch + KW + Mood's per (slot, KPI), with Bonferroni and FDR-BH corrections per slot, pass/fail per test | Section 11.3.3 |
| 93 | `df` — final display |
| 94–96 | **Parallel-trends for holdout vs control** at monthly, weekly, daily | Section 11.3.4 |

### 13.9 Cells 97–109: final matrix write

| Cell | What happens | Section |
|---|---|---|
| 97 (md) | Blank section marker (probably intended as `## 8. FINAL MATRIX` — fill in if PR-ing) |
| 98 | `from datetime import datetime` (re-import to be safe) |
| 99 | `final_df = holdout_selector.write_final_matrix(df, config['start_date'], config['end_date'], current_year, date_of_run, control_dmas, control_dmas_str)` | Section 12.1 |
| 100 | Build `slot_channel_df` from `slot_dict` — long-form `(slot, channel, network, tactic)` | Section 8.4 |
| 101 | Merge to attach channel taxonomy to `final_df` |
| 102–103 | Display |
| 104 | Set `experiment_id = 1` (the commented-out version constructs an `EXP_<year>_Q<n>_GEO_<channel>_...` identifier — wired up in production) | Section 12.1 |
| 105 | Display |
| 106 | Project to the canonical 17-column schema | Section 12.1 |
| 107 | Display |
| 108 | **Spark write**: `saveAsTable(f"{catalog}.{gold_schema}.holdout_schedule")` with `mode("overwrite")` | Section 12.2 |
| 109 | `mlflow.end_run()` — close out the parent run |

If you ran the notebook end-to-end on the December 2025 – February 2026
window with the conventional config, you would land at cell 108 with a
final_df of **~6 rows** (one per slot), each row carrying the 5-DMA holdout
list and ~175-DMA control list, all stat-tests passing.

---

## 14. Causal Lab package architecture

The notebook described in Section 13 is the **caller** — the orchestrator. The
**methodology** lives in the Causal Lab Python package (`causallab`). This
section walks the package as Tharun did in KT 2026-03-23.

### 14.1 Folder structure

```
causallab/
├── pyproject.toml             # Poetry build manifest
├── Dockerfile                 # Databricks-parity image for local dev
├── README.md
├── causallab/                 # The package itself
│   ├── __init__.py
│   ├── config.py              # YAML-loader wrapper
│   ├── casuallab_logger.py    # Structured logger (note: typo "casual" not "causal" in module name — match existing import)
│   ├── metrics/               # KPI pull helpers — SQL → DataFrame
│   │   ├── __init__.py
│   │   ├── business_metrics.py
│   │   └── economic_metrics.py
│   ├── holdout_setup/         # The geo design (this doc)
│   │   ├── __init__.py
│   │   ├── assignment.py      # DataPreparation, DataDistribution,
│   │   │                       # CompositeScorer, Stratifier, CellAssigner,
│   │   │                       # HoldoutSelectorClass, ValidationEngine
│   │   ├── latin_square.py    # Latinsquarecreation, overlap check
│   │   └── (no validation_engine.py — folded into assignment.py)
│   ├── dark_period/           # TV dark-period scheduling (→ Doc 03)
│   │   ├── __init__.py
│   │   └── scheduler.py
│   └── measurement/           # WIP — DiD + linear regression
│       └── __init__.py
└── tests/
    ├── test_assignment.py
    ├── test_latin_square.py
    └── ...
```

Path conventions:

- The notebook imports as `from holdout.assignment import ...` (no
  `causallab.` prefix) because the wheel installs `holdout` and
  `dark_period` as top-level packages at the wheel-install path. The
  source tree has them nested under `causallab/` for organizational
  clarity, but the wheel build flattens them.
- `casuallab_logger.py` carries a typo (`casual` not `causal`) in the
  module filename, preserved across imports — fixing it now would break
  every existing notebook in lab. The team treats it as the kind of
  technical debt that's cheaper to live with than to fix.

### 14.2 `config.yaml` — the configuration surface

The single source of truth for tunable parameters. Schema (illustrative):

```yaml
# Input metric lists
business_kpis:
  - Visits
  - FS_Submits
  - ZHL_Submits
  - Rental_Visits
  - MF_Submits

econ_variables:
  - median_income
  - mortgage_rate
  - unemployment_rate
  - google_trends_zillow
  - housing_starts

population_metric:
  - population_cnt

# Composite-score weights
composite_weights:
  kpi: 0.70
  econ: 0.25
  pop: 0.05

# Stratification + cell assignment
n_strata: 6
n_cells: 6
n_slots: 6
balance_score_n_trials: 5000
balance_score_weights:
  Visits: 1.0
  FS_Submits: 1.0
  ZHL_Submits: 0.8
  Rental_Visits: 0.8
  MF_Submits: 0.6
  # econ vars get ~0.3 each by default
n_strata_for_holdout: 5  # 5 of the 6 strata contribute one DMA each

# Latin square
max_overlap_pct: 10
max_attempts: 1000

# Slot / LOB mapping
slot_dict:
  1: [SEM_Google_Buyer]
  2: [SEM_Google_Rental]
  3: [Display_Programmatic_Buyer]
  4: [Display_Programmatic_Rental]
  5: [PaidSocial_Meta_Buyer]
  6: [PaidSocial_Meta_Rental]

lob_mapping:
  PA: 1
  Rentals: 2
  ZHL: 3
  Seller: 4

# Exclusion rules — business overrides
exclusion_rules:
  - slot_restricted: SEM_Google_Buyer
    lob_restricted: PA
    dma_restricted: 501  # New York
  - ...

# Date window
start_date: 2026-04-01
end_date: 2026-06-30
```

> **Inline flag — exact config keys.** The schema above is reconstructed
> from the notebook references; the live `config.yaml` may rename some
> keys. The structure — separation of input lists, weights, sizes,
> exclusions, dates — is the stable part.

### 14.3 Key files in `holdout_setup/`

#### 14.3.1 `assignment.py` — the end-to-end DMA certification pipeline

A single file with one class per pipeline stage. Per Tharun's KT
walkthrough, the classes (in execution order):

| Class | Methods | What it does |
|---|---|---|
| `DataPreparation` | `load_and_prepare`, `cap_at_percentile_df`, `apply_smart_log_transform` | Pulls metrics, applies non-zero filter, percentile-caps, log-transforms |
| `DataDistribution` | `check_distribution`, `skewness_check`, `plot_distribution` | Pre/post-transform skewness diagnostics + plots |
| `CompositeScorer` | `composite_score`, `validate_score_distribution`, `score_distribution_plot` | Min-max normalizes, applies 70/25/5 weights, validates resulting distribution |
| `Stratifier` | `number_of_strata` (K-means elbow), `create_strata` (quantile-cut), `validate_stratification` (monotonicity), `validate_within_stratum_homogeneity` (CV), `variance_reduction_check` (VRF) | All stratification + the first three internal validations |
| `CellAssigner` | `assign_cells` | The 5,000-trial balanced shuffle |
| `HoldoutSelectorClass` | `apply_to_allcells`, `get_control_dmas`, `write_final_matrix` | Slot-wise holdout selection with exclusions, control-pool definition, schema-shaped output |
| `ValidationEngine` | `levens_anova_test`, `moods_test`, `icc_test`, `balance_score_validation`, `check_smd_std`, `check_smd_pooled`, `plot_as_curve`, `parallel_kpi_trends_check`, `within_cell_anova`, `run_holdout_validation`, `parallel_trends_check_holdouts` | All the statistical tests, plottable curves, and parallel-trends checks |

The single-file design is intentional: it means a reader can scan the
whole pipeline top-to-bottom without bouncing between files. The file is
~1,500 lines — not unmanageable.

#### 14.3.2 `latin_square.py` — the rotation matrix

A single class `Latinsquarecreation`. Key methods (inferred from cell 79):

| Method | What it does |
|---|---|
| `generate_simple_matrix(previous_orders, max_overlap_pct, max_attempts)` | Generates Latin matrices via repeated random sampling until overlap with `previous_orders` is ≤ `max_overlap_pct`%, or until `max_attempts` is exceeded (raises if so) |
| `_validate_no_duplicates(matrix)` | Internal: confirms each row has unique entries (Latin-square property) |
| `_compute_overlap(matrix_a, matrix_b)` | The overlap fraction defined in Section 8.3 |

It also holds the `previous_orders` lookup — when running quarterly, the
caller passes in the prior quarter's matrix (typically loaded from the
prior `holdout_schedule` table row).

#### 14.3.3 `validation_engine` — modularized checks

In the snapshot, the validation engine is *inside* `assignment.py` as the
`ValidationEngine` class. Per Tharun's KT, the longer-term roadmap is to
split it out into `holdout_setup/validation_engine.py` so the same engine
can be reused by the dark-period code (Doc 03). When that split happens,
the engine will own all the test runners and the `assignment.py` pipeline
classes will *call into* the engine rather than embedding it.

### 14.4 The logger and config patterns

#### 14.4.1 Centralized config — no hardcoded numbers in code

A design rule (Tharun's KT 03-24): **every tunable is in `config.yaml`**.
Examples:

- The 70/25/5 composite weights — in config, not in `CompositeScorer`.
- The 5,000-trial count — in config (`balance_score_n_trials`), defaulted
  in the class but configurable.
- The 10% overlap cap — in config (`max_overlap_pct`), passed to
  `generate_simple_matrix`.
- The 99th-percentile cap — passed as `upper_percentile=99` from the
  notebook, defaulted in the class but overrideable.

Net effect: every methodological knob can be turned without code changes.
A new quarter with a different MDE target re-runs with a different
`balance_score_weights` config but the same code.

#### 14.4.2 Logger over print — packaged-code constraint

Once code is in a Python package and gets called inside a Databricks
notebook, `print()` statements behave inconsistently — they may or may not
appear in cell output depending on how the function is called. The Causal
Lab pattern (Tharun's KT 03-24):

- Every module instantiates a configured logger from `casuallab_logger`.
- All informational output uses `logger.info(...)`, all warnings
  `logger.warning(...)`, etc.
- The logger is configured at notebook-startup time to route to (a)
  stderr (visible in Databricks notebook), (b) MLflow's logged artifacts
  (for run records), and (c) the local lab filesystem (for debugging).

No `print()` calls anywhere in `causallab/`. New contributors are expected
to follow the convention; a pre-commit hook (planned, not yet implemented
as of KT snapshot) will eventually enforce it.

### 14.5 SQL-only data access — the 03-24 design decision

A specific design rule from KT 2026-03-24 (Tharun): **metric-pull functions
return DataFrames built from SQL strings, not Spark or pandas read paths
directly**. Why:

- **Boundary clarity.** SQL is the well-defined boundary between the data
  layer (warehouse tables) and the modeling layer (Python classes).
  Keeping the boundary in SQL means changes to table schemas are caught
  at the SQL parse step, not at NumPy-runtime when something goes wrong.
- **Cross-env portability.** The same SQL works in dev, stage, prod —
  only the catalog name swaps (via the widget). A pandas read path would
  need separate logic per environment.
- **Spark-or-not flexibility.** The same SQL string can be executed via
  Spark (for large DMA-week panels) or via pandas / DuckDB locally (for
  development). The Causal Lab functions take a `spark` session as input
  and dispatch.

The rule is enforced via code review. The data-pulling helpers in
`metrics/` (`business_metrics.py`, `economic_metrics.py`) take parameters,
build a SQL string, execute via the provided spark session, and return a
pandas DataFrame for downstream use.

### 14.6 How `geo_holdout_tactic.ipynb` consumes the package

End-to-end consumption pattern (drawn from Section 13):

```text
1. Notebook imports the Causal Lab classes (cell 9).
2. Notebook reads config.yaml (cell 14).
3. Notebook instantiates the classes (DataPreparation, CompositeScorer,
   Stratifier, CellAssigner, HoldoutSelectorClass, ValidationEngine,
   Latinsquarecreation) at the right pipeline stages.
4. Each instantiation passes the relevant config keys.
5. The classes return DataFrames; the notebook displays them or passes
   them downstream.
6. MLflow auto-logs figures and test results.
7. The final spark write to holdout_schedule is the only side effect.
```

The notebook is a thin orchestration layer. The methodology is in the
package. New contributors building, e.g., a *user-level* stratification
backup for Email (the plan from KT 2026-03-17 — see
[Doc 01 Section 2](01_existing_aot_systems.md#section-2-email)) would add a
`user_level/` subpackage following the same pattern: pipeline classes in
one file, a thin notebook to orchestrate them, config in `config.yaml`.

### 14.7 Packaging and CI/CD

- **Build**: Poetry produces `causallab-0.1.0-py3-none-any.whl` (visible in
  cell 1 of the notebook). Poetry is the Python-ecosystem-standard
  build/dependency tool.
- **Containerization**: a `Dockerfile` builds a Databricks-parity image
  (Spark, Python, native libs) so dev parity with prod is straightforward.
- **Tests**: `tests/test_assignment.py`, `test_latin_square.py` — pytest-
  based unit tests on synthetic data. WIP, coverage is incomplete.
- **Versioning**: SemVer; `0.1.0` is the pre-1.0 development version. The
  team plans to cut `1.0.0` once measurement is added.
- **Deployment**: the wheel is uploaded to `/Workspace/Shared/causal_lab/`
  and pip-installed in the cluster init script (or uncommented at the top
  of the notebook in lab).
- **Repo**: a separate git repo from `rapidmmm` and from `mmm_model`, but
  same Databricks workspace structure (lab / stage / prod parity, DAB-
  deployed jobs once measurement is in production).

The packaging follows the **same pattern as `rapidmmm`** — see
[MMM Doc 02](../learning_docs/md/02_rapidmmm_library_internals.md) for the
reference. Same Poetry build, same Dockerfile pattern, same wheel-upload
deployment. The package-level decision is to *not* combine Causal Lab and
rapidmmm: they're conceptually different (experiment design vs Bayesian
modeling), they ship at different cadences, and they have different
audiences (Causal Lab → AOT team and channel leads; rapidmmm → MMM team).

---

## 15. The taxonomy bridge — where this lands in the MMM ecosystem

The `holdout_schedule` table is the per-quarter design output. Once the
quarter runs, the **measurement** outputs flow downstream to the
incrementality layer ([Doc 04](04_incrementality_and_forecasting.md)),
which combines the geo-AOT cost-per with the MMM cost-per via the 50/50
weighting from [Doc 00 Section 7](00_aot_ecosystem_and_foundations.md#section-7).

The grain of the geo-AOT output must match the grain of the MMM output for
the join to work. Concretely:

| AOT-side | MMM-side | Match? |
|---|---|---|
| `(date, channel, network, core_lob, core_campaign_super, KPI)` | `(week_monday, channel, network, lob, campaign_super, KPI)` ([MMM Doc 06](../learning_docs/md/06_fs_submits_taxonomy_track.md)) | Date vs week_monday — the AOT measurement layer aggregates daily values to week-Monday for the MMM-side join |

The taxonomy alignment is enforced via the `slot_dict` in config — the
strings `SEM_Google_Buyer` etc. are split on underscores into
`(channel, network, tactic)` in cell 100, which matches the MMM taxonomy
exactly.

This is the symmetric counterpart to MMM's commitment to the same taxonomy
— see [MMM Doc 06 Section 1](../learning_docs/md/06_fs_submits_taxonomy_track.md)
for the MMM-side enforcement. The two systems converge on the same
`(channel, network, lob, campaign_super)` grain *by design*, not by
coincidence — that's what makes the incrementality-layer fusion in Doc 04
possible.

---

## 16. Closing — common interview questions

> 1. **"Walk me end-to-end through how you pick the 5 DMAs to hold out for a
>    given LOB next quarter."** Compose Sections 2 → 12. Mention the
>    composite score, K-means elbow → 6 strata, 5,000-trial balanced cell
>    shuffle, Latin square scheduling, power analysis for the 5-DMA size,
>    one-DMA-per-stratum diversification, exclusion overrides, and the
>    holdout-vs-control validation battery.
> 2. **"Why a composite score? Why those weights?"** Section 4. KPIs are 70%
>    because the experiment *is* measuring KPIs; econ is 25% as a residual-
>    variance explainer; population is 5% as a tiebreaker. Normalization
>    before weighting (Section 4.2) is what makes the weights interpretable.
> 3. **"K-means or quantile-cut?"** Both. K-means to *find K* via the elbow;
>    quantile-cut to *do the stratification*. Section 5.1.3 — quantile-cut
>    gives equal-size strata (good for cell assignment) and ordered strata
>    (good for diversification).
> 4. **"What does the balance score optimize?"** Across-cell CV of cell-level
>    means, weighted by importance. Section 6.2. Minimizes across 5,000
>    trials.
> 5. **"Same test, opposite expectation — why?"** ANOVA / Mood's / ICC are
>    run at both stratification (want reject) and cell-assignment (want
>    fail-to-reject) stages. Section 5.2 vs Section 7 — the *grouping* you
>    test against is different and so is the desired outcome. Same machinery,
>    different question.
> 6. **"Parallel trends at three horizons. Why three?"** Different scales
>    catch different violations. Section 7.7 — monthly catches seasonality,
>    weekly is the operational granularity, daily catches within-week
>    patterns.
> 7. **"Latin square — what does the 10% cap protect against?"** Section 8.3.
>    Without it, the same DMAs could be held out for the same LOB across
>    consecutive quarters, biasing the DiD measurement and crushing revenue
>    in those DMAs.
> 8. **"Why 5 DMAs?"** Section 9. Power analysis with $\alpha=0.05$,
>    $1-\beta=0.80$, target lift ~10%, log-normalized SD ~0.15 yields
>    $n \approx 3.5$ rounded up with margin to 5. Smaller = under-powered;
>    larger = unnecessary holdout cost.
> 9. **"Welch's t-test, Kruskal-Wallis, Mood's median — why three?"** Each
>    catches different failure modes. Welch's assumes approximate
>    normality; KW is rank-based, robust to non-normality; Mood's tests
>    medians, robust to outliers. With only 5 DMAs in the holdout, none of
>    the three alone is sufficient; the conjunction is.
> 10. **"Bonferroni vs FDR-BH — when do you use which?"** Section 11.3.3.
>     Bonferroni is the strict family-wise-error correction; FDR-BH is
>     the modern false-discovery-rate correction, more powerful when
>     there are real signals to find. For balance-checking (where we want
>     to *not* reject), FDR-BH is the operational gate; Bonferroni is
>     reported alongside for the strict-minded.

---

**Next:** Read [03_dark_period_tv.md](03_dark_period_tv.md)
— the time-axis generalization of the geo design for TV channels that can't
be geo-targeted. It reuses the same `latin_square.py`, the same
`ValidationEngine`, and the same MLflow / DAB packaging, but adds dark-
period scheduling logic (40–60% spend reduction, exclusion weeks, minimum
gap weeks) on top.
