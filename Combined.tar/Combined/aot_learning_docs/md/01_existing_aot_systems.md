---
title: Existing AOT Systems — Email, Paid Social (Meta), and SEM
description: Production walkthroughs of the three legacy AOT pipelines — user-level Email (Simon Data → Hightouch migration), vendor-managed Paid Social Facebook (Meta-handled Lift studies), and DMA-level SEM (manual R-code holdouts + DiD measurement). Push systems, pull systems, attribution windows, table architectures, cost-per math, and the operational limitations that motivated the rebuild.
---

# 01 — Existing AOT Systems: Email, Paid Social Meta, SEM

> **What this doc is.** A walkthrough of the three legacy AOT pipelines that
> are in production today — the only three channels with continuous causal
> measurement before the new Causal Lab geo-stratification and dark-period
> designs come online. For each system: how the **push side** (holdout
> design) works, how the **pull side** (measurement) works, the worked math
> for the lift calculation, the bronze/silver/transient/gold table inventory
> with full schema paths, the cadence and data-availability lag, and the
> operational limitations that motivated the rebuild documented in
> [Doc 02](02_geo_stratification_design.md) and
> [Doc 03](03_dark_period_tv.md).
>
> **What this doc is not.** The math primer (→ [Doc 00 Section 5](00_aot_ecosystem_and_foundations.md#section-5))
> or the new design (→ [Doc 02](02_geo_stratification_design.md)).
> We use the foundations from Doc 00 — DiD, counterfactual, stratified
> sampling — without re-deriving them.

---

## 1. The three systems at a glance

The three channels with continuous incrementality measurement at Zillow
today all sit on the same conceptual pattern (push → execute → pull, see
[Doc 00 Section 4](00_aot_ecosystem_and_foundations.md#section-4)) but each
implements it differently because the underlying delivery mechanism is
different. The summary table:

| | **Email** | **Paid Social (Meta/Facebook)** | **SEM** |
|---|---|---|---|
| **Holdout grain** | User (`ezuid`) | User (managed by Meta) | DMA (Nielsen designated market area) |
| **Holdout size** | ~4% of past-3-months recipients | 20% of campaign audience | 80 of 210 DMAs are "spend-focus"; subset held out monthly per LOB |
| **Test cadence** | Quarterly (3-month tests, refreshed every 90 days) | Quarterly (was monthly, switched to 90-day starting Jan 2026) | Monthly (groups change every month, set annually) |
| **Push owner** | Zillow DS (legacy) → Hightouch (in progress) | Meta Lift API (Zillow only configures via a Google Sheet) | Zillow DS (annual R-code generation) |
| **Pull owner** | Marketing DE | Marketing DE | Marketing DE |
| **Syndication target** | Simon Data (legacy) / Hightouch (new) | Meta Business Manager | None — pull side reads marketing-side tables directly |
| **Attribution windows** | 1, 3, 5 day (post-Nov 2025; was 1, 7, 14) | 7-day click + 1-day view (inherited from campaign, **not settable**) | Daily, with 60-day rolling for stability |
| **Measurement method** | DiD with 30-day pre-period baseline + t-test confidence | Meta's Lift methodology (vendor black-box) — Zillow only re-grains the output | YoY DiD with population-normalized counterfactual + t-test |
| **Statistical significance** | t-test confidence per metric × attribution-window | Meta-reported lift/confidence per cell × objective | t-test p-value; 60-day rolling significance flag |
| **Data lag** | 4–8 days behind current date | Daily (15-day lookback); previous month's results finalize on the 15th of the following month | Daily, ~6 PM UTC after 5:20 PM UTC job; 60-day rolling enforces stability |
| **Gold table** | `marketing.always_on_testing_gold.email_pooled_results` (since May 2023) | `marketing.always_on_testing_gold.fb_pooled_results` (since Jan 2025) | `marketing.always_on_testing_gold.sem_pooled_results` (since Apr 2023) |
| **Cross-channel gold** | All three flow into `marketing.always_on_testing_gold.testing_pooled_results` for downstream MMM × AOT integration ([Doc 04](04_incrementality_and_forecasting.md)) | | |
| **Job orchestrator** | Databricks Workflow (DAB-deployed); DBT-based transforms | Same | Same |
| **Catalog / schemas** | `marketing.always_on_testing_{bronze,silver,transient,gold}` | Same | Same |

Three things to notice in that table:

1. **The bronze/silver/transient/gold pattern is identical across all three.**
   This is a Marketing Datamart convention (Pulkit Bansal's
   architecture docs confirm it). New AOT designs will follow the same
   layering — see [Doc 00 Section 9](00_aot_ecosystem_and_foundations.md#section-9).
2. **The cadence diverges.** Email is quarterly because of user-churn risk
   (rotation rule, see Section 3.2); SEM is monthly because the DMA grain
   makes finer cadence safe; Meta moved monthly → quarterly to align with
   Email's 90-day study window.
3. **The data-lag diverges by an order of magnitude.** Meta returns results
   daily but with a hard "finalize on the 15th of the following month"
   ceiling. SEM and Email each have multi-day lags driven by source-table
   refresh times.

Each section below is structured: **(A) what makes this channel
distinctive**, **(B) the push system**, **(C) the pull system**, **(D) the
measurement math**, **(E) the table architecture**, **(F) the cadence and
lag**, **(G) the production limitations**.

---

## 2. The common shape: push, pull, and the medallion layers

Before the three deep dives, it's worth pinning down what's identical
across the three. Every AOT pipeline does the following:

### 2.1 The two-half architecture

```
┌─────────────────────────────────────┐        ┌──────────────────────────────────────────┐
│  PUSH (holdout design)              │        │  PULL (measurement)                      │
│  ──────                             │        │  ──────                                  │
│  • Build the holdout list           │        │  • Read source-of-truth KPI tables       │
│  • Append to                        │        │  • Filter to current test/control IDs    │
│    always_on_testing_silver.        │        │  • Apply attribution window aggregation  │
│    <channel>_*_holdout              │        │  • Compute DiD / counterfactual / lift   │
│  • Syndicate to activation platform │        │  • Compute cost-per-incremental + t-test │
│    (Simon Data / Hightouch /        │   →    │  • Write daily and 60-day rolling tables │
│     Meta API / SEM holdout sheet)   │        │  • Pool into <channel>_pooled_results    │
└─────────────────────────────────────┘        └──────────────────────────────────────────┘
       Runs on a slow cadence                          Runs daily (~6 PM UTC)
       (quarterly / monthly / annually)
```

### 2.2 The four-layer Delta architecture

Every AOT pipeline uses the standard Marketing Datamart medallion:

| Layer | Schema | Purpose |
|---|---|---|
| **Bronze** | `marketing.always_on_testing_bronze` | Raw landing zone — JSON-shaped API pulls, raw Facebook results, raw cumulative ad-account tables. Minimal transformation. |
| **Silver** | `marketing.always_on_testing_silver` | Cleaned, validated, type-cast, joined to taxonomy (`ad_hierarchy`). Holdout-membership tables live here. |
| **Transient** | `marketing.always_on_testing_transient` | Intermediate calculations — daily metric aggregations, attribution-window rollups, statistical-test inputs. Per-metric breakouts. |
| **Gold** | `marketing.always_on_testing_gold` | Standardized cross-channel output. `<channel>_pooled_results` is the consumption table; `testing_pooled_results` unions all three. |

The schema names are stable across channels. Within each schema the channel-
prefix differs (`email_*`, `fb_*`, `sem_*`).

### 2.3 The shared dimensions

All three pipelines harmonize against the same taxonomy tables (see
[MMM Doc 04 Section 3](../learning_docs/md/04_data_lineage_and_schemas.md)):

- **`marketing.marketingde_gold.ad_hierarchy`** — campaign → core_campaign_super
  / core_lob mapping. This is how AOT outputs become joinable with MMM at
  the same `channel × network × LOB × campaign_super` grain.
- **`marketing.marketingde_silver.mmm_regionmapping`** — DMA name ↔ dmacode
  (used by SEM; the legacy SEM also has its own Google-region → DMA
  mapping; see Section 5.5).
- **`marketing.rapidmmm_silver.mmm_holidays`** — though not directly used
  by AOT, it's how the downstream incrementality layer ([Doc 04](04_incrementality_and_forecasting.md))
  date-aligns AOT output with MMM.

### 2.4 The orchestration stack

- **Databricks Asset Bundles (DAB)** for multi-environment deployment
  (`zg-marketing-lab` / `-stage` / `-prod` workspaces). CI/CD-managed.
- **DBT** for SQL transformations, documentation, and tests (each pipeline
  has a `dbt` project — 13 models for Email Testing Workflow, 11 + 1 for
  Email Analysis, 36 for SEM, etc.).
- **Unity Catalog** for governance + access control.
- **Delta Lake** for the underlying storage (ACID, time-travel for
  backfills).
- **`#marketing-de-support`** for ops; **`#mops-oncall`** for OpsGenie
  alerts on prod failures.

This is the same orchestration story the MMM library uses
([MMM Doc 09](../learning_docs/md/09_operations_and_interview_capstone.md) covers
DAB deployment patterns), so cross-team handoffs are clean.

---

## 3. Email — User-level holdouts, Simon → Hightouch migration

### 3.1 Why Email is the most operationally subtle of the three

Email holdouts have a structural bias problem that the other two channels
don't. At any given moment, only a small slice of Zillow's ~42M registered
users is actually being *targeted* — the **ratio of email-targeted users
to untargeted users is ~1:18**. That means a naive "take 4% of all users"
holdout draws mostly from people who weren't going to be emailed anyway,
making the resulting test vs control comparison meaningless: you'd be
comparing two random samples of mostly-untargeted users.

The fix the team adopted (and which is preserved through the Hightouch
migration) is to **sample the holdout from the *previous test's treatment
group***, not from the full user base. That is: only people who *actually
received* marketing emails in the prior period are eligible for the next
holdout. This gives apples-to-apples comparability and is the single most
important design choice in the email pipeline.

A second design choice — **rotation** — prevents a user from being in the
holdout for two consecutive 3-month periods. Six months of no marketing
email materially raises churn risk; the rotation rule caps each user's
holdout exposure at 90 days.

### 3.2 Push system — quarterly holdout refresh

**Job**: [`aot_email_holdout_refresh_prod`](https://zg-marketing-prod.cloud.databricks.com)
**Schedule**: 1st day of every quarter (Jan 1 / Apr 1 / Jul 1 / Oct 1)
**Repo**: Email AOT repo under "Always On Testing" group

The push system runs once a quarter and does four things:

1. **Identify the eligible pool** — pull `customer.metrics.library` and
   `hive_metastore.mart_mede.bdo_email` joined to
   `marketing.marketingde_gold.ad_hierarchy` to find all users who received
   a marketing email in the **past 3 months** (the previous test window),
   filtered by `Channel = Email`, `Ad Network = Simon Data`,
   `Account = Marketing Emails`, `Campaign Super = B2C`,
   `Type = Injection`. Operational emails are excluded — only B2C
   promotional emails count.
2. **Take a ~30-day slice** from that 3-month window — any 30-day cohort
   works (the team's preference is the most recent 30 days for recency).
3. **Random-sample ~4%** of that ~30-day cohort as the new control group.
   This is the step a future redesign would replace with stratified
   sampling (see Section 3.10).
4. **Append + syndicate** — the new holdout list is appended to
   `marketing.always_on_testing_silver.email_testing_holdout` and
   syndicated daily to Simon Data via the
   `marketing_enrichment_syndication_daily_1_prod` workflow (the
   responsible task is `dbt_run_global_holdout_email`, model
   `global_holdout_email.sql`).

The 4% number is set by the business, not by us — the data-science team
owns the *methodology*, the marketing team owns the *percentage*.

Two related Silver tables track the *previous* test:

- `marketing.always_on_testing_silver.email_testing_holdout_prev_control`
- `marketing.always_on_testing_silver.email_testing_holdout_prev_test`

These exist for two reasons. (1) The rotation rule needs to know who was
in the previous holdout so they can be *excluded* from the next one. (2)
The new control sample is drawn from the previous *treatment* (recipients)
list, which is what `_prev_test` records.

### 3.3 Pull system — daily measurement at 1/3/5-day windows

**Job**: [`aot_email_pull_adstudy_daily_prod`](https://zg-marketing-prod.cloud.databricks.com)
**Schedule**: Daily at 06:00 AM UTC
**Latency**: Latest available date typically 4–8 days behind current
(driven by an explicit `current_date − 8 days` filter on the control-final
input table, designed to ensure the source-of-truth metric library has
fully populated for the window in question)

The pull system has two DBT projects running back-to-back:

#### Email Testing Workflow (13 DBT models)

This prepares the test-vs-control comparison data:

1. **User segmentation** — flag users as test or control with their
   activity dates (`email_testing_test_users`,
   `email_testing_control_users`).
2. **Metrics aggregation** — for each user × date, compute the per-metric
   counts (visits, FS submits, ZGMI submits, ZHL submits, rental metrics)
   from the **metric library** (`customer.metrics.library`) plus a
   ZHL-specific path via `hive_metastore.zetlstore.mmp_v2_zhl_contacts_w_zuid`.
3. **Attribution-window rollups** — re-aggregate the same metric for
   1-day, 3-day, and 5-day windows. (Before Nov 2025 the windows were
   1/7/14; the team tightened to 1/3/5 once they had enough run-time
   stability to justify finer granularity.)
4. **Data cleaning** — drop null metric values, *remove contaminated
   controls* (users in the control list who somehow received a marketing
   email anyway — measured by the `email_testing_control_check` table),
   and **divide attribution for users who received multiple campaigns** in
   the same window (so an FS Submit isn't double-counted across two
   simultaneous campaigns).
5. **Campaign aggregation** — roll metrics up to `campaign × initiative ×
   LOB`.
6. **Pre-period baseline** — compute the **30-day pre-period averages** for
   test and control separately
   (`email_testing_test_pre_period_avg`,
   `email_testing_control_pre_period_avg`). These are the
   "before" half of the DiD calculation.

#### Email Analysis Workflow (11 incrementality models + 1 consolidator)

For each of the 11 metrics (Visits, FSHDP submits, ZGMI submits, ZHL
submits, FR BDP PVs, FR HDP PVs, MF visits, SF visits, Rental visits,
FR BDP submits, FR HDP submits), a separate DBT model computes:

- Pre-vs-current difference for test (`avg_test_TY − avg_test_pre`)
- Pre-vs-current difference for control (`avg_control_TY − avg_control_pre`)
- The DiD estimate: difference-of-differences
- A **t-test** on the two sample means to produce a p-value
- A `confidence_level` of `high` / `medium` / `low` based on the p-value

These 11 models then get UNION-ALL'd into `email_analysis_init` and
aggregated into the gold table.

The **≥ 200K user exposure floor** is also applied here: campaigns are
included only if they exposed at least ~200K users in the test window.
This is to prevent highly-targeted small campaigns from contaminating the
pooled lift estimate (the variance on a 1K-exposure campaign is too high
to learn from). Two metrics — **Visits and FSHDP submits** — are exempt
from the 200K floor because the broad-population coverage of those KPIs
makes the variance well-controlled even at small exposure.

### 3.4 The measurement math — DiD with a 30-day pre-period

For a single metric (e.g., FS Submits) and a single attribution window
(say, 3-day), the calculation per day is:

$$\widehat{\tau}_{\text{DiD}} = \big(\bar{Y}_{T, \text{TY}} - \bar{Y}_{T, \text{pre}}\big) - \big(\bar{Y}_{C, \text{TY}} - \bar{Y}_{C, \text{pre}}\big)$$

where:

- $\bar{Y}_{T, \text{TY}}$ = average per-user metric value in the test
  group (recipients) for the current day's 3-day attribution window.
- $\bar{Y}_{T, \text{pre}}$ = the 30-day pre-period average for that same
  test group (computed once per quarter, when the holdout was last
  refreshed).
- $\bar{Y}_{C, \text{TY}}$ and $\bar{Y}_{C, \text{pre}}$ — the same for
  control.

This is straight textbook DiD (see
[Doc 00 Section 5.2](00_aot_ecosystem_and_foundations.md#section-5)). The
identifying assumption is parallel trends between recipients and the
holdout in the pre-period.

The **lift %** is then $\widehat{\tau}_{\text{DiD}} / \bar{Y}_{C, \text{TY}}$
(the causal lift expressed as a fraction of control). The **incremental
event count** is `lift × treatment_population_count`. The **cost per
incremental** is `marginal_spend / incremental_count` — where marginal
spend is the daily spend, not cumulative (which is one of the things the
Datamart consolidation fixed).

The **t-test** runs on the two means
($\bar{Y}_{T, \text{TY}}, \bar{Y}_{C, \text{TY}}$) using their respective
sample sizes to produce a p-value, which maps to a `confidence_level`:

| p-value | `confidence_level` |
|---|---|
| < 0.05 | `high` |
| 0.05 – 0.1 | `medium` |
| > 0.1 | `low` |

> **Inline flag — exact thresholds.** The Confluence FAQ describes the
> three-tier classification but does not pin the exact cutoffs in writing.
> The thresholds above (0.05 / 0.10) are the industry-standard "high/medium/
> low" mapping the codebase appears to use — confirm against
> `email_analysis_<metric>.sql` for the literal `case when p < 0.05` branch
> before quoting in production.

### 3.5 Table architecture — Email

The full Delta-table footprint of the Email pipeline, in dependency order:

**Source (raw, not in AOT schemas):**

```
communications.email_gold.fact_email                     -- email send fact
hive_metastore.mart_mede.bdo_email                       -- email events (open/click)
customer.identity.legacy_summary                         -- user identity mapping
customer.metrics.library                                 -- user × day × metric counts (the KPI source-of-truth)
marketing.marketingde_gold.ad_hierarchy                  -- campaign → super × LOB taxonomy
hive_metastore.zetlstore.mmp_v2_zhl_contacts_w_zuid      -- ZHL-specific contact lookup
```

**Silver (`marketing.always_on_testing_silver`):**

```
email_testing_holdout                                    -- current quarter's control list
email_testing_holdout_prev_control                       -- previous quarter's control
email_testing_holdout_prev_test                          -- previous quarter's recipients (pool for next holdout)
email_testing_control_check                              -- contamination check (controls who got emails)
email_testing_metrics                                    -- daily user × engagement metric counts
email_testing_test_list                                  -- user × campaign × send date for recipients
email_testing_zhl_metric                                 -- ZHL contact data mapped to ZUIDs
```

**Transient (`marketing.always_on_testing_transient`):**

```
email_testing_control_users                              -- control with activity dates
email_testing_test_users                                 -- treatment with activity dates
email_testing_test_metrics                               -- treatment metrics × dates
email_testing_control_metrics
email_testing_control_metrics_summarized
email_testing_test_metrics_cleaned                       -- nulls dropped, contamination removed
email_testing_test_mapped                                -- campaign × LOB attribution split
email_testing_final_zhl                                  -- ZHL-specific consolidation
email_testing_control_metrics_cleaned
email_testing_control_final
email_testing_campaigns_final                            -- campaign-level rolled-up output
email_testing_test_pre_period_avg                        -- the 30-day pre-period baseline for treatment
email_testing_control_pre_period_avg                     -- same for control

-- Per-metric incrementality models (11):
email_analysis_visits
email_analysis_fshdp_submits
email_analysis_zgmi_submits
email_analysis_zhl_submits
email_analysis_fr_bdp_pvs
email_analysis_fr_hdp_pvs
email_analysis_mf_visits
email_analysis_sf_visits
email_analysis_rental_visits
email_analysis_fr_bdp_submits
email_analysis_fr_hdp_submits

-- Consolidator:
email_analysis_init                                      -- UNION ALL of the 11 above
```

**Gold (`marketing.always_on_testing_gold`):**

```
email_pooled_results                                     -- the consumption table (since May 2023)
```

The gold table schema standardizes:

| Column | Meaning |
|---|---|
| `date` | The test day |
| `channel` | Hardcoded `"Email"` |
| `ad_network` | Hardcoded `"Simon_Data"` (this is what the MMM taxonomy expects) |
| `core_campaign_super` | From `ad_hierarchy` |
| `lob` | From `ad_hierarchy` |
| `metric_type` | One of the 11 standardized metric names (`Visits`, `FS Submits`, ...) |
| `att_w` | Attribution window: `1`, `3`, or `5` |
| `cost_per` | Cost per incremental metric for this day × window |
| `lift` | DiD lift % |
| `confidence_metric_type` | `p-value` |
| `confidence_metric_value` | Numeric p-value |
| `confidence_level` | `high` / `medium` / `low` |
| `email_date` (Test rows) | The actual email receive date |
| `n_email_date` (Control rows) | Synthetic mirror of `email_date` for schema alignment (control users obviously have no real `email_date`) |
| `sample_size` | Cohort user count |
| Various `TY_*`, `LY_*`, `avg_*`, `std_*`, `sum_*` | Prefixed metric aggregates. `LY_` columns are deprecated as of late 2025. |

#### Specific metric formulas (from the Confluence Architecture doc)

These are the production definitions of each KPI as joined out of the
metric library:

| Metric | SQL |
|---|---|
| **Visits** | Session counts on Web + App with a 30-minute inactivity timeout |
| **FS Submits** | `COUNT(DISTINCT CASE WHEN metric_num['FSHDPCallSubmits'] > 0 OR metric_num['FSHDPEmailSubmits'] > 0 THEN ml.zuid END)` |
| **ZGMI Submits** | `SUM(MortgageZLFPurchaseContacts + MortgageZLFContacts)` |
| **ZHL Submits** | `COUNT(DISTINCT(ContactID))` from `mmp_v2_zhl_contacts_w_zuid` |
| **Sends** | `COUNT(messageid)` |
| **Sample Size** | `COUNT(ezuids)` |
| **Rental metrics** | `fr_bdp_pvs`, `fr_hdp_pvs`, `sf_visits`, `mf_visits`, `rental_visits`, `fr_bdp_submits`, `fr_hdp_submits` (each is a distinct metric_num key in the metric library) |

### 3.6 Cadence and data-availability lag

- **Push job (holdout refresh)**: Quarterly, fires on Jan 1 / Apr 1 /
  Jul 1 / Oct 1. The new holdout is syndicated daily to Simon Data
  starting the next day; in practice the control is live in Simon's
  exclusion list within 24 hours of the push job completing.
- **Pull job**: Daily at 06:00 AM UTC.
- **Lag**: The Confluence Overview says results are "typically 4–8 days
  behind current"; the Architecture doc clarifies the control-final
  component specifically uses `current_date − 8 days` as its source
  filter to give the metric library time to populate. So the freshest day
  available in the gold pooled table is `today − 8 days` (sometimes
  fresher, never more current). A separate FAQ entry mentions "23–24 days
  behind" — this is the worst-case end-to-end, including identity table
  refresh lag, but the typical case is 4–8 days.
- **Data history**: `email_pooled_results` has data since **May 2023**.
- **Lookback / reprocessing window**: 5 days (the pipeline re-processes
  `current_date − 4` through `current_date − 8` each day in case of late-
  arriving metrics).

### 3.7 What's filtered in / out

The Confluence FAQ pins this explicitly:

| Filter | Value |
|---|---|
| `channel` | `Email` |
| `ad_network` | `Simon Data` |
| `account` | `Marketing Emails` |
| `core_campaign_super` | `B2C` |
| `type` | `Injection` |

Translated: only B2C promotional emails routed through Simon Data with an
"Injection" type are included. **Operational emails are explicitly
excluded** — password resets, transactional confirmations, and other
non-promotional sends don't enter the test.

### 3.8 Limitations that motivated the rebuild

There are five real production limitations:

1. **Random 4% sampling is biased.** Single-draw stratum representation
   variance — see [Doc 00 Section 5.3](00_aot_ecosystem_and_foundations.md#section-5).
   Even sampling from the targeted pool only, you can over- or under-
   represent high-engagement vs low-engagement users. The stratified-
   sampling backup (Section 3.10) is the planned fix.
2. **Holdouts are at campaign-super level, not LOB level.** The current
   email AOT can attribute lift to `Buyer` or `Rental` as a whole but
   cannot split rental-customer vs rental-partner. The FAQ explicitly
   confirms this. The Hightouch migration potentially fixes it via
   journey-level holdouts (Section 3.9).
3. **Vendor lock-in.** The Simon Data integration is bespoke — the
   syndication workflow knows Simon's bucket structure and table format.
   When Zillow decided to migrate to Hightouch, all that integration code
   had to be re-thought. A future move to a third vendor would repeat the
   pain.
4. **Latency.** The 4–8 day lag is not driven by the pipeline itself —
   it's driven by the metric library's refresh schedule. Until that
   upstream changes, no AOT redesign can produce fresher numbers.
5. **Contamination risk.** Users in the control sometimes still receive
   marketing email (via different system paths, manually-triggered sends,
   or sends prior to Simon's exclusion list refresh). The
   `email_testing_control_check` table exists to identify contamination,
   but contaminated users dilute the lift estimate downward — a hard
   problem to fix with off-platform delivery.

### 3.9 The Simon Data → Hightouch migration (in progress, 50% as of KT 2026-03-23)

Hightouch is structurally different from Simon Data: it **supports
in-platform holdout creation**, meaning Zillow can construct test/
control splits *inside Hightouch's UI* rather than pre-computing them
and pushing a list. The unit Hightouch operates on is a **journey** — a
series of campaigns targeting a specific audience (e.g., "users who
viewed a rental listing in the past 7 days").

What changes:

| | **Simon Data (legacy)** | **Hightouch (new)** |
|---|---|---|
| Holdout construction | Zillow builds in Databricks, pushes a list to Simon | Hightouch UI builds it given audience definition + treatment/control percentage |
| Holdout grain | Campaign super | Journey (more granular than campaign super; close to LOB) |
| Audience definition | Implicit (whoever is in the campaign list) | Explicit (audience built in Hightouch's audience-builder via filters) |
| Activation | Simon's email-send platform | Hightouch routes to Braze (the actual send platform) |
| LatentView's role | Phase 1 (setup) + Phase 3 (measurement) | Phase 3 (measurement) only — Phase 1 moves to Hightouch's UI |

The migration shifts our role from end-to-end ownership to measurement-
only. That has two consequences: (1) less operational toil for the team,
(2) we have less control over the holdout design, which means the
stratified-sampling backup plan (Section 3.10) is doubly important if
the next platform doesn't have in-platform holdouts.

### 3.10 The stratified-sampling backup plan (Tharun, KT 2026-03-17)

If a future platform doesn't support in-platform holdouts, the team has
designed a fallback: replace the random 4% with a **20-strata stratified
sample** at the user level. The mechanic:

1. For each user who received marketing email in the past 30 days,
   compute their **past-28-day** and **past-84-day** engagement metrics
   (visits, FS submits, ZHL submits, rental visits) from the metric
   library.
2. Build a **composite engagement score** as a weighted average. The
   weighting depends on the campaign super:
   - For a *Buyer* campaign-super holdout, weight FS-related metrics
     higher (they're the high-intent signal for that audience).
   - For a *Rental* campaign-super holdout, weight rental-related metrics
     higher (rental visits, MF submits).
3. Run `NTILE(20) OVER (ORDER BY composite_score)` to split users into
   20 strata.
4. From each stratum, sample the target fraction (4% or 8% depending on
   business needs) → union → that's the new holdout.

This is the same general philosophy that drives the new geo design
([Doc 02 Sections 4–5](02_geo_stratification_design.md#section-4)) —
just at the user grain instead of the DMA grain. The variance-reduction
argument is identical: stratified sampling collapses the binomial variance
on the stratification dimension (composite engagement score) compared to
SRS.

> **Open question for an interview**: *"Why 20 strata, not 10 or 50?"*
> The KT material doesn't justify the 20 explicitly, but the rationale is
> probably the same as the geo design's K-means elbow — empirically the
> point where further sub-division stops reducing within-stratum variance.
> For email's case, with millions of users in the recipient pool, 20
> strata gives ~50K+ users per stratum, plenty for stable 4% sampling.

---

## 4. Paid Social Facebook — Meta-handled, we just ETL

### 4.1 Why Paid Social is the simplest of the three

Meta runs the entire experiment. The Facebook Business API supports
**Lift studies** as a first-class object: Zillow tells Meta "run a
90-day Lift study on this ad account, measure these conversions, with
20% holdout" and Meta does the holdout split, runs the campaigns,
attributes the conversions, and returns the lift numbers via API. Zillow
never sees the user-level data — only Meta's aggregated cell × objective
output.

Our entire pipeline is therefore (a) configure the study via a Google
Sheet → push to Meta API, (b) pull the results daily from Meta API,
(c) re-grain the output to match the MMM taxonomy. There is no DiD
calculation on our side, no t-test, no significance test — Meta's Lift
API gives us those numbers directly.

### 4.2 Push system — Google Sheet → Alteryx → Databricks → Meta API

**Job**: [`aot_fb_post_adstudy_prod`](https://zg-marketing-prod.cloud.databricks.com)
**Schedule**: Quarterly via cron `"0 0 0 1 1,4,7,10 ?"` — first day of
Jan / Apr / Jul / Oct (starting Jan 2026; previously monthly with 28-day
studies)
**Cadence change**: Cadence moved from **monthly 28-day** studies →
**quarterly 90-day** studies to align with Email's quarterly cadence and
reduce study-setup churn.

The data flow:

```
┌─────────────────────────┐
│ Google Sheet            │ ── DS team owns this. Each row = one ad-account × objective × study config.
│ ("Ad-account Events     │    Columns include start_date, end_date, custom_event_y_n, event name or
│  list")                 │    custom_conversion_id, account ID, holdout % (default 20%).
└────────┬────────────────┘
         │ Alteryx job
         ▼
┌─────────────────────────┐
│ Avro file in S3         │
└────────┬────────────────┘
         │ Databricks file ingestion
         ▼
┌─────────────────────────────────────────────────────┐
│ marketingde_silver.fb_test_automation_result        │   Source-of-truth for what Lift studies should exist.
└────────┬────────────────────────────────────────────┘
         │ aot_fb_post_adstudy_prod
         │ (Databricks notebook: fb_api_push_adstudy.ipynb,
         │  uses FB Business API SDK v19)
         ▼
┌─────────────────────────┐
│ Meta Business Manager   │   Lift studies created here. Each study runs for 90 days; 7-hour cooldown
│ (Lift Studies)          │   before activation; 95% confidence level configured by default.
└─────────────────────────┘
```

The Databricks notebook reads `fb_test_automation_result`, builds a JSON
config per study (study type = `LIFT`, treatment = 80%, control = 20%,
duration = 90 days, cooldown = 7 hours, confidence = 0.95), and calls
`AdStudy(...).api_create(params=...)` for each. There's a `dry_run` flag
that prints the JSON without making the API call — useful for stage/lab.

**Configurable knobs in the sheet** (per study row):
- `account_id` — which ad account to test on
- `objective` — the conversion event to measure (Visits, FS Submits, or
  account-specific custom events)
- `custom_event_y_n` — flag: standard FB event vs Zillow custom conversion
- `event_name` (for standard) or `custom_conversion_id` (for custom)
- `start_date`, `end_date`
- Holdout percentage (defaults to 20% but per-row override possible)

**Key constraint — CAPI enablement.** Meta only allows Lift studies on
**CAPI-enabled events** (Conversion API — events tracked both client-side
and server-side via the pixel). Adding a non-CAPI event to the sheet will
cause the API call to fail. The Confluence FAQ notes that Visits
(AddPaymentInfo) is *not* fully CAPI-enabled, so its measured lift may
be inaccurate.

### 4.3 Pull system — daily API fetch

**Job**: [`aot_fb_pull_adstudy_results_prod`](https://zg-marketing-prod.cloud.databricks.com)
**Schedule**: Daily at 16:30 / 3:45 PM UTC (the cron is `45 15 * * *` in
some docs, `16:30 UTC` in others — both refer to the same job; the
Overview page is canonical)
**Lookback**: 15 days (each day's run fetches the latest 15 days of
results to handle Meta's irregular update cadence)
**Hard ceiling**: Final monthly results are only updated until the **15th
of the following month**, after which Meta freezes the study output.

The pipeline:

1. **Fetch via API** — using Meta SDK v19, hit the Lift study results
   endpoint for each active study. Results come back in **cumulative
   JSON** with one row per cell × objective × day.
2. **Land in Bronze** — `fb_adstudy_list_raw`, `fb_adstudy_results_raw`,
   `fb_adstudy_cell_info_raw`.
3. **Cast types + incremental save to Silver** — `fb_adstudy_list_test`,
   `fb_adstudy_results_test`, `fb_adstudy_cell_info_test`.
4. **Rank + flatten JSON in Transient** — for a given study × day, take
   the latest record (deduplication). Flatten the JSON metric blob into
   columnar form. `fb_adstudy_results_prod`, `fb_adstudy_info_prod`,
   `fb_adstudy_cell_info_prod`.
5. **Cumulative-to-daily conversion** — the engineering crux of this
   pipeline; see Section 4.5.
6. **Aggregate + join to taxonomy** — sum/avg metrics across the 15-day
   lookback window per cell, join to `ad_hierarchy` to get
   `core_campaign_super` and `core_lob`. Write to gold
   `fb_pooled_results`.

### 4.4 The Meta hierarchy

Meta's data model is a 4-level hierarchy that our pipeline collapses to
the MMM taxonomy grain:

```
Ad Account (≈ campaign-super × LOB combination, 1 or a few per LOB)
   └── Campaign (one period of marketing activity)
        └── Ad Set (audience + budget)
             └── Ad (creative)
```

The Lift study runs at the **ad-account level** — one study per ad account
per period, measuring multiple `objectives` (Visits / FS Submits / custom)
within the same study. Meta returns results at the **cell × objective**
level. A *cell* is a sub-group within the study; effects across objectives
within the same cell are **additive** (so `FS Submit (main)` + `FS Submit
(call)` sum to total FS Submits for that cell).

Our pipeline joins the ad account ID to a side table that says
"ad account A belongs to `core_campaign_super = Buyer`, `core_lob = PA`,"
allowing the Meta cell × objective output to be re-grained to the MMM
`channel × network × LOB × campaign_super` schema.

### 4.5 Cumulative-to-daily conversion + gap imputation — the engineering crux

This is the most code-heavy part of the FB pipeline because **Meta returns
cumulative numbers, not daily numbers**. If the campaign saw 100
incremental visits on day 1 and 80 more on day 2, the table shows
`day_1 = 100, day_2 = 180`, not `day_1 = 100, day_2 = 80`. So:

**Step 1 — un-cumulate by lag subtraction:**

$$Y_t^{\text{daily}} = Y_t^{\text{cumulative}} - Y_{t-1}^{\text{cumulative}}$$

Implemented in SQL with `LAG()`. The first day in a study just keeps its
cumulative value (since there's nothing before it to subtract).

**Step 2 — handle gaps caused by Meta pipeline failures.** Meta sometimes
fails to update a day's row. If `day_3` is missing but `day_4` is present,
the naive lag gives:

| Date | Cumulative | Naive daily (= cum_t − cum_{t-1}) |
|---|---|---|
| Jan 1 | 100 | 100 |
| Jan 2 | 300 | 200 |
| Jan 3 | (missing) | NULL |
| Jan 4 | 700 | 400 (= 700 − 300) |

The "400" at Jan 4 actually covers Jan 3 + Jan 4 combined — Meta updated
both days but only emitted one row.

**Step 3 — impute the missing day by splitting evenly.** Cross-join with
a calendar to find the missing date, then:

| Date | Cumulative | Final daily |
|---|---|---|
| Jan 1 | 100 | 100 |
| Jan 2 | 300 | 200 |
| Jan 3 | (imputed) | **200** (= 400/2) |
| Jan 4 | 700 | **200** (= 400/2) |

If two consecutive days are missing and `day_5` shows the catchup,
divide by 3, and so on. The KT 2026-03-17 walkthrough confirms this
splitting logic.

The result of this step lands in `fb_adstudy_results_prod` as a
day-grained metric table, suitable for join to `ad_hierarchy` and roll-up
to gold.

### 4.6 Table architecture — Facebook

**Source / configuration:**

```
marketingde_silver.fb_test_automation_result             -- the per-study config sheet, ingested from Google Sheets via Alteryx
```

**Bronze (`marketing.always_on_testing_bronze`):**

```
fb_adstudy_list_raw                                      -- raw JSON of all studies returned by the API
fb_adstudy_results_raw                                   -- raw JSON of per-cell × objective results
fb_adstudy_cell_info_raw                                 -- raw JSON of cell metadata (spend, impressions, exposed pop)
```

**Silver (`marketing.always_on_testing_silver`):**

```
fb_adstudy_list_test                                     -- typed incremental list
fb_adstudy_results_test                                  -- typed incremental results
fb_adstudy_cell_info_test                                -- typed incremental cell info
```

**Transient (`marketing.always_on_testing_transient`):**

```
fb_adstudy_info_prod                                     -- ranked latest record per study × day; flattened JSON
fb_adstudy_results_prod                                  -- the post-uncumulate, post-imputation daily-grain table
fb_adstudy_cell_info_prod                                -- cell metadata at prod-clean grain
```

**Gold (`marketing.always_on_testing_gold`):**

```
fb_pooled_results                                        -- the consumption table (since Jan 2025)
```

Additional dependencies the pull pipeline reads from:

```
growth.traffic_gold.metrics_traffic_summary              -- used as a multiplier source (or mlv2 replacement)
marketing.marketingde_gold.ad_hierarchy                  -- the campaign taxonomy
```

The gold table standardizes to the same cross-channel schema as Email and
SEM gold tables (date, channel, ad_network, lob, core_campaign_super,
metric_type, cost_per, lift, confidence_*, etc.). For FB,
`ad_network = "Facebook"` and `channel = "Paid Social"`.

### 4.7 Cadence + lag

- **Push**: Quarterly (Jan 1 / Apr 1 / Jul 1 / Oct 1 starting 2026).
  90-day studies.
- **Pull**: Daily at 16:30 / 3:45 PM UTC.
- **Lookback**: 15 days each run.
- **Latency**: Same-day from Meta (when Meta's API returns results),
  modulo Meta's irregular update behavior.
- **Hard ceiling**: Previous month's results finalize on the 15th of the
  following month — Meta doesn't update them after that.

### 4.8 Study configuration knobs (the FB-specific particulars)

| Parameter | Value | Notes |
|---|---|---|
| `study_type` | `LIFT` | Meta's randomized holdout experiment type |
| Treatment / control split | 80% / 20% | Default; per-study override possible via the Google sheet |
| Duration | 90 days | Was 28 days monthly; switched 2026 |
| Cooldown | 7 hours before study start | Lets the Meta team verify config |
| Confidence level | 95% | Used by Meta for the lift CI / significance flag |
| Attribution window | **7-day click + 1-day view** | **Inherited from the campaign** — Lift studies cannot set this independently |
| Objectives | FS Submits + Visits on all accounts; account-specific events per Google sheet | Only CAPI-enabled events are eligible |

### 4.9 Limitations

1. **No attribution-window control.** Lift studies inherit the campaign's
   attribution window, so we can't compare 1-day vs 3-day vs 5-day like
   we do for Email. This is a Meta-side restriction.
2. **No historical re-pull.** Meta's API gives us only the latest day's
   results; if our pipeline missed a day, we can't backfill. We get one
   shot per day.
3. **No setup confirmation.** The push job calls `api_create()` for each
   study but Meta doesn't return a confirmation that the study was
   actually created and is running. The push notebook just assumes
   success.
4. **CAPI gating.** Events not CAPI-enabled either fail outright or
   return less accurate numbers (the Visits/AddPaymentInfo case). To
   measure a new event, the engineering team has to CAPI-enable it via
   pixel setup, which is a separate workstream.
5. **Vendor black-box.** We don't see the underlying user-level data, the
   exact statistical methodology Meta uses, or the cell-assignment
   randomization. We trust Meta's lift estimate and its 95% confidence
   interval, but we can't validate it.

> **Interview angle — "What's the AOT Paid Social pipeline actually
> doing?"** Three things: (1) it configures Lift studies on Meta via the
> Business API based on a config sheet, (2) it pulls Meta's daily
> cumulative results, converts to daily values, imputes gaps, and (3) it
> aligns the cell × objective output to Zillow's MMM taxonomy grain so
> the incrementality layer can join it. The actual lift estimation is
> done by Meta — we don't do statistics on this channel.

---

## 5. SEM — DMA-level holdouts and YoY DiD

### 5.1 Why SEM is the cleanest DiD geo pattern

SEM is the channel where geo-targeting is fully under our control — we
can bid (or not bid) on Google's search auctions in any DMA. So the
holdout is at the **DMA level**: pick some DMAs as the holdout, don't bid
in them for the test period, compare to DMAs where we did bid. This is
a textbook geo-experiment, and the new geo-stratification design
([Doc 02](02_geo_stratification_design.md)) generalizes
exactly this idea to non-SEM geo-targetable channels.

The legacy SEM measurement uses a slightly opinionated DiD variant:
**year-over-year** (this year vs last year, same month) rather than
within-year (post vs pre, same year). The reason is that SEM has strong
seasonality, and last-year-same-month is a cleaner baseline than
last-month-same-year. Population normalization (dividing by DMA
population) handles cross-DMA size differences.

### 5.2 Push system — annual R-code generation of monthly DMA holdouts

**Job**: Manual, run **once a year** at the start of each calendar year.
**Owner**: Data Science team (the only AOT push system still owned by DS
rather than Marketing DE).
**Tool**: R script (`SEM_Test_Schedule_Aug23.R`, run locally in RStudio).

The flow:

```
┌────────────────────────────────────┐
│ Marketing team's preferred DMAs    │  Google Sheet — the 80 DMAs out of 210 that SEM will focus
│ (~80 of 210 spend-focus DMAs)      │  spending on for the year. Updated annually.
└────────┬───────────────────────────┘
         │ export → CSV (Active_DMAs_2023.xlsx)
         ▼
┌────────────────────────────────────┐
│ DMA population data                │  Pulled from warehouse.regionmaster_dbo_region (Query_for_region_master.txt)
│ (region_master.txt)                │  → region_master.txt
└────────┬───────────────────────────┘
         │
         ▼
┌────────────────────────────────────┐
│ DMA → region mapping               │  region_dma_mapping.xlsx (one-time reference)
└────────┬───────────────────────────┘
         │
         ▼
┌────────────────────────────────────┐
│ R script (SEM_Test_Schedule_Aug23.R)│ Run locally in RStudio v4.4.2. Depends on tidyverse,
│   Inputs: above 3 CSVs              │ readxl, xlsx, openxlsx. Generates monthly DMA holdouts
│   Output: SEM_Revised_Schedule_1.xlsx│ balanced by population per LOB.
└────────┬───────────────────────────┘
         │ Review with PMMs, finalize
         ▼
┌────────────────────────────────────┐
│ Google Sheet (final holdout)       │  PMMs sign off on this.
└────────┬───────────────────────────┘
         │ Alteryx job (MOPS team) → ingest
         ▼
┌────────────────────────────────────────────┐
│ marketingde_silver.sem_test_automation_result  │   Daily-refreshed table that the SEM pull job reads.
└────────────────────────────────────────────┘
```

The constraints baked into the R code:

1. **Holdouts only from the 80 spend-focus DMAs**, not the full 210.
   (The other 130 DMAs have low SEM spend; the variance on their YoY
   change is too high to measure lift reliably.)
2. **Population-balanced groups** — each month's holdout list across
   all LOBs is balanced so each group's combined population is close
   to the others (~4–8% of the 80-DMA total).
3. **One DMA cannot be holdout for two different LOBs in the same
   month.** This is the cross-LOB rule from
   [Doc 00 Section 3.2](00_aot_ecosystem_and_foundations.md#section-3) —
   if a DMA is dark for both Buyer-SEM and Rental-SEM in the same month,
   you can't attribute any lift drop to one specific LOB.
4. **One DMA cannot be holdout for two consecutive months for the same
   LOB.** The cross-month rule, again from Doc 00 — extended dark
   periods materially hurt the DMA's revenue.
5. **Business overrides** — the channel team can manually exclude
   high-revenue DMAs (e.g., **New York**, **Texas**) from the holdout
   list for specific LOBs. The KT 2026-03-16 walkthrough mentions this
   happens routinely: the DS team generates a draft, the channel team
   says "swap New York out for Buyer-LOB this Q," and the DS team
   re-runs the R code with a hard exclusion to produce the final
   schedule.

> **Inline flag — population threshold.** The Confluence Overview says
> "80 of 210 DMAs" but the KT walkthrough mentions "**4–5%** or sometimes
> **8%** of US population" as the per-LOB-per-month holdout target.
> Reconcile: the 80 DMAs are the *pool*; from that pool, a per-month
> holdout per LOB is selected such that the holdout's combined population
> hits the 4–8% target. So "4–8% of total US pop" is the per-LOB-per-
> month constraint, not the annual total.

### 5.3 Pull system — daily SparkSQL + PySpark

**Job**: [`aot_sem_pull_prod`](https://zg-marketing-prod.cloud.databricks.com)
**Schedule**: Daily at 05:20 PM UTC; data available by ~6 PM UTC.
**Implementation**: SparkSQL for table reads + PySpark for the
statistical modeling.

The pull system has two modules:

#### Module 1 — Build the unified SEO/SEM metrics table

The challenge: SEM holdouts measure the lift of *paid* search; but we
need to compare against *total search* sessions (SEO + SEM combined),
because a DMA without SEM might still get organic traffic that absorbs
some of what the SEM ad would have driven. So the silver layer combines
both.

Sources:

| Source table | Purpose |
|---|---|
| `warehouse.uazillowweb` | Google Analytics session data (SEO/SEM split) |
| `clickstream.daily_web_nopii` | NL clickstream-level session data (alternate session source) |
| `warehouse.metrics_library` / `warehouse.metrics_library_v2` | User × day × KPI counts (Visits, FS, ZGMI submits) |
| `warehouse.uamloa` | ZHL-specific submits |

The DBT project (in the SEM AOT repo) joins these and writes:

```
marketing.always_on_testing_silver.metrics_prod_seo_sem
```

— a DMA × date table with combined SEO + SEM session and submit counts
for each metric (Visits, FS Submits, ZGMI Submits, ZHL Submits, rental
metrics).

The session-marketing distinction (paid vs organic) is encoded in the
session ID and the campaign info — paid sessions came from a SEM ad
click and carry the campaign name in the URL parameters; organic
sessions don't. The `session_marketing_info_dictionary` table holds the
campaign metadata. The join chain:

```
session ID + date → session_marketing_info_dictionary (campaign info)
                  → metric_library (per-session KPI events)
                  → google_region (via session attribution)
                  → dma_code (via google_region → dma_code mapping table)
```

The Google region → DMA region mapping is critical — Google reports
sessions at *Google's* region grain, which doesn't perfectly align with
Nielsen DMAs. The mapping is a side table maintained by the team.

#### Module 2 — Lift and cost-per calculation

For each metric × LOB × date, build a daily table with:

- `LY_test_metric` — sum of metric across treatment DMAs, last year, same day
- `TY_test_metric` — sum of metric across treatment DMAs, this year, same day
- `LY_control_metric` — sum of metric across holdout DMAs, last year, same day
- `TY_control_metric` — sum of metric across holdout DMAs, this year, same day
- All four are **population-normalized** (divided by DMA population) so
  cross-DMA averaging is meaningful.

Then apply the formulas in Section 5.4.

### 5.4 The measurement math — population-normalized YoY DiD

Following the explicit formulas from the Confluence Architecture page:

**Step 1 — Year-over-year change in the treatment group:**

$$g_{\text{treat}} = \frac{Y^{\text{LY}}_{\text{treat}} - Y^{\text{TY}}_{\text{treat}}}{Y^{\text{LY}}_{\text{treat}}}$$

> **Inline flag — sign of the YoY delta.** The Confluence doc writes this
> as `(LY − TY) / LY`, which yields a *positive* number if TY < LY (a
> decline). The KT walkthrough writes it as `(TY − LY) / LY` (a *growth*
> rate, positive if TY > LY). These are the same number with opposite
> sign; downstream both code paths handle it correctly because they
> multiply by the right LY-of-control value to get the counterfactual.
> When reading the SQL, watch the sign of the multiplier — what's plotted
> as "YoY decline" in dashboards is the positive `(LY − TY) / LY` form.
> The worked example in [Doc 00 Section 5.2](00_aot_ecosystem_and_foundations.md#section-5)
> uses the *growth* form for intuitive clarity.

**Step 2 — Counterfactual for the control DMAs:**

$$Y_{\text{control, counterfactual}}^{\text{TY}} = Y_{\text{control}}^{\text{LY}} \times (1 + g_{\text{treat}})$$

(If $g_{\text{treat}}$ is the growth-form positive number; if it's the
decline-form, the multiplier sign flips.)

**Step 3 — Daily lift:**

$$\text{daily\_lift} = \frac{Y_{\text{control, counterfactual}}^{\text{TY}} - Y_{\text{control, actual}}^{\text{TY}}}{Y_{\text{control, counterfactual}}^{\text{TY}}}$$

**Step 4 — Cost per incremental event:**

$$\text{cost\_per\_incremental} = \frac{\text{SEM spend in the day for that LOB}}{Y_{\text{control, actual}}^{\text{TY}} \times \text{daily\_lift}}$$

Note that the denominator is the **lift × control** — i.e., the
incremental events attributable to marketing — and the spend is the
daily marginal spend (not cumulative), which is the consolidation the
2025 Datamart migration fixed.

The full worked example with concrete numbers — 100 → 150 in treatment,
100 → 120 in holdout, 150 counterfactual, 30 incremental visits, 20%
lift — is in [Doc 00 Section 5.2](00_aot_ecosystem_and_foundations.md#section-5).

### 5.5 Outlier capping — the 60-day median substitution

Cost-per-incremental is a ratio of two noisy numbers, and on any given
day it can blow up to absurd values (e.g., when daily lift is near zero,
the cost-per goes to infinity). The pipeline applies metric-specific
**hard caps** and substitutes out-of-range values with the **median of
the last 60 non-NaN daily values** for that metric.

The thresholds (from the SEM Architecture doc):

| Metric | Lower bound | Upper bound | If outside → substitute with |
|---|---|---|---|
| Visits | ≤ 0 | > 0.9 | 60-day median |
| FS Submits | ≤ 0 | > 150 | 60-day median |
| ZHL Submits | ≤ 0 | > 1000 | 60-day median |
| ZGMI Submits | ≤ 0 | > 2000 | 60-day median |

The rationale: cost-per for Visits should be sub-$1 in reality (Visits
are cheap conversions), so anything above $0.90 is a noise artifact. FS
Submits cost-per peaks around $50–100 in practice, so anything above
$150 is noise. ZHL and ZGMI have much higher cost-pers (loan-application
acquisition is expensive). The lower bound (≤ 0) catches the case where
the formula produced a negative number, which is mathematically
impossible for a real cost-per.

The 60-day median is robust to outliers (unlike a 60-day mean) and is
the natural fallback when a day's number is unreliable.

### 5.6 Statistical significance — t-test + 60-day rolling

A **two-sample t-test** runs on the `counterfactual` vector vs the
`actual TY control` vector across the test-period dates, producing a
p-value. The p-value is then mapped to a 3-tier `confidence_level`
(high / medium / low — same convention as Email; explicit thresholds
not pinned in the Architecture doc but expected to be 0.05 / 0.10 cuts).

**60-day rolling** versions of `lift`, `cost_per`, `p-value`, and
`statistical_significance` are computed per LOB and stored in the
`*_60d` and `*_conf_level_final` tables. The 60-day rolling is what
downstream consumers actually read — daily numbers are too noisy for
direct dashboarding.

### 5.7 The 36 transient models

The SEM transient layer has **36 DBT models** organized into per-metric
pipelines:

| Group | Count | Models |
|---|---|---|
| All-metrics aggregations | 3 | `sem_all_metrics_daily`, `sem_all_metrics_60d`, `sem_cpiv_adj` |
| Visits (3 sub-types) | 9 | `sem_visits_daily/_60d/_conf_level_final`, `sem_mf_visits_*`, `sem_sf_visits_*`, `sem_rental_visits_*` |
| Submits (5 sub-types) | 15 | `sem_fs_submits_*`, `sem_zgmi_submits_*`, `sem_zhl_submits_*`, `sem_fr_bdp_submits_*`, `sem_fr_hdp_submits_*` |
| Page Views (2 sub-types) | 6 | `sem_fr_bdp_pvs_*`, `sem_fr_hdp_pvs_*` |
| (rebalanced for above) | 3 | reflects 9 + 15 + 6 = 30 + 3 + 3 = 36 |

Each `*_daily` model computes the per-day metric × LOB rollup; each
`*_60d` computes the rolling window; each `*_conf_level_final` computes
the final confidence-level classification.

The pattern (per metric, e.g., `sem_fs_submits_daily`):

| Column | Meaning |
|---|---|
| `datadate` | The day |
| `lob` | Line of business |
| `dma_group` | `HO` (holdout) or `Others` (treatment) |
| `actual` vs `counterfactual` | The DiD inputs |
| `cpiv_raw` | Unfiltered cost-per |
| `cpiv_adj` | Cost-per after the 60-day median substitution |
| `daily_lift_raw`, `daily_lift_adj` | Same for lift |
| `sem_spend` | Daily SEM spend for that LOB |
| Year-over-year columns | `LY_*` and `TY_*` for the same metrics |

### 5.8 Table architecture — SEM

**Source / configuration:**

```
marketingde_silver.sem_test_automation_result            -- the monthly DMA holdout schedule (from R + Google Sheet + Alteryx)
warehouse.regionmaster_dbo_region                        -- DMA population
warehouse.uazillowweb                                    -- GA sessions (SEO + SEM)
clickstream.daily_web_nopii                              -- alternate session source (NL clickstream)
warehouse.metrics_library / _v2                          -- user × day × KPI events
warehouse.uamloa                                         -- ZHL-specific
```

**Silver (`marketing.always_on_testing_silver`):**

```
metrics_prod_seo_sem                                     -- the unified daily SEO + SEM × DMA metric table
seo_sem_metrics_max_date                                 -- helper: max(datadate) for max-date checks
```

**Transient (`marketing.always_on_testing_transient`):** see Section 5.7
for the 36 models.

**Gold (`marketing.always_on_testing_gold`):**

```
sem_pooled_results                                       -- the consumption table (since Apr 2023)
testing_pooled_results                                   -- unions sem + email + fb (cross-channel)
```

### 5.9 Cadence + lag

- **Push**: Annual. The R code runs once at the start of the year. The
  Google Sheet driving `sem_test_automation_result` is daily-refreshed,
  so mid-year edits to the holdout schedule do propagate — but the
  Architecture page notes this is *not advisable* mid-month, because the
  test results assume a full-month assignment.
- **Pull**: Daily at 05:20 PM UTC; data available ~6 PM UTC.
- **Lag**: Minimal day-to-day lag — outputs are essentially same-day.
- **Stability window**: 60 days. The `_conf_level_final` tables that
  downstream consumers read have a 60-day lookback effectively built in.
- **Data history**: `sem_pooled_results` has data since **April 2023**.

### 5.10 Limitations

1. **Manual annual push process owned by DS.** The only legacy AOT push
   process not yet automated under Marketing DE. R code, local RStudio,
   manual review with PMMs. High operational toil; high knowledge-
   transfer cost when team members change.
2. **No LOB-level measurement for SEO.** SEM holdouts work at the
   `(campaign_super, LOB)` grain, but SEO traffic can't be split by LOB
   cleanly (a search for "Zillow rentals" gets organic and paid
   counterparts; you can identify the paid one by campaign, but the
   organic one is just a generic Zillow visit). The pipeline includes
   SEO + SEM combined for measurement, but the lift is attributed to
   SEM only. This is a known limitation; the future-improvements section
   of the Confluence FAQ calls it out.
3. **80-DMA spend-focus is set by marketing**, not by AOT. If a new DMA
   becomes a spend-focus mid-year, the R-code holdout schedule doesn't
   know about it until the next annual refresh.
4. **The 60-day median outlier cap** is a blunt instrument — it can mask
   real shifts in cost-per if a channel genuinely becomes more
   expensive over a short window. A more principled approach would be
   robust regression or a Bayesian update, both of which the new geo
   design contemplates.
5. **The push-side R code is non-reproducible across environments.** It
   runs on someone's laptop. Migration to a Databricks notebook + the
   Causal Lab package (→ [Doc 02 Section 14](02_geo_stratification_design.md#section-14))
   is part of the rebuild.

---

## 6. Side-by-side comparison

A consolidated comparison across the three:

| Dimension | **Email** | **Paid Social (FB)** | **SEM** |
|---|---|---|---|
| **Channel** | Email | Paid Social | Search Engine Marketing |
| **`ad_network`** | `Simon_Data` | `Facebook` | `Google` (implicit) |
| **Holdout grain** | User (`ezuid`) | User (Meta-managed, opaque to us) | DMA |
| **Setup cadence** | Quarterly | Quarterly (was monthly) | Annual (monthly schedule generated up-front) |
| **Setup automation** | Databricks job (DBT) | Databricks job (Python notebook) | R code on a laptop, manual review |
| **Setup owner** | Marketing DE (Hightouch takes over) | Marketing DE | DS team |
| **Holdout %** | ~4% of past recipients | 20% of campaign audience (Meta-controlled) | ~4–8% of US population per LOB per month |
| **Pull cadence** | Daily 06:00 UTC | Daily 16:30 UTC | Daily 17:20 UTC |
| **Pull lookback** | 5 days (re-processes `today-4` to `today-8`) | 15 days | 60-day rolling window |
| **Lag to fresh data** | 4–8 days behind current | Daily, but freezes on 15th of following month | Same-day, minor |
| **Measurement method** | DiD with 30-day pre-period + t-test | Meta Lift API (vendor) | YoY DiD with population-normalized counterfactual + t-test |
| **Attribution windows** | 1, 3, 5 day (was 1, 7, 14) | 7-day click + 1-day view (inherited from campaign) | Daily + 60-day rolling |
| **Outlier handling** | DBT contamination check; ≥200K user filter | None at our end; Meta handles | Metric-specific hard caps + 60-day median substitution |
| **Confidence metric** | t-test p-value → high/med/low | Meta-reported confidence | t-test p-value → high/med/low |
| **Source-of-truth KPI table** | `customer.metrics.library` | Meta API | `warehouse.metrics_library_v2` |
| **Taxonomy join** | `marketing.marketingde_gold.ad_hierarchy` | Same | Same |
| **Bronze schema** | `marketing.always_on_testing_bronze` | Same | Same |
| **Silver schema** | `marketing.always_on_testing_silver` | Same | Same |
| **Transient schema** | `marketing.always_on_testing_transient` | Same | Same |
| **Gold table** | `email_pooled_results` (since May 2023) | `fb_pooled_results` (since Jan 2025) | `sem_pooled_results` (since Apr 2023) |
| **Cross-channel pooled** | All three feed `marketing.always_on_testing_gold.testing_pooled_results` | | |
| **Job orchestration** | `aot_email_holdout_refresh_prod` (Push) + `aot_email_pull_adstudy_daily_prod` (Pull) | `aot_fb_post_adstudy_prod` (Push) + `aot_fb_pull_adstudy_results_prod` (Pull) | (manual R) + `aot_sem_pull_prod` (Pull) |
| **Workspace** | `zg-marketing-prod.cloud.databricks.com` | Same | Same |
| **Stack** | DAB + DBT + Unity Catalog + Delta + Python | Same | Same + SparkSQL/PySpark for stats |
| **Number of metrics tracked** | 11 (Visits, FSHDP, ZGMI, ZHL submits + 7 rental variants) | Configurable per study; minimally FS Submits + Visits | 12 (same 11 + cpiv_adj all-metrics aggregations) |
| **LOB granularity** | Campaign-super level only (limitation) | Cell × objective (no LOB granularity natively) | LOB level per campaign-super |
| **Statistical significance** | p-value from t-test | Meta-reported via Lift API | p-value from t-test |
| **Web + App coverage** | Yes (both Web and App KPIs) | Configurable (CAPI gating) | Yes |
| **Downstream consumers** | MMM × AOT incrementality layer ([Doc 04](04_incrementality_and_forecasting.md)), MMBR, ADT, CC Steering Committee | Same | Same |

### Three patterns visible in the comparison

1. **Vendor coupling defines complexity.** FB is the simplest because
   Meta does all the experiment math; Email is medium because we have to
   build the DiD ourselves; SEM is the most complex because we also have
   to handle the DMA-level geo measurement, the SEO/SEM split, and the
   manual annual push process.
2. **Latency tracks holdout grain.** User-grain (Email) has the longest
   lag — 4–8 days — because the metric library has to populate per-user
   KPI events. DMA-grain (SEM) has ~same-day lag because DMA roll-ups
   are computed from already-aggregated session data. Vendor (FB) has
   "ish" same-day with a hard 15th-of-following-month freeze.
3. **Statistical sophistication is constant** across the three —
   counterfactual reasoning, DiD, t-test, p-value, confidence tier.
   The new designs ([Doc 02](02_geo_stratification_design.md),
   [Doc 03](03_dark_period_tv.md)) raise the sophistication
   bar (stratification, Latin square, Welch's ANOVA, SMD, parallel
   trends, regression-based measurement) precisely because the
   business value of getting causal measurement right is higher
   for the broader channel set.

---

## 7. What the rebuild changes — preview of Doc 02

The legacy systems all work. They're in production, they feed
dashboards, they recalibrate MMM. So why rebuild?

Six reasons that drive
[Doc 02 (geo stratification)](02_geo_stratification_design.md)
and [Doc 03 (dark-period TV)](03_dark_period_tv.md):

1. **Channel coverage**. Three channels (Email, FB, SEM) out of ~25 in
   the MMM mix is too few. Channels like Linear TV, Connected TV,
   Programmatic Display, Affiliate, Native — all uncovered today.
   The new geo design generalizes to *any* geo-targetable channel; the
   dark-period design covers the broadcast channels that aren't
   geo-targetable.
2. **Better holdout selection**. The legacy email random-4% and legacy
   SEM 4–8%-population-balanced approaches are both at the "good enough"
   bar. The new geo design's composite-score → 6-strata → Latin-square
   pipeline produces holdouts with *much* better cross-cell balance
   (SMD < 0.1, parallel-trends pre-tested), which means *lower-variance
   lift estimates with smaller holdouts*.
3. **Smaller holdouts → less revenue cost**. The new geo design's
   power analysis settles on **5 DMAs per LOB**, vs the legacy SEM's
   4–8% of population (often 15–20 DMAs per LOB). Smaller holdouts cost
   less revenue per test.
4. **Packaging**. The legacy systems are three separate codebases under
   one umbrella. The new design is a single Python package — **Causal
   Lab** — that handles user-level, geo-level, and time-level designs
   from one config-driven entry point. Same engineering ergonomics as
   `rapidmmm` (see [MMM Doc 02](../learning_docs/md/02_rapidmmm_library_internals.md)).
5. **TV measurement at all**. There's currently *no* causal
   measurement for Linear TV or Connected TV — both rely entirely on
   MMM, which is a worst-case identification problem because TV spend
   doesn't vary much period-to-period. Dark-period testing
   ([Doc 03](03_dark_period_tv.md)) is the first credible
   measurement design for those channels.
6. **Statistical-rigor upgrade**. The legacy systems use raw t-tests
   and ad-hoc outlier capping. The new designs use Welch's ANOVA,
   Levene's, SMD, Mood's median, parallel-trends — a validation engine
   that runs every stage and refuses to proceed if any check fails.
   This is the difference between "we measure lift" and "we measure
   lift and we can defend the measurement methodology to a skeptical
   stakeholder."

> **Interview angle — "Why rebuild a working system?"** Because *good
> enough* in 2023 is the wrong bar when (a) the channel mix is broader,
> (b) the business is more incrementality-aware, (c) the platform tools
> (Databricks, DBT, Causal Lab) make rigorous design cheaper to
> implement, and (d) the legacy designs have known biases (random
> sampling, no parallel-trends check, ad-hoc outlier caps) that erode
> trust over time. The rebuild isn't replacing something broken — it's
> *productionizing what we should have had from the start*.

---

## 8. Companion-doc index

- [00_aot_ecosystem_and_foundations.md](00_aot_ecosystem_and_foundations.md) — start here for causal-inference foundations
- [02_geo_stratification_design.md](02_geo_stratification_design.md) — the new geo design that supersedes legacy SEM
- [03_dark_period_tv.md](03_dark_period_tv.md) — the new TV measurement design
- [04_incrementality_and_forecasting.md](04_incrementality_and_forecasting.md) — how these AOT outputs flow into MMM

**Across to the MMM library:**

- [MMM Doc 04 — Data Lineage and Schemas](../learning_docs/md/04_data_lineage_and_schemas.md) — the DMA / region tables that SEM joins to
- [MMM Doc 06 — FS Submits Taxonomy](../learning_docs/md/06_fs_submits_taxonomy_track.md) — the `channel × network × LOB × campaign_super` grain AOT outputs match
- [MMM Doc 09 — Operations and Interview Capstone](../learning_docs/md/09_operations_and_interview_capstone.md) — the DAB / DBT / Unity Catalog patterns shared across MMM and AOT

> **Interview questions you should be able to answer cold after this doc:**
> 1. *"Walk me through the Email AOT push-pull pipeline."* — Sections 3.2,
>    3.3, 3.4 — sample 4% from past 3 months of recipients, syndicate to
>    Simon Data, daily pull computes 1/3/5-day DiD with 30-day pre-period
>    baseline + t-test.
> 2. *"Why does Email use a 1:18 targeted ratio in its rationale?"* —
>    Section 3.1: most users aren't targeted in any given period, so
>    sampling from the full user base would compare two random groups of
>    mostly-untargeted users. The fix is to sample the control from the
>    previous treatment group.
> 3. *"How does Facebook AOT differ from Email and SEM?"* — Section 4.1:
>    Meta runs the experiment; we only configure via a Google Sheet and
>    re-grain the daily output. No DiD on our side. The complexity is in
>    cumulative-to-daily conversion (Section 4.5).
> 4. *"What's the cumulative-to-daily gap-imputation logic?"* — Section
>    4.5: lag-subtract for normal days; cross-join with a calendar to
>    find missing dates; split the next-non-null delta evenly across the
>    gap.
> 5. *"Why does SEM normalize by DMA population?"* — Section 5.4: DMAs
>    have wildly different sizes (NYC vs Boise), and raw-count averages
>    would be dominated by big DMAs. Per-capita normalization makes
>    cross-DMA averaging meaningful.
> 6. *"What are the SEM outlier thresholds, and why those numbers?"* —
>    Section 5.5: Visits cost-per > $0.90, FS submits > $150, ZHL > $1000,
>    ZGMI > $2000. These reflect the realistic upper bound of each
>    channel's cost-per — anything beyond is almost certainly noise
>    artifact from low-lift days.
> 7. *"Why is the SEM push process still owned by DS and manually run in
>    R?"* — Section 5.2: historical artifact. The R code embeds business
>    constraints (population balancing, cross-LOB exclusions, NY/TX
>    overrides) that were faster to encode in R than to formalize. The
>    rebuild (Causal Lab, [Doc 02](02_geo_stratification_design.md))
>    productionizes this in Python with explicit config.
> 8. *"What are the cross-channel limitations the rebuild fixes?"* —
>    Section 7: channel coverage, holdout-selection rigor, smaller
>    holdouts (5 DMAs vs ~20), packaging consolidation, TV measurement
>    that didn't exist, statistical-rigor upgrade.

---

**Next:** Read [02_geo_stratification_design.md](02_geo_stratification_design.md)
for Jesmma's new geo design — composite scoring, 6 strata, 5,000-trial
cell assignment, Latin square, the validation engine, and the Causal Lab
package walkthrough.
