---
title: Zillow Always-On Testing (AOT) — Complete Study Guide
description: An end-to-end, ground-up explanation of Zillow's Always-On Testing incrementality program — causal foundations, the statistical-validation toolkit, the legacy Email/Meta/SEM systems, the new geo-stratification design, dark-period TV testing, and the incrementality layer that fuses AOT with MMM. Every concept is built from first principles with worked numeric examples.
---

# Zillow Always-On Testing — Complete Study Guide

> **How to read this guide.** It is built to be read front to back. Every idea is
> introduced from first principles, then turned into a formula, then shown with a
> worked numeric example you can reproduce by hand. The statistics are taught from
> the ground up — if you have never met a counterfactual, a p-value, or a standard
> deviation, you will by the end. One piece of vocabulary causes more confusion than
> anything else — **holdout vs control** — so we pin it down once, early, and use it
> consistently everywhere after.

---

## 0. Orientation — what AOT is and why it exists

### 0.1 The one-sentence definition

**Always-On Testing (AOT)** is Zillow's program of *continuously running real
experiments* to measure the **causal** effect of marketing — i.e., how many extra
Visits, submits, etc. each channel actually *causes* — and to express it as a
**cost per incremental KPI** (dollars spent ÷ extra KPI produced).

The output of AOT is a stream of rows like:

```
(date, channel, network, LOB, campaign_super, metric) -> cost_per_incremental
```

structured to line up with the MMM output so the two can be fused.

### 0.2 Why AOT exists *alongside* MMM (the central idea)

You already know MMM. The crucial contrast:

- **MMM is correlational.** It looks at historical, observational data and infers
  "when spend on channel X moved, the KPI moved this much." It is only as good as
  the natural variation in the history. For channels whose spend barely changes week
  to week, MMM has almost nothing to learn from, and its estimate for that channel
  can be badly wrong.
- **AOT is causal by construction.** It *deliberately creates* a contrast — it
  withholds marketing from a chosen group — and compares. That withheld group is a
  real, randomized counterfactual, so the difference it produces is *caused* by the
  marketing, not merely correlated with it.

So the two are complements, not competitors:

| | MMM | AOT |
|---|---|---|
| Nature | a **model** (correlational) | an **experiment** (causal) |
| Coverage | *all* ~25 channels | a *few* channels per period |
| Cost | cheap (just compute) | expensive (you forgo real revenue in the holdout) |
| Variance | low (fit on ~104 weeks) | higher (small samples per test) |
| Best at | breadth + the *shape* of response curves | the *true level* of cost-per for the channels it covers |

**The punch line, which recurs throughout this guide:** AOT measures the true
cost-per for a handful of important channels, and that measurement is used to
**recalibrate** MMM — i.e., to correct MMM's number for those channels. (Full
mechanics in Section 6. The classic case is "Email Simon Data recalibration.")

> **A misconception worth killing now.** AOT does **not** measure "the KPI we'd get
> with no marketing," and it does **not** set MMM's baseline/intercept (alpha). AOT
> measures the **incremental lift caused by marketing** — the *gap* between what
> happened with marketing and what would have happened without it. The
> without-marketing group is the *measuring stick*, not the output. And AOT
> recalibrates specific channel **cost-pers**, not MMM's baseline.

### 0.3 The three testing levels — chosen by what you can control

A channel falls into exactly one level, decided by **what delivery you can switch
off**:

| Level | You can withhold marketing from… | Canonical channel |
|---|---|---|
| **User-level** | an individual person (you have an ID/email) | **Email** |
| **Geo-level** | a whole geography (a DMA) | **SEM**, and the new geo design |
| **Dark-period (time-level)** | nobody by person or place — only a *time window* | **Linear / Connected TV** |

The decision rule is purely "what can you turn off?" Email has user IDs → withhold
per user. SEM can choose not to bid in a DMA → withhold per geography. A national TV
ad plays everywhere with no IDs → you can only withhold *in time* (dark weeks).

*(A "DMA" is a Nielsen Designated Market Area — a US TV market. There are ~210, and
they are the same DMAs MMM uses.)*

### 0.4 The three phases of any test

Independent of level, every test has three phases:

```
1. SETUP ("push")        2. EXECUTION             3. MEASUREMENT ("pull")
   build the holdout,        the vendor/agency        pull the KPI data,
   send it to the      -->   actually runs the   -->  compute the lift (DiD /
   activation platform       media (not us)           regression), cost-per
```

The data-science team owns phases 1 and 3 (build the holdout, measure the result).
The actual media delivery (phase 2) is done by vendors/agencies.

### 0.5 The five KPIs

AOT measures the *same five KPIs MMM models*, so the outputs join cleanly:

1. **Visits** 2. **FS Submits** (the primary monetizable conversion)
3. **ZHL Submits** (Zillow Home Loans) 4. **Rental Visits** 5. **MF Submits** (multi-family rentals).

### 0.6 The terminology that trips everyone: holdout vs control

This single point causes more confusion than any formula in the program, so read it
slowly. **Do not track the word "control" — it means opposite things in different
systems.** Instead, anchor on two plain phrases:

- **WITHOUT-marketing group** — the people/DMAs we deliberately deny marketing.
- **WITH-marketing group** — the people/DMAs that get marketing as normal.

And the universal definition of lift:

```
LIFT = (WITH-marketing outcome) - (WITHOUT-marketing outcome)
```

Now the only consistent piece of jargon:

> **"Holdout" always = the WITHOUT-marketing group.** That never changes.

The troublesome word is "control." Here is the decoder:

| System | WITHOUT-marketing group | WITH-marketing group |
|---|---|---|
| **Email** | the 4% **holdout** *(email also calls this "control")* | **recipients** *(email calls this "test")* |
| **Geo / SEM / new design** | the 5 **holdout** DMAs | the ~175 other DMAs *(geo calls these "control")* |

Notice the trap: in **Email**, "control" = the *without*-marketing group; in **Geo**,
"control" = the *with*-marketing group. They are opposite. That is why, throughout
this guide, we always say "holdout (without marketing)" and "the with-marketing
group" — and only attach the system's jargon next to it.

### 0.7 The data layers (medallion)

Every AOT pipeline lands data in four layers: **bronze** (raw vendor/system pulls),
**silver** (cleaned, joined to the taxonomy; holdout lists live here), **transient**
(intermediate calculations), **gold** (the final, MMM-aligned output that downstream
consumers read). The new designs follow the same shape.

---

## 1. Causal-Inference Foundations

Everything AOT does rests on one question and a small set of tools to answer it.

### 1.1 The core question (the aspirin example)

You have a headache, take an aspirin, and an hour later feel fine. **Did the aspirin
cause it?** You cannot know from this alone — maybe the headache would have faded on
its own. You only lived *one* version of history ("took aspirin, felt better"); you
never saw the other version ("didn't take it, then what?") for *that same headache at
that same time*. That missing other version is the heart of causal inference.

### 1.2 Potential outcomes — the two versions of history

For any unit `i` (a user, a DMA, a week) and a treatment (marketing), there are two
**potential outcomes**:

```
Y_i(1) = the outcome if i IS treated      (gets marketing)
Y_i(0) = the outcome if i is NOT treated  (no marketing)
```

The **treatment effect** for that unit is the difference:

```
tau_i = Y_i(1) - Y_i(0)
```

For a DMA: `Y(1)` = visits if we advertise there; `Y(0)` = visits in that same DMA,
same week, if we did not. The lift we want is `Y(1) - Y(0)`.

### 1.3 The fundamental problem of causal inference

> **For any single unit you can observe only ONE of `Y_i(1)` or `Y_i(0)` — never
> both.** A DMA either got the ad or it didn't; you can't have the same DMA, same
> week, both ways.

So `tau_i` for a single unit is never directly measurable — half the equation is
always missing. This impossibility is *the* reason every method below exists.

### 1.4 The counterfactual

The half you did *not* observe is the **counterfactual** — the "counter-to-fact"
world.

- A DMA that **got** marketing → you saw `Y(1)`; its counterfactual is `Y(0)` = what
  it *would* have done with no marketing.
- A DMA in the **holdout** (no marketing) → you saw `Y(0)`; its counterfactual is
  `Y(1)` = what it *would* have done *with* marketing.

The counterfactual is the **unobserved opposite** world. In AOT the one we care about
is: *for the holdout group, what would it have done if it HAD kept marketing?* We
cannot see it, so we **estimate** it — and estimating that counterfactual *is the
entire job of an incrementality test*.

### 1.5 From one unit to the average (ATE)

We can't get `tau_i` for one unit, but we can get an **average** over many, because
one group can stand in for another's missing half:

```
ATE = average[ Y(1) ] - average[ Y(0) ]
```

The **with-marketing group** gives us `average[Y(1)]`; the **holdout** gives us
`average[Y(0)]`. We never matched a single unit's two halves — we let the holdout's
average play the role of the with-marketing group's missing counterfactual. **This
only works if the two groups are otherwise comparable** — which is the whole reason
for stratification and balance checks (Section 2).

### 1.6 Why the obvious comparisons fail — two traps

Hold this little dataset (visits per group, before vs during a test):

```
                          BEFORE (pre)   DURING (post)
WITH-marketing group:        100             150
Holdout (no marketing):      100             120
```

- **Trap 1 — compare the two groups only in the post period:** `150 - 120 = 30`.
  Looks fine here only because both started at 100. Usually groups start at different
  levels (big DMA vs small DMA), and any pre-existing gap gets falsely blamed on
  marketing. This is **selection bias**.
- **Trap 2 — compare the holdout's own before vs after:** `120 - 100 = +30`. The
  holdout *grew* with no marketing at all — because the whole world drifts over time
  (seasonality, market growth). This is the **time trend**. Crediting that drift to
  marketing would overstate the effect.

Difference-in-Differences cancels **both** traps at once.

### 1.7 Difference-in-Differences (DiD) — the four numbers

DiD uses **four numbers**: two **groups** (with-marketing vs holdout) measured in two
**periods** (pre vs post):

```
DiD = ( WITH_post - WITH_pre )  -  ( HOLDOUT_post - HOLDOUT_pre )
       \___________________/       \________________________/
        with-group's change          holdout's change
        (marketing + drift)          (drift only)
```

The with-group's change mixes marketing + natural drift. The holdout's change is the
drift alone (it had no marketing in the post period). Subtract → the drift cancels →
what remains is the marketing effect. **That subtraction is literally estimating the
counterfactual:** "this is how much the with-group would have moved on its own."

### 1.8 Parallel trends — the assumption that makes DiD legal

> **Parallel-trends assumption:** absent any marketing, the two groups would have
> drifted *by the same amount*. If true, the holdout's drift is a fair estimate of the
> with-group's would-have-been drift, and DiD is unbiased *even if the groups start at
> different levels*.

You can't test it in the post period (that's the unobservable counterfactual), so you
check whether the groups moved in parallel *before* the test — the **parallel-trends
test** (Section 2).

### 1.9 Worked DiD

Plug the Section 1.6 numbers in:

```
WITH change    = 150 - 100 = 50
HOLDOUT change = 120 - 100 = 20
DiD            = 50 - 20   = 30 incremental visits
```

Of the with-group's +50, twenty was natural drift (matching the holdout) and **30 was
marketing**. The lift as a percentage is `30 / 150 = 20%`.

### 1.10 Additive vs multiplicative DiD — why Zillow uses growth rates

Section 1.9 used **additive** DiD (differences of raw counts). It assumes *additive*
parallel trends: absent marketing, both groups change by the same *absolute* amount.
That shatters the moment groups differ in **size** — which DMAs always do. Watch:

```
                          pre      post
WITH-marketing (big DMA):  1000     1500     (+50%)
Holdout (small DMA):        100      120     (+20%)
```

Additive DiD:

```
DiD = (1500 - 1000) - (120 - 100) = 500 - 20 = 480 incremental visits  ?!
```

That **480 is nonsense** — it is dominated by the big DMA's raw scale. The fix is
**multiplicative** parallel trends (both grow by the same *percentage*), using growth
rates:

```
Step 1  with-group growth:  g = (1500 - 1000) / 1000 = 0.50  (+50%)
Step 2  holdout counterfactual = holdout_pre * (1 + g) = 100 * 1.50 = 150
        ("what the small holdout WOULD have hit if it had grown like the with-group")
Step 3  incremental = counterfactual - actual = 150 - 120 = 30
Step 4  lift % = (counterfactual - actual) / counterfactual = 30 / 150 = 20%
```

**30 incremental visits, 20% lift** — sensible, and unaffected by the size mismatch,
because growth rates are scale-free. This is exactly why the SEM pipeline uses the
year-over-year, growth-rate (counterfactual) form, plus population normalization
(Section 3).

> **Why "pre", never "post", in the counterfactual.** The counterfactual grows the
> **baseline (pre)** forward by one period. The holdout's **post** value is the thing
> we *compare against* (the "actual") — it is never the base. Growing the pre value by
> `(1+g)` lands you exactly at the post period, the period you want the counterfactual
> for. Growing the post value would land you a period too far and leave nothing to
> compare against.

### 1.11 Pre/post vs holdout/control — two separate axes

A frequent confusion: "in the post period, does the holdout get marketing?" **No.**
"Pre/post" (time) and "holdout/with-marketing" (group) are *independent axes*. They
make a 2×2 grid, and marketing is removed in **only one cell**:

| | PRE (baseline, before the test) | POST (the test window) |
|---|---|---|
| **With-marketing group** | gets marketing | **gets marketing** |
| **Holdout group** | gets marketing (normal) | **NO marketing** ← the only change |

So the holdout had marketing *before* the test (it was behaving normally), and loses
it *during* the test. The pre-period is an earlier baseline, **not** the first half of
the test window. The holdout still *grew* in the post period (100→120) only because of
natural drift; with marketing it would have reached 150 (the counterfactual), and the
30-visit shortfall is the marketing's contribution.

Two real conventions for "pre":
- **Email:** pre = the ~30 days *before* the test (the future-holdout users were still
  being emailed then); post = the test window (holdout cut off).
- **SEM:** pre = **last year**, same month (both groups had ads); post = **this year**
  (holdout dark). Here "pre vs post" literally means "last year vs this year."

### 1.12 Attribution windows (1 / 3 / 5-day) — smoothing daily noise

A single day's KPI is noisy, so each test-day's lift is also recomputed over rolling
**3-day** and **5-day** sums of the metric (the same DiD, wider window). Watch the
noise collapse on a holdout's daily FS submits over a test week:

```
Day             Jun1  Jun2  Jun3  Jun4  Jun5  Jun6  Jun7
Counterfactual  100   100   100   100   100   100   100   (steady "with marketing")
Actual           70    95    80    90    60   100    75   (no marketing, noisy)
```

**1-day lift** = `(cf - actual)/cf`:

```
Jun1: 30%  Jun2: 5%  Jun3: 20%  Jun4: 10%  Jun5: 40%  Jun6: 0%  Jun7: 25%
```

That swings 0%–40%, and on Jun 6 incremental = 0 → cost-per = spend/0 = infinity (one
bad day breaks it). **3-day window** (sum the day + 2 prior, then lift):

```
Jun3 (Jun1-3): (300-245)/300 = 18.3%
Jun4 (Jun2-4): (300-265)/300 = 11.7%
Jun5 (Jun3-5): (300-230)/300 = 23.3%
Jun6 (Jun4-6): (300-250)/300 = 16.7%
Jun7 (Jun5-7): (300-235)/300 = 21.7%
```

**5-day window:**

```
Jun5 (Jun1-5): (500-395)/500 = 21.0%
Jun6 (Jun2-6): (500-425)/500 = 15.0%
Jun7 (Jun3-7): (500-405)/500 = 19.0%
```

The 1-day series bounces 0–40%; the 5-day series hugs the true week-long lift
(`130/700 = 18.6%`). Wider window = less noise, more stable cost-per, at the cost of
being slower to reflect a recent change. Zillow stores all three. (The infinite
cost-per on Jun 6 is why SEM later adds a 60-day-median outlier cap — Section 3.)

---

## 2. The Statistical-Validation Toolkit

This is the engine for two things: (a) building a holdout that is a *fair* comparison,
and (b) proving it. We build every test from fundamentals.

### 2.1 Why a random holdout is risky

Suppose we need a holdout of a few units from a population that has low, mid, and high
tiers. A *simple random* draw is **unbiased on average** but has **high variance** —
any single draw can be wildly unrepresentative (you might grab all high-tier units).
And you only get one draw. Tharun's phrase — "take 4% of India at random and you might
get all of North India" — is exactly this. When the holdout's *composition* is lopsided,
the lift you compute inherits all that noise.

### 2.2 Stratified sampling — the fix

Split the population into **strata** (internally-similar tiers), then take a fixed
share **from each stratum**. Now every possible holdout spans all tiers, so it is
representative *every* draw. You have converted a high-variance "which tier did I land
in?" gamble into a tiny "which near-twin within a tier?" wobble.

### 2.3 The variance math (law of total variance), VRF, and CV

Total variance splits into two pieces — the **law of total variance**:

```
variance_total = variance_within (avg spread inside groups)
               + variance_between (spread of the group means)
```

Worked on 12 DMAs in 3 tiers (KPI = visits per capita):

```
Tier A (low) :  10, 10, 14, 14    mean = 12
Tier B (mid) :  28, 28, 32, 32    mean = 30
Tier C (high):  58, 58, 62, 62    mean = 60
Grand mean = 34
```

```
variance_within  (each tier's values are mean +/- 2 -> variance 4) = 4
variance_between ( [ (12-34)^2 + (30-34)^2 + (60-34)^2 ] / 3 )      = 392
variance_total                                                      = 396   (= 4 + 392, checks out)
```

Why this matters for the *estimate*: the variance of a sample mean is roughly
`variance / n`. So:

```
random holdout:     estimate variance ~ 396 / n
stratified holdout: estimate variance ~   4 / n   (the "between" part is deleted)
```

Stratification removes the `variance_between` term → here the estimate is ~99% less
noisy. This gives two headline metrics for free:

- **VRF (Variance Reduction Factor)** = fraction of variance the tiers explain:
  ```
  VRF = variance_between / variance_total = 392 / 396 = 0.99
  ```
  VRF near 1 = great stratification. **Pass bar: VRF > 0.6.** The noise your estimate
  *keeps* is `1 - VRF` (here 1%).
- **CV (Coefficient of Variation)** = relative spread *inside* a tier (`SD / mean`):
  ```
  Tier A: 2/12 = 16.7%   Tier B: 2/30 = 6.7%   Tier C: 2/60 = 3.3%
  ```
  **Pass bar: CV < 20% per stratum** (each tier is internally tight). All pass.

### 2.4 Mean and standard deviation (fundamentals)

The next tests use **standard deviation (SD)** = *the typical distance of a point from
the mean*. Example:

```
Data:      2, 4, 6, 8, 10        mean = 6
distance: -4,-2, 0,+2, +4
squared:  16, 4, 0, 4, 16  -> sum 40 -> variance = 40/5 = 8 -> SD = sqrt(8) = 2.83
```

"Points sit about 2.83 away from the mean of 6." Tight data → small SD; spread data →
large SD. (Variance = SD²; we used variance in VRF, SD in SMD below.)

### 2.5 SMD (Standardized Mean Difference) — the headline balance metric

**SMD = the gap between two group means, measured in standard deviations:**

```
SMD = (mean_groupA - mean_groupB) / SD
```

Why standardize? Because a raw gap is meaningless without knowing the natural spread.
The same gap of 3 means opposite things:

```
World X (tightly clustered, SD = 5):  SMD = 3/5  = 0.60  -> groups meaningfully differ -> FAIL
World Y (widely spread,    SD = 30):  SMD = 3/30 = 0.10  -> groups basically twins      -> PASS
```

Interpretation scale (Cohen):

```
|SMD| < 0.1  negligible    0.2  small    0.5  medium    0.8  large
```

**Pass bars:** `|SMD| < 0.1` between balanced cells; relaxed to `|SMD| < 0.2` for the
final small (5-DMA) holdout.

**Why SMD instead of a t-test p-value for balance?** Because a p-value is fooled by
sample size. Keep the same gap (means 50 vs 52, SD 20):

```
n = 6 per group     -> t ~ 0.17 -> p ~ 0.86 -> "no significant difference"
n = 10,000 per group-> t ~ 7.1  -> p ~ 0.000-> "HIGHLY significant difference!"
```

Same groups, equally close (0.1 SD apart) — but with huge n the p-value screams
"different!" SMD reports 0.10 either way. It measures *how big* the gap is, not how
many rows you have.

### 2.6 Bias vs variance (the dartboard) — answering "but wide-spread data?"

A subtle question: "if a holdout is balanced (small SMD) but the data is wide-spread,
is the lift any good?" This is the bias-variance distinction:

| Concern | Question | Tool | Effect of wide spread |
|---|---|---|---|
| **Bias** | Are the groups a *fair* comparison? | **SMD / stratification** | none — SMD already accounts for it |
| **Precision** | How *certain* is the lift number? | **variance + sample size (power)** | hurts it — wider spread = noisier estimate |

Dartboard: **bias** = are the darts centered on the bullseye? **variance** = are they
tightly clustered? A small SMD means *centered* (unbiased). Wide spread means
*scattered* (imprecise) — fixed separately by more units or by stratifying to shrink
the spread. So: a balanced-but-wide holdout is a *fair* comparison whose *number* will
be noisy; the cure is more DMAs or tighter stratification — **not** a different SMD.

### 2.7 p-values (fundamentals) and the sign-flip

Every test starts from a null hypothesis: *"the groups are actually the same."* The
**p-value** answers: *if the groups were truly identical, how likely is a difference
this big by pure luck?*

```
small p (< 0.05): too big to be luck    -> the groups REALLY DIFFER -> REJECT "same"
large p (> 0.05): totally normal luck   -> no evidence of a difference -> FAIL TO REJECT ("same")
```

Mnemonic: **small p = "proof of a difference"; large p = "looks the same."**

Now the meta-rule that governs the whole battery — **the sign-flip:** the *same tests*
are run at two stages with *opposite* desired outcomes.

- After **stratification** we *want the tiers to DIFFER* → tests should **REJECT**
  ("tiers exist because they differ").
- After **cell assignment** we *want the cells to MATCH* (be interchangeable replicas)
  → tests should **FAIL TO REJECT**.

| Stage | What we want | We want p to be… |
|---|---|---|
| Strata | tiers differ | **small** (< 0.05) → reject |
| Cells | cells match | **large** (> 0.05) → fail to reject |

### 2.8 Power analysis — how big the holdout must be, and the 15.7

**Power analysis** answers: *how many units do I need to reliably detect a real lift?*
Think "spotting a signal in noise." Four knobs:

| Symbol | Name | Meaning | More of it → |
|---|---|---|---|
| `n` | sample size | how many holdout units (what we solve for) | — |
| `δ` (delta) | effect size / MDE | the smallest lift we want to catch (e.g. 10%) | smaller δ → **more** units |
| `σ` (sigma) | standard deviation | how noisy the units are (`σ²` = variance) | bigger σ → **more** units |
| `α` (alpha) | significance | tolerated false-alarm rate (usually 5%) | smaller α → more units |
| `power` | power | chance of catching a real lift (usually 80%) | higher → more units |

The two-sample formula:

```
n  ≈  2 · σ² · (z_{1-α/2} + z_{1-β})² / δ²
```

**Where the 15.7 comes from.** A **z-value** is "how many SDs out on the bell curve."
`z = 1.96` is the 95%-confidence cutoff (the middle 95% of a bell curve sits within
±1.96 SD), used for `α = 0.05`. `z = 0.84` is the 80%-power value (80% of the curve
lies below 0.84 SD). They **add** because the gap δ must span two distances — 1.96 SDs
to clear the false-alarm threshold, plus 0.84 more so a real effect reliably lands
past it — and the whole thing is **squared** when you solve for `n`. The standard
error of a two-group difference is `sqrt(2σ²/n)`, where the **2** is "two groups." Put
it together:

```
δ = (1.96 + 0.84) · sqrt(2σ²/n)   ->   n = 2 · σ² · (1.96 + 0.84)² / δ²
15.7 = 2 × (1.96 + 0.84)² = 2 × (2.80)² = 2 × 7.84 = 15.68 ≈ 15.7
```

So `15.7 = 2 (two groups) × (1.96 (false-alarm) + 0.84 (power))²`. It is
**convention-specific** — stricter settings change it (α=1%, power=90% → ≈ 29.8).

**How σ² and δ are decided.** σ² is **measured from data** (the variance of the DMA
KPIs — specifically the small *within-stratum* residual variance). δ is **chosen** by
the business with DS ("what's the smallest lift worth acting on?" — ~10%). α and power
are statistical conventions.

**Why "5 DMAs."** Plug in a 10% lift (δ=0.10) and watch σ² decide everything:

```
poorly stratified, σ = 0.15:   n ≈ 15.7 × 0.15²/0.10²  ≈ 35 DMAs/arm  (absurd)
well stratified,   σ = 0.056:  n ≈ 15.7 × 0.056²/0.10² ≈  5 DMAs/arm  (perfect)
```

Stratification crushed the variance (Section 2.3), which crushed the holdout size.
That is the link: **the variance reduction is what makes a 5-DMA holdout valid.** The
huge ~175-DMA control arm makes it even more comfortable (effective sample > 5). Also,
`n ∝ 1/δ²`, so halving the lift you want to detect *quadruples* the DMAs needed.

### 2.9 The validation tests, each from fundamentals

Each is run at both stages (the sign-flip). To make them concrete, here is one mock
holdout we will reuse (visits per capita):

```
HOLDOUT (5 DMAs):  40, 60, 50, 45, 55          mean = 50,  SD = 7.91
CONTROL (10 DMAs): 43, 59, 53, 49, 57,
                   45, 51, 55, 47, 51          mean = 51,  SD = 5.16
```

**ANOVA (and why Welch's).** ANOVA tests whether several group **means** are equal by
comparing between-group spread to within-group spread: `F = MS_between / MS_within`. A
big F = means are far apart → reject. On the 12-DMA tiers of Section 2.3:

```
Between SS = 4×[ (12-34)² + (30-34)² + (60-34)² ] = 4×1176 = 4704 ; df=2 ; MS=2352
Within  SS = 16 per tier × 3 = 48                                  ; df=9 ; MS=5.33
F = 2352 / 5.33 ≈ 441   (huge -> p ≈ 0 -> reject -> tiers differ, PASS at stratification)
```

*Why Welch's variant:* classic ANOVA assumes every group has the **same variance**.
DMAs do not (a big DMA's variance dwarfs a small one's). **Welch's ANOVA** drops that
assumption (weights groups by inverse variance, adjusts the degrees of freedom). Same
F-interpretation; valid under unequal variance — which is always the DMA case.

**SMD (on the mock).**

```
pooled SD = sqrt[ (4×7.91² + 9×5.16²) / 13 ] = sqrt[490/13] = 6.14
SMD = (50 - 51) / 6.14 = -0.16   ->  |0.16| < 0.2  ->  PASS (balanced)
```

**Welch's two-sample t-test (means, unequal variance).**

```
t = (50 - 51) / sqrt(7.91²/5 + 5.16²/10) = -1 / sqrt(12.5 + 2.67) = -0.26  ->  p ≈ 0.80
```

Large p → fail to reject → means indistinguishable → **PASS**.

**Kruskal-Wallis (ranks, no normality assumption).** Pool all values, rank them, sum
the holdout's ranks; compare to what's expected if balanced.

```
holdout ranks: 40→1, 45→3.5, 50→7, 55→11.5, 60→15  -> rank sum = 38
expected if balanced = 5 × (15+1)/2 = 40
```

38 ≈ 40 → tiny statistic → large p → **PASS**. With only 5 DMAs, normality is suspect;
KW only uses *order*, so it is a robust backup.

**Mood's median test (medians, robust to outliers).** Overall median of the 15 = 51.
Count each group above vs at/below it:

```
            above 51   at/below
Holdout        2          3       -> 40% above
Control        4          6       -> 40% above
```

Identical proportions → chi-square ≈ 0 → large p → **PASS**. Robust because it only
asks which *side* of the median each value is on. (The KT's "surrender validation" was
a mis-transcription of "median validation" — this is it.)

**Levene's test (equal variances?).** Null: all groups have equal variance. Runs an
ANOVA on each point's absolute deviation from its group median. Used as a diagnostic
(do we need Welch?) and at the cell stage as a balance check (want p > 0.05).

**ICC (Intraclass Correlation Coefficient).** Fraction of total variance that is
*between* groups: `ICC = variance_between / (variance_between + variance_within)`. On
the 12-DMA tiers, `392/396 = 0.99`. **Want ICC high at stratification** (tiers explain
the variance), **low at cells** (cell label explains nothing). It is the same quantity
as VRF, fit via a random-effects model.

**Parallel-trends test.** The pre-period check that licenses DiD. Over pre-test weeks,
fit `metric ~ time + group + time×group`; the **time×group** coefficient is the
*trend difference* — if its interval includes 0 (≈ p > 0.10), trends are parallel →
**PASS**. Run at three horizons (daily / weekly / monthly), because a violation can
hide at one resolution and show at another. Example pre-period:

```
            Wk1  Wk2  Wk3  Wk4
Holdout      48   49   50   51   (+1/week)
Control      49   50   51   52   (+1/week)
```

Both rise +1/week → trend difference ≈ 0 → PASS.

**Bonferroni / FDR (multiple-testing corrections).** The final battery runs 3 tests ×
5 KPIs = 15 p-values per LOB. By chance, ~1 in 20 looks "significant" even when all is
balanced. So we adjust:

```
A KPI's raw Welch p = 0.01 (looks like imbalance!).
Bonferroni: adjusted p = 0.01 × 15 = 0.15  ->  now > 0.05  ->  NOT significant.
```

The "alarming" 0.01 was just the expected fluke among 15 tests. **Bonferroni**
(multiply by the number of tests) is strict; **FDR-Benjamini-Hochberg** is gentler and
is the operational gate (want adjusted p > 0.05 on all KPIs → balanced).

**Why so many tests for 5 DMAs?** No single test is trustworthy at n=5. Welch checks
means, KW checks ranks, Mood's checks medians, SMD measures *size*, parallel-trends
guards the DiD. Each catches a different failure mode; the conjunction certifies the
holdout.

---

## 3. The Legacy Systems — Email, Meta, SEM

Three channels have live testing today. Each is the toolkit wired to a real pipeline.

| | **Email** | **Paid Social (Meta)** | **SEM (Google)** |
|---|---|---|---|
| Holdout grain | a **user** | a user (Meta-managed) | a **DMA** |
| Who runs the experiment | **us** | **Meta** | **us** |
| Measurement | DiD, 30-day pre-period | none on our side (Meta's API) | YoY multiplicative DiD |
| Level | user | user (vendor black-box) | geo |

Every one follows **push** (build + send the holdout, slow cadence) → **execute** →
**pull** (pull KPIs, compute lift daily).

### 3.1 Email — user-level holdouts

**Why email is the trickiest: the 1:18 problem.** At any moment only ~1 in 18
registered users is actually being emailed. So a holdout of "4% of *all* registered
users" would mostly contain people who were never going to get an email anyway — the
with-marketing and without-marketing groups would both be ~95% un-targeted, and the
lift would be meaningless noise.

**The fix (the key design choice):** sample the holdout **from the previous test
period's *recipients*** — only people who *actually got* marketing emails. This makes
the comparison apples-to-apples and, in Section-2 language, gives a **low baseline SMD
for free** (both groups were being emailed before).

**Push (quarterly).** Find everyone emailed in the past 3 months (B2C promotional only
— operational emails like password resets excluded), take a recent ~30-day slice,
random-sample ~4% as the holdout (no promotional email for the quarter), and send that
exclusion list to the activation platform. **Rotation rule:** a user can't be in the
holdout two quarters running (6 months of silence raises churn) — the 4% is set by the
business.

**The holdout is per campaign super.** The 4% holdout for *Buyer* is withheld from
*Buyer* promotional emails only — a held-out user could still get *Rental* emails.
Each campaign super (Buyer, Rental, …) runs its **own** continuous, quarterly-refreshed
test. (It can measure at campaign-super grain, not finer LOB grain — a known
limitation.)

**Pull (daily) — DiD with a 30-day pre-period.** Per-user average metric, recipients
vs holdout, pre vs now:

```
                          PRE (30-day baseline)   NOW (test)
Recipients (with email):        0.020                 0.035    FS submits per user
Holdout (no email):             0.020                 0.028
```

```
Recipients' change = 0.035 - 0.020 = 0.015   (marketing + drift)
Holdout's change   = 0.028 - 0.020 = 0.008   (drift only)
DiD per user       = 0.015 - 0.008 = 0.007
Lift %             = DiD / holdout_now = 0.007 / 0.028 = 25%
Incremental        = DiD × #recipients = 0.007 × 4,000,000 = 28,000 submits
Cost-per           = spend / incremental = $14,000 / 28,000 = $0.50 per submit
```

DiD handles unequal baselines fine — divide the lift by the *holdout's now* value, not
its pre value. Two refinements reuse earlier ideas: the **1/3/5-day attribution
windows** (Section 1.12) and a **t-test confidence tier** (p < 0.05 = high, 0.05–0.10 =
medium, > 0.10 = low).

**The daily pull output** — one row per `campaign_super × metric × attribution_window`:

| date | campaign_super | metric | att_w | lift | incremental | cost_per | p_value | confidence |
|---|---|---|---|---|---|---|---|---|
| 2026-06-01 | Buyer | FS Submits | 3 | 25% | 28,000 | $0.50 | 0.01 | high |
| 2026-06-01 | Buyer | Visits | 3 | 8% | 140,000 | $0.10 | 0.02 | high |
| 2026-06-01 | Rental | Rental Visits | 3 | 15% | 60,000 | $0.18 | 0.07 | medium |

**Migration (Simon Data → Hightouch).** Hightouch can build holdouts inside its own
UI, so our role shifts from **push + pull** to **pull only** (Hightouch does the push).
If a future platform can't build holdouts, the backup is the Section-2 plan at user
grain: score each user by engagement, `NTILE(20)` into 20 strata, sample 4% from each.

### 3.2 Paid Social (Meta) — the easy one

**Meta runs the entire experiment.** Facebook's built-in "Lift study" splits users
into with/without-marketing (~20% holdout), runs the ads, measures the lift, and hands
us the finished numbers. So there is **no DiD and no statistics on our side.** Our job
is plumbing: (1) **configure** studies via a Google Sheet (ad account, events, holdout
%), (2) **pull** results daily from Meta's API, (3) **re-grain** to the MMM taxonomy.

**The one real piece of work: cumulative → daily.** Meta reports running totals; we
un-cumulate by subtracting yesterday from today:

```
Cumulative:  50, 130, 210          Daily = today - yesterday:
                                     Day1 = 50          (keep)
                                     Day2 = 130 - 50  = 80
                                     Day3 = 210 - 130 = 80
```

**Gap imputation.** If Meta skips a day, the next day's jump bundles two days; split it
evenly:

```
Cumulative:  Day1=50, Day2=130, Day3=missing, Day4=330
Day2 = 130 - 50 = 80
Day4 jump = 330 - 130 = 200   (covers Day3 + Day4)
-> Day3 = 100, Day4 = 100     (split the 200 evenly)
```

Facts: 20% holdout, 90-day quarterly studies, attribution inherited from the campaign
(7-day click + 1-day view — so **no** 1/3/5 windows), only CAPI-enabled events
eligible, results freeze on the 15th of the following month. Main limitation: it is a
**black box** — we trust Meta's lift and can't validate the method.

### 3.3 SEM (Google) — DMA-level YoY DiD

SEM is geo-controllable (we can choose not to bid in a DMA), so the holdout is **DMAs**.
Measurement uses the **year-over-year, multiplicative** DiD of Section 1.10 — "this
year vs last year, same month" (holding the season constant) — **plus population
normalization** (visits per capita) because DMAs differ wildly in size. Worked:

```
                          population    LY visits   TY visits   per-capita LY -> TY
With-marketing DMAs:        10,000,000   1,000,000   1,500,000   0.10 -> 0.15
Holdout DMAs:                2,000,000     200,000     240,000   0.10 -> 0.12
```

```
Step 1  with-group growth: g = (0.15 - 0.10)/0.10 = 50%
Step 2  holdout counterfactual (per capita) = 0.10 × 1.50 = 0.15
Step 3  incremental (per capita) = 0.15 - 0.12 = 0.03 ; lift = 0.03/0.15 = 20%
Step 4  total incremental = 0.03 × 2,000,000 = 60,000 visits
        cost-per = SEM spend / incremental = $30,000 / 60,000 = $0.50 per visit
```

**Push (annual):** an R script builds the monthly DMA holdout schedule. Constraints: a
DMA can't be holdout for two LOBs in the same month (else you can't attribute the
drop), nor two consecutive months (churn), and the business can exclude high-revenue
DMAs (New York, Texas). **Pull (daily):** combine SEO + SEM sessions, run the YoY DiD,
and apply a **60-day-median outlier cap** on cost-per — the direct fix for the
divide-by-zero blow-ups from Section 1.12. **Why SEM gets rebuilt:** the holdout is
"pick 4–6 DMAs to hit 4% population" — a *cost* constraint, not stratified, not
power-sized, not balance-checked. Section 4 fixes all of that.

---

## 4. The New Geo-Stratification Design

Everything converges here: the causal logic (Section 1), the stats toolkit (Section
2), and the lessons from legacy SEM. The pipeline:

```
1. Composite score    -> one importance number per DMA
2. Stratify           -> quantile-cut into 6 tiers (K-means elbow picks "6")
3. Cell assignment    -> round-robin tiers into 6 balanced "mini-USA" cells; 5,000 shuffles
4. Validate cells     -> sign-flip battery (want cells to MATCH)
5. Latin square       -> rotate which cell is each LOB's holdout across quarters (<=10% overlap)
6. Power -> 5 DMAs    -> darken only 5 per LOB (not the whole cell)
7. Exclusions         -> skip business-protected (DMA, LOB) pairs
8. Holdout select+validate+write -> pick 5, run holdout-vs-control battery, write the schedule
```

### 4.1 Step 1 — Composite score and the transformations

We must stratify, but quantile-cutting needs a **single number** per DMA. So we
collapse five KPIs + economics + population into one "market importance" score:

```
CompositeScore = 0.70 × (avg normalized KPIs)
               + 0.25 × (avg normalized economic vars)
               + 0.05 × (normalized population)
```

**Why 70/25/5.** KPIs get 70% because the experiment *measures KPIs* — two DMAs with
similar KPI levels behave alike in the test. Econ gets 25% (explains leftover
differences). Population gets only 5% — it is **already baked into the KPIs** (big
DMAs have more visits), so weighting it high would double-count; 5% is a tiebreaker.

**The transformations (in order), each shown on a mock visits column:**

```
Raw:  10, 12, 15, 20, 25, 30, 40, 500     (the 500 is an NYC-style giant)
```

1. **Non-zero filter** — drop DMAs with any zero KPI (takes ~210 → ~180 usable).
2. **Outlier cap at the 99th percentile** — clip anything above p99 down to it (say
   p99 = 45 → the 500 becomes 45). Why it matters — without it, normalization squashes
   everyone:
   ```
   WITHOUT cap (max=500):  40 -> 40/500 = 0.08 ; 10 -> 0.02   (everyone crushed into 0.02-0.08)
   WITH cap   (max=45):    40 -> 40/45  = 0.89 ; 10 -> 0.22   (spread nicely across 0-1)
   ```
3. **Log transform (`log1p` = ln(1+x))** — compresses right-skew so a few giants don't
   dominate:
   ```
   Raw:        1,    10,    100,   1000     (ratio 1 : 1000)
   ln(1+x):  0.69, 2.40,  4.62,  6.91       (ratio ~0.7 : 6.9 ≈ 10×)
   ```
   `log1p` (not plain `log`) because `ln(1+0) = 0` handles zeros gracefully.
4. **Min-max normalization** `(x - min)/(max - min)` → every column on a 0–1 scale, so
   the **weights** decide influence, not the raw units.

Order: `filter → cap → log → normalize → weight & sum`. Worked composite (2 DMAs,
normalized inputs):

```
            KPI_norm  econ_norm  pop_norm
DMA A:        0.80      0.60       0.90   -> 0.70(0.80)+0.25(0.60)+0.05(0.90) = 0.755
DMA B:        0.30      0.50       0.20   -> 0.70(0.30)+0.25(0.50)+0.05(0.20) = 0.345
```

DMA A (0.755) is a big market; DMA B (0.345) is small.

### 4.2 Step 2 — Stratify (quantile cut + the K-means elbow)

Sort all ~180 composite scores and **quantile-cut** into 6 equal-size, ordered tiers
(~30 DMAs each). Worked on 12 DMAs into 3 tiers:

```
Tier 0 (low):   0.21, 0.24, 0.27, 0.30   mean ≈ 0.255
Tier 1 (mid):   0.42, 0.45, 0.47, 0.50   mean ≈ 0.460
Tier 2 (high):  0.61, 0.65, 0.70, 0.78   mean ≈ 0.685
```

Equal-size tiers make cell assignment clean; ordered tiers let us later pick "one DMA
per tier."

**Where "6" comes from — the elbow method.** Try tiers K = 2..10; for each, measure
VRF (Section 2.3); plot VRF vs K and find where it stops rising steeply (the "elbow"):

```
K     VRF      gain
2     0.41      —
3     0.59     +0.18
4     0.71     +0.12
5     0.81     +0.10
6     0.88     +0.07
------------------------  <- elbow: gains collapse after here
7     0.90     +0.02
8     0.91     +0.01
```

5→6 still buys +0.07, but 6→7 only +0.02. The curve flattens after 6, so K = 6.
K-means only *picks the number*; the quantile cut does the slicing. Validate the tiers
(sign-flip): ANOVA across tiers should **reject** (F=441 in our Section-2.9 example),
CV < 20% per tier, VRF > 0.6, ICC high.

### 4.3 Step 3 — Cell assignment (round-robin + the 5,000 shuffles)

**Tiers vs cells — keep these straight.** A **tier** groups *similar* DMAs (all big,
all small); tiers *differ* from each other. A **cell** is a balanced team containing
DMAs *from every tier* — a "mini-USA"; cells *resemble* each other. (Analogy: tiers =
sorting players by skill; cells = building evenly-matched teams.)

**Round-robin** = dealing cards. Within each tier, shuffle and deal one DMA at a time
around the cells. Worked with 18 DMAs, 3 tiers of 6, 3 cells (so each cell gets 2 per
tier):

```
Tier 0 (low) :  D1=0.10 D2=0.12 D3=0.14 D4=0.16 D5=0.18 D6=0.20
Tier 1 (mid) :  D7=0.40 D8=0.42 D9=0.44 D10=0.46 D11=0.48 D12=0.50
Tier 2 (high):  D13=0.70 D14=0.72 D15=0.74 D16=0.76 D17=0.78 D18=0.80
```

Deal tier 0 in a shuffled order `[D3,D1,D5,D2,D6,D4]` round-robin to Cell1,Cell2,Cell3:

```
D3->C1  D1->C2  D5->C3  D2->C1  D6->C2  D4->C3
=> from tier 0: C1={D3,D2}  C2={D1,D6}  C3={D5,D4}   (2 each)
```

Do the same for tiers 1 and 2; each cell ends with 2 low + 2 mid + 2 high = 6 DMAs:

| Cell | values | cell mean |
|---|---|---|
| Cell 1 | 0.14, 0.12, 0.46, 0.44, 0.72, 0.76 | **0.440** |
| Cell 2 | 0.10, 0.20, 0.40, 0.42, 0.78, 0.80 | **0.450** |
| Cell 3 | 0.18, 0.16, 0.50, 0.48, 0.70, 0.74 | **0.460** |

**Why deal *within* tiers and not freely?** A free shuffle could give one cell all the
big DMAs, throwing away stratification. Within-tier dealing *guarantees* each cell a
fair slice of every tier.

**The balance score and the 5,000 shuffles.** Round-robin fixes the count, but *which*
DMAs still matters. The **balance score** = the across-cell CV of the cell means (low =
cells alike). Compare two shuffles:

```
Trial A: cell means {0.440, 0.450, 0.460}  -> SD 0.0082, CV = 0.0082/0.45 = 0.018  (1.8%, great)
Trial B: cell means {0.410, 0.450, 0.490}  -> SD 0.0327, CV = 0.0327/0.45 = 0.073  (7.3%, worse)
```

We try 5,000 random within-tier shuffles, score each, and **keep the lowest** (Trial A
here). Cheap (seconds) and basically guarantees near-identical cells.

### 4.4 Step 4 — Validate the cells (the sign-flip's "want them SAME" side)

Re-run the battery, now wanting **fail to reject**:

| Test | At tiers (before) | At cells (now) |
|---|---|---|
| ANOVA (Welch) | reject, p<0.05 (tiers differ) | **p > 0.05** (cells match) |
| SMD between cells | — | **\|SMD\| < 0.1** |
| ICC | high | **low** |
| Mood's median | reject | fail to reject |
| Parallel-trends (3 horizons) | — | **pass** |

A failure → re-run the shuffle with a different seed. Parallel-trends is the most
important: it is the direct guarantee that the eventual DiD will be valid.

### 4.5 Step 5 — Latin square (rotating the holdout)

For each LOB we pick one **cell** to be the holdout. Two rules: (1) within a quarter,
each cell is the holdout for only one LOB (else you can't attribute the drop); (2)
across quarters, the holdout cell must rotate (don't darken the same DMAs forever). A
**Latin square** — a grid where each symbol appears once per row and once per column —
enforces both:

```
          Q1    Q2    Q3
LOB 1     C2    C4    C1     <- across a row: an LOB cycles cells (rotation)
LOB 2     C4    C1    C2
LOB 3     C1    C2    C4     <- down a column: a quarter uses distinct cells (attribution)
```

**The 10% overlap cap.** When generating next quarter's square, count how many LOBs
keep the *same* holdout cell as last quarter, ÷ number of LOBs. Must be ≤ 10%. With 5
LOBs:

```
Last quarter:  LOB1->C2  LOB2->C4  LOB3->C1  LOB4->C5  LOB5->C3
Candidate:     LOB1->C4  LOB2->C1  LOB3->C6  LOB4->C3  LOB5->C5
matches = 0 -> overlap 0/5 = 0%   -> ACCEPT

Bad candidate: LOB1->C2 (same!) ...rest differ
matches = 1 -> overlap 1/5 = 20% > 10%  -> REJECT (those C2 DMAs would be dark twice running)
```

With few LOBs even one repeat blows the cap; the generator tries up to 1,000 random
squares until one clears 10%.

### 4.6 Step 6 — Power → 5 DMAs

We do **not** darken the whole 30-DMA cell (too much lost revenue). Power analysis
(Section 2.8) on the small post-stratification variance gives **5 DMAs** per LOB. The 5
are taken **one from each of 5 tiers** (diversification), so the holdout spans the
range.

### 4.7 Step 7 — Exclusions

The business vetoes certain (DMA, LOB) pairs (e.g., never darken New York for Buyer).
When picking the 5, if an excluded DMA would be chosen, **skip it and take the
next-best DMA from the same tier.** Exclusions are *runtime config*, not baked into the
score, because they are **LOB-specific** (NY excluded for Buyer but fine for Brand),
**change quarterly**, and are exceptions — NY should still be *scored and stratified*
normally (so it helps build representative tiers); it is only skipped at selection.

### 4.8 Step 8 — Holdout selection, the validation battery, and the write

From the holdout cell, pick **one representative DMA per tier** (near the tier median),
trying multiple combinations and keeping the set most balanced against the control:

```
Buyer holdout cell = Cell 4:
  Tier 0 -> Fresno     Tier 1 -> Sacramento
  Tier 2 -> (median = New York) EXCLUDED for Buyer -> Boston instead
  Tier 3 -> Tampa      Tier 4 -> Denver
HOLDOUT (ads off) = {Fresno, Sacramento, Boston, Tampa, Denver}
CONTROL (ads on)  = every other DMA (~175)
```

Then run the **final holdout-vs-control battery** on the 5-vs-rest split (using the
mock from Section 2.9: holdout `40,60,50,45,55`; control `43,59,53,49,57,45,51,55,47,51`):

- **SMD** = −0.16 → |0.16| < **0.2** (the relaxed bar for 5 DMAs) → PASS.
- **Welch t** = −0.26 → p ≈ 0.80 → PASS.
- **Kruskal-Wallis**: holdout rank sum 38 ≈ expected 40 → PASS.
- **Mood's median**: 40% above vs 40% above → PASS.
- **Parallel-trends** (daily/weekly/monthly): groups move together pre-test → PASS.
- **Bonferroni / FDR** across the 15 (3 tests × 5 KPIs) p-values: a fluke raw p=0.01
  becomes 0.15 after correction → not significant → PASS.

If anything fails, re-run selection with a new seed. Finally **write the schedule** —
one row per LOB: `holdout_dmas`, `control_dmas`, start/end dates. That table is the
handoff: activation teams switch ads off in those 5 DMAs; after the quarter, the DiD
(Section 1) measures the lift → cost-per → into the incrementality layer (Section 6).

**This is the rigorous replacement for legacy SEM:** stratified (not random),
power-sized to 5 (not population-sized), and balance-validated (not unchecked).

---

## 5. Dark-Period TV Testing

### 5.1 Why TV needs a time axis

TV is **broadcast**: a national spot plays in *every* DMA at once (no geo-targeting)
and there are *no user IDs* (no user-targeting). Both withholding axes are gone, so the
only thing we can control is **when** — we run TV normally most weeks and **reduce it
in scheduled "dark weeks,"** comparing KPIs across weeks. Cross-section (DMA vs DMA)
becomes time-series (week vs week).

### 5.2 Cut 40–60%, not to zero

A dark week reduces an LOB's TV spend ~50% (not zero) for three reasons: (1)
**operational invisibility** — going fully dark is loud; the agency/network notices and
may react, contaminating the measurement, whereas a ~50% cut looks like normal
variation; (2) **revenue protection** — full-zero weeks hurt too much to repeat all
year; (3) **detection still works** — power analysis says ~50% reduction is enough
signal given enough dark weeks.

### 5.3 Building the schedule

A 52-week plan, anchored to **week-Monday** (matches the MMM grain). Constraints:
- **Exclusion weeks** — never go dark on revenue-critical weeks (Black Friday, Cyber
  Monday, Christmas, Super Bowl); forced live.
- **Minimum gap (~4 weeks)** between two dark weeks for the same LOB, so the previous
  dark week's effect *decays* (TV has strong carryover/adstock) before the next, or the
  observations contaminate each other.
- **At most one LOB dark per week**, so the KPI drop is attributable to one LOB.
- **Balanced rotation** — each LOB goes dark roughly equally often.

### 5.4 Measurement — regression with dark-week dummies, and why controls matter

At **week level (national)**, fit one regression over all weeks:

```
KPI_week = α + β·(dark indicator) + γ·season + (other controls) + error
```

`β` (sign-flipped) is the lift. The single biggest threat in time-series data is
**confounders that move with time** — and controls are what defeat them. Watch what
happens if the dark weeks happen to fall in *high season* (true dark effect = −8):

```
Week  season  dark?   KPI = season - 8·dark
 1     100     no       100
 2     105     no       105
 3     110     no       110
 4     115     YES      107   (= 115 - 8)
 5     120     YES      112   (= 120 - 8)
 6     125     no       125
```

**Naive "dark vs normal" comparison:**

```
dark avg   = (107 + 112)/2       = 109.5
normal avg = (100+105+110+125)/4 = 110
naive effect = 109.5 - 110 = -0.5   ->  "TV does almost nothing" (BADLY wrong)
```

The dark weeks *looked* high (107, 112) only because they sat in high season — masking
the real damage. **The regression** `KPI = α + β·dark + γ·season` separates the forces
and recovers the truth:

```
γ = 1   (each season point -> +1 KPI)
β = -8  (going dark -> -8 KPI)   <- the TRUTH
```

Naive said −0.5; the regression says −8. That gap *is* why controls are essential — the
dark weeks were confounded with season, and the regression strips the season out.

**From β to cost-per.** Each LOB gets its own dark dummy in the one regression (and
"one LOB dark per week" keeps them attributable). Then:

```
β = -8,000 submits per dark week ; that 50% cut removed $100,000
cost-per ≈ $100,000 / 8,000 = $12.50 per submit
```

### 5.5 Overlap with other channels = a feature

During a TV-dark week, SEM/Display keep running. That is *wanted*: the budget question
is "if we cut TV while everything else runs normally, what happens?" — so the
in-context effect *is* the useful counterfactual. Measuring TV in a sterile vacuum
would be impossible and irrelevant. Always frame the result as "TV's lift given the
current marketing mix."

### 5.6 v1 limitations → v2 roadmap

v1 is plain OLS. Weaknesses (all familiar from MMM): no adstock on the dark indicator
(TV carries over), no Hill saturation, no per-DMA hierarchy, wide error bars (few dark
weeks/year). v2 fixes these by reusing MMM machinery — adstock the dark indicator,
Hill-saturate impressions, hierarchical Bayesian priors (with MMM's posterior as the
prior), NUTS sampling. Essentially a mini-MMM.

---

## 6. The Incrementality Layer — AOT × MMM

After AOT has *measured* cost-per (Sections 1–5) and MMM has *modeled* all channels,
the incrementality layer **fuses them** into the numbers the budget team uses. It runs
after each MMM job.

```
AOT cost-pers --clean--------------------------------------┐
                                                            ├ blend 50/50 - refit Hill curve - forecast -> AOP
MMM predictions --inverse adstock--weekly->daily--cost-per-┘  (=recalibration) (predict_stability,  (historical
                                                            └ tag direct/halo; Brand TVPA patch       scale+bias)  retention)
```

### 6.1 Cleaning the AOT cost-pers

AOT daily cost-pers are noisy, so: **impute missing dates**, **smooth with a 7-day
moving average**, **zero out invalid values** (negative/infinite cost-per from
near-zero-lift days — the Section 1.12 divide-by-zero), and **cap at the 95th
percentile** (more aggressive than the geo design's p99 because AOT cost-pers have a
worse spurious tail).

### 6.2 Inverse adstock — putting MMM in the same space as AOT

Recall MMM **adstock**: raw impressions carry over with geometric decay λ, so MMM's
prediction lives in **adstocked space**:

```
Adstocked_t = Raw_t + λ·Raw_{t-1} + λ²·Raw_{t-2} + ...
```

**The problem.** AOT measures cost-per on **raw** impressions (this week's spend → this
week's lift). If you divide MMM's adstocked prediction by *this* week's spend, the
numerator secretly includes *past* weeks' carryover → cost-per comes out artificially
low. The two are not in the same space, so you can't blend them.

**The fix.** Inverse-adstock MMM's prediction back to raw-driven (since
`A_t = X_t + λ·A_{t-1}`, solve for X):

```
Raw_t = Adstocked_t - λ · Adstocked_{t-1}
```

Worked (λ = 0.5):

```
MMM adstocked:  Week1=100, Week2=150, Week3=175
Raw-driven:     Week1=100
                Week2 = 150 - 0.5×100 = 100
                Week3 = 175 - 0.5×150 = 100
```

The raw-driven prediction is 100 each week — the adstocked numbers grew only from
carryover. Now the cost-per is honest:

```
this week's spend = $500
WRONG (adstocked): 500/175 = $2.86   (credits this week with past carryover)
RIGHT (raw):       500/100 = $5.00   (matches AOT's this-week-only basis)
```

Note: subtract λ × the **previous** period's value, never the current one.

### 6.3 Weekly → daily proportioning

MMM is weekly, AOT is daily. Split each week's (inverse-adstocked) prediction across
its 7 days in proportion to each day's share of the week's impressions:

```
day_share_d = impressions_d / (week's total impressions)
predicted_d = day_share_d × predicted_week
```

If the week's prediction is 700 and Monday carried 20% of impressions: Monday = `0.20 ×
700 = 140`. Now MMM and AOT are both daily and both raw-space → ready to blend.

### 6.4 The 50/50 blend — this *is* "recalibration"

For each AOT-covered channel: `cost_per_final = 0.5 × AOT + 0.5 × MMM`. For all other
channels: `1.0 × MMM`. Worked (Email — the canonical case):

```
AOT measured:  $0.50 / submit   (causal, from the holdout experiment)
MMM modeled:   $2.00 / submit   (MMM under-credits email)
Blend (50/50): 0.5×0.50 + 0.5×2.00 = $1.25 / submit
```

That blended **$1.25** replaces MMM's wrong $2.00 in the response curve — **that is the
"Email Simon Data recalibration,"** now in general form. **Why blend, not 100% AOT?**
AOT is causal but **noisy** (few DMAs/test periods); MMM is correlational but **stable**
(~104 weeks). The blend trades a little causal purity for a lot of variance reduction.
The weights live in a **CSV** (per channel × KPI), tunable toward AOT if MMM is badly
wrong — *without retraining MMM*. That CSV is the operational recalibration lever.

### 6.5 Direct vs halo, and the temporary Brand patch

**Direct vs halo.** A campaign aimed at one KPI can also move another (a home-loans
campaign nudges some Rental Visits). The effect on its *intended* KPI = **direct**; the
spillover onto another KPI = **halo**. A config tags each (LOB, campaign_super) per KPI;
both are kept (direct for primary dashboards, halo for cross-LOB attribution). This is
*different* from MMM's **funnel effect** (Visits → submits propagation between KPIs);
direct/halo is about *intent within* a KPI.

**Brand "TVPA" patch (temporary).** New 2026 Brand campaigns have too little data for
MMM to fit (its posterior collapses to ~zero). A one-off model assigns Brand ~5% of
baseline Visits (95% stays baseline), split across Brand channels, excluding channels
MMM already fit. Visits-only; decommissioned once Brand spend accumulates.

### 6.6 Refit the response curves (predict_stability, scale, bias)

Fit a **Hill response curve** per (channel, network, campaign_super) per KPI on the
blended cost-pers — same machinery as MMM, fed the recalibrated inputs:

```
f(spend) = bottom + (top - bottom) · spend^slope / (spend^slope + saturation^slope)
```

**`predict_stability` — the quality gate.** Check the fitted curve reproduces the data
("the actual") it was fit on. At each historical spend point compute the ratio
predicted ÷ actual, and average them into **ρ (rho)**:

```
ρ = average( curve-predicted / actual )
```

- ρ in **[0.9, 1.1]** → **stable**, use the curve.
- outside → **unstable**, flag and correct.

Worked:

```
spend   actual   curve says   ratio
$1,000    50        60         1.20
$2,000    90       108         1.20
$3,000   120       144         1.20
$4,000   140       168         1.20
$5,000   150       180         1.20
                              ρ = 1.20  -> > 1.10 -> UNSTABLE (over-predicts 20%)
```

**Scale factor (multiplicative)** = `1/ρ`, clipped to **[0.75, 1.5]**:

```
scale = 1/1.20 = 0.83   (within the clip -> keep)
calibrated at $3,000 = 0.83 × 144 = 120  -> now matches actual
```

The curve's *shape* (from the Hill fit) stays; the scale shifts its *level* to match
reality. **Bias (additive)** then fixes any leftover constant offset:

```
calibrated_curve = scale × raw_curve + bias
bias = average(actual) - average(scale × raw_curve)
```

Apply scale first (proportions), then bias (level). **Why clip to [0.75, 1.5]?** If ρ
were 2.5, `1/2.5 = 0.4` < 0.75 — a curve needing that big a rescue is *broken*. Instead
of trusting a wildly-rescaled curve, **fall back to a flat historical-mean cost-per.**
The clip is a guardrail.

### 6.7 Forecasting to the AOP

The **AOP (Annual Operating Plan)** is the marketing team's budget + KPI targets.
Turn the calibrated curves into a forward forecast:

1. Take the planned budget (monthly), **re-grain month → week** (proportional to days).
2. Apply the **calibrated curve** to each week's planned spend → predicted KPI →
   **cost-per-submit forecast**.
3. Apply scale + bias.
4. Multiply by a **multiplier table** (currently all 1.0 — reserved for manual business
   overrides, e.g., "expect 1.15× from a Q3 creative refresh").
5. Tag direct/halo.
6. **Historical-retention rule** — when a *new* MMM version reruns, **do not overwrite
   past months' forecasts.** The team committed to them; revising Jan/Feb every two
   weeks would look revisionist. Only future months recompute.
7. **Unstable-curve fallback** — for curves flagged unstable, use the flat historical
   mean instead of the curve.
8. **Merge with AOP targets** → `forecast_output` (predicted vs target per channel/week)
   → dashboards + the budget allocator.

Worked: planned weekly Email spend = $10,000; calibrated curve → 8,000 submits →
forecast cost-per = `$10,000 / 8,000 = $1.25`; shown against the AOP target.

---

## 7. Operations & Interview Capstone

### 7.1 How it all runs

Legacy AOT (Email/Meta/SEM) and the new designs deploy via Databricks Asset Bundles
(lab/stage/prod parity), DBT for SQL transforms, Unity Catalog for governance, Delta
Lake for storage, and MLflow for run logging. The new geo + dark-period designs are
packaged in a Python library, **Causal Lab**, modeled on `rapidmmm`: config-driven (no
hard-coded numbers — weights, strata count, trial count, exclusions, dates all live in
`config.yaml`), logger-over-print, and SQL-as-the-data-boundary. The incrementality
layer runs bi-weekly, right after each MMM job.

### 7.2 The whole picture in one breath

> AOT runs continuous randomized experiments (withhold marketing from a holdout) to
> measure the **causal** cost-per for a few important channels. The new geo design picks
> those holdouts rigorously — composite score → 6 strata (elbow) → balanced cells
> (5,000 shuffles) → Latin-square rotation → power-sized 5-DMA holdouts → validated
> against control. TV, which can't be held out by user or geo, uses time-based dark
> weeks measured by regression. All these cost-pers are cleaned, put in MMM's
> raw-impression space (inverse adstock), blended 50/50 with MMM (= recalibration),
> turned into calibrated response curves, and forecast against the AOP — which the
> budget allocator then acts on. MMM gives breadth; AOT gives causal ground truth; the
> incrementality layer marries them.

### 7.3 Source-material caveats (the KT notes are noisy — these are the correct versions)

The knowledge-transfer transcripts contain real errors; where sources conflict, use
these:

- **Composite weights = 70/25/5** (KPI/econ/pop). The synthesized "Overview" text says
  70/20/10 — a transcription slip; config wins.
- **The SEM example lift is 20%, not 30%.** `(150-120)/150 = 20%`. The transcript says
  "30%" by conflating the *count* (30 incremental visits) with a percentage. The cost-per
  uses the count (30), so downstream is unaffected.
- **Percentile caps differ by stage and are not all the same:** geo stratification caps
  at p99; the incrementality layer caps AOT cost-pers at p95. (The "Overview" text's
  p05/p95 lower bound is an artifact — the real lower bound is 0.)
- **The "5 DMAs" comes from power analysis on the post-stratification variance.** The
  exact σ²/δ inputs aren't recorded, and one doc prints "≈ 3.5" where the arithmetic
  gives ≈ 34 — an error. The defensible statement: "small post-stratification variance
  → ~5 DMAs."
- **The 50/50 weight is config-driven** and can differ per channel; 50/50 is the default
  concept, not a hard constant.
- **"surrender validation"** in a transcript = "median validation" (Mood's test).
- **"TVPA"** is best read as "Time-Varying Parameter Attribution" — the acronym isn't
  spelled out in the notes; safest to say "the brand-attribution model."

### 7.4 Interview questions you should be able to answer cold

1. Why run AOT if you already have MMM? *(MMM correlational/broad; AOT causal/narrow;
   AOT recalibrates MMM's cost-pers.)*
2. Explain the counterfactual and the fundamental problem in one breath.
3. Walk a DiD with the 100→150 / 100→120 numbers; give incremental (30) and lift (20%).
4. Why multiplicative, not additive, DiD? *(Different-size DMAs; additive gives the 480
   garbage.)*
5. Why is a random holdout worse than a stratified one even though both are unbiased?
   *(Variance of the single draw.)*
6. The sign-flip: reject at stratification, fail-to-reject at cells — why?
7. Where do "6" and "5" come from? *(Elbow → 6 strata; power → 5 DMAs.)*
8. Why blend AOT with MMM instead of using AOT alone? *(AOT causal-but-noisy; MMM
   stable; blend = variance reduction.)*
9. Why inverse adstock before computing MMM cost-per? *(Put it in raw-impression space
   to match AOT.)*
10. How does TV differ, and how is it measured? *(Broadcast → time axis; dark weeks;
    regression with controls; sign-flipped coefficient.)*

---

## 8. Glossary

| Term | Meaning |
|---|---|
| **AOT** | Always-On Testing — continuous randomized experiments measuring causal cost-per |
| **Counterfactual** | the unobserved opposite world (what would have happened otherwise) |
| **Fundamental problem** | you can observe only one of `Y(1)`/`Y(0)` per unit |
| **ATE** | Average Treatment Effect — `avg[Y(1)] - avg[Y(0)]` |
| **DiD** | Difference-in-Differences — `(with: post-pre) - (holdout: post-pre)` |
| **Parallel trends** | absent treatment, groups would drift equally (DiD's key assumption) |
| **Holdout** | the WITHOUT-marketing group (always) |
| **Control** | the comparison group — *with*-marketing in geo/SEM, *without* in email |
| **Stratified sampling** | split into homogeneous tiers, sample within each → variance reduction |
| **VRF** | Variance Reduction Factor — `variance_between / variance_total` (>0.6) |
| **CV** | Coefficient of Variation — `SD / mean` (within a tier, <20%) |
| **SD** | Standard deviation — typical distance from the mean |
| **SMD / Cohen's d** | mean gap ÷ SD; the balance metric (<0.1 cells, <0.2 final holdout) |
| **p-value** | chance of a difference this big if the groups were truly identical |
| **Sign-flip** | reject at stratification (tiers differ), fail-to-reject at cells (cells match) |
| **Power analysis** | `n ≈ 15.7·σ²/δ²`; the holdout size to detect a lift |
| **MDE / δ** | minimum detectable effect — smallest lift worth detecting (business-set) |
| **ANOVA / Welch** | test of equal group means; Welch's allows unequal variances |
| **Levene** | test of equal group variances |
| **Kruskal-Wallis** | rank-based (non-normal) analog of ANOVA |
| **Mood's median** | non-parametric test of equal medians (robust to skew) |
| **ICC** | Intraclass Correlation — fraction of variance between groups |
| **Bonferroni / FDR** | corrections for running many tests at once |
| **DMA** | Designated Market Area — Nielsen US TV market (~210) |
| **Composite score** | one number per DMA = 0.70 KPI + 0.25 econ + 0.05 population (normalized) |
| **Cell** | a balanced "mini-USA" with DMAs from every tier; cells resemble each other |
| **Latin square** | rotation grid: each cell holds out for one LOB/quarter; ≤10% overlap |
| **Dark period** | a week with TV spend reduced 40–60% (the TV testing mechanic) |
| **Inverse adstock** | `Raw_t = Adstocked_t - λ·Adstocked_{t-1}` — undo carryover |
| **Recalibration** | blend AOT + MMM cost-per (default 50/50) to correct MMM |
| **predict_stability / ρ** | mean(curve-predicted ÷ actual); [0.9,1.1] = stable |
| **Scale factor / bias** | curve calibration: `scale × curve + bias`, scale clipped [0.75,1.5] |
| **AOP** | Annual Operating Plan — the marketing budget + targets the forecast aligns to |

---

*End of guide. Read it front to back once, then use the worked examples as flashcards —
each number in this document is reproducible by hand.*
