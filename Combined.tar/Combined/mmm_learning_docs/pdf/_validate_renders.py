"""Headless-browser validation that each generated HTML actually renders.

For each .html in learning_docs/pdf/, opens it in headless Chromium and counts:
  - rendered KaTeX math instances (.katex elements)
  - rendered Mermaid SVG diagrams
  - ASCII-diagram-tagged blocks
  - syntax-highlighted code blocks

Prints a verification table; non-zero counts where expected = OK.
"""

from __future__ import annotations

import asyncio
from pathlib import Path

PDF_DIR = Path("/mnt/d/MMM_Learning/learning_docs/pdf")

# Expectations per doc (rough lower bounds — we just want to confirm non-zero where expected)
EXPECTED = {
    "00": {"math": 0,  "mermaid": 1, "ascii": 3, "code": 0},
    "01": {"math": 30, "mermaid": 0, "ascii": 3, "code": 0},
    "02": {"math": 5,  "mermaid": 1, "ascii": 0, "code": 15},
    "03": {"math": 0,  "mermaid": 1, "ascii": 0, "code": 5},
    "04": {"math": 0,  "mermaid": 1, "ascii": 0, "code": 0},
    "05": {"math": 10, "mermaid": 0, "ascii": 1, "code": 5},
    "06": {"math": 5,  "mermaid": 0, "ascii": 3, "code": 5},
    "07": {"math": 5,  "mermaid": 0, "ascii": 1, "code": 5},
    "08": {"math": 0,  "mermaid": 1, "ascii": 2, "code": 0},
    "09": {"math": 0,  "mermaid": 0, "ascii": 0, "code": 5},
}


async def validate_one(page, html_path: Path) -> dict:
    await page.goto(f"file://{html_path}", wait_until="networkidle")
    await page.wait_for_timeout(2500)  # allow KaTeX + Mermaid time to finish
    counts = await page.evaluate(
        """() => {
            return {
                katex_displays: document.querySelectorAll('.katex-display').length,
                katex_inline:   document.querySelectorAll('.katex:not(.katex-display .katex)').length,
                mermaid_svgs:   document.querySelectorAll('.mermaid svg').length,
                ascii_blocks:   document.querySelectorAll('.ascii-diagram-wrap, pre.ascii-diagram').length,
                code_blocks:    document.querySelectorAll('.highlight, .codehilite').length,
                title_pages:    document.querySelectorAll('.title-page').length,
                toc_pages:      document.querySelectorAll('.toc-page').length,
                h2_count:       document.querySelectorAll('h2').length,
                tables:         document.querySelectorAll('table').length,
            };
        }"""
    )
    return counts


async def main() -> None:
    from playwright.async_api import async_playwright

    print(
        f"\n{'Doc':<8} {'Math':>6} {'Mermaid':>9} {'ASCII':>7} {'Code':>6} "
        f"{'Tables':>7} {'H2':>5} {'Title':>6} {'TOC':>4}"
    )
    print("-" * 70)

    async with async_playwright() as p:
        browser = await p.chromium.launch()
        page = await browser.new_page()
        for html_path in sorted(PDF_DIR.glob("*.html")):
            doc_id = html_path.stem[:2]
            counts = await validate_one(page, html_path)
            print(
                f"{doc_id:<8} {counts['katex_displays']:>6} {counts['mermaid_svgs']:>9} "
                f"{counts['ascii_blocks']:>7} {counts['code_blocks']:>6} "
                f"{counts['tables']:>7} {counts['h2_count']:>5} "
                f"{counts['title_pages']:>6} {counts['toc_pages']:>4}"
            )
        await browser.close()

    print()


if __name__ == "__main__":
    asyncio.run(main())
