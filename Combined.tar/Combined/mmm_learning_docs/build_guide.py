# -*- coding: utf-8 -*-
"""Builds the Zillow MMM Pipeline Study Guide PDF (reportlab + matplotlib math)."""
import os, hashlib
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
matplotlib.rcParams['mathtext.fontset'] = 'cm'
import numpy as np

from reportlab.lib.pagesizes import A4
from reportlab.lib import colors
from reportlab.lib.styles import ParagraphStyle
from reportlab.lib.enums import TA_LEFT, TA_CENTER
from reportlab.lib.utils import ImageReader
from reportlab.platypus import (BaseDocTemplate, PageTemplate, Frame, Paragraph,
    Spacer, Table, TableStyle, Image, PageBreak, KeepTogether)

HERE = os.path.dirname(os.path.abspath(__file__))
OUT  = os.path.join(HERE, "MMM_Pipeline_Study_Guide.pdf")
EQD  = os.path.join(HERE, "_assets"); os.makedirs(EQD, exist_ok=True)

LM = RM = 40; TM = 54; BM = 46
CONTENT_W = A4[0] - LM - RM     # ~515 pt

# ---------- styles ----------
def S(name, **kw):
    base = dict(fontName='Helvetica', fontSize=10, leading=14, textColor=colors.HexColor('#1b1f24'))
    base.update(kw); return ParagraphStyle(name, **base)
st_body = S('body', fontSize=10, leading=14.5, alignment=TA_LEFT, spaceAfter=5)
st_h1   = S('h1', fontName='Helvetica-Bold', fontSize=18, leading=22, textColor=colors.HexColor('#16335c'), spaceBefore=6, spaceAfter=8)
st_h2   = S('h2', fontName='Helvetica-Bold', fontSize=13.5, leading=17, textColor=colors.HexColor('#1f4e79'), spaceBefore=10, spaceAfter=5)
st_h3   = S('h3', fontName='Helvetica-Bold', fontSize=11, leading=14, textColor=colors.HexColor('#2f5f8a'), spaceBefore=7, spaceAfter=3)
st_td   = S('td', fontSize=8.4, leading=10.6)
st_tdh  = S('tdh', fontSize=8.4, leading=10.6, fontName='Helvetica-Bold', textColor=colors.white)
st_note = S('note', fontSize=9, leading=12.6)
st_small= S('small', fontSize=8.6, leading=11, textColor=colors.HexColor('#55606e'))
st_cap  = S('cap', fontSize=8.4, leading=10.5, textColor=colors.HexColor('#5b6675'), alignment=TA_CENTER, spaceAfter=4)
st_title= S('title', fontName='Helvetica-Bold', fontSize=26, leading=30, textColor=colors.HexColor('#16335c'), alignment=TA_LEFT)
st_sub  = S('sub', fontSize=12, leading=16, textColor=colors.HexColor('#42536b'))

story = []
def sp(h=6): story.append(Spacer(1, h))
def P(t, s=st_body): story.append(Paragraph(t, s))
def H1(t): story.append(Paragraph(t, st_h1))
def H2(t): story.append(Paragraph(t, st_h2))
def H3(t): story.append(Paragraph(t, st_h3))
def bullets(items, s=st_body):
    for it in items:
        story.append(Paragraph('&bull;&nbsp;&nbsp;' + it, s))

# ---------- equation rendering ----------
_eqcache = {}
def eqimg(latex, fontsize=15, max_w=None, center=True):
    max_w = max_w or (CONTENT_W - 8)
    key = hashlib.md5((latex + str(fontsize)).encode()).hexdigest()
    path = os.path.join(EQD, "eq_" + key + ".png")
    if path not in _eqcache:
        fig = plt.figure(figsize=(0.01, 0.01))
        fig.text(0, 0, "$%s$" % latex, fontsize=fontsize, color='#15233a')
        try:
            fig.savefig(path, dpi=210, bbox_inches='tight', pad_inches=0.04, transparent=True)
            _eqcache[path] = True
        except Exception as e:
            print("EQ FALLBACK:", latex, "->", e)
            return None
        finally:
            plt.close(fig)
    iw, ih = ImageReader(path).getSize()
    w = iw * 72.0 / 210.0; h = ih * 72.0 / 210.0
    if w > max_w:
        sc = max_w / w; w *= sc; h *= sc
    im = Image(path, width=w, height=h)
    im.hAlign = 'CENTER' if center else 'LEFT'
    return im
def EQ(latex, fontsize=15):
    im = eqimg(latex, fontsize)
    story.append(Spacer(1, 3))
    if im is not None:
        story.append(im)
    else:
        story.append(Paragraph(latex, ParagraphStyle('eqfb', fontName='Courier', fontSize=9,
                     leading=12, alignment=TA_CENTER, textColor=colors.HexColor('#15233a'))))
    story.append(Spacer(1, 4))

# ---------- tables ----------
def tbl(rows, fracs, header=True, font=8.4, zebra=True):
    colw = [f * CONTENT_W for f in fracs]
    data = []
    for r, row in enumerate(rows):
        cells = []
        for c in row:
            cells.append(Paragraph(str(c), st_tdh if (header and r == 0) else st_td))
        data.append(cells)
    t = Table(data, colWidths=colw, repeatRows=1 if header else 0, hAlign='LEFT')
    ts = [('GRID', (0,0), (-1,-1), 0.5, colors.HexColor('#c7cfdb')),
          ('VALIGN', (0,0), (-1,-1), 'TOP'),
          ('LEFTPADDING',(0,0),(-1,-1),4), ('RIGHTPADDING',(0,0),(-1,-1),4),
          ('TOPPADDING',(0,0),(-1,-1),3), ('BOTTOMPADDING',(0,0),(-1,-1),3)]
    if header:
        ts.append(('BACKGROUND',(0,0),(-1,0),colors.HexColor('#2f4a6b')))
    if zebra:
        for r in range(1, len(rows)):
            if r % 2 == 0:
                ts.append(('BACKGROUND',(0,r),(-1,r),colors.HexColor('#f2f6fb')))
    t.setStyle(TableStyle(ts))
    return t
def T(rows, fracs, **kw):
    story.append(tbl(rows, fracs, **kw)); story.append(Spacer(1, 6))

def note(text, kind='key'):
    cm = {'key':('#e9f1fe','#1a56db'), 'warn':('#fff3e2','#b4530a'),
          'aot':('#e7f7ef','#0f8a5f'), 'math':('#f1ecff','#5b3fb5')}
    bg, br = cm[kind]
    inner = Paragraph(text, st_note)
    t = Table([[inner]], colWidths=[CONTENT_W])
    t.setStyle(TableStyle([('BACKGROUND',(0,0),(-1,-1),colors.HexColor(bg)),
        ('BOX',(0,0),(-1,-1),0.4,colors.HexColor(br)),
        ('LINEBEFORE',(0,0),(0,-1),3,colors.HexColor(br)),
        ('LEFTPADDING',(0,0),(-1,-1),9),('RIGHTPADDING',(0,0),(-1,-1),8),
        ('TOPPADDING',(0,0),(-1,-1),6),('BOTTOMPADDING',(0,0),(-1,-1),6)]))
    story.append(t); story.append(Spacer(1, 6))

# ---------- plots ----------
def plot_img(fn, w_frac=1.0):
    path = os.path.join(EQD, fn)
    iw, ih = ImageReader(path).getSize()
    w = CONTENT_W * w_frac; h = w * ih / iw
    im = Image(path, width=w, height=h); im.hAlign = 'CENTER'; return im

def make_plots():
    # Hill shapes
    x = np.linspace(0.01, 4, 200)
    def hill(x, k, s): return 1/(1+(x/s)**(-k))
    fig, ax = plt.subplots(figsize=(6.4, 2.5))
    ax.plot(x, hill(x, 0.37, 1.0), label='slope k = 0.37  (concave: TV-like)', lw=2.2, color='#1f7a4d')
    ax.plot(x, hill(x, 3.0, 1.0), label='slope k = 3.0  (S-curve: SEM-like)', lw=2.2, color='#b4530a')
    ax.axvline(1.0, ls=':', color='#888'); ax.text(1.02, 0.05, 'saturation s=1 (half-way)', fontsize=7, color='#555')
    ax.set_xlabel('scaled & adstocked impressions  (x)', fontsize=8)
    ax.set_ylabel('Hill(x)', fontsize=8); ax.legend(fontsize=7.5, loc='lower right')
    ax.tick_params(labelsize=7); ax.grid(alpha=0.25); fig.tight_layout()
    fig.savefig(os.path.join(EQD,'p_hill.png'), dpi=170); plt.close(fig)

    # Adstock carryover
    wk = np.arange(1,9); tv = np.array([0,50000,50000,0,0,0,30000,30000.0])
    d=0.5; w=np.array([d**i for i in range(4)]);
    ad=np.array([ (sum(w[l]*tv[i-l] for l in range(4) if i-l>=0))/w.sum() for i in range(8)])
    fig, ax = plt.subplots(figsize=(6.4, 2.4))
    ax.bar(wk, tv, color='#c9d6e8', label='raw TV impressions')
    ax.plot(wk, ad, '-o', color='#b4530a', lw=2, label='adstocked (carryover)')
    ax.set_xlabel('week', fontsize=8); ax.set_ylabel('impressions', fontsize=8)
    ax.legend(fontsize=7.5); ax.tick_params(labelsize=7); ax.grid(alpha=0.22); fig.tight_layout()
    fig.savefig(os.path.join(EQD,'p_adstock.png'), dpi=170); plt.close(fig)

    # Response curve
    s=np.linspace(0,8000,200); T_,sat,k=40,1200,1.3
    r=T_*s**k/(sat**k+s**k)
    fig, ax = plt.subplots(figsize=(6.4, 2.4))
    ax.plot(s, r, color='#16335c', lw=2.4)
    ax.axhline(T_, ls='--', color='#999'); ax.text(200, T_-3, 'top = 40 (ceiling)', fontsize=7, color='#555')
    ax.axvline(sat, ls=':', color='#b4530a'); ax.scatter([sat],[T_/2], color='#b4530a', zorder=5)
    ax.text(sat+120, T_/2-3, 'saturation $1200  ->  half of ceiling', fontsize=7, color='#b4530a')
    ax.set_xlabel('spend ($)', fontsize=8); ax.set_ylabel('predicted submits', fontsize=8)
    ax.tick_params(labelsize=7); ax.grid(alpha=0.22); fig.tight_layout()
    fig.savefig(os.path.join(EQD,'p_curve.png'), dpi=170); plt.close(fig)

    # Smoothing
    wk=np.arange(1,7); raw=np.array([60,65,70,62,58,60.0]); sm=[raw[0]]
    for i in range(1,6): sm.append(0.3*raw[i]+0.7*sm[-1])
    fig, ax = plt.subplots(figsize=(6.4, 2.2))
    ax.plot(wk, raw, '-o', color='#9aa7bd', label='raw forsale_index')
    ax.plot(wk, sm, '-o', color='#1f7a4d', label='smoothed (a=0.3)')
    ax.set_xlabel('week', fontsize=8); ax.set_ylabel('index', fontsize=8)
    ax.legend(fontsize=7.5); ax.tick_params(labelsize=7); ax.grid(alpha=0.22); fig.tight_layout()
    fig.savefig(os.path.join(EQD,'p_smooth.png'), dpi=170); plt.close(fig)
make_plots()

# =====================================================================
# COVER
# =====================================================================
story.append(Spacer(1, 60))
story.append(Paragraph("Zillow MMM Pipeline", st_title))
story.append(Paragraph("Complete Study Guide", st_title))
sp(14)
story.append(Paragraph("A step-by-step walkthrough of the production Marketing Mix Model: "
    "from raw Delta tables to budget response curves &mdash; data structures, preprocessing, "
    "feature engineering, the hierarchical Bayesian model, the taxonomy fan-out, response curves, "
    "and the stability loop. Every stage is traced on one small mock dataset, with the math "
    "and the code locations behind each step.", st_sub))
sp(20)
T([["Convention","Detail"],
   ["Grain","one row = one DMA &times; one week (Monday-anchored)"],
   ["Mock data","3 DMAs (501, 803, 602) &middot; 3 channel-networks (each with sub-variants) &middot; 8 weeks &middot; 2 KPIs &middot; 3 controls"],
   ["Code map","<b>rapidmmm</b> = reusable modeling library &nbsp;|&nbsp; <b>mmm_model/&lt;kpi&gt;</b> = per-KPI notebooks (NB1&ndash;NB9) &nbsp;|&nbsp; <b>shared_utils</b> = preprocessing"],
   ["KPIs / funnel","Visits &rarr; FS Submits &nbsp;&middot;&nbsp; Rental Visits &rarr; MF Submits &nbsp;&middot;&nbsp; ZHL (standalone)"]],
  [0.18,0.82])
sp(10)
story.append(Paragraph("Contents: 0 Roadmap &nbsp; 1 Data Structures &nbsp; 2 Preprocessing &nbsp; "
    "3 Feature Engineering &nbsp; 4 Bayesian Model &nbsp; 5 Taxonomy Track &nbsp; 6 Response Curves &nbsp; "
    "7 Stability &amp; Operations &nbsp; 8 Appendices", st_small))
story.append(PageBreak())

# =====================================================================
# MOCK DATASET
# =====================================================================
H1("The Mock Dataset (used in every section)")
P("Every worked example below uses this one tiny dataset so you can watch the same numbers flow "
  "through the whole pipeline. Numbers are invented for teaching, not real Zillow data.")
H3("Dimensions")
T([["Element","Values"],
   ["DMAs","501 (New York), 803 (Los Angeles), 602 (Chicago)"],
   ["Weeks","W1&ndash;W8 (Mondays from 2024-01-01). <b>Train = W1&ndash;W6, Holdout = W7&ndash;W8.</b>"],
   ["Channel-networks &rarr; sub-variants (lob|campaign_super)",
    "SEM|Google Search &rarr; {PA-Customer|Buyer, Rentals-Customer|Rental, ZHL-Customer|Buyer}<br/>"
    "Linear TV|Media Agency &rarr; {Multi Product|Brand, Multi Product|Buyer}<br/>"
    "Email|Simon Data &rarr; {PA-Customer|Buyer, Rentals-Customer|Rental}"],
   ["Controls","interest_rate, googletrends_forsale_index, unemployment_rate"],
   ["KPIs","visits (parent), fs_submits (child); New Year's Day holiday in W1"]],
  [0.26,0.74])
H3("DMA 501 weekly values (803 &asymp; 60% of 501, 602 &asymp; 40%)")
T([["week","SEM imp","TV imp","Email imp","visits","fs_submits","int_rate","forsale_idx","split"],
   ["W1","1000","0","500","10000","200","7.0","60","Train"],
   ["W2","1200","50000","0","14000","260","7.1","65","Train"],
   ["W3","1100","50000","600","15000","280","7.1","70","Train"],
   ["W4","1300","0","0","12500","250","6.9","62","Train"],
   ["W5","1250","0","550","12000","240","6.8","58","Train"],
   ["W6","1400","0","0","12800","255","6.8","60","Train"],
   ["W7","1300","30000","500","13500","265","6.7","61","Holdout"],
   ["W8","1500","30000","0","14200","270","6.7","63","Holdout"]],
  [0.08,0.12,0.11,0.12,0.11,0.13,0.11,0.12,0.10])
note("The TV burst in W2&ndash;W3 (then dark) is deliberate: it lets us watch <b>adstock</b> spread TV's "
     "effect into later weeks. The second smaller burst in W7&ndash;W8 gives the holdout and the response "
     "curves real signal to work with.", 'key')
story.append(PageBreak())

# =====================================================================
# 0 ROADMAP
# =====================================================================
H1("0 &nbsp; Roadmap &amp; Big Picture")
P("<b>Marketing Mix Modeling (MMM)</b> is a top-down attribution method: it uses aggregated "
  "(region &times; week) history to estimate how much of a business outcome each marketing channel "
  "drove, after controlling for non-marketing drivers (seasonality, holidays, macro-economy). "
  "Unlike user-level attribution it needs no cookies, so it can measure offline channels (TV, OOH, Audio) "
  "and survives privacy changes.")
H2("0.1 &nbsp; The five KPIs and the funnel")
T([["KPI","Funnel position","Target (in business metrics)","Funnel parent"],
   ["Visits","top (traffic)","value|visits|visits","&mdash; (root)"],
   ["FS Submits","mid (for-sale leads)","value|leads|fs_submits","Visits"],
   ["ZHL Submits","mid (home loans)","ZHL-specific","standalone"],
   ["Rental Visits","top (rentals traffic)","value|rentalsmetrics_zillowbrand|rental_visits","&mdash; (root)"],
   ["MF Submits","mid (multi-family leads)","value|rentalsmetrics_zillowbrand|fr_bdp_submits","Rental Visits"]],
  [0.16,0.22,0.40,0.22])
P("Each KPI is a <b>separately-fit model</b> with its own priors and config. Lower-funnel KPIs use their "
  "upper-funnel parent for funnel-effect attribution (Section 4).")
H2("0.2 &nbsp; The four data layers")
T([["Layer","What lives there","Produced by"],
   ["Raw source (marketingde_gold)","impressions/spend + KPI events + econometrics","upstream DE team"],
   ["Silver &ndash; shared (rapidmmm_silver)","pivoted, validated inputs + smoothed macros","MMM Input Job (shared_utils)"],
   ["Silver &ndash; per-KPI","feature-engineered tables, melted contributions","KPI notebooks 1,3,4,5"],
   ["Gold (rapidmmm_gold)","model outputs, response curves, stability (versioned)","KPI notebooks 2,6,7,8,9"]],
  [0.27,0.46,0.27])
H2("0.3 &nbsp; The whole pipeline in one view")
T([["Phase","Notebook","Turns &hellip; into &hellip;"],
   ["2 Preprocessing","shared_utils","raw long tables &rarr; wide silver + smoothed macros"],
   ["3 Feature Eng","NB1","impressions &rarr; adstock &rarr; scale &rarr; Atan &rarr; Hill (+holidays, seasonality)"],
   ["4 Overall model","NB2","features + priors &rarr; Bayesian fit &rarr; contributions &rarr; AOT recal &rarr; funnel"],
   ["5 Taxonomy","NB3&ndash;6","split each channel's credit across lob|campaign_super (15 parallel, no intercept)"],
   ["6 Response curves","NB7&ndash;8","fit Hill on (spend, predicted) &rarr; budget curves + 150-pt grids"],
   ["7 Stability + ops","NB9","compare vN vs vN-1 ROI bands &rarr; stability flags; version, schedule"]],
  [0.18,0.13,0.69])
story.append(PageBreak())

# =====================================================================
# 1 DATA STRUCTURES
# =====================================================================
H1("1 &nbsp; Data Structures &amp; Schema")
P("Everything in the system is a transformation of just <b>five raw source tables</b>. Other teams own "
  "them; MMM only reads them. All share the grain <b>dmacode &times; week_monday</b>.")
H2("1.1 &nbsp; mmm_marketing_metrics &mdash; what we spent / showed (long format)")
T([["column","type","meaning"],
   ["dmacode, week_monday","INT / TS","the market &times; week spine"],
   ["channel, network","STRING","platform &amp; buy, e.g. SEM &amp; Google Search"],
   ["lob, campaign_super, tactic, initiative","STRING","taxonomy levels (line of business, campaign category, &hellip;)"],
   ["impressions","DECIMAL","<b>the model's X (input feature)</b>"],
   ["clicks, spend","LONG / DOUBLE","spend is kept for cost-per &amp; response curves, not used as X"]],
  [0.30,0.13,0.57])
note("People miss this: the regression's input is <b>impressions</b>, not spend. Spend rides alongside so "
     "we can later say &lsquo;$X of spend bought Y impressions which drove Z conversions&rsquo; and build "
     "spend-based response curves.", 'key')
H2("1.2 &nbsp; mmm_business_metrics &mdash; what happened (targets + controls, long format)")
P("This single long table holds <b>every target variable</b> and the non-marketing controls, keyed by the "
  "triple <i>value | data_name | metric</i>. A model selects its target by filtering to one (data_name, metric).")
T([["KPI model","Target = value | data_name | metric"],
   ["Visits","value | visits | visits"],
   ["FS Submits","value | leads | fs_submits"],
   ["Rental Visits","value | rentalsmetrics_zillowbrand | rental_visits"],
   ["MF Submits","value | rentalsmetrics_zillowbrand | fr_bdp_submits"]],
  [0.28,0.72])
H3("The 21 control variables (also in this table)")
T([["Group","Variables","Smoothed?"],
   ["Housing market (econmetricsmsa)","for_sale_inventory, mean/median_days_to_pending, median_list/sale_price, new_listings, newly_pending_listings, percent_listings_with_price_cut, sales_count_raw, zillow_home_value_index","yes"],
   ["Google Trends","branded, competitive, forsale, mortgage, rentals, zillowoffers (indices)","yes"],
   ["Macro (Moody's)","unemployment_rate, consumer_price","yes"],
   ["Rentals supply","rental_daily_listings","yes"],
   ["Mortgage","interest_rate","<b>no</b> (used raw)"],
   ["App","app_installs","<b>no</b> (used raw)"]],
  [0.22,0.62,0.16])
P("<b>Why controls matter:</b> they absorb KPI movements that marketing did <i>not</i> cause &mdash; so the "
  "model does not credit a channel for a visits bump that was really a mortgage-rate drop or a seasonal "
  "search spike.")
H3("The three support tables")
T([["Table","Gives","Used for"],
   ["mmm_calendar","calendardate &rarr; weekstartmonday","roll days to weeks, build seasonality"],
   ["mmm_holidays","US holidays list","holiday dummy features"],
   ["mmm_regionmapping","dmacode &harr; DMA name","label outputs with human market names"]],
  [0.24,0.40,0.36])
story.append(PageBreak())

# =====================================================================
# 2 PREPROCESSING
# =====================================================================
H1("2 &nbsp; Preprocessing (raw &rarr; silver)")
P("The <b>MMM Input Job</b> (shared_utils / mmm_input_data_preprocessing.py) turns the two tall raw tables "
  "into wide, model-ready silver tables shared by all KPIs &mdash; so no two KPIs can disagree on what an "
  "input means. It does four things.")
H2("2.1 &nbsp; Filter to allowed channel combinations")
P("A config whitelist (allowed_channels_and_networks) keeps only valid channel|network|lob|campaign_super "
  "rows; everything else is dumped into an inspected &lsquo;invalid_rows&rsquo; set, so nothing silently disappears.")
H2("2.2 &nbsp; Pivot long &rarr; wide (the move that creates the two model tracks)")
P("The same long table is pivoted twice (MarketingMetricsData.get_pivoted_impressions_for_mmm):")
T([["Pivot key","Becomes","Builds"],
   ["channel, network","~25 impression columns","mmm_input_preprocessing_overall_data (the <b>overall</b> track)"],
   ["channel, network, lob, campaign_super","~146 columns","mmm_input_preprocessing_taxonomy_data (the <b>taxonomy</b> track)"]],
  [0.30,0.24,0.46])
P("On our mock data (DMA 501, W2), the long rows pivot into wide columns:")
T([["overall column","value","","taxonomy column (same 50000 split)","value"],
   ["impressions_SEM_Google_Search","1200","","impressions_..._SEM_..._PA_Buyer","700"],
   ["impressions_Linear_TV_Media_Agency","50000","","impressions_..._SEM_..._Rentals_Rental","400"],
   ["impressions_Email_Simon_Data","0","","impressions_..._SEM_..._ZHL_Buyer","100"]],
  [0.32,0.10,0.04,0.42,0.12])
note("<b>Overall = &Sigma;(its taxonomy children).</b> The overall pivot sums impressions across all "
     "lob/campaign for a channel-network; the taxonomy pivot keeps them split. That identity keeps the two "
     "tracks reconcilable and is the root of every &lsquo;two tracks&rsquo; thing downstream.", 'key')
H2("2.3 &nbsp; For-sale overall vs rentals overall (do FS and MF share impressions?)")
P("Two marketing objects are built from the same raw table. The rentals object starts as a copy, then "
  "<b>removes</b> Agent, Brand and Elevate campaign_supers and ZGMI and ZHL LOBs:")
T([["Built from","Written to","Used by"],
   ["full set (MD)","mmm_input_preprocessing_overall_data","Visits + FS Submits"],
   ["filtered (MD1 = full minus Agent/Brand/Elevate/ZGMI/ZHL)","mmm_input_preprocessing_overall_data_rentals","Rental Visits + MF Submits"]],
  [0.40,0.36,0.24])
note("So FS and MF do <b>not</b> see identical impression numbers &mdash; rentals is a filtered subset. "
     "They <i>overlap</i> on the consumer channels that survive the filter, which is fine: a for-sale lead "
     "and a rental lead are different events, the models are fit separately and never summed, and the two "
     "funnels have different parents (FS&larr;Visits, MF&larr;Rental Visits).", 'warn')
P("The train/holdout label is stamped here too: a week is <b>Train</b> if it falls before holdout_start_week, "
  "else <b>Holdout</b> (the most recent weeks).")
H2("2.4 &nbsp; The exogenous feature store (smoothing the macros)")
P("A separate notebook (mmm_exogeneous_feature_store.py) smooths the noisy macro controls before the model "
  "sees them, using per-DMA <b>exponential smoothing</b>:")
EQ(r"s_t = \alpha\, x_t + (1-\alpha)\, s_{t-1}, \qquad \alpha = 0.3")
story.append(plot_img('p_smooth.png', 0.74)); story.append(Paragraph("forsale_index: the W3 spike (70) is pulled back toward trend (~64).", st_cap))
bullets(["Only the macro_econ_vars_to_smooth are smoothed; interest_rate and app_installs stay <b>raw</b> "
         "(already clean, slow-moving).",
         "For future/holdout weeks where a macro is unknown, it is back-filled with the <b>seasonal mean for "
         "that ISO week</b> &mdash; safer than 0, which would fake a demand collapse."])
story.append(PageBreak())

# =====================================================================
# 3 FEATURE ENGINEERING
# =====================================================================
H1("3 &nbsp; Feature Engineering (NB1)")
P("Raw impressions cannot enter a regression directly. Three transforms fix three different problems, in order.")
T([["Problem with raw impressions","Fix","Controls"],
   ["an ad shown this week keeps working next week","Adstock","WHEN (time)"],
   ["NY has 50&times; the impressions of a small DMA","Mean scaling","LEVEL (comparability)"],
   ["the millionth impression does less than the thousandth","Saturation (Atan, Hill)","SHAPE (curvature)"]],
  [0.50,0.22,0.28])
H2("3.1 &nbsp; Adstock &mdash; carryover (the WHEN)")
P("Adstock is a weighted sum of this week plus past weeks. The variants differ only in the weights "
  "(rapidmmm FeatureEngineering):")
EQ(r"\mathrm{Exponential:}\quad \mathrm{adstock}_t = \sum_{l=0}^{L} d^{\,l}\, x_{t-l}")
EQ(r"\mathrm{Geometric:}\quad \mathrm{adstock}_t = \frac{\sum_{l=0}^{M} d^{\,l}\, x_{t-l}}{\sum_{l=0}^{M} d^{\,l}}")
EQ(r"\mathrm{Delayed:}\quad w_l = \frac{d^{\,(l-D)^2}}{\sum_l d^{\,(l-D)^2}}\quad(\mathrm{peak\ at\ lag}\ l=D)")
P("The Delayed (l&minus;D)&sup2; term puts the <b>peak</b> effect D weeks later &mdash; exactly how Linear TV "
  "is modeled (delay 5). On our mock TV burst (geometric, d=0.5):")
story.append(plot_img('p_adstock.png', 0.74)); story.append(Paragraph("TV stops after W3 but its adstocked effect lingers into W4&ndash;W6 &mdash; that is the point of adstock.", st_cap))
note("<b>Where adstock params come from:</b> a grid of (decay, lag, delay) variants is generated; a LASSO "
     "regression of the KPI on all variants keeps the single best-fitting shape (argmax coefficient). The "
     "winner is frozen in config_param.yml. This is done <b>offline</b>, not in the bi-weekly job.", 'math')
H2("3.2 &nbsp; Mean scaling &mdash; comparable levels (the LEVEL)")
P("Each column is divided by <b>that DMA's mean over the training weeks</b> (rapidmmm MeanScalingRegional):")
EQ(r"\mathrm{scaled}_{d,t,c} = \frac{x_{d,t,c}}{\bar{x}^{\,\mathrm{train}}_{d,c}}, \qquad "
   r"\bar{x}^{\,\mathrm{train}}_{d,c} = \frac{1}{|T|}\sum_{t\in\mathrm{train}} x_{d,t,c}")
P("Worked: DMA 501's adstocked TV over train weeks W1&ndash;W6 averages to a single number "
  "(say 17,400). Every week &mdash; train and holdout &mdash; is divided by that same number.")
note("Three things to lock in: (1) the scaling mean is one number <b>per DMA per column</b>, computed over "
     "<b>training weeks</b> (it collapses the time axis). (2) It is fit on train and <b>reused</b> on holdout, "
     "so holdout cannot peek at itself. (3) The <b>target fs_submits is also scaled</b> (one mean per DMA, "
     "no channel dimension); predictions are multiplied back by that mean to read real submits.", 'key')
P("<b>Why divide by the mean (not z-score)?</b> It keeps 0 at 0, centres every feature near 1.0 regardless "
  "of DMA size, and makes coefficients comparable elasticities &mdash; which is what lets the hierarchical "
  "model pool DMAs.")
H2("3.3 &nbsp; Saturation &mdash; diminishing returns (the SHAPE)")
P("After scaling, two squashing functions run. <b>Atan</b> (arctan, parameter-free) is applied only to 8 "
  "heavy-tailed channels listed in config to tame outlier spikes; <b>Hill</b> is applied to every adstocked "
  "impression column:")
EQ(r"A(x) = \arctan(x) \qquad\qquad H(x) = \frac{1}{1 + (x/s)^{-k}}")
P("Hill encodes diminishing returns: doubling scaled impressions less-than-doubles the output. The "
  "saturation s and slope k come from offline curve_fit and are frozen in config (Section 6 explains how "
  "to read them).")
H2("3.4 &nbsp; Holidays, seasonality, and Share-of-Voice")
bullets(["<b>Holidays:</b> mmm_holidays is merged into dummy columns (New Year's Day = 1 in W1, else 0), so a "
         "holiday dip is not blamed on a channel.",
         "<b>Seasonality:</b> statsmodels seasonal_decompose extracts a recurring component as its own feature.",
         "<b>Share-of-Voice:</b> a channel's adstocked impressions / total that week &mdash; an extra 0&ndash;1 "
         "feature (skips mean scaling)."])
H2("3.5 &nbsp; Where each number comes from")
T([["Quantity","Source","Fixed / computed / learned"],
   ["Adstock decay, lag, delay","config (offline grid + LASSO)","<b>fixed</b> hyperparameter"],
   ["Hill slope, saturation","config (offline curve_fit)","<b>fixed</b> hyperparameter"],
   ["Scaling mean","df.groupby(dma).mean() on train","<b>computed</b> from data"],
   ["Coefficients &beta;, intercept &alpha;","NUTS posterior (Section 4)","<b>learned</b>, guided by priors"],
   ["Prior Mean / Sd per &beta;","artifacts/&lt;kpi&gt;_priors.csv","<b>fixed</b> input to learning"]],
  [0.30,0.40,0.30])
story.append(PageBreak())

# =====================================================================
# 4 BAYESIAN MODEL  (expanded diagnostics)
# =====================================================================
H1("4 &nbsp; The Overall Bayesian Model (NB2)")
P("This is the heart of MMM. It estimates, for every DMA and channel, how strongly the (transformed) "
  "impressions drive the KPI &mdash; with full uncertainty. Engine: rapidmmm BayesianModel using numpyro + "
  "JAX with the NUTS sampler.")
H2("4.1 &nbsp; The generative model (full math)")
P("Every quantity is drawn from a distribution; reading top to bottom is the &lsquo;story&rsquo; of how the "
  "KPI is generated. For DMA d, week t, feature c:")
H3("Hyperpriors (global &mdash; one set, shared by all DMAs)")
EQ(r"\mu_\alpha \sim \mathrm{TruncNormal}(0,\,1,\ \mathrm{low}{=}0)\qquad \sigma_\alpha \sim \mathrm{HalfNormal}(5)")
EQ(r"m_c \sim \mathrm{Normal}(0,1)\ \ (\mathrm{controls})\qquad m_c \sim \mathrm{TruncNormal}(\mu_c,\sigma_c,\mathrm{low}{=}0)\ \ (\mathrm{ads})")
EQ(r"\sigma_{\beta,c} \sim \mathrm{HalfNormal}(s_c)")
H3("DMA-level (drawn around the globals &mdash; the pooling)")
EQ(r"\alpha_d \sim \mathrm{TruncNormal}(\mu_\alpha,\sigma_\alpha,\mathrm{low}{=}0)\quad[\mathrm{Overall\ only;\ Taxonomy}:\ \alpha_d{=}0]")
EQ(r"\beta_{d,c} \sim \mathrm{Normal}(m_c,\sigma_{\beta,c})\ \ (\mathrm{controls})\qquad \beta_{d,c} \sim \mathrm{TruncNormal}(m_c,\sigma_{\beta,c},\mathrm{low}{=}0)\ \ (\mathrm{ads})")
H3("Likelihood (connect to the observed KPI)")
EQ(r"\hat{y}_{d,t} = \alpha_d + \sum_c \beta_{d,c}\, x_{c,d,t}\qquad y_{d,t} \sim \mathrm{Normal}(\hat{y}_{d,t},\ \sigma)")
T([["Distribution","Why it is used"],
   ["TruncNormal(&middot;, low=0)","forces non-negativity &mdash; ad effects and the baseline cannot be negative"],
   ["HalfNormal(s)","prior for scale/SD parameters, which must be &ge; 0"],
   ["Normal","symmetric &mdash; control coefficients may be + or &minus; (e.g. interest rate)"]],
  [0.26,0.74])
H2("4.2 &nbsp; Symbols")
T([["Symbol","Meaning","Symbol","Meaning"],
   ["&alpha;<sub>d</sub>","baseline for DMA d (KPI with zero marketing)","m<sub>c</sub>","global typical effect of feature c"],
   ["&beta;<sub>d,c</sub>","effect of feature c in DMA d","&sigma;<sub>&beta;,c</sub>","spread of &beta;<sub>c</sub> across DMAs"],
   ["&mu;<sub>&alpha;</sub>, &sigma;<sub>&alpha;</sub>","global baseline mean &amp; spread","&sigma;","residual noise"],
   ["x<sub>c,d,t</sub>","transformed feature value","~ / &prop;","&lsquo;distributed as&rsquo; / &lsquo;proportional to&rsquo;"]],
  [0.13,0.40,0.12,0.35])
H2("4.3 &nbsp; How Bayesian updating works (one coefficient)")
P("Bayesian inference is one formula &mdash; the posterior is the prior reshaped by the data:")
EQ(r"p(\theta \mid \mathcal{D}) \ \propto\ p(\mathcal{D}\mid\theta)\ \cdot\ p(\theta) \qquad (\mathrm{posterior} \propto \mathrm{likelihood} \times \mathrm{prior})")
P("For a single &beta; with a Normal prior and Normal data, the posterior mean is a "
  "<b>precision-weighted average</b> (precision &tau; = 1/&sigma;&sup2; = confidence):")
EQ(r"\mu_{\mathrm{post}} = \frac{\tau_0\,\mu_0 + \tau_d\,\hat{\mu}}{\tau_0 + \tau_d},\qquad \tau = \frac{1}{\sigma^2}")
P("Example: prior &beta; ~ Normal(0.16, 0.02), data says 0.10 &plusmn; 0.04. Then &tau;<sub>0</sub>=2500, "
  "&tau;<sub>d</sub>=625, and &mu;<sub>post</sub> = (2500&middot;0.16 + 625&middot;0.10)/3125 = <b>0.148</b> &mdash; "
  "pulled toward the more confident prior.")
note("This is why the priors.csv <b>Sd</b> matters. Sd = 0.0001 makes the prior nearly immovable &rarr; the "
     "channel is &lsquo;pinned&rsquo; (how an AOT-measured value is locked in). A large Sd lets the data "
     "decide. <b>Granularity:</b> one prior row per feature (the global m<sub>c</sub>), shared across all DMAs; "
     "in code, custom priors are read <b>only for impression columns</b> &mdash; controls/holidays default to "
     "a weak Normal(0,1).", 'key')
H2("4.4 &nbsp; Partial pooling (shrinkage) &mdash; on our 3 DMAs")
P("Each DMA's &beta; is drawn from the shared global m<sub>c</sub>, so noisy DMAs borrow strength:")
T([["DMA (TV)","Fit alone (data only)","Hierarchical posterior","95% HDI","what happened"],
   ["501 (strong signal)","0.40","0.37","[0.30, 0.44]","keeps its own value"],
   ["803 (weak/noisy)","0.19","0.27","[0.17, 0.37]","pulled toward global 0.31"],
   ["602 (medium)","0.30","0.30","[0.22, 0.39]","stays near global"],
   ["global m_TV","&mdash;","0.31","[0.22, 0.40]","learned from all three"]],
  [0.18,0.20,0.20,0.18,0.24])
P("The noisy DMA 803 is rescued by the hierarchy &mdash; the whole reason to model ~210 DMAs jointly rather "
  "than one national series or 210 isolated ones.")
H2("4.5 &nbsp; NUTS and its diagnostics (what to look at)")
P("Because there is no closed-form posterior for thousands of coupled coefficients, NUTS (No-U-Turn Sampler) "
  "<b>samples</b> it. It uses gradients of the log-posterior (JAX autodiff) plus simulated Hamiltonian "
  "dynamics to propose long, high-acceptance moves. Two kinds of coupling occur in one joint fit: the "
  "<b>same channel is pooled across DMAs</b> (via the shared prior m<sub>c</sub>), and <b>different channels "
  "are coupled within a DMA</b> (via the shared y in the likelihood &mdash; collinear channels get correlated, "
  "wider posteriors).")
H3("Warmup vs sampling")
P("<b>Warmup</b> draws tune the step size and mass matrix and are discarded; the kept <b>samples</b> are the "
  "posterior draws used for all summaries.")
H3("The convergence / health diagnostics")
T([["Diagnostic","What it measures","Good value","If bad &rarr;"],
   ["R-hat (Gelman&ndash;Rubin)","agreement of between-chain vs within-chain variance: sqrt(V_hat / W)",
    "&le; 1.01 (&asymp; 1.0)","chains disagree &mdash; not converged; sample more / reparameterize"],
   ["ESS (effective sample size)","independent-equivalent draws after autocorrelation: N / (1 + 2&Sigma;&rho;<sub>k</sub>)",
    "&gt; ~400 (bulk &amp; tail)","high autocorrelation &mdash; estimates noisy; draw more"],
   ["Divergences","leapfrog integrator energy errors (hard, funnel-shaped geometry)",
    "0 (or very few)","biased exploration; raise target accept / reparameterize"],
   ["Mean accept_prob","average Metropolis acceptance (NUTS targets ~0.8)",
    "in [0.6, 1.0] (config gate)","step size too large; lower it"],
   ["Tree depth","leapfrog steps per draw = 2^depth (capped by max_tree_depth)",
    "rarely hits the cap","sampler inefficient; tune step size"],
   ["Trace plot","visual mixing of the chain over draws",
    "a flat &lsquo;fuzzy caterpillar&rsquo;","trends/sticking = poor mixing"]],
  [0.16,0.36,0.20,0.28])
note("The production code's acceptance gate checks <b>mean accept_prob in [0.6, 1.0]</b> and "
     "<b>divergences &le; max_divergences</b> (= 2000 samples &times; perc_divergence 0.15 = 300). These two "
     "are exactly the extra_fields ('accept_prob','diverging') pulled from the MCMC run. R-hat and ESS are the "
     "standard ArviZ convergence checks on the posterior.", 'aot')
H2("4.6 &nbsp; From posterior to the numbers in the tables")
P("After sampling, each &beta;<sub>d,c</sub> is thousands of draws. Two summaries are extracted:")
bullets(["<b>posterior mean</b> &rarr; the point estimate (the &lsquo;coefficient&rsquo;).",
         "<b>95% HDI</b> (Highest Density Interval) &rarr; the narrowest range holding 95% of the draws &mdash; "
         "the Bayesian credible interval."])
T([["Output column","Mock value","Meaning"],
   ["coefficient","0.37","posterior mean of &beta;<sub>501,TV</sub>"],
   ["coef_hdi_2point5_pct / _97point5_pct","0.30 / 0.44","95% HDI of the coefficient"],
   ["predicted","40","mean contribution = &beta;&middot;x, inverse-scaled to real submits"],
   ["predicted_2point5/97point5_pct_hdi","32 / 49","95% HDI of that contribution"],
   ["return_lower / return_higher","32/imp / 49/imp","ROI band = predicted HDI / impressions (used by stability)"]],
  [0.36,0.18,0.46])
P("<b>Where HDI is used:</b> (1) stored on every output row as the uncertainty band; (2) the stability loop "
  "(Section 7) compares ROI HDI bands across versions; (3) risk-aware budgeting prefers tight bands.")
H2("4.7 &nbsp; Melted contributions and inverse scaling")
P("The wide output is melted to one row per dma&times;week&times;channel (mmm_&lt;kpi&gt;_overall_model_"
  "melted_data). Each contribution &beta;&middot;x is then multiplied by the DMA's fs_submits training mean to "
  "return real submits. Example (DMA 501, W3): scaled SEM contribution 0.099 &times; mean 250 &asymp; 25 submits.")
H2("4.8 &nbsp; AOT recalibration (Email)")
P("<b>AOT (Always-On Testing)</b> is Zillow's geo-experiment system: it turns a channel off in some markets "
  "and on in others and compares the KPI &mdash; a true causal measurement. MMM is correlational and "
  "<b>over-credits Email</b> (emails reach people already intending to act). So for Email (and App) the "
  "model output is recalibrated to the AOT truth:")
EQ(r"\mathrm{recal} = \frac{\mathrm{impressions}}{\mathrm{spi}}, \qquad "
   r"\mathrm{spi} = \frac{\sum \mathrm{sends}}{\sum \mathrm{incremental\ visits}}\ \ (\mathrm{from\ AOT})")
EQ(r"\Delta = \mathrm{predicted} - \mathrm{recal};\qquad \mathrm{Email} \leftarrow \mathrm{recal};\qquad \mathrm{baseline} \leftarrow \mathrm{baseline} + \Delta")
P("Multi-week mock (DMA 501, spi = 4000 sends per incremental submit); only the <b>direct</b> effect is "
  "recalibrated, the funnel rows are untouched:")
T([["week","sends","MMM direct","AOT recal = sends/4000","funnel (untouched)"],
   ["W1","100000","50","25","20"],
   ["W2","120000","60","30","24"],
   ["W3","110000","55","27.5","22"],
   ["totals","&mdash;","165","82.5 (&Delta;=82.5 &rarr; baseline)","66"]],
  [0.14,0.16,0.20,0.30,0.20])
note("Conservation: the &Delta; is <b>moved to baseline</b>, not deleted, so total predicted KPI is unchanged "
     "&mdash; only the attribution shifts (Email down, organic baseline up). The <b>funnel</b> rows are left "
     "alone because AOT measures only Email's <i>direct</i> incremental effect, and the funnel piece is "
     "derived from the (already recalibrated) Visits model. Config: aot_recalibration_flag, "
     "channel_to_recalibrate_aot = [Email|Simon Data].", 'aot')
H2("4.9 &nbsp; Holdout usage")
P("The model is fit on <b>train</b> only. The fitted posterior then predicts the <b>holdout</b> weeks (which it "
  "never saw) and r&sup2;/rmse/mape are computed there &mdash; an out-of-time trust check that catches drift "
  "or overfitting. Both train and holdout rows are written, labelled. Keep separate the two gates: "
  "<b>MCMC health</b> (R-hat, ESS, divergences, accept_prob &mdash; did the sampler converge?) vs "
  "<b>holdout accuracy</b> (mape &mdash; does it predict unseen weeks?).")
H2("4.10 &nbsp; Funnel effects (Visits &rarr; FS Submits)")
P("Visits is a <b>regressor in the FS Submits model</b>. So an ad earns FS credit two ways: directly "
  "(impressions &rarr; submits) and through the funnel (impressions &rarr; visits &rarr; submits). The funnel "
  "step (FunnelEffects.funnel_effects) splits the submits explained by the Visits regressor among channels by "
  "their share of visits:")
EQ(r"\mathrm{percent1}_c = \frac{\mathrm{visits\_pred}_c}{\sum_c \mathrm{visits\_pred}_c},\quad "
   r"\mathrm{percent2} = \frac{\mathrm{submits\_via\_visits}}{\sum \mathrm{submits\_pred}}")
EQ(r"\mathrm{funnel}_c = \mathrm{submits\_via\_visits}\ \times\ \mathrm{percent1}_c")
P("Worked (DMA 501, W3). Visits model: total 15000, TV share 0.20. FS model: 90 submits via Visits.")
T([["channel","Direct","Funnel = 90 &times; visits-share","Combined"],
   ["TV (share 0.20)","40","18","58"],
   ["SEM (share 0.133)","50","12","62"],
   ["Email (share 0.067)","0","6","6"],
   ["baseline / B_Visits (0.60)","100","54","154"],
   ["total","190 + (90 funneled)","&rarr; redistributed 90","280"]],
  [0.30,0.22,0.30,0.18])
note("The 90 submits-via-visits are <b>redistributed</b> (18+12+6+54 = 90), so the grand total stays 280 "
     "&mdash; that conservation is the proof funnel effects are not double counting. Direct-only lands in "
     "mmm_model_output_overall_level; Direct+Funnel in mmm_model_combined_output_overall_level. MF Submits "
     "does the same with Rental Visits as parent.", 'key')
story.append(PageBreak())

# =====================================================================
# 5 TAXONOMY
# =====================================================================
H1("5 &nbsp; The Taxonomy Track (NB3&ndash;NB6)")
P("The overall model says &lsquo;SEM drove 100 submits&rsquo;. The taxonomy track splits that across SEM's "
  "lob|campaign_super sub-variants.")
H2("5.1 &nbsp; The key idea: the target is the overall model's output")
P("The taxonomy model does <b>not</b> predict the raw KPI. Its dependent variable y is the overall model's "
  "<b>predicted contribution</b> for that channel-network (read from mmm_&lt;kpi&gt;_overall_model_melted_data):")
T([["Element","In the taxonomy model"],
   ["y (target)","SEM's predicted contribution from the overall model (e.g. 100 submits)"],
   ["X","the sub-variant impressions, adstock + scale + Hill at taxonomy level"],
   ["intercept","<b>none</b> (modeltype = 'Taxonomy', &alpha; = 0)"]],
  [0.18,0.82])
P("<b>Why no intercept?</b> We are carving up an already-attributed amount, so there is no baseline to leave "
  "over &mdash; the sub-pieces must sum to the channel total.")
H2("5.2 &nbsp; The split (mock)")
T([["sub-variant","predicted submits"],
   ["SEM | PA-Customer | Buyer","70"],
   ["SEM | Rentals-Customer | Rental","20"],
   ["SEM | ZHL-Customer | Buyer","10"],
   ["sum (= overall SEM)","100"]],
  [0.6,0.4])
P("The raw fitted splits only approximately sum to 100, so a normalization (pred_ratio = predicted / "
  "pred_sum, times the overall value) forces them to sum <b>exactly</b> to the channel total.")
H2("5.3 &nbsp; Structure")
T([["Notebook","Role"],
   ["NB3 taxonomy_model_input","pivot taxonomy_data to sub-variant impressions; transform; join overall predicted as target"],
   ["NB4 taxonomy_model (&times;15 parallel)","one run per channel-network; no-intercept hierarchical Bayes; weak default priors"],
   ["NB5 single_variable_channel","channels with one sub-variant (cnt_dict = 1) skip the model &mdash; whole credit to that variant"],
   ["NB6 taxonomy_output_merge","UNION staging &rarr; gold taxonomy tables (+ funnel at this level)"]],
  [0.30,0.70])
note("Each of the 15 is the <b>same</b> Bayesian engine with NUTS, just no intercept. They run in parallel "
     "because, given the overall output, each channel's internal split is independent of the others. "
     "Sub-variant columns with no listed prior fall back to a weak Normal(0,1), so the splits are "
     "data-driven.", 'key')
story.append(PageBreak())

# =====================================================================
# 6 RESPONSE CURVES
# =====================================================================
H1("6 &nbsp; Response Curves (NB7&ndash;NB8)")
P("Curves turn the model into a forward-looking budget tool: &lsquo;if I spend $X on SEM, how many submits?&rsquo;")
H2("6.1 &nbsp; Two different Hills")
T([["","Hill in Section 3 (feature)","Hill in Section 6 (curve)"],
   ["applied to","the input impressions (saturate before modeling)","the model output (predicted KPI vs spend)"],
   ["form","1 / (1 + (x/s)^&minus;k)","b + (T&minus;b) x^k / (s^k + x^k)"],
   ["params","frozen in config","fit fresh per channel via curve_fit"]],
  [0.16,0.42,0.42])
H2("6.2 &nbsp; The point cloud and the fit")
P("Each <b>point</b> is one week: x = spend, y = predicted KPI for that channel &mdash; i.e. &lsquo;this week "
  "SEM spent $1000 and the model attributes 22 submits&rsquo;. The curve is fit through the cloud with "
  "scipy.optimize.curve_fit minimizing squared error:")
EQ(r"R(x) = b + (T-b)\,\frac{x^{k}}{s^{k} + x^{k}};\qquad \min_{T,s,k}\ \sum_t \left(\mathrm{predicted}_t - R(\mathrm{spend}_t)\right)^2")
note("The curve uses <b>all</b> weeks from response_curves_start_week onward &mdash; <b>train and holdout "
     "both</b> &mdash; to get the widest spread of spend levels. Two more rules: <b>Email uses impressions</b> "
     "(not spend) as x, since email spend &asymp; 0; and channels with aggregate spend &lt; $100K are dropped "
     "(too little signal).", 'warn')
H2("6.3 &nbsp; Reading slope and saturation")
story.append(plot_img('p_curve.png', 0.72)); story.append(Paragraph("Diminishing returns: the first $1200 buys half the ceiling; later dollars buy far less.", st_cap))
T([["Param","Meaning","Budget reading"],
   ["bottom (b)","response at x=0 (usually 0)","zero spend, zero incremental"],
   ["top (T)","ceiling as x&rarr;&infin;","the most this channel can ever drive"],
   ["saturation (s)","the spend at half the ceiling","where diminishing returns bite hard"],
   ["slope (k)","steepness of the S-curve","how fast you saturate"],
   ["r_2","fit quality","trust gate on the curve"]],
  [0.16,0.40,0.44])
P("The slope shape is the part people misread:")
story.append(plot_img('p_hill.png', 0.74)); story.append(Paragraph("k<1 (e.g. TV slope 0.371): concave from the start, the first dollar is best, ROI only falls. "
   "k>1 (e.g. SEM slope 3.046): S-shaped, a warm-up then a sharp rise then a plateau.", st_cap))
P("So Linear TV (k=0.371, small saturation) is a smooth brand-awareness scaler; SEM (k=3.046) needs a base "
  "level then saturates fast &mdash; a capture channel with a ceiling.")
H2("6.4 &nbsp; Levels and outputs")
bullets(["Curves are fit per <b>DMA</b> (shift spend between markets) and <b>national</b> (set total channel "
         "budget); national = aggregate across DMAs per week (same channel, never across channels).",
         "Taxonomy curves (NB8) do the same one level deeper, per channel&times;network&times;campaign_super.",
         "Every KPI gets curves (Visits, FS, Rental Visits, MF, ZHL).",
         "A 150-point (spend &rarr; predicted) reporting grid is written for Tableau (overwrite, latest only)."])
story.append(PageBreak())

# =====================================================================
# 7 STABILITY + OPS
# =====================================================================
H1("7 &nbsp; Stability Loop &amp; Operations (NB9)")
P("After a new version is produced, NB9 asks: did this refit move any channel's ROI suspiciously vs last "
  "time? It pulls the latest two versions and compares each channel's ROI <b>band</b>:")
EQ(r"\mathrm{return} = \frac{\mathrm{predicted}}{\mathrm{impressions}};\quad "
   r"[\,\mathrm{return\_lower},\ \mathrm{return\_higher}\,] = \left[\frac{\mathrm{pred\_2.5\%hdi}}{\mathrm{imp}},\ \frac{\mathrm{pred\_97.5\%hdi}}{\mathrm{imp}}\right]")
H2("7.1 &nbsp; The rule (two tests, lenient OR)")
EQ(r"\mathrm{overlap\%} = \frac{\min(h_{curr},h_{prev}) - \max(l_{curr},l_{prev})}{h_{curr}-l_{curr}}\times100\ \ \Rightarrow\ \mathrm{Stable\ if}>50")
EQ(r"\mathrm{PE\%} = \frac{|\,\mathrm{return}_{curr}-\mathrm{return}_{prev}\,|}{\mathrm{return}_{prev}}\times100\ \ \Rightarrow\ \mathrm{Stable\ if} \leq 25")
P("Final: Stable if <b>either</b> test passes &rarr; flagged Unstable only if bands overlap &le; 50% "
  "<b>and</b> ROI moved &gt; 25%. Thresholds are widgets (50, 25).")
T([["channel","prev band","curr band","overlap%","PE%","verdict"],
   ["SEM","[.0035,.0045]","[.0038,.0048]","70%","5%","Stable"],
   ["TV","[.0035,.0045]","[.0070,.0090]","no overlap","100%","Unstable (investigate)"]],
  [0.12,0.22,0.22,0.16,0.10,0.18])
H2("7.2 &nbsp; Operations &amp; versioning (what happens each run)")
T([["Mechanism","What it does"],
   ["Auto-version","version = MAX(version)+1 per KPI &mdash; old versions retained as history"],
   ["Idempotent writes","every write uses replaceWhere business_kpi AND version &mdash; re-running a version "
    "overwrites only its own slice (safe recovery)"],
   ["Rolling window","train/holdout slides ~2 weeks forward each run; last run's holdout becomes this run's train"],
   ["Job metadata","every write logged to mmm_model_job_metadata_detail (job_id, run_id, version, table)"],
   ["Bi-weekly gate","weekly cron + ISO-week-parity check &rarr; effective bi-weekly cadence"],
   ["Stability + Slack","NB9 flags moved channels; prod run sends a Slack completion notice"]],
  [0.22,0.78])
note("So values <b>persist as versioned history</b>, the window rolls forward, and each run is sanity-checked "
     "against the previous &mdash; reporting tables (response-curve grids) are the only ones overwritten to "
     "&lsquo;latest&rsquo;.", 'key')
story.append(PageBreak())

# =====================================================================
# 8 APPENDICES
# =====================================================================
H1("8 &nbsp; Appendices")
H2("8.1 &nbsp; Glossary")
T([["Term","Meaning"],
   ["DMA","Designated Market Area &mdash; Nielsen US TV market (~210), keyed by dmacode"],
   ["Adstock","carryover transform &mdash; this week's impressions affect future weeks"],
   ["Hill / saturation","diminishing-returns curve on impressions (feature) or spend (response curve)"],
   ["NUTS","No-U-Turn Sampler &mdash; the MCMC algorithm used by numpyro"],
   ["HDI","Highest Density Interval &mdash; Bayesian credible interval (95% by default)"],
   ["Partial pooling","each DMA's coefficient is pulled toward a shared global &mdash; borrows strength"],
   ["Direct vs Funnel","a channel's own effect on a KPI vs the effect propagated via the parent KPI"],
   ["AOT","Always-On Testing &mdash; geo-experiments used to recalibrate MMM (Email/App)"],
   ["SoV","Share of Voice &mdash; a channel's impressions / total that week"],
   ["vN / p_data_date","model version / write date (used to find the latest run)"]],
  [0.20,0.80])
H2("8.2 &nbsp; Table inventory")
T([["Layer","Key tables","Holds"],
   ["Raw","mmm_marketing_metrics, mmm_business_metrics, mmm_calendar, mmm_holidays, mmm_regionmapping","source impressions/spend, KPIs + controls, calendar, holidays, DMA names"],
   ["Silver shared","mmm_input_preprocessing_overall_data(_rentals), _taxonomy_data, _spend_data, mmm_automation_exogenous_feature_store","pivoted inputs + smoothed macros"],
   ["Silver per-KPI","mmm_&lt;kpi&gt;_adstock_transformed_data, _final_data_for_modeling, _overall_model_melted_data, _taxonomy_model_input, _staging","features, melted contributions, taxonomy staging"],
   ["Gold","mmm_model_output_overall/taxonomy_level, _combined_output_*, mmm_response_curves_*, _stability","contributions (direct &amp; +funnel), curves, stability"]],
  [0.16,0.46,0.38])
H2("8.3 &nbsp; Where every number comes from")
T([["Number","Origin"],
   ["adstock decay/lag/delay, Hill slope/saturation","offline grid+LASSO / curve_fit &rarr; config (fixed)"],
   ["scaling mean","groupby(dma).mean() over train weeks (computed)"],
   ["prior Mean/Sd","artifacts/&lt;kpi&gt;_priors.csv (fixed; ads only)"],
   ["&beta;, &alpha;, &sigma; (+ HDI)","NUTS posterior (learned)"],
   ["AOT spi (sends per incremental)","AOT geo-experiment tables"],
   ["version","MAX(version)+1 per KPI at write time"]],
  [0.40,0.60])
H2("8.4 &nbsp; Full mock dataset (all 3 DMAs)")
P("803 &asymp; 60% of 501, 602 &asymp; 40% (rounded). Impressions/visits/submits scale together; controls are "
  "shared market-wide.")
T([["DMA","week","SEM imp","TV imp","Email imp","visits","fs_submits"],
   ["501","W2","1200","50000","0","14000","260"],
   ["803","W2","720","30000","0","8400","156"],
   ["602","W2","480","20000","0","5600","104"],
   ["501","W3","1100","50000","600","15000","280"],
   ["803","W3","660","30000","360","9000","168"],
   ["602","W3","440","20000","240","6000","112"]],
  [0.10,0.10,0.15,0.15,0.15,0.18,0.17])
sp(8)
P("<i>End of guide &mdash; you can now trace any number end to end and explain why each transformation "
  "exists.</i>", st_small)

# =====================================================================
# build
# =====================================================================
def footer(canvas, doc):
    canvas.saveState()
    canvas.setFont('Helvetica', 7.5); canvas.setFillColor(colors.HexColor('#8a94a6'))
    canvas.drawString(LM, 28, "Zillow MMM Pipeline — Complete Study Guide")
    canvas.drawRightString(A4[0]-RM, 28, "Page %d" % doc.page)
    canvas.setStrokeColor(colors.HexColor('#dde3ec')); canvas.line(LM, 38, A4[0]-RM, 38)
    canvas.restoreState()

doc = BaseDocTemplate(OUT, pagesize=A4, leftMargin=LM, rightMargin=RM, topMargin=TM, bottomMargin=BM,
                      title="Zillow MMM Pipeline - Complete Study Guide")
frame = Frame(LM, BM, CONTENT_W, A4[1]-TM-BM, id='main', leftPadding=0, rightPadding=0, topPadding=0, bottomPadding=0)
doc.addPageTemplates([PageTemplate(id='all', frames=[frame], onPage=footer)])
doc.build(story)
print("OK pages built ->", OUT)
