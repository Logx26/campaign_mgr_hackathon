---
doc_id: 01
title: MMM Methodology Primer — Theory, Math, and Why Each Choice Was Made
companion_docs:
  - 00_mmm_ecosystem_overview.md (system map, jobs, tables — read first)
  - 02_rapidmmm_library_tour.md (Python implementation of every formula here)
  - 05_fs_submits_feature_engineering_and_overall_model.md (these equations in production code)
  - 09_interview_prep_critique.md (rehearsal questions on this material)
---

# 01 — MMM Methodology Primer

> **What this doc is.** Pure theory, code-agnostic. Every concept used in the
> Zillow MMM production pipeline is derived from first principles here, with
> the specific parameter choices from `config_param.yml` and
> `mmm_*_priors.csv` used as concrete worked examples.
>
> Every subsequent doc links *back* here when a concept first appears. If you
> can read and follow this doc, you can read every notebook in `mmm_model/`.

> **How to read.** Read each section sequentially the first time. After that
> use it as a lookup. Each math block has an intuition paragraph *before* the
> formula so you can skim for ideas and dive in for derivations.

> **Notation conventions used throughout this doc:**
>
> - $t$ = week index (Monday-anchored)
> - $d$ = DMA index ($d \in \{1, \ldots, D\}$, $D \approx 210$ for US)
> - $c$ = channel-network index
> - $x_{c,d,t}$ = raw weekly impressions for channel $c$, DMA $d$, week $t$
> - $\tilde{x}_{c,d,t}$ = adstocked impressions (after carryover transform)
> - $\bar{x}_{c,d,t}$ = adstocked + saturated impressions (after Hill)
> - $z_{k,d,t}$ = $k$-th control variable (macroeconomic, holiday, seasonal)
> - $y_{d,t}$ = the KPI value (e.g., FS Submits) at DMA $d$, week $t$
> - $\hat{y}_{d,t}$ = the model's predicted value
> - $\alpha$, $\beta$, $\gamma$, $\sigma$ = parameters (more notation in Section 6)

---

## 1. What MMM is, and the business problem it solves

**Marketing Mix Modeling (MMM)** is a top-down, econometric attribution
methodology. It takes *aggregated* historical observations of marketing inputs
(impressions and spend, summed to a region-week granularity) plus the
business outcomes they're meant to drive (sales, leads, sign-ups), and fits
a statistical model that decomposes the outcome into:

1. A **baseline** that would have occurred with zero marketing,
2. The **direct contribution of each marketing channel** (after accounting
   for the time-delayed and diminishing-returns nature of media), and
3. Adjustments from **external controls** (macroeconomic conditions,
   seasonality, holidays).

The output is a per-channel "this is how much business outcome you got per
dollar / per impression" attribution and — crucially — a **response curve**
that tells the marketing team: *"if you spend an additional $1M on channel
C, here is the expected incremental KPI."*

### 1.1 Why MMM exists when there are alternatives

There are three families of attribution methods used in modern marketing:

| Method | Granularity | Strengths | Failures |
|---|---|---|---|
| **Multi-Touch Attribution (MTA)** | User-level event paths | Per-user precision; in-platform optimization | Requires cross-channel user identity (cookies, device IDs). iOS 14 ATT framework and third-party-cookie deprecation broke most MTA. **Cannot measure offline channels** (TV, OOH, Audio) because there's no user touch to attribute. |
| **Incrementality / geo-experiments / RCTs** | Geo × time, holdout-vs-treatment | Causally identified — gold standard. | Slow (weeks per channel), expensive (you must turn marketing off in some regions), one-channel-at-a-time, **cannot retrospectively attribute past spend.** |
| **MMM** | Region × time × channel | Works on aggregated data — no user IDs needed. Handles offline + online uniformly. Provides response curves for budget allocation. **Survived cookie deprecation untouched.** | Statistical estimation — not causally identified by default. Susceptible to multicollinearity, omitted-variable bias, and identification problems if marketing levels are constant. Slow to detect short-term changes. |

Zillow uses all three in a stack:

- **MMM** is the *primary budget allocator* — runs bi-weekly, covers all 25+
  channel-networks including offline (Linear TV, Connected TV, OOH, Audio,
  Radio).
- **Always-On Testing (AOT)** geo-experiments are used to **calibrate MMM** —
  when AOT measurements systematically disagree with MMM for a channel
  (notably Email Simon Data), the MMM output is recalibrated to the AOT
  truth (Section 11 of this doc).
- **Last-click / in-platform attribution** is used inside each ad platform
  (Google Ads, Facebook Ads Manager) for the operational decision of which
  *individual ads* to bid on, separately from the cross-channel allocation.

### 1.2 Why MMM survived the cookie-deprecation era

In 2020–2024, two changes collapsed the user-level attribution world:

1. **Apple's ATT framework (iOS 14)** required apps to ask for permission to
   track users across apps. The opt-in rate hovered around 25–30%, breaking
   identifier-based attribution for the iOS install funnel.
2. **Third-party cookie deprecation** in Chrome (rolled out gradually
   2022–2025) eliminated the cross-site identifier that powered most web-
   based MTA.

MMM works at the *aggregated impressions × spend × outcomes* level — it
never needed individual identifiers. The methodology that economists used in
the 1960s to measure TV advertising became, in 2024, the only attribution
method that fully covers the modern marketing mix.

> **Interview angle — "What's the business problem MMM solves at Zillow?"**
> Two sentences: *"Zillow spends across ~25 channel-networks including
> offline channels where user-level attribution doesn't exist. MMM measures
> what each channel actually drove and produces response curves that the
> marketing team uses to allocate the next quarter's budget — both within
> KPIs (which channel got more visits per dollar) and across KPIs (because
> Visits feed FS Submits via funnel effects)."*

---

## 2. The canonical MMM equation

Before any of the structure (hierarchy, Bayesian priors, etc.), the
fundamental MMM equation is a **regression** with engineered media features:

$$
y_t = \alpha + \sum_{c=1}^{C} \beta_c \cdot \text{Hill}\!\left(\text{Adstock}(x_{c,t})\right) + \sum_{k=1}^{K} \gamma_k \cdot z_{k,t} + \varepsilon_t
$$

Reading the equation term-by-term:

| Term | Meaning | What it represents in production |
|---|---|---|
| $y_t$ | The dependent variable at time $t$ | One of the five KPIs: Visits, FS Submits, ZHL Submits, Rental Visits, MF Submits |
| $\alpha$ | Intercept ("baseline") | The KPI level that would occur with zero marketing. In the hierarchical version, $\alpha_d$ varies by DMA. |
| $\beta_c$ | Channel coefficient | The "marginal effect" of one unit of saturated, adstocked impressions on $y$. Constrained $\beta_c \geq 0$ for media (Hill output is bounded, but coefficients on impressions are economically meaningful only if non-negative). |
| $\text{Adstock}(x_{c,t})$ | Carryover transform | Weights this week's impressions plus a decaying tail of prior weeks — captures the fact that media has memory (Section 3). |
| $\text{Hill}(\cdot)$ | Saturation transform | Squashes adstocked impressions through a non-linear curve so that doubling impressions does not double effect — diminishing returns (Section 4). |
| $\gamma_k$ | Control-variable coefficient | Effect of an exogenous variable (mortgage rate, Google Trends index, etc.) on $y$. **Not** constrained to be non-negative (e.g., higher mortgage rates can *reduce* FS Submits — coefficient should be free to be negative). |
| $z_{k,t}$ | $k$-th control variable | Macro indicators, holiday dummies, seasonal components. |
| $\varepsilon_t$ | Residual / noise term | Modeled as $\varepsilon_t \sim \mathcal{N}(0, \sigma^2)$. Becomes the likelihood in Section 6. |

The two non-linear transforms — adstock and Hill — are what make MMM
distinct from "throw a linear regression at marketing data". Both are pre-
computed *before* fitting, with parameters fixed from config
(`config_param.yml::adstock_hill_best_params`). This means the final model
is *linear in its parameters* $(\alpha, \beta, \gamma)$ but *non-linear in
its inputs* — exactly the structure of a generalized linear model on
engineered features.

The DMA-hierarchical extension and the Bayesian estimation framework come
in Section 6. Adstock and Hill are below.

> **Interview angle — "Walk me through the math of an MMM model."** Start
> here. Say: *"At its core MMM is a regression of the KPI on media features.
> What makes MMM distinct are two engineered transforms applied to each
> channel's impressions before fitting: adstock (carryover, capturing that
> media has memory) and Hill saturation (diminishing returns). On top of
> that, the Zillow implementation is hierarchical across DMAs (each DMA gets
> its own coefficient drawn from a population prior) and Bayesian (priors
> from the prior model version, fit via NUTS MCMC). Outputs feed
> downstream response curves that the marketing team uses to allocate
> budget."*

---

## 3. Adstock — modeling carryover

### 3.1 Why media has memory

A TV ad seen this week creates awareness that lasts. The viewer might visit
Zillow next week, or four weeks from now. A push notification clicked today
might produce a session in a few minutes. A Pinterest pin saved during a
home-search session might convert months later.

So the relationship between *this week's impressions* and *this week's
outcome* is incomplete — it ignores the future-period influence of those
impressions. We need a way to **redistribute** impressions over time so that
the impressions value used in the regression for week $t$ reflects not just
$x_t$ but also the residual influence of $x_{t-1}, x_{t-2}, \ldots$.

This is **adstock**: a convolution of the raw impressions time series with
a decaying kernel.

### 3.2 Geometric / Exponential adstock

The simplest formulation. Define a decay rate $\lambda \in [0, 1]$ and a
maximum lag $L$. The adstocked impressions at time $t$ are:

$$
\tilde{x}_t \;=\; \sum_{i=0}^{L} \lambda^{i} \cdot x_{t-i}
$$

This is a discrete convolution between the raw series $x$ and the kernel
$\mathbf{w} = (1, \lambda, \lambda^2, \ldots, \lambda^L)$.

**Intuition.** Each historical impression contributes a fraction
$\lambda^i$ of its value to the current week's adstocked total. If $\lambda
= 0.7$ and $L = 5$, then 5 weeks ago's impressions contribute $0.7^5
\approx 0.17$ — about 17% of their original weight. If $\lambda = 0$, no
carryover (only current week counts). If $\lambda = 1$, infinite memory
(every past week counts at full weight).

In the rapidmmm code, this is `ExponentialAdStock` (uses `convolve2d` with
the un-normalized kernel) and `GeometricAdStock` (normalized version that
divides by $\sum_i \lambda^i$ so the total weight equals 1).

The **normalized** version (geometric) preserves the average level of the
series:

$$
\tilde{x}_t \;=\; \frac{\sum_{i=0}^{L} \lambda^i \cdot x_{t-i}}{\sum_{i=0}^{L} \lambda^i}
$$

When $L$ is large and $\lambda < 1$, the denominator approaches
$1/(1-\lambda)$, the geometric series sum.

**ASCII view of the geometric kernel for $\lambda = 0.7$, $L = 5$:**

```
weight
 1.00 │ █
 0.70 │ █  █
 0.49 │ █  █  █
 0.34 │ █  █  █  █
 0.24 │ █  █  █  █  █
 0.17 │ █  █  █  █  █  █
      └──────────────────── lag (weeks)
        0  1  2  3  4  5
```

### 3.3 Delayed adstock (the variant used most in this codebase)

For some channels — notably TV and OOH — the *peak* effect doesn't occur
in the impression week. People see a Linear TV spot, and the awareness
*builds* in their memory over the next 1–3 weeks before it influences
behavior. This is captured by **delayed adstock**, which shifts the peak
weight to a non-zero lag $\delta$ and falls off quadratically in distance
from that peak:

$$
w_i \;=\; \lambda^{(i - \delta)^2}, \qquad i = 0, 1, \ldots, L
$$

$$
\tilde{x}_t \;=\; \frac{\sum_{i=0}^{L} w_i \cdot x_{t-i}}{\sum_{i=0}^{L} w_i}
$$

**Intuition.** The weight $w_i$ is maximized at $i = \delta$ (where
$\lambda^0 = 1$) and falls off according to the *squared* distance from
$\delta$. Squaring distance means the falloff is faster on both sides of
the peak compared to a normal exponential — it produces a bell-like shape
centered at $\delta$. The decay rate $\lambda$ controls how narrow that
bell is: $\lambda$ close to 0 means very narrow (effectively only the peak
lag matters); $\lambda$ close to 1 means very wide (many lags contribute).

This is what `DelayedAdStock` in `rapidmmm.FeatureEngineering` implements.
The class signature `DelayedAdStock(max_lag, decay_rate, delay)` maps
directly to $L$, $\lambda$, $\delta$.

**Worked example — MF Submits Linear TV** has parameters `max_lag=6,
decay_rate=0.5, delay=1`. The weights are:

| Lag $i$ | $(i - \delta)^2$ | $w_i = 0.5^{(i-1)^2}$ | Normalized weight |
|---|---|---|---|
| 0 | 1 | 0.500 | 0.244 |
| 1 | 0 | **1.000** ← peak | 0.488 |
| 2 | 1 | 0.500 | 0.244 |
| 3 | 4 | 0.063 | 0.030 |
| 4 | 9 | 0.002 | 0.001 |
| 5 | 16 | $\approx 0$ | $\approx 0$ |
| 6 | 25 | $\approx 0$ | $\approx 0$ |

So 73% of the adstocked weight sits at lag 1 and lag 2 — Linear TV's effect
peaks one week after the spot airs, with a meaningful residual two weeks
later.

**Worked example — MF Submits SEM Google Search** has `max_lag=1,
decay_rate=0.0, delay=0`. The weights are $w_0 = 0^0 = 1$, $w_1 = 0^1 = 0$.
So adstocked impressions $= x_t$ exactly — no carryover. This is correct
business logic: SEM is intent-driven; people search, see ads, and convert
within the same week. There's no awareness build-up.

### 3.4 Adstock variants supported by the codebase

| Variant | Class in `rapidmmm` | Formula | Used for |
|---|---|---|---|
| Exponential | `ExponentialAdStock` | $\tilde{x}_t = \sum_{i=0}^{L} \lambda^i \cdot x_{t-i}$ (un-normalized convolution) | Used in MF Submits for `SEM\|Google Performance Max` (`decay=0.89, length=26`) — newer SEM signal with long carryover |
| Delayed (quadratic) | `DelayedAdStock` | $w_i = \lambda^{(i-\delta)^2}$, normalized | The dominant variant in production. Linear TV, Connected TV, OOH, Owned Social all use this. |
| Geometric (normalized exponential) | `GeometricAdStock` | $w_i = \lambda^i$, normalized | Used in older Visits priors (e.g., Native Media Agency `geometric_max_lag_4_length_0.05`) |
| Weibull | `WeibullAdStock` | Weibull-PDF weighted lags | Robyn-style — defined in code but not actively used in production configs |
| Raw lags | `AddLags` | $w_i = 1$ at lag $i$, separate features per lag | Only for grid search; never in production |

### 3.5 The full production adstock map for MF Submits

This is taken directly from `mmm_mf_submits/config_param.yml`.

| Channel \| Network | AdStock type | Params (`max_lag`, `decay_rate`, `delay`) or (`length`, `decay`) | Business reasoning |
|---|---|---|---|
| `App \| Apple Search` | Delayed | (1, 0.0, 0) | App-search intent: convert same week |
| `App \| Facebook` | Delayed | (4, 0.05, 0) | Slight tail — app-install funnel takes a few days |
| `App \| Google UAC` | Delayed | (2, 0.05, 0) | Same as above |
| `Audio \| Media Agency` | Delayed | (1, 0.0, 0) | Effectively no carryover (very weak signal for MF) |
| `Audio \| Radio` | Delayed | (3, 0.05, 1) | Modest 1-week peak — radio builds awareness slightly |
| `Connected TV \| Media Agency` | Delayed | (6, 0.5, 4) | **Peak at lag 4** — CTV awareness builds over a month |
| `Display \| Media Agency` | Delayed | (1, 0.0, 0) | Same-week response — re-targeting context |
| `Display \| Video Demand Gen` | Delayed | (2, 0.05, 0) | Short tail |
| `Email \| Simon Data` | Delayed | (1, 0.0, 0) | Email clicks convert same week |
| `Email \| Sparkpost` | Delayed | (2, 0.05, 0) | Slight tail |
| `Linear TV \| Media Agency` | Delayed | (6, 0.5, 1) | Peak at lag 1 — TV creative effect 1 week after spot |
| `Media Solutions \| Facebook` | Delayed | (7, 0.8, 4) | **Long, late peak** — partner builder campaign with long awareness build |
| `Native \| Media Agency` | Delayed | (1, 0.0, 0) | Same-week |
| `Online Video \| Media Agency` | Delayed | (7, 0.8, 4) | YouTube-style awareness — long carryover, late peak |
| `OOH \| Media Agency` | Delayed | (6, 0.5, 4) | OOH (billboards) builds memory over a month |
| `Operational Emails \| Iterable_Simon Data` | Delayed | (4, 0.0, 3) | Strong delayed peak — operational emails (price alerts, etc.) prompt later sessions |
| `Owned Social \| Facebook` | Delayed | (4, 0.1, 3) | Organic social — 3-week delayed peak |
| `Owned Social \| TikTok` | Delayed | (1, 0.1, 0) | Same-week (TikTok is fast-converting) |
| `Paid Social \| Facebook` | Delayed | (2, 0.1, 1) | 1-week delay |
| `Paid Social \| Pinterest` | Delayed | (1, 0.1, 0) | Same-week |
| `Paid Social \| TikTok` | Delayed | (1, 0.1, 0) | Same-week |
| `Push \| null` | Delayed | (1, 0.0, 0) | Push notifications act instantly |
| `SEM \| Google Search` | Delayed | (1, 0.0, 0) | Intent-driven, same-week |
| `SEM \| Google Performance Max` | **Exponential** | `decay=0.89, length=26` | Newer PMax signal — long-tail decay over 6 months |
| `SEM \| Microsoft Search` | Delayed | (1, 0.0, 0) | Same as Google SEM |

The pattern is clear: **TV-like / broadcast / awareness-building channels
have long, delayed adstock (large $L$, mid $\lambda$, non-zero $\delta$);
intent / direct-response channels have zero or near-zero adstock.**

### 3.6 How adstock parameters are chosen

The codebase does *not* search adstock parameters during each bi-weekly
run. They are **fixed in config** and reviewed by the analytics team
quarterly. The hyperparameters were determined originally via:

1. **Grid search** (using `FeatureEngineeringAdStockGrid` + LASSO-based
   `FeatureSelectionGridSearch`) to find $(\lambda, L, \delta)$ that
   maximize fit on a validation period.
2. **Industry priors** (Linear TV is widely known to peak at lag 1–2 with
   $\lambda \approx 0.7$–$0.9$).
3. **Robyn-style** documentation cross-checked.

Once chosen, the parameters are stabilized — changing them between runs
would invalidate version-over-version comparisons (the stability loop in
Section 10 would flag every channel as "unstable" if adstock were re-fit each
run).

> **Interview angle — "How do you choose adstock parameters?"** *"In
> production we fix adstock parameters per channel-network and only refit
> them quarterly because the bi-weekly stability check requires comparable
> features across runs. The choice is informed by (1) grid search with a
> LASSO selector during initial development, (2) industry priors — TV
> typically peaks at lag 1–2 with high decay, intent-driven channels like
> SEM have zero carryover, and (3) the delayed-adstock kernel
> $\lambda^{(i-\delta)^2}$ which puts a bell-shaped weight centered at lag
> $\delta$ with width controlled by $\lambda$."*

---

## 4. Saturation — modeling diminishing returns

### 4.1 The intuition

The first $1M spent on Linear TV in a DMA reaches the high-value
prospects. The second $1M reaches less-targeted prospects who are less
likely to convert. The 10th $1M is showing ads to people who have already
seen the campaign 30 times. Effectiveness per dollar **decreases** as spend
grows.

A linear model — $y = \beta x$ — cannot capture this: it predicts that
doubling spend doubles output forever. We need a **concave** transform of
adstocked impressions before they enter the regression.

There are three standard choices: **Hill** (the production default in this
codebase), **Atan** (used for specific channels post-scaling), and
**Sigmoid** (defined in code, optional via config). All three map $[0,
\infty)$ to a bounded range. Hill is the most flexible.

### 4.2 The Hill function

The Hill function — originally from biochemistry (it models receptor-ligand
binding) — has the form used in `rapidmmm.FeatureEngineering.HillTransform`:

$$
\text{Hill}(x; s, K) \;=\; \frac{1}{1 + (x/K)^{-s}} \;=\; \frac{x^s}{K^s + x^s}
$$

where:

- $s > 0$ is the **slope** (sometimes called the Hill exponent or shape) —
  controls how *steeply* the curve transitions
- $K > 0$ is the **saturation** parameter (also called half-saturation
  point) — the value of $x$ at which $\text{Hill}(x) = 0.5$

**Properties:**

| $x$ | $\text{Hill}(x)$ |
|---|---|
| 0 | 0 |
| $K/2$ | $\dfrac{(1/2)^s}{1 + (1/2)^s}$ — depends on $s$ |
| $K$ | 0.5 (always) |
| $\infty$ | 1 |

**ASCII curves at three slopes (with $K = 1$ fixed):**

```
 slope = 0.5  (very gentle)        slope = 1  (logistic-like)        slope = 3  (sharp S-curve)
 1.0 ┤            ▄▄▄▄▄▄▄          1.0 ┤            ▄▄▄▄▄▄▄          1.0 ┤        ▄▄▄▄▄▄▄▄▄▄
 0.8 ┤        ▄▄▀▀                 0.8 ┤        ▄▄▀▀                 0.8 ┤       █
 0.6 ┤     ▄▀▀                     0.6 ┤      ▄▀                     0.6 ┤      █
 0.4 ┤   ▄▀                        0.4 ┤    ▄▀                       0.4 ┤      █
 0.2 ┤ ▄▀                          0.2 ┤  ▄▀                         0.2 ┤      █
 0.0 ┴─▀───────────────             0.0 ┴─▀───────────────             0.0 ┴──────█──────────
     0   K       4K                     0   K       4K                     0   K       4K
```

**Slope intuition:**

- **Small slope** ($s < 1$) — concave from the start. Saturation begins
  immediately, every additional impression has lower marginal value than
  the previous. This is what you'd choose for a channel that is *already
  fairly saturated* in current spend levels.
- **Slope $\approx 1$** — logistic-shaped. Smooth transition.
- **Large slope** ($s > 2$) — S-shaped (sigmoidal): the curve is nearly
  flat for low $x$, rises sharply around $x = K$, then flattens. This
  represents a *threshold* effect — you need a minimum amount of spend
  before the channel starts producing anything, but once you cross that
  threshold you get strong returns up to saturation.

**Saturation point $K$ intuition:** at $x = K$, you've achieved exactly
half the maximum effect. $K$ measures the *scale* at which saturation kicks
in for this channel. A high $K$ means saturation is far away (you'd need to
spend a lot before diminishing returns matter); a low $K$ means saturation
is near at hand (small spend levels already produce diminishing returns).

### 4.3 The production Hill parameters for MF Submits

From `config_param.yml::adstock_hill_best_params.<channel>.Saturation_best_params`:

| Channel \| Network | slope $s$ | saturation $K$ | Shape interpretation |
|---|---|---|---|
| `App \| Apple Search` | 1.561 | 0.388 | Mildly S-shaped, saturation kicks in well before $x=1$ |
| `Connected TV \| Media Agency` | 1.243 | 0.402 | Gentlest curve — slowest saturation |
| `Linear TV \| Media Agency` | 1.429 | 0.402 | Logistic-shape |
| `SEM \| Google Search` | 1.492 | 0.392 | Sharpest of SEM — quick S-curve |
| `Media Solutions \| Facebook` | 1.484 | 0.391 | Logistic-shape |
| `Paid Social \| TikTok` | 1.440 | 0.409 | Slower saturation than other social |
| `OOH \| Media Agency` | 1.437 | 0.437 | Highest $K$ — saturates latest |

The slopes are tightly clustered in $[1.24, 1.61]$ — all are mildly
S-shaped. The saturation points are all in $[0.38, 0.44]$ on the
mean-scaled features. (Note: features are scaled per-DMA by their mean
before Hill is applied — see Section 6.5 — so $K \approx 0.4$ means "saturation
kicks in around 40% of the DMA's average adstocked impression level.")

### 4.4 Atan and Sigmoid alternatives

The codebase also supports two simpler saturation curves applied to
*specific* channels in the post-scaling pipeline:

**Sigmoid:**

$$
\text{Sigmoid}(x) = \frac{1}{1 + e^{-x}}
$$

Output bounded in $(0, 1)$. Symmetric S-curve around $x = 0$. Used when the
input range is naturally compact (e.g., already-scaled values).

**Arctangent (Atan):**

$$
\text{Atan}(x) = \arctan(x)
$$

Output bounded in $(-\pi/2, \pi/2)$. Concave for $x > 0$. Used when you
want a gentler saturation than Hill for already-scaled features.

In MF Submits, atan is applied (via `config_param.yml::transform_cols_atan`)
to two channels after scaling:
- `impressions|Paid Social|TikTok` (delayed-adstocked)
- `impressions|SEM|Google Search` (delayed-adstocked, with decay 0.0)

The reason for atan on these specific channels: their scaled features have
heavy tails (a few weeks with very high impressions skew the distribution).
Atan compresses those tails into a bounded range before Hill is applied —
preventing the Hill curve from being dominated by a few outlier weeks.

### 4.5 Why saturation matters for budget allocation

The Hill curve is what produces the **response curve** that Marketing
consumes. The response curve answers: *"If I currently spend $S$ on this
channel, what's the marginal return from spending one more dollar?"*

Without saturation, marginal return is constant — every dollar buys the
same outcome — and the optimal allocation collapses to "put all budget on
the channel with the highest coefficient." With saturation, the optimum is
*balanced*: spend on each channel until its marginal return equals every
other channel's marginal return (the classical Lagrangian condition for
optimal budget allocation under a budget constraint).

We come back to this when computing response curves in Section 9.

> **Interview angle — "Why use Hill saturation instead of log or sqrt?"*
> *"Three reasons. (1) Hill has two free parameters ($s$, $K$) versus log/
> sqrt's zero free parameters — it can fit both S-shaped and concave
> patterns. (2) Hill is bounded above by 1, giving a well-defined 'maximum
> reachable' level for each channel that response-curve consumers need for
> budget planning. (3) The Hill function is invertible analytically, so
> turning a 'target outcome' into 'required spend' (for budget
> optimization) is a closed-form computation. Log and sqrt are unbounded
> above, so they extrapolate badly into spend levels never observed in
> training."*

---

## 5. Share of Voice (SoV) scaling

### 5.1 What SoV is

For some channels, raw impressions are a poor predictor of effect — what
matters is the *fraction* of total impressions in the market that belong
to your brand. This is the **Share of Voice (SoV)** concept from
advertising economics:

$$
\text{SoV}_{c,d,t} \;=\; \frac{x_{c,d,t}}{\text{TotalImpressions}_{d,t}}
$$

In this codebase the denominator is approximated as the sum of *all
adstocked impression columns* in the DMA-week — i.e., the brand's own
total adstocked footprint:

```text
adstock_merged_data_sov[sov_cols] =
  adstocked[sov_cols] / sum(adstocked[all_impression_cols])  per DMA-week
```

(See `mmm_mf_submits/1_mmm_mf_submits_feature_engineering.py` around
line 606.)

So strictly this is "share of Zillow's own brand voice" rather than "share
of total market voice" — but in practice for paid-only channels it
correlates closely with the latter.

### 5.2 Which channels use SoV in MF Submits

From `config_param.yml::sov_cols`:

1. `Native|Media Agency`
2. `Online Video|Media Agency`
3. `Display|Media Agency`
4. `Paid Social|Pinterest`

These are channels where:

- The total impressions volume varies massively week-over-week (e.g.,
  large campaign bursts followed by quiet periods), and
- The *effect* is better explained by the channel's share of attention than
  by absolute count.

**Worked example.** Suppose `Native|Media Agency` ran 10M impressions in
week 1 and 100M impressions in week 2, but in both weeks the brand's total
adstocked impressions were similar to the channel's contribution. Raw
impressions would tell the model "10× more impact in week 2." SoV would
tell the model "actually, you had a much larger share of total attention
both weeks" — capturing the *competitive* attention dimension rather than
absolute volume.

The other channels (SEM, App, TV, etc.) use raw adstocked impressions
because absolute volume *does* predict their effect linearly within the
plausible range.

> **Interview angle — "When would you use SoV instead of raw impressions?"**
> *"When the channel's effect is competitive — i.e., what matters is your
> share of the audience's attention, not the absolute volume of
> impressions. Common cases are display/native/programmatic channels where
> creative quality and crowding effects dominate, and channels with very
> bursty spend patterns where absolute impressions don't smoothly scale
> with effect. The trade-off is that SoV is bounded in [0, 1], so it
> implicitly assumes you've already saturated the absolute-volume
> dimension."*

---

## 6. Hierarchical Bayesian regression — the core estimator

This is the longest section. The Zillow MMM is fit with a *hierarchical
Bayesian regression* implemented in NumPyro using NUTS MCMC. We build up
from the non-Bayesian baseline, motivate why Bayesian is necessary, then
write out the full hierarchy.

### 6.1 The non-Bayesian baseline and why it fails

Suppose we have $N = D \times T$ observations (DMA × week). The naive
non-Bayesian MMM is **ridge regression**:

$$
\hat{\boldsymbol{\beta}} \;=\; \arg\min_{\boldsymbol{\beta}} \;\; \sum_{n=1}^{N} (y_n - \mathbf{x}_n^\top \boldsymbol{\beta})^2 + \lambda \|\boldsymbol{\beta}\|_2^2
$$

with a non-negativity constraint $\beta_c \geq 0$ for media channels.

This fails for MMM for four reasons:

| Failure mode | Description | Why it bites MMM specifically |
|---|---|---|
| **Multicollinearity** | When channels are spent together (e.g., Facebook + Instagram + TikTok all run a coordinated campaign), their adstocked features are highly correlated and individual coefficients become unstable | Marketing campaigns are coordinated by design — multicollinearity is intrinsic to the data, not a sampling fluke |
| **Identification under low variation** | If channel $c$ ran at roughly the same level every week, its coefficient is not identified — you can't tell from data how much it contributes | Always-on channels (SEM brand, push notifications) suffer this in real production data |
| **No DMA-level coefficients** | A single pooled $\boldsymbol{\beta}$ assumes all DMAs respond identically to each channel | This is empirically false. NYC's response to Linear TV differs from rural-area DMAs by 10× or more |
| **No uncertainty quantification** | Point-estimate $\hat{\boldsymbol{\beta}}$ doesn't tell you "how much we trust this number" | The downstream stability check and response curve confidence bands require posterior uncertainty |

The Bayesian hierarchical model fixes all four.

### 6.2 The Bayesian formulation

Bayesian inference treats the parameters as random variables with a prior
distribution. After observing data, we update to the posterior via Bayes'
rule:

$$
\underbrace{p(\boldsymbol{\theta} \mid \mathbf{y})}_{\text{posterior}} \;\propto\;
\underbrace{p(\mathbf{y} \mid \boldsymbol{\theta})}_{\text{likelihood}} \;\cdot\;
\underbrace{p(\boldsymbol{\theta})}_{\text{prior}}
$$

For the MMM regression:

- **Likelihood** ($p(\mathbf{y} | \boldsymbol{\theta})$): assumes
  $y_{d,t} \sim \mathcal{N}(\hat{y}_{d,t}, \sigma^2)$ where $\hat{y}_{d,t}$
  is the linear combination of features.
- **Prior** ($p(\boldsymbol{\theta})$): captures business knowledge about
  plausible coefficient values, hierarchical structure across DMAs, and
  the non-negativity of media coefficients.
- **Posterior** ($p(\boldsymbol{\theta} | \mathbf{y})$): the *joint*
  distribution of all parameters given the observed KPI data, used to
  compute uncertainty intervals (HDI) and the predictive distribution.

### 6.3 The hierarchical structure (partial pooling)

The fundamental Zillow MMM uses **partial pooling** across DMAs. Each DMA
gets its own coefficient, but those coefficients are drawn from a shared
population distribution. This is the "hierarchical" in hierarchical
Bayesian regression.

For each media channel $c$ and DMA $d$:

$$
\beta_{c,d} \;\sim\; \mathcal{N}_{>0}\!\left(\mu_{\beta_c}, \sigma_{\beta_c}\right)
$$

(truncated at 0 to enforce non-negativity — see Section 6.4). The hyperparameters
$\mu_{\beta_c}$ and $\sigma_{\beta_c}$ are themselves random variables
drawn from hyperpriors:

$$
\mu_{\beta_c} \;\sim\; \mathcal{N}_{>0}(\text{prior\_mu}_c, \text{prior\_sd}_c) \quad \text{(media)}
$$

$$
\sigma_{\beta_c} \;\sim\; \text{HalfNormal}(\text{prior\_sigma\_sd}_c)
$$

For DMA-level intercepts:

$$
\alpha_d \;\sim\; \mathcal{N}_{>0}(\mu_\alpha, \sigma_\alpha)
$$

$$
\mu_\alpha \;\sim\; \mathcal{N}_{>0}(0, 1), \qquad \sigma_\alpha \;\sim\; \text{HalfNormal}(5)
$$

For non-media controls $k$ (mortgage rate, googletrends, holidays, etc.),
the constraint $> 0$ is removed because economic effects can be negative:

$$
\gamma_{k,d} \;\sim\; \mathcal{N}(\mu_{\gamma_k}, \sigma_{\gamma_k}) \quad \text{(no truncation)}
$$

$$
\mu_{\gamma_k} \;\sim\; \mathcal{N}(0, 1), \qquad \sigma_{\gamma_k} \;\sim\; \text{HalfNormal}(\cdot)
$$

**Three regimes of pooling, and where the codebase sits:**

| Regime | Specification | Behavior | Problem |
|---|---|---|---|
| **No pooling** | $\beta_{c,d}$ independent for each $d$ | Each DMA has its own coefficient, no sharing | Overfits — small DMAs with weak signal get noisy estimates |
| **Complete pooling** | $\beta_c$ identical across all $d$ | Single national coefficient | Ignores DMA heterogeneity — NYC and rural-PA assumed identical |
| **Partial pooling** ← *what this codebase uses* | $\beta_{c,d} \sim \mathcal{N}(\mu_{\beta_c}, \sigma_{\beta_c})$ | DMA coefficients shrink toward the population mean $\mu_{\beta_c}$ in proportion to how much DMA-specific data supports them | DMAs with strong signal stay close to data; DMAs with weak signal are pulled toward $\mu_{\beta_c}$ |

The partial-pooling magic — the per-DMA coefficient is pulled toward
$\mu_{\beta_c}$ when DMA data is weak, but stays close to its own data when
DMA data is strong — is the central reason hierarchical models work for
heterogeneous, unbalanced data like MMM. It avoids the overfit-vs-underfit
trap entirely.

### 6.4 Non-negativity for media coefficients

Media coefficients $\beta_{c,d}$ are constrained to be non-negative.
Economically, a channel can't *reduce* a positive KPI — at worst, it
contributes zero.

In NumPyro this is implemented with a **truncated normal** prior:

$$
\beta_{c,d} \;\sim\; \mathcal{N}\!\left(\mu_{\beta_c}, \sigma_{\beta_c}\right) \quad \text{truncated at} \quad \beta_{c,d} \geq 0
$$

written as `dist.TruncatedNormal(mu, sd, low=0.0)`. The truncation rescales
the density so the integral over $[0, \infty)$ equals 1.

Non-media coefficients (mortgage rate, Google Trends, etc.) are not
truncated — they're free to be negative, which is correct (higher mortgage
rates should *reduce* FS Submits).

### 6.5 Mean-scaling before fitting (elasticity interpretation)

Before the model is fit, the codebase applies **regional mean scaling**
via `MeanScalingRegional` from `rapidmmm.FeatureEngineering.FeatureScaling`:

$$
\bar{x}_{c,d,t}^{\text{scaled}} \;=\; \frac{\bar{x}_{c,d,t}}{\frac{1}{T}\sum_t \bar{x}_{c,d,t}}
$$

i.e., divide each variable by its mean over the training period within
each DMA. The same scaling is applied to $y_{d,t}$.

This has two consequences:

1. **Coefficients become elasticity-like.** $\beta_c$ now answers: "a 1%
   change in adstocked-Hill-impressions on channel $c$ produces a
   $\beta_c$% change in KPI." This is a *unitless* effect — easy to compare
   across channels of vastly different absolute scale.
2. **Numerical stability.** Adstocked impressions can range over 6+ orders
   of magnitude across channels (Push notifications: millions per week;
   Linear TV: ~10K GRPs per week). Without scaling, NUTS struggles to
   navigate the posterior.

The MeanScaling is fit on training data and re-applied to holdout — so the
holdout's scaling uses train means, not its own (preventing leakage).

### 6.6 Priors in this codebase — informative, from prior version

The Bayesian framework requires *priors* $p(\boldsymbol{\theta})$ before
seeing data. Two extremes exist:

- **Uninformative / weak priors** — e.g., $\beta \sim \mathcal{N}(0, 100)$
  — let the data dominate. Used when you have lots of data and no prior
  knowledge.
- **Informative priors** — tight distributions around values you believe
  before seeing data. Used when data is scarce, multicollinearity is
  severe, or you have strong domain knowledge.

This codebase uses **informative priors derived from the previous model
version's posterior**. The CSV file `mmm_*_priors.csv` is the prior table.
A few rows from `mmm_fs_submits_priors.csv`:

| column (with adstock suffix) | Mean | Sd | Interpretation |
|---|---|---|---|
| `impressions|SEM|Google Search_delayed_lag_1_decay_0.05_delay_1` | 0.159 | 0.0001 | **Very tight** — production has high confidence SEM elasticity is ~16%; barely allow movement |
| `impressions|Paid Social|Facebook_delayed_lag_1_decay_0.05_delay_1` | 5.0 | 0.020 | Tight prior pinning Paid Social Facebook elasticity around 5.0 |
| `impressions|Owned Social|Facebook_exponential_decay_0.6_length_3` | 0.0065 | 0.0013 | Tight prior — small expected effect |
| `impressions|Email|Iterable_exponential_decay_0.3_length_2` | 0.0 | 1.0 | **Uninformative** — Mean=0, Sd=1 says "we don't know much about this, let data decide" |
| `impressions|Native|Media Agency_exponential_decay_0.7_length_6` | 0.054 | 0.026 | Mildly informative — central estimate from prior version, allow some movement |
| `impressions|Online Video|YouTube_exponential_decay_0.7_length_7` | 0.2 | 0.0001 | Very tight at 0.2 — extremely informative |

This is the Bayesian principle of "yesterday's posterior is today's
prior" applied to a recurring model. Each bi-weekly run incorporates the
prior run's evidence; the system *accumulates* information over time.

The Sd column controls how much the new data can move the estimate. A tiny
Sd (e.g., 0.0001) effectively pins the coefficient at the prior mean —
useful when you've previously validated the channel against AOT and want
to lock it in. A wide Sd (1.0) is essentially uninformative — lets each
run's data redetermine the coefficient.

> **Interview angle — "Why Bayesian vs frequentist for MMM?"** *"Five
> reasons. (1) Built-in regularization via priors handles MMM's
> multicollinearity better than ridge's L2 penalty (priors can be
> per-channel, ridge applies a single penalty to everything). (2) Native
> uncertainty quantification — the posterior gives an HDI for each
> coefficient, which downstream consumers use for response-curve confidence
> bands and the stability check. (3) The hierarchical / partial-pooling
> structure is much cleaner Bayesian than fitting mixed-effects models in
> a frequentist framework — both work but Bayesian is more natural. (4)
> Informative priors let you incorporate AOT-derived knowledge — for
> instance, pinning Email's elasticity at the AOT-measured rate. (5) The
> 'yesterday's posterior is today's prior' update means the model
> accumulates evidence over time rather than retraining from scratch every
> two weeks."*

### 6.7 The full hierarchy in one diagram

```
                       (hyperpriors — fixed)
                                │
                                ▼
              ┌──────────────────────────────────────────────────┐
              │ μ_α ~ TN⁺(0,1)          σ_α ~ HalfNormal(5)      │
              │ μ_β_c ~ TN⁺(prior_mu, prior_sd)  for media       │
              │ μ_γ_k ~ N(prior_mu, prior_sd)    for controls    │
              │ σ_β_c ~ HalfNormal(prior_sigma_sd)               │
              └──────────────────────────────────────────────────┘
                                │
                                ▼
         ┌────────────────────────────────────────────────────────┐
         │ (DMA-level random effects — partially pooled)          │
         │   α_d ~ TN⁺(μ_α, σ_α)                                  │
         │   β_{c,d} ~ TN⁺(μ_β_c, σ_β_c)  for media               │
         │   γ_{k,d} ~ N(μ_γ_k, σ_γ_k)    for controls            │
         └────────────────────────────────────────────────────────┘
                                │
                                ▼
              ┌─────────────────────────────────────────────────┐
              │ (data-level mean — linear combination)          │
              │ ŷ_{d,t} = α_d                                   │
              │         + Σ_c β_{c,d} · Hill(Adstock(x_{c,d,t})) │
              │         + Σ_k γ_{k,d} · z_{k,d,t}               │
              └─────────────────────────────────────────────────┘
                                │
                                ▼
              ┌─────────────────────────────────────────────────┐
              │ (likelihood)                                    │
              │ y_{d,t} ~ N(ŷ_{d,t}, σ)                        │
              │ σ ~ HalfNormal(5)                              │
              └─────────────────────────────────────────────────┘
```

This is exactly what `rapidmmm.Model.BayesianModel.Model._base_model_fn`
implements. The non-negativity is via TruncatedNormal (notation $\mathrm{TN}^+$); the
HalfNormal for standard-deviation parameters keeps them strictly positive;
the partial pooling is the inner $\beta_{c,d} \sim \mathcal{N}(\mu_{\beta_c}, \sigma_{\beta_c})$
structure.

> **Interview angle — "How do you handle multicollinearity between
> channels?"** *"Four mechanisms work together. (1) Informative priors —
> when two channels are spent together, the prior keeps both coefficients
> close to their previously-validated values rather than letting the data
> over-attribute to whichever happens to have slightly higher correlation
> with the KPI. (2) Mean scaling reduces the condition number of the
> design matrix. (3) The taxonomy split — instead of one regression with
> 100+ taxonomy features, we fit the overall regression on ~25 channel-
> network combinations and then break down each channel's overall
> attribution into taxonomy-level pieces via separate models, which avoids
> the multicollinearity dominating any single regression. (4) Hierarchical
> partial pooling acts as additional regularization — extreme estimates
> from one DMA are shrunk toward the population mean, dampening the impact
> of multicollinearity-induced noise."*

> **Interview angle — "Why hierarchical?"** *"Three reasons. (1) Pooling
> across DMAs gives 22,000 observations per year instead of 104, which is
> what makes identifying 20+ channel coefficients feasible. (2) DMA-level
> coefficients capture real heterogeneity — urban vs rural, English vs
> Spanish-speaking, coastal vs inland have measurably different media
> elasticities. (3) Partial pooling regularizes — DMAs with weak signal
> are pulled toward the national mean, preventing overfit to noisy
> per-DMA data. The alternative — fit one model per DMA — overfits the
> small DMAs badly. The alternative — fit one national model — ignores
> heterogeneity and underestimates uncertainty."*

> **Interview angle — "How do you avoid overfitting in MMM?"** *"Five
> defenses. (1) Informative priors — pull coefficients toward known
> plausible values. (2) Non-negativity constraints on media — eliminates
> half the parameter space that's economically meaningless. (3)
> Hierarchical partial pooling — shrinks DMA-specific noise toward the
> population mean. (4) Holdout validation — last 4 weeks held out, model
> stats computed on both train and holdout, high-variance DMAs (>20%
> error) flagged. (5) Stability check — every run is compared to the
> previous version; channels whose ROI jumps unexpectedly are flagged for
> review. The point of overfitting in MMM isn't training-set error — it's
> 'this run says channel X is amazing and last run said it was terrible.'"*

---

## 7. MCMC, NUTS, and posterior diagnostics

### 7.1 Why MCMC is necessary

Given the hierarchical structure above with ~20 channels, ~210 DMAs, plus
hyperparameters, the parameter vector $\boldsymbol{\theta}$ has dimension
in the thousands. The posterior

$$
p(\boldsymbol{\theta} \mid \mathbf{y}) \;=\; \frac{p(\mathbf{y} \mid \boldsymbol{\theta}) \, p(\boldsymbol{\theta})}{p(\mathbf{y})} \quad \text{where} \quad p(\mathbf{y}) = \int p(\mathbf{y} \mid \boldsymbol{\theta}) \, p(\boldsymbol{\theta}) \, d\boldsymbol{\theta}
$$

has a normalizing constant $p(\mathbf{y})$ that is a high-dimensional
integral — **intractable** to compute analytically.

**MCMC (Markov Chain Monte Carlo)** sidesteps this. Instead of computing
the posterior density, MCMC produces a *sequence of samples*
$\{\boldsymbol{\theta}^{(1)}, \boldsymbol{\theta}^{(2)}, \ldots\}$ that
asymptotically distribute according to the posterior. Posterior summaries
(means, HDIs) are then computed from these samples.

### 7.2 The MCMC algorithm lineage

**Metropolis–Hastings (1953/1970).** Propose a new $\boldsymbol{\theta}'$
from some symmetric distribution; accept with probability

$$
\min\!\left(1, \frac{p(\boldsymbol{\theta}' \mid \mathbf{y})}{p(\boldsymbol{\theta} \mid \mathbf{y})}\right)
$$

Works in theory but very inefficient in high dimensions — random-walk
proposals are vanishingly unlikely to land in good regions.

**Hamiltonian Monte Carlo (HMC, 1987 / popularized 2010s).** Treats
parameters as positions and introduces auxiliary momentum variables.
Proposes new states by *simulating Hamiltonian dynamics* (using the
gradient of the log-posterior) for a fixed number of leapfrog steps. This
makes proposals follow "physical trajectories" through the posterior
landscape, achieving much better acceptance rates and mixing in high
dimensions. The catch: you must tune the step size and the number of
leapfrog steps per proposal.

**No-U-Turn Sampler (NUTS, 2014).** Eliminates the need to tune the
trajectory length. NUTS builds a binary tree of leapfrog steps in both
directions and stops when the trajectory makes a "U-turn" — when continuing
would start sampling positions closer to where you started than where you
just were. Step size is auto-tuned via dual averaging during warmup. The
result: HMC's efficiency with no manual tuning.

**This codebase uses NUTS** via `numpyro.infer.NUTS` wrapping
`numpyro.infer.MCMC`. The standard configuration is `num_warmup=1000,
num_samples=2000, num_chains=1`. (The codebase has multi-chain support
gated off due to instability — see `BayesianModel.py:271`.)

### 7.3 Posterior diagnostics: what the codebase actually enforces

After NUTS finishes, several diagnostics indicate whether the chain
"behaved well." The Zillow MMM enforces two specific gates in
`run_model_with_accept_prob_and_divergence_check` (see notebook 2 of every
KPI):

**Acceptance probability** — the average over all samples of the
Metropolis–Hastings acceptance ratio. NUTS aims for ~0.8 by default; the
codebase requires:

$$
0.6 \;\leq\; \mathbb{E}[\text{accept\_prob}] \;\leq\; 1.0
$$

Too low → step size too large; chain jumps around aggressively but rejects
most proposals → poor mixing. Too high → step size too small; chain
accepts everything but barely moves → also poor mixing.

**Divergences** — when the leapfrog integrator's numerical error exceeds a
threshold, the trajectory "diverges" (numerical blow-up). This typically
happens in regions of high posterior curvature — e.g., the boundary of the
non-negativity constraint, or when a hyperparameter $\sigma_{\beta_c}$
goes near zero (the "funnel" geometry). The codebase requires:

$$
\#\{\text{divergences}\} \;\leq\; 0.15 \times \#\{\text{samples}\} \;=\; 300 \text{ out of } 2000
$$

If either gate fails, the model is **automatically refit up to 3 times**
(`max_retries=3`). If all 3 fail, the job raises `RuntimeError` with
specific failure reasons. This is the production reliability mechanism for
catching pathological posterior geometry.

Two other diagnostics that are computed but not actively gated:

**R-hat** ($\hat{R}$) — when multiple chains are run, the ratio of
inter-chain variance to intra-chain variance. $\hat{R} \approx 1.0$ means
chains agree (converged); $\hat{R} > 1.1$ means chains haven't mixed yet
(non-converged). The codebase runs 1 chain by default, so $\hat{R}$ isn't
meaningful — but if multi-chain were re-enabled, it would be the primary
convergence check.

**Effective sample size (ESS)** — the number of independent samples
equivalent to the (autocorrelated) MCMC sample. ESS / num_samples gives
the "efficiency" of the sampler — typical values are 0.5–1.0 for NUTS.
Low ESS means the sampler is correlated, so credible intervals from the
samples are wider than they could be.

### 7.4 HDI vs credible interval vs confidence interval

Three intervals that are easily confused:

| Interval | Framework | Interpretation |
|---|---|---|
| **Confidence interval** (frequentist) | "If we repeated this experiment many times, 95% of the constructed CIs would contain the true parameter." | Does **not** give a probability statement about the parameter itself in any single experiment. |
| **Credible interval** (Bayesian, generic) | "Given the observed data and prior, there's a 95% probability the parameter lies in this interval." | Direct probability statement about the parameter — the interpretation laypeople incorrectly assume CIs have. |
| **HDI (Highest Density Interval)** | "The *narrowest* credible interval containing 95% of the posterior mass." | For symmetric posteriors, HDI equals the quantile-based credible interval. For asymmetric posteriors, HDI gives the tighter, more informative range. |

The codebase reports **95% HDI** for every coefficient (`hdi_prob=0.95` in
`az.summary`) and stores `coef_hdi_2point5_pct` and `coef_hdi_97point5_pct`
columns in every output table. These are the 2.5th and 97.5th percentile
of the HDI for each coefficient — used downstream by the stability check
(Section 10) to compare ranges across model versions.

> **Interview angle — "Why NUTS specifically?"** *"NUTS gives you HMC's
> sample efficiency in high dimensions without the manual tuning HMC
> requires. For a ~3000-parameter MMM with ~22000 observations, NUTS
> typically achieves effective sample sizes around 0.5–1.0 per draw
> (compared to Metropolis-Hastings which can be 0.001 or worse in high-D).
> NumPyro's NUTS runs on JAX, which JIT-compiles the entire posterior and
> runs on GPU — a full posterior with 2000 samples and 1000 warmup steps
> typically takes 10–30 minutes on a g6e.xlarge instance instead of hours
> on CPU. The auto-divergence-retry wrapper handles the rare cases where
> the posterior geometry is pathological."*

---

## 8. Funnel attribution

### 8.1 The two-node funnel

Some Zillow KPIs are *causally upstream* of others. Visits drive FS
Submits. Rental Visits drive MF Submits. Naively, you'd run an MMM for FS
Submits with media impressions on the right side and FS Submits on the
left. But that throws away an obvious fact: **most of the FS Submits in a
DMA-week were driven by Visits in that DMA-week**, and channels that
drove those Visits should get partial credit for the downstream FS
Submits even if they don't appear with high direct coefficients in the FS
Submits model.

The Zillow MMM handles this with **funnel-effect attribution** — a
post-hoc decomposition that's applied after both the parent KPI model
(node 1) and the child KPI model (node 2) have been fit.

### 8.2 The data setup

After fitting both models, you have two `melted` tables:

- **Node-1 data** (`overall_model_melted_data` for parent KPI): per DMA,
  per week, per channel: `predicted` (channel's contribution to parent KPI)
- **Node-2 data** (`overall_model_melted_data` for child KPI): same
  structure for child KPI. Critically, this includes a row for the
  parent KPI variable itself (`value|visits|visits` for FS Submits;
  `value|rentalsmetrics_zillowbrand|rental_visits` for MF Submits) — the
  child model uses the parent KPI as a control variable, so it has a
  coefficient on the parent.

### 8.3 The attribution math

For each $(d, t)$ — DMA, week:

**Step 1.** Compute the share of the child KPI's prediction that's
attributed to the parent variable in the child model:

$$
\pi_{d,t}^{(2)} \;=\; \frac{\hat{y}^{(\text{node 2})}_{d,t,\,\text{parent\_var}}}{\sum_{v} \hat{y}^{(\text{node 2})}_{d,t,v}}
$$

(In code: `prop_2['percent_2'] = prop_2['predicted'] / prop_2['predicted_agg']`,
then filter to the parent-variable row.)

**Step 2.** Compute the share of the parent KPI's prediction attributable
to each channel $c$ in the parent model:

$$
\pi_{d,t,c}^{(1)} \;=\; \frac{\hat{y}^{(\text{node 1})}_{d,t,c}}{\sum_{c'} \hat{y}^{(\text{node 1})}_{d,t,c'}}
$$

(In code: `prop_1['percent_1'] = prop_1['predicted'] / prop_1['predicted_agg']`.)

**Step 3.** Compute the funnel-effect contribution of channel $c$ to the
child KPI in $(d, t)$:

$$
\text{FunnelEffect}_{d,t,c} \;=\; \hat{y}^{(\text{node 1})}_{d,t,c} \,\cdot\, \pi_{d,t}^{(2)}
$$

That is: take the channel's contribution to the parent KPI, scale it by
the share of the child KPI that the parent variable explains.

(In code: `prop_1['predicted_adj'] = prop_1['predicted_nd1'] * prop_1['percent_1']`,
where `predicted_nd1` is the per-channel parent prediction. This is
algebraically equivalent.)

**Step 4.** Add a row tagged `Type = 'Funnel Effect'` per channel,
distinct from the channel's `Type = 'Direct Effect'` row that came from the
child KPI model directly.

The total attribution for channel $c$ in the child KPI is then:

$$
\text{Total}_{c} \;=\; \underbrace{\sum_{d,t} \hat{y}^{(\text{node 2}, \text{direct})}_{d,t,c}}_{\text{direct effect}} \;+\; \underbrace{\sum_{d,t} \text{FunnelEffect}_{d,t,c}}_{\text{indirect / funnel effect}}
$$

### 8.4 Why two coefficient types

Some channels have a direct effect on FS Submits because they're shown to
users with intent (SEM, retargeting display). Some channels have a funnel
effect because they drive Visits which later become Submits (Linear TV,
Connected TV). Most channels have both. The decomposition lets the
marketing team see which mechanism is operating per channel.

### 8.5 Validation checks

`validate_funnel_effects` in notebook 2 enforces four invariants:

| Check | Test | Why it must hold |
|---|---|---|
| 1 | Both `Direct Effect` and `Funnel Effect` types appear in the output, and their row counts sum to total rows | Guarantees the type tagging is exhaustive — no row was dropped |
| 2 | Total spend in (child melted + parent melted) = total spend in funnel output | Spend should not be double-counted nor lost in the funnel attribution |
| 3 | For channels in the funnel-applied list, total attribution after funnel ≥ total attribution before funnel | Funnel attribution can only *increase* a channel's total credit (it can't subtract from direct effect) |
| 4 | Sum of all `Funnel Effect` rows ≤ total parent-KPI prediction | The funnel pool of effect must not exceed the parent KPI's total predicted volume — you can't funnel more than what the parent produced |

Check 4 is the tightest. If it failed, it would mean the attribution had
created child-KPI volume out of nowhere — a clear bug.

> **Interview angle — "How do you attribute across a marketing funnel?"**
> *"For Zillow's two-node funnel (Visits → FS Submits, Rental Visits → MF
> Submits), we fit the parent and child KPIs as separate hierarchical
> Bayesian models, then apply post-hoc proportional attribution. The
> formula: the funnel-effect credit for channel $c$ in the child KPI is
> the channel's predicted contribution to the parent KPI, scaled by the
> share of the child KPI that the child model attributes to the parent
> variable. Direct effect (from the child model coefficient) and funnel
> effect are stored separately so the marketing team can see whether a
> channel works via intent (direct) or awareness (funnel). Four validation
> invariants — spend balance, type exhaustiveness, monotonicity of
> attribution, parent-KPI cap — guard against attribution bugs."*

---

## 9. Response curves — turning the model into budget decisions

### 9.1 What a response curve is

A **response curve** for channel $c$ is a function

$$
R_c(s) \;=\; \text{expected KPI contribution from spend } s
$$

It's what the marketing team actually uses for budget allocation. The
model coefficients $\beta_{c,d}$ aren't directly actionable for budget
planning because they're elasticities on adstocked-and-Hill-saturated
features, not on spend. The response curve translates back into "if you
spend $X, you get $Y" — the language Marketing speaks.

### 9.2 How the codebase fits response curves

In `rapidmmm.Model.ResponseCurves.ResponseCurveFit`, for each channel $c$:

1. Aggregate the model's per-DMA-week `predicted` contributions and `spend`
   to either national (`Modellevel='Overall'`) or per-DMA (`Modellevel='DMA'`)
   level.
2. Sort by spend.
3. Fit a Hill-shaped curve

$$
R(s) \;=\; \text{bottom} + (\text{top} - \text{bottom}) \cdot \frac{s^{\text{slope}}}{\text{saturation}^{\text{slope}} + s^{\text{slope}}}
$$

via `scipy.optimize.curve_fit`. The codebase fixes `bottom=0` (no baseline
spend in the response curve — at zero spend, zero contribution).

The result is per-channel parameters $(\text{top}, \text{slope},
\text{saturation}, R^2)$ stored in `mmm_response_curves_overall_level`.

### 9.3 Marginal return on ad spend (mROAS)

The actionable quantity from the response curve is the **marginal ROAS**
— the derivative of the curve evaluated at the current spend level:

$$
\text{mROAS}_c(s) \;=\; \frac{dR_c(s)}{ds} \;=\; (\text{top} - \text{bottom}) \cdot \frac{\text{slope} \cdot \text{saturation}^{\text{slope}} \cdot s^{\text{slope}-1}}{(\text{saturation}^{\text{slope}} + s^{\text{slope}})^2}
$$

**Interpretation.** $\text{mROAS}_c(s)$ tells you "if you add one more
dollar to channel $c$ at current spend level $s$, here's the expected
incremental KPI." Optimal budget allocation under a budget constraint
$\sum_c s_c = B$ requires $\text{mROAS}_c(s_c)$ to be **equalized across
all channels** (Lagrangian first-order condition). When one channel's
mROAS is higher than another's, you should shift dollars from the lower
to the higher until they equalize.

### 9.4 Stability check on the curve parameters

After fitting, the codebase computes `predict_stability(bottom, top, slope,
saturation, X)` at two stress-test spend levels ($X = \$100M$ and $\$300M$)
to detect numerical pathologies (overflow, divide-by-zero) in the fitted
curve. Curves that produce `inf` predictions are tagged `stability_status =
'unstable'` and excluded from the reporting layer.

The reporting layer (`mmm_response_curves_overall_level_reporting`) then
samples each stable curve at 150 spend levels from 0 to $100M, producing a
Tableau-ready dataframe of `(business_kpi, version, channel_network,
spend, predicted)`.

---

## 10. Stability analysis — trusting a new version

Every bi-weekly run produces a new `version = vN+1`. Before Marketing
trusts the new numbers, the **stability loop** (notebook 9 for every KPI)
compares per-channel ROI between $v_{N+1}$ and $v_N$.

### 10.1 The two stability criteria

For each (channel × network) — and similarly for each (channel × network ×
campaign_super × LOB) at the taxonomy level:

**Step 1.** Compute the per-version return metric

$$
\text{return}_c^{(v)} \;=\; \frac{\sum_{d,t} \text{predicted}_{c,d,t}^{(v)}}{\sum_{d,t} \text{impressions}_{c,d,t}}
$$

(Predicted KPI per impression — a normalized effectiveness measure.)

**Step 2.** Compute the credible-interval bounds for return

$$
\text{return\_lower}_c^{(v)} \;=\; \frac{\sum_{d,t} \text{pred\_2.5\%\_hdi}_{c,d,t}^{(v)}}{\sum_{d,t} \text{impressions}_{c,d,t}}
$$

$$
\text{return\_higher}_c^{(v)} \;=\; \frac{\sum_{d,t} \text{pred\_97.5\%\_hdi}_{c,d,t}^{(v)}}{\sum_{d,t} \text{impressions}_{c,d,t}}
$$

**Step 3.** Two stability tests:

**Test A (point-estimate stability):**

$$
\text{PE\_drift}_c \;=\; \left|\frac{\text{return}_c^{(v_{N+1})} - \text{return}_c^{(v_N)}}{\text{return}_c^{(v_N)}}\right| \times 100
$$

Pass if $\text{PE\_drift}_c \leq 25\%$.

**Test B (HDI overlap):** Compute the overlap range between
$[\text{return\_lower}^{(v_{N+1})}, \text{return\_higher}^{(v_{N+1})}]$ and
$[\text{return\_lower}^{(v_N)}, \text{return\_higher}^{(v_N)}]$:

$$
\text{overlap\_range} \;=\; \max\!\left(0, \;\min(\text{return\_higher}^{(v_{N+1})}, \text{return\_higher}^{(v_N)}) - \max(\text{return\_lower}^{(v_{N+1})}, \text{return\_lower}^{(v_N)})\right)
$$

$$
\text{HDI\_overlap}_c \;=\; \frac{\text{overlap\_range}}{\text{return\_higher}^{(v_{N+1})} - \text{return\_lower}^{(v_{N+1})}} \times 100
$$

Pass if $\text{HDI\_overlap}_c > 50\%$.

**Final stability:** a channel is `Stable` if **either** Test A OR Test B
passes (the codebase uses `'Stable' in [PE_test, Overlap_test]`). This is
a deliberately lenient rule — only flag a channel as Unstable when *both*
tests fail.

### 10.2 Why bi-weekly stability matters

Bayesian re-fitting on rolling data shifts estimates with every update.
Two sources of legitimate drift:

1. **New data** — actual campaign performance changes.
2. **Prior update** — informative priors change between runs (each run's
   posterior becomes the next run's prior in some channels).

Two sources of *illegitimate* drift:

1. **MCMC noise** — different RNG seed gives slightly different posterior
   sample summaries.
2. **Multicollinearity reshuffling** — a small data change makes the
   regression re-distribute attribution between collinear channels.

The stability check distinguishes "expected drift from real changes" from
"unexpected reshuffling that erodes Marketing's trust." Channels flagged
Unstable get reviewed before the version is released to Tableau.

---

## 11. Train / Holdout / Recalibration

### 11.1 The train / holdout split (introduced v13)

Before v13 the models trained on a continuous 2-year window with no
holdout — overfit potential was high. Since v13:

- **Training window** = last 2 years of weekly DMA data ending at
  `train_end_week`
- **Holdout window** = 4 weeks immediately after `train_end_week`,
  ending at `holdout_end_week`

The holdout is **temporal** (most-recent 4 weeks), not random. This tests
the model's *forward-prediction* generalization, which is the only kind of
generalization that matters for a model that's updated bi-weekly to
forecast the next 2-week budget allocation.

Model fit statistics ($R^2$, RMSE, MAPE) are computed on both windows and
stored in `mmm_model_output_stat`. A high-variance-DMA filter excludes
DMAs whose holdout error exceeds 20% before computing holdout stats —
preventing a few extreme DMAs from distorting the headline metric.

### 11.2 Why holdout matters more for Bayesian MMM than for typical ML

Bayesian MMM doesn't have train/test in the usual sense — the posterior is
defined over the training data. Holdout in this codebase is **not** used
for hyperparameter selection (adstock + Hill parameters are fixed in
config). It is used for:

1. **Communicating model quality** to stakeholders ("the model predicted
   89% of last month's variation it never saw")
2. **Detecting concept drift** (sudden holdout-error spikes flag that
   real-world dynamics have changed)
3. **Identifying high-variance DMAs** that need investigation

### 11.3 Email Simon Data recalibration

Even with all the modeling machinery, MMM systematically over- or under-
attributes some channels — most notably **Email Simon Data**, where the
MMM consistently overestimates effect because emails go to users with
existing intent. The codebase uses AOT-derived ground truth to recalibrate.

The math:

**Step 1.** Compute "sends per incremental visit" from the AOT
incrementality data over the past year:

$$
\text{spi} \;=\; \frac{\sum_{\text{aot weeks}} \text{sends}}{\sum_{\text{aot weeks}} \text{incremental\_visits}}
$$

**Step 2.** Compute the model's impressions-per-predicted-visit ratio:

$$
\text{impv} \;=\; \frac{\text{impressions}_E}{\hat{y}_E}
$$

**Step 3.** Recalibrate:

$$
\hat{y}_E^{\text{recal}} \;=\; \frac{\hat{y}_E \cdot \text{impv}}{\text{spi}} \;=\; \frac{\text{impressions}_E}{\text{spi}}
$$

So the recalibrated Email prediction is simply `impressions / spi` —
ignoring the model's elasticity estimate and using the AOT-measured rate
directly.

**Step 4.** Adjust the intercept $\alpha$ to absorb the difference:

$$
\alpha_{\text{new}} \;=\; \alpha_{\text{old}} + (\hat{y}_E - \hat{y}_E^{\text{recal}})
$$

so that the total predicted KPI is unchanged but the Email contribution
matches AOT.

**Production refinement.** The production implementation in NB2 is
slightly more nuanced than the formula above: instead of using $\text{spi}$
directly, it computes an `adjusted_target` that backs out Email's
funnel-effect contribution before recalibrating. The reason is that
Email's funnel-effect rows (its share of Visits' attribution
propagating to FS Submits) shouldn't be touched by AOT recalibration —
AOT measures Email's *direct* incrementality only. The adjusted target
preserves the funnel rows and recalibrates only the direct-effect
rows. See [Doc 05 Section B9](05_fs_submits_overall_model_track.md) for
the full step-by-step code-level derivation.

### 11.4 Taxonomy recalibration

At the taxonomy level (channel × network × LOB × campaign_super), some
breakdowns also need adjustment because the taxonomy model doesn't know
about business-prior expectations. The recalibration:

$$
\text{factor}_{\text{tax}} \;=\; \frac{\text{expected\_percentage}_{\text{tax}}}{\text{current\_percentage}_{\text{tax}}}
$$

$$
\text{predicted}_{\text{tax}}^{\text{recal}} \;=\; \text{predicted}_{\text{tax}} \cdot \text{factor}_{\text{tax}}
$$

where `expected_percentage` is set by historical output and business
judgment (e.g., "Buyer campaign_super should be 70% of Paid Social
Facebook, not the 40% the model says"). The recalibration factor is
applied multiplicatively to the predicted contribution.

> **Interview angle — "How do you blend MMM with experiments?"** *"MMM is
> the primary attribution method but it has known biases — most notably
> over-attributing Email (because emails go to users with existing
> intent) and under-attributing brand-building channels like Linear TV at
> certain spend levels. We run AOT (Always-On Testing) geo-experiments
> continuously on calibration-critical channels. When AOT's measured
> incrementality systematically diverges from MMM's estimate, we
> recalibrate MMM. For Email Simon Data the recalibration replaces the
> model's elasticity estimate with the AOT-derived rate directly and
> shifts the difference into the intercept. The combination — MMM for
> coverage, AOT for ground truth on calibration channels — is what
> 'incrementality-aware MMM' means in industry parlance."*

---

## 12. Glossary recap

| Term | Definition |
|---|---|
| **Adstock** | Carryover transform on impressions, modeling that media has memory. Convolution with a decaying or bell-shaped kernel. |
| **AOT** | Always-On Testing — continuous geo-experiments used to calibrate MMM ground truth on selected channels. |
| **Bayesian regression** | Regression that treats parameters as random variables with prior distributions and produces a posterior distribution after observing data. |
| **Credible interval** | Bayesian range that contains the parameter with stated probability given the data and prior. |
| **DMA** | Designated Market Area — Nielsen US TV market, ~210 of them, identified by `dmacode`. The unit of geographic granularity in this MMM. |
| **Direct effect** | A channel's contribution to a KPI estimated from that KPI's own regression coefficient. |
| **Funnel effect / indirect effect** | A channel's contribution to a downstream KPI attributed proportionally from its contribution to an upstream KPI. |
| **HDI (Highest Density Interval)** | The narrowest Bayesian credible interval containing 95% of posterior mass. |
| **HMC (Hamiltonian Monte Carlo)** | MCMC method that uses gradient information to make smart proposals through Hamiltonian dynamics. |
| **Hierarchical model / partial pooling** | Model in which per-group parameters (e.g., per-DMA coefficients) are drawn from a shared population distribution, providing regularization. |
| **Hill function** | Saturation function $x^s / (K^s + x^s)$ bounded in $(0, 1)$ with shape parameter $s$ and half-saturation $K$. |
| **Holdout** | Last 4 weeks of data withheld from training to measure forward-prediction generalization. |
| **Hyperprior** | Prior on a parameter that itself parameterizes another prior (e.g., $\mu_{\beta_c}$ in the hierarchical model). |
| **Informative prior** | Prior with tight distribution around a specific value — used when domain knowledge or prior runs constrain the parameter. |
| **mROAS** | Marginal Return on Ad Spend — derivative of the response curve at current spend level. The "next dollar" expected return. |
| **MCMC** | Markov Chain Monte Carlo — a family of algorithms for sampling from intractable posterior distributions. |
| **Multicollinearity** | When two or more predictors are highly correlated, making individual coefficients unstable. Endemic in MMM because campaigns coordinate. |
| **NUTS (No-U-Turn Sampler)** | HMC variant that auto-tunes trajectory length. The default MCMC method in this codebase. |
| **Posterior** | The updated distribution of parameters given the observed data, in the Bayesian framework. |
| **Prior** | The distribution of parameters assumed before observing data. |
| **Recalibration** | Post-hoc adjustment of MMM outputs to match AOT-measured incrementality or business-prior expectations. |
| **Response curve** | Function mapping spend to expected KPI for a channel, used by Marketing for budget planning. |
| **Saturation** | Diminishing-returns property: doubling spend doesn't double effect. Modeled here via the Hill function. |
| **SoV (Share of Voice)** | A channel's impressions as a fraction of total impressions in the same DMA-week. |
| **Stability check** | Bi-weekly comparison of per-channel ROI between versions to detect unexpected drift. |
| **Taxonomy** | The 4-level hierarchy `channel × network × LOB × campaign_super` used to break down a channel's attribution. |
| **Truncated normal** | Normal distribution restricted to a sub-interval (e.g., $(0, \infty)$) to enforce non-negativity. |

---

**Next:** Read [02_rapidmmm_library_tour.md](02_rapidmmm_library_tour.md) for
how each formula in this doc is implemented in Python, with file paths and
class signatures.
