---
doc_id: 06
title: FS Submits — Taxonomy Track (Notebooks 3, 4, 5, 6)
companion_docs:
  - 00_mmm_ecosystem_overview.md (system map)
  - 01_mmm_methodology_primer.md (theory)
  - 02_rapidmmm_library_internals.md (the BayesianModel + FunnelEffects internals)
  - 04_data_lineage_and_schemas.md (the gold taxonomy tables)
  - 05_fs_submits_overall_model_track.md (Notebooks 1 and 2 — prerequisite)
  - 07_response_curves_and_stability.md (Notebooks 7, 8, 9 — downstream from this doc)
---

# 06 — FS Submits Taxonomy Track (Notebooks 3, 4, 5, 6)

> **What this doc is.** The second half of the FS Submits deep dive.
> [Doc 05](05_fs_submits_overall_model_track.md) covered the
> channel × network overall model in NB1 and NB2. This doc covers the
> deeper channel × network × LOB × campaign_super decomposition in
> NB3, NB4, NB5, and NB6 — the **15-way parallel taxonomy fan-out**.
> After reading, you should be able to explain why we run 15
> separate Bayesian models per KPI instead of one giant model, how
> Direct-Effect channels get a real taxonomy regression while
> no-Direct-Effect channels get a funnel-only allocation, and how all
> 15 outputs get unioned into the final gold taxonomy tables.
>
> **The chain at a glance.**
>
> ```text
>     mmm_input_preprocessing_taxonomy_data   (silver, KPI-agnostic)
>     mmm_fs_submits_overall_model_melted_data (silver, from NB2)
>                       │
>                       ▼
>     NB3 — Taxonomy Model Input
>       adstock → SoV (5 tax cols) → split → MeanScale → Hill →
>       write modeling input + create two empty staging tables
>                       │
>                       ▼
>           mmm_fs_submits_taxonomy_model_input             (silver)
>           mmm_fs_submits_taxonomy_model_output_staging    (silver, empty)
>           mmm_fs_submits_combined_taxonomy_output_staging (silver, empty)
>                       │
>                       ▼
>      ╔══════════════════════════════════════════════════════════════╗
>      ║  NB4 — Taxonomy Model  (×15 parallel tasks — one per channel) ║
>      ║                                                              ║
>      ║  for each channel-network in (DE list ∪ noDE list):          ║
>      ║    if single-variable DE → exit (NB5 handles it)             ║
>      ║    build channel-specific data (DE: y from node1; noDE: 0)   ║
>      ║    fit hierarchical Bayesian model (modeltype='Taxonomy')   ║
>      ║    register per-channel model in UC                          ║
>      ║    build melted contribution table for this channel          ║
>      ║    if channel == Email|Simon Data: AOT recalibration         ║
>      ║    apply taxonomy funnel effects (Visits taxonomy → FS tax)  ║
>      ║    validate sum vs overall (15% tolerance for Email)         ║
>      ║    write to two staging tables with replaceWhere channel_network ║
>      ╚══════════════════════════════════════════════════════════════╝
>                       │
>                       ▼
>     NB5 — Single-Variable Channel
>       for channels with only 1 taxonomy row and in DE list,
>       allocate the overall model's coefficient directly
>                       │
>                       ▼
>     NB6 — Output Merge
>       UNION ALL: staging ∪ single-var → final gold tables;
>       rename lob → core_lob, campaign_super → core_campaign_super
>                       │
>                       ▼
>      mmm_model_output_taxonomy_level             (direct only)
>      mmm_model_combined_output_taxonomy_level   (direct + funnel + AOT recal)
> ```
>
> **Math depth.** Heaviest in Part B — the two helper functions for
> DE vs noDE data preparation, the taxonomy AOT recalibration, and
> the taxonomy funnel-effect attribution all get full derivations.

---

## Part A — Notebook 3 (Taxonomy Input Data Preparation)

[`3_mmm_fs_submits_taxonomy_model_input.py`](D:/MMM_Learning/mmm_model/mmm_fs_submits/3_mmm_fs_submits_taxonomy_model_input.py)
runs as the "Taxonomy_Model_Input" task in the MMM FS Submits Job,
after NB2 completes. It reads the shared
`mmm_input_preprocessing_taxonomy_data` table (the 4-level taxonomy
view of the silver layer), applies the same transformations NB1 did
but at full taxonomy granularity, and writes the modeling input plus
two empty staging tables that NB4's parallel fan-out will populate.

### A1. What changes vs NB1 (Doc 05 Part A)

The structural transformations are **identical** to NB1's flow:
adstock → SoV scaling → split → MeanScaling → Hill saturation. What
changes is the granularity and a few small differences:

| Aspect | NB1 (overall) | NB3 (taxonomy) |
|---|---|---|
| Source silver table | `mmm_input_preprocessing_overall_data` | `mmm_input_preprocessing_taxonomy_data` |
| Column count | ~71 (one impression + one spend per channel × network) | ~146 (one per channel × network × LOB × campaign_super) |
| Impression columns | `impressions\|<Channel>\|<Network>` | `impressions\|<Channel>\|<Network>\|<LOB>\|<CampaignSuper>` |
| SoV target list | `config_param.yml::sov_cols` (3 channels) | `config_param.yml::sov_cols_taxonomy` (5 channels with specific LOB/super) |
| Atan transform | applied to 8 specific channels | **not applied** (taxonomy doesn't atan) |
| Sigmoid transform | applied if `transform_cols_sigmoid` set (currently null) | **not applied** |
| Holiday + seasonal + anomaly merges | applied | **not applied** — these stay at the overall level since they're not taxonomy-specific |
| Excluded channels | `excluded_channel_network_list` | `excluded_channel_network_list` ∪ `exclude_channels_bfr_taxonomy` |
| Output | full modeling feature matrix (silver) | adstocked + scaled + Hill-saturated taxonomy features (silver) — without holidays/seasonal/anomaly flags |

The most important difference is that **NB3 does not add the
exogenous features** (holidays, seasonal, anomaly flag). That's
because the taxonomy model's dependent variable is *already* the
overall-level per-channel attribution (constructed in NB4 — see Part
B), which has the exogenous effects already absorbed into the
overall coefficients. Adding them again at the taxonomy level would
double-count.

The Atan and Sigmoid steps are also dropped for the same reason: the
overall model already absorbed the heavy-tailed distributional shape
of those channels via Atan; re-applying at taxonomy level would
distort.

### A2. The exclusion stack

NB3 builds the impression-column list by **two filters in sequence**:

```python
exclude_channels_bfr_taxonomy = get_yaml_value('config_param.yml', 'exclude_channels_bfr_taxonomy')
excluded_channel_network_list = get_yaml_value('config_param.yml', 'excluded_channel_network_list')
exclude_combined = list(set(exclude_channels_bfr_taxonomy + excluded_channel_network_list))

impression_columns = [
    col for col in data.columns
    if 'impressions|' in col
    and not any(pattern in col for pattern in exclude_combined)
]
```

For FS Submits the taxonomy-specific exclusion list is:

```yaml
exclude_channels_bfr_taxonomy:
- OMP
- Push
- Email|Sparkpost
- Email|Iterable
- Operational Emails
```

These are channels that **should never appear in the taxonomy
attribution** for various reasons: OMP has its own ZHL pipeline, Push
is too sparse at taxonomy grain, the non-Simon-Data Email channels
have no meaningful taxonomy structure, and Operational Emails are
non-marketing so they shouldn't be allocated to campaign supers.

Combined with the NB1-level `excluded_channel_network_list` (which
for FS Submits is `[impressions|OOH|Media Agency, impressions|App|Facebook]`),
this drops roughly 7 channel families from the taxonomy modeling
scope.

### A3. Adstock + SoV + scaling + Hill — the re-run at taxonomy grain

The transformation calls are identical to NB1, just on the larger
DataFrame:

**Adstock.** Same `FeatureEngineeringAdStock(params_dict=config,
datecol='week_monday', regioncol='dmacode')` with the same
config-loaded `adstock_hill_best_params`. The key intuition: the
adstock parameters are configured per *channel × network* (e.g.,
`'|Linear TV|Media Agency'`), not per *channel × network × LOB ×
campaign_super*. So every taxonomy variant of Linear TV Media Agency
(e.g., `impressions|Linear TV|Media Agency|Multi Product|Buyer`,
`impressions|Linear TV|Media Agency|ZHL - Customer|Buyer`, etc.) all
inherit **the same adstock kernel** — `max_lag=9, decay=0.9,
delay=5`. The orchestrator class uses `channel_network_keys` (the
4-element-stripped-to-2-element keys) to look up the right adstock
for each impression column.

**SoV taxonomy.** From `config_param.yml::sov_cols_taxonomy`:

```yaml
sov_cols_taxonomy:
- impressions|Paid Social|Facebook|Rentals - Customer|Rental_delayed_lag_1_decay_0.05_delay_1
- impressions|Paid Social|Facebook|ZHL - Customer|Buyer_delayed_lag_1_decay_0.05_delay_1
- impressions|SEM|Google Search|ZGMI - Customer|Buyer_delayed_lag_1_decay_0.05_delay_1
- impressions|SEM|Google Search|ZHL - Customer|Buyer_delayed_lag_1_decay_0.05_delay_1
- impressions|SEM|Google Search|Rentals - Partner|Rental_delayed_lag_1_decay_0.05_delay_1
```

Five specific (channel × network × LOB × campaign_super) cells get
SoV-scaled: the cross-brand spillover cells (Paid Social Facebook
on Rentals/ZHL, SEM Google Search on ZGMI/ZHL/Rentals-Partner). For
each, the value is divided by the sum of all adstocked impression
columns in that DMA-week — same SoV formula as NB1.

**Split → MeanScale (excluding SoV cols) → re-join.** Identical to
NB1's contract: fit `MeanScalingRegional` on train data, transform
both train and holdout; then re-join the un-scaled SoV columns.

**Hill saturation.** Uses the same per-channel-network slope and
shape from `Saturation_best_params` in the config. Multiple taxonomy
columns for the same channel-network share the same Hill parameters
(because Hill is parameterized at the channel-network level, not the
taxonomy level).

### A4. The `cnt_dict` artifact — published back to config

After all transformations, NB3 computes a **count of taxonomy
variants per channel-network** and writes it back to `config_param.yml`:

```python
cnt_dict = {
    key: len([j for j in train_hill_transformed_data.columns if key in j])
    for key in channel_network_keys
}
add_mapping(
    file_path='config_param.yml',
    mapping_name='cnt_dict',
    mapping_dict=cnt_dict,
)
```

The result, for FS Submits:

```yaml
cnt_dict:
  '|App|Apple Search': 2
  '|App|Google UAC': 1                  ← single-variable
  '|Audio|Media Agency': 1              ← single-variable
  '|Connected TV|Media Agency': 4
  '|Display|Media Agency': 4
  '|Display|Video Demand Gen': 1        ← single-variable
  '|Email|Simon Data': 8
  '|Linear TV|Media Agency': 2
  '|Media Solutions|Facebook': 2
  '|Native|Media Agency': 1             ← single-variable
  '|Online Video|Media Agency': 4
  '|Online Video|YouTube': 1            ← single-variable
  '|Owned Social|Facebook': 5
  '|Owned Social|TikTok': 5
  '|Paid Social|Facebook': 6
  '|Paid Social|Pinterest': 4
  '|Paid Social|TikTok': 4
  '|SEM|Google Performance Max': 4
  '|SEM|Google Search': 6
  '|SEM|Microsoft Search': 4
```

This dictionary controls a critical branching decision in NB4: any
channel-network with `cnt_dict[ch] == 1` and in the Direct-Effect
list **skips NB4 entirely** and gets handled by NB5 (the single-
variable shortcut). The reason is that a Bayesian regression with a
single predictor degenerates — there's nothing to fit, the model
just recovers the prior mean. NB5 short-circuits this by directly
allocating the overall model's per-channel coefficient to the single
taxonomy variant.

### A5. The Direct-Effect vs no-Direct-Effect lists

Two lists in `config_param.yml` partition all channels into two
categories:

```yaml
list_with_DE:                  # Direct-Effect channels
- '|Owned Social|Facebook'
- '|Display|Media Agency'
- '|Linear TV|Media Agency'
- '|Connected TV|Media Agency'
- '|Paid Social|TikTok'
- '|Paid Social|Facebook'
- '|SEM|Google Search'
- '|SEM|Google Performance Max'
- '|Email|Simon Data'
- '|Email|Sparkpost'

list_noDE:                     # Funnel-effect-only channels
- '|App|Facebook'
- '|App|Google UAC'
- '|Audio|Radio'
- '|Audio|Media Agency'
- '|Online Video|YouTube'
- '|Display|Video Demand Gen'
- '|Native|Media Agency'
- '|Paid Social|Pinterest'
- '|SEM|Microsoft Search'
- '|App|Apple Search'
- '|Owned Social|TikTok'
- '|Online Video|Media Agency'
```

**What "Direct Effect" means.** A channel is in `list_with_DE` when
the team believes the channel has a meaningful *direct* relationship
with FS Submits — i.e., users see this channel's impressions and
some convert directly to a submission (perhaps through a click, app
install, search, or click-through email).

**What "no Direct Effect" means.** A channel is in `list_noDE` when
its FS Submits attribution is believed to flow **entirely through the
upper-funnel KPI** (Visits). Linear TV, Connected TV, OOH, and Online
Video all drive Visits which then convert to FS Submits — the team's
business judgment is that these channels' direct conversion to FS
Submits at the channel level is zero (or at least not separately
identifiable from the funnel effect).

This division shapes the modeling: DE channels get a real per-channel
Bayesian regression on FS Submits proportions; noDE channels get a
"target = 0" regression (so coefficients shrink to zero) and then
receive their entire attribution via the taxonomy funnel-effect step.
The next section walks through how each type's data is constructed.

### A6. Staging table setup — clean slate for the parallel fan-out

The final cells of NB3 **drop and recreate** the two staging tables
that NB4's 15 parallel tasks will write into:

```python
stage_drop_query = f"DROP TABLE IF EXISTS {catalog}.{silver_schema}.mmm_fs_submits_taxonomy_model_output_staging;"
spark.sql(stage_drop_query)

stg_tbl_create_query = f"""CREATE TABLE IF NOT EXISTS {catalog}.{silver_schema}.mmm_fs_submits_taxonomy_model_output_staging (
    model_dma_id BIGINT, dmacode BIGINT, week_monday TIMESTAMP,
    channel STRING, network STRING, lob STRING, campaign_super STRING,
    model_idv DOUBLE, model_dv DOUBLE, coefficient DOUBLE,
    coef_hdi_2point5_pct DOUBLE, coef_hdi_97point5_pct DOUBLE,
    predicted_initial DOUBLE, predicted_2point5_pct_hdi DOUBLE,
    predicted DOUBLE, predicted_97point5_pct_hdi DOUBLE,
    spend DOUBLE, impressions DOUBLE,
    business_kpi STRING, modeltype STRING, mcmc_id STRING,
    version STRING, run_time STRING, p_data_date DATE,
    train_holdout STRING, channel_network STRING
) USING delta"""
spark.sql(stg_tbl_create_query)
```

Same for `mmm_fs_submits_combined_taxonomy_output_staging` (which
adds `type` and `funneleffect_variable` columns for the after-funnel
output).

**Why drop and recreate.** Each bi-weekly run starts these tables
empty. The 15 parallel NB4 invocations each write their own
channel-network slice via `replaceWhere channel_network = '...'`. If
the staging tables weren't dropped at the start, leftover rows from
a prior run's channel-networks (which might no longer be in the
current run's channel list) would persist and pollute the downstream
merge in NB6.

The `channel_network` column on these tables is the partition key for
the parallel writes — it's set by each NB4 invocation to the
parameterized channel-network identifier (e.g., `_Paid_Social_Facebook`),
and the `replaceWhere channel_network = '_Paid_Social_Facebook'`
predicate ensures each NB4 task overwrites only its own slice without
clobbering siblings.

### A7. Outputs

NB3 writes:

| Table | Contents |
|---|---|
| `mmm_fs_submits_taxonomy_model_input` | Adstocked + scaled + Hill-transformed taxonomy features at `(dma × week × channel × network × lob × campaign_super)` granularity, with train_holdout flag |
| `mmm_fs_submits_taxonomy_model_output_staging` | Empty staging table for NB4's per-channel direct-effect writes |
| `mmm_fs_submits_combined_taxonomy_output_staging` | Empty staging table for NB4's per-channel combined (direct + funnel) writes |

The `cnt_dict` mapping is also persisted back to `config_param.yml`
for NB4 + NB5 to read.

---

## Part B — Notebook 4 (Taxonomy Model — the parallel per-channel models)

[`4_mmm_fs_submits_taxonomy_model.py`](D:/MMM_Learning/mmm_model/mmm_fs_submits/4_mmm_fs_submits_taxonomy_model.py)
is the longest notebook in the FS Submits chain (1,346 lines). It is
*the* notebook in this codebase. The Databricks job invokes it
**~15 times in parallel** — once per channel-network in
`list_with_DE ∪ list_noDE` — each invocation differing only by the
`channel_network` widget parameter.

### B1. Why one model per channel-network — the central design choice

The alternative would be a single hierarchical Bayesian model with
all ~70 taxonomy columns (channel × network × LOB × campaign_super)
as predictors. The team chose **15 separate per-channel-network
models** instead. Three reasons, in order of importance:

**1. Computational tractability.** A single hierarchical model with
70 predictors × 210 DMAs × ~104 weeks has ~14,700 random-effect
coefficients (β_{c,d}) plus ~70 population-level means and standard
deviations. NumPyro NUTS with 2000 samples on a single GPU would take
several hours per fit and consume tens of GB of memory. Splitting
into 15 models, each with ~5 predictors × 210 DMAs × ~104 weeks,
gives ~1,050 coefficients per model — each fits in 10–20 minutes on
the same GPU and uses a few GB. The 15 models run in parallel across
~3 CPU clusters with ~5 parallel tasks each, completing the whole
fan-out in roughly the same wall-clock time as a single large model
would take.

**2. Multicollinearity isolation.** Within a single channel-network
(e.g., Paid Social Facebook), the 6 taxonomy variants
(Multi-Product-Buyer, PA-Customer-Buyer, Rentals-Customer-Rental,
ZHL-Customer-Buyer, Multi-Product-Brand, etc.) tend to be highly
correlated — they're all Facebook ad campaigns, often coordinated.
Across channel-networks (Paid Social Facebook vs SEM Google Search),
the multicollinearity is less severe. By isolating each channel-
network in its own model, multicollinearity is constrained to
*within-channel* relationships, where it's at least well-understood.
A single 70-predictor model would have to deal with both within-
channel and across-channel multicollinearity simultaneously,
producing unstable coefficient estimates.

**3. Per-channel priors and orchestration.** Each channel-network can
have its own DE/noDE classification (different data construction —
see Section B3 below), its own AOT recalibration logic (only Email
Simon Data is recalibrated), and its own failure mode for the
diagnostic-retry wrapper. A single model would have to bundle all
these decisions into one monolithic configuration; 15 separate
models let each be handled independently and lets the parallel
Databricks scheduler use the diagnostic retry loop without taking
down sibling fits.

**The parallelism in practice.** From the FS Submits PDF: the MMM FS
Submits Job has ~27 tasks total. The "Taxonomy_Model" task is
actually 15 sub-tasks running concurrently on CPU clusters — one
notebook execution per channel-network in `list_with_DE ∪ list_noDE`
(minus the single-variable DE channels that NB5 handles instead).
Each task gets a separate `channel_network` widget value.

> **Interview angle — "Why don't you fit one giant hierarchical
> model with all taxonomy columns?"** *"Three reasons. (1)
> Computational tractability — a single 70-predictor × 210-DMA
> hierarchical NUTS fit takes hours and tens of GB; 15 parallel
> per-channel fits complete in roughly the same wall-clock time
> using cheaper CPU clusters in parallel. (2) Multicollinearity
> isolation — the strong cross-correlation between sibling taxonomy
> variants within a channel (e.g., the 6 Paid Social Facebook
> variants are all FB ad campaigns) stays contained inside that
> channel's model rather than corrupting estimates across channels.
> (3) Per-channel policy flexibility — each channel can have its own
> Direct-Effect vs no-Direct-Effect data construction, its own AOT
> recalibration (only Email Simon Data is recalibrated), and its own
> diagnostic retry without taking down sibling fits. The trade-off:
> we lose the partial-pooling benefit *across* channels at the
> taxonomy level — but we retain partial pooling *across DMAs*
> within each channel's model, which is where the bulk of the
> regularization value comes from."*

> **Interview angle — "How do you parallelize MMM training in
> production?"** *"Two-layer parallelism. (1) Within a KPI: the
> taxonomy fan-out is 15 parallel Databricks tasks on CPU clusters,
> each running an independent NumPyro fit for one channel-network.
> The tasks coordinate only through shared input silver tables (read
> at the start) and a shared staging table that they write
> non-overlapping slices of via `replaceWhere channel_network =
> '...'`. (2) Within a model: NumPyro JIT-compiles the entire
> posterior to a single XLA program and runs NUTS on GPU using
> `vmap` over observations, achieving full-device utilization for the
> Overall model. The two layers don't compete because GPU is used by
> the Overall model (NB2), CPU by the per-channel Taxonomy models
> (NB4 ×15). Within a KPI's bi-weekly job, the GPU finishes the
> Overall fit first, then the CPUs fan out for the taxonomy fits."*

### B2. The channel-network skip — single-variable DE channels exit early

The first thing NB4 does after setting up the channel context is
check whether this is a single-variable DE channel — if so, exit:

```python
cnt_dict = get_yaml_value('config_param.yml', 'cnt_dict')
list_with_DE = get_yaml_value("config_param.yml", "list_with_DE")
list_noDE   = get_yaml_value("config_param.yml", "list_noDE")
channelgrouping = channel_network

if any(value == 1 and key == channel_network for key, value in cnt_dict.items()) \
   and (channelgrouping in list_with_DE):
    dbutils.notebook.exit(f"{channel_network} - Detected a single variable DE channel. "
                          f"Skipping subsequent executions.")
```

If a channel is in `list_with_DE` AND has `cnt_dict[ch] == 1`, NB4
returns early — NB5 will handle it. Note this only skips
**single-variable DE channels**; single-variable noDE channels do
go through NB4 because the noDE data-prep path (Section B3 below)
doesn't need multiple variants to be meaningful (the regression
target is just 0 for noDE channels, so even one predictor produces
useful output).

For FS Submits with the current `cnt_dict` and `list_with_DE` /
`list_noDE`, the single-variable channels split as:

| Single-variable channel | In list | What happens |
|---|---|---|
| `\|Audio\|Media Agency` | (neither — excluded earlier) | Never enters NB4 |
| `\|Display\|Video Demand Gen` | `list_noDE` | NB4 runs (noDE path) |
| `\|Native\|Media Agency` | `list_noDE` | NB4 runs (noDE path) |
| `\|App\|Google UAC` | `list_noDE` | NB4 runs (noDE path) |
| `\|Online Video\|YouTube` | `list_noDE` | NB4 runs (noDE path) |

None of FS Submits' current single-variable channels are in `list_with_DE`,
so NB5 has **no work to do** for FS Submits — the codebase still
runs NB5 but exits early.

### B3. The two data-preparation helpers — DE vs noDE

The notebook defines two helper functions at lines 184 and 230:
`data_for_taxonomy_model(...)` for DE channels and
`data_for_taxonomy_model_noDE(...)` for noDE channels. They differ in
exactly one line — the merge `how='inner'` (DE) vs `how='left'` (noDE).
But the conceptual difference is significant.

**DE path — for channels in `list_with_DE`.**

For DE channels, the taxonomy model's dependent variable is the
**share of FS Submits attributable to this channel-network from the
overall model**. Specifically, the helper:

1. Reads `mmm_fs_submits_overall_model_melted_data` (NB2's melted
   contribution table) — one row per `(dma × week × variable)` with
   coefficient × value × y_mean = predicted contribution.
2. Filters to rows where `variable` matches the channel-network
   (e.g., `impressions|Paid Social|Facebook_delayed_lag_1_decay_0.05_delay_1`).
3. Divides the predicted contribution by `y_mean` to get the
   normalized predicted-per-DMA-mean:

   $$
   y^{\text{tax}}_{c,d,t} = \frac{\hat{y}^{\text{overall}}_{c,d,t}}{\overline{y}_d}
   $$

4. Inner-joins the taxonomy adstocked/scaled/Hill-transformed features
   on `(dmacode, week_monday)` to produce the modeling DataFrame.

```python
def data_for_taxonomy_model(channel_networks, data_w_all_channels,
                            overall_lvl_outputs, dep_var):
    preds = overall_lvl_outputs[['dmacode','week_monday','variable',
                                  dep_var + '_mean','predicted']]
    x_cls = []
    l1_cls = []
    for i in channel_networks:
        x_cls   += [j for j in data_w_all_channels.columns if i in j]
        l1_cls  += [j for j in overall_lvl_outputs.variable.unique() if i in j]
    preds = preds[preds['variable'].isin(l1_cls)].reset_index(drop=True)
    preds.columns = ['dmacode','week_monday','variable','y_mean', dep_var]
    preds[dep_var] = preds[dep_var] / preds['y_mean']
    preds = preds[['dmacode','week_monday','y_mean', dep_var]]\
               .groupby(['dmacode','week_monday','y_mean']).sum().reset_index()
    data_for_model = data_w_all_channels[['dmacode','week_monday'] + x_cls]\
                       .merge(preds, on=['dmacode','week_monday'])     # inner join
    return data_for_model, x_cls
```

The conceptual move: the taxonomy model's job is to *decompose* the
overall model's per-channel contribution into per-(channel × network ×
LOB × campaign_super) shares. So the dependent variable at row
$(d, t)$ is the overall model's predicted contribution of this
channel-network at $(d, t)$, normalized by the DMA's mean KPI value.
The predictors are the taxonomy-level scaled features for the same
channel-network. The fit learns the share weights that, when applied
to the taxonomy features, reproduce the overall-level contribution.

**noDE path — for channels in `list_noDE`.**

For noDE channels, the same SQL filter on the overall model's melted
table returns *no rows* — because noDE channels were excluded from
NB2's `exclude_channels_bfr_model` and therefore don't appear in the
overall model's predictions. So the inner join in the DE path would
produce an empty DataFrame.

The noDE helper avoids this by using a **left join** instead of
inner:

```python
data_for_model = data_w_all_channels[['dmacode','week_monday'] + x_cls]\
                   .merge(preds, on=['dmacode','week_monday'], how='left')   # left join
data_for_model.fillna(0, inplace=True)
```

With `how='left'`, rows from the taxonomy features stay even when no
overall-level contribution exists. The `fillna(0)` then sets the
dependent variable to zero for every row. So the noDE model fits
"taxonomy features ↦ zero" — the Bayesian regression with non-
negative coefficients shrinks all $\beta_{c,d}$ toward zero, producing
**zero direct-effect attribution** at the taxonomy level. The
channel's entire FS Submits attribution will then come from the
funnel-effect step (Section B6 below), which is the intended outcome.

**Why fit a model at all for noDE channels?** Two reasons. (1) The
melted contribution table that NB4 writes per channel must include
rows for *every* taxonomy variant — Tableau dashboards expect the
table to be complete. Even if all contributions are zero, the rows
must be present. (2) The funnel-effect step needs taxonomy-level
melted data as input; without NB4 producing it, the funnel effect
couldn't allocate across taxonomy variants.

### B4. Building the per-channel Bayesian model

After data prep, the `Model` instantiation:

```python
mdl = mt.Model(
    region_col      = ['dmacode'],
    X_col           = train_x_col,            # ~2–8 taxonomy features for this channel-network
    y_col           = target_variable,        # 'value|leads|fs_submits'
    priors          = None,                   # ← no informative priors for taxonomy
    hierarchical    = True,
    samples         = 2000,
    warmup          = 1000,
    nonnegative     = True,
    modeltype       = 'Taxonomy',             # ← omits per-DMA intercept α
    channelgrouping = channelgrouping,        # ← e.g., '|Paid Social|Facebook'
)
mdl_mcmc = mdl.ModelBuild(train_data_for_model, num_chains=1)
```

Two differences from the Overall model construction in NB2:

**1. `priors=None`.** Taxonomy models don't load informative priors
from a CSV — they use default uninformative priors (`Normal(0, 1)`
for controls, `TruncatedNormal(0, 1, low=0)` for impressions).
Rationale: the taxonomy dependent variable is constructed from the
overall model's per-channel attribution (Section B3 above), which
itself was constrained by tight overall-level priors. Adding a
second layer of priors on the taxonomy decomposition would over-
constrain — the taxonomy model is doing a *decomposition*, not an
independent fit, and the prior information has already been baked
into the dependent variable.

**2. `modeltype='Taxonomy'`** which (per
[Doc 02 Section 4.2](02_rapidmmm_library_internals.md)) omits the
per-DMA intercept $\alpha_d$. The dependent variable is already
"residualized" — it's the overall model's per-channel contribution
without the baseline — so an intercept would double-count the
baseline that the overall model already absorbed into its $\alpha$.

The `channelgrouping=channelgrouping` argument names the model with
the channel-network string, which becomes part of `self.modelid =
channelgrouping + datetime.now().strftime("%Y%m%d%H%M%S")` (see
[Doc 02 Section 4.1 footnote](02_rapidmmm_library_internals.md))
and propagates to the `mcmc_id` column of every output row written
by this channel's NB4 invocation. Downstream consumers can tell
which of the 15 parallel taxonomy models produced any given gold-
table row just by reading the `mcmc_id` prefix.

### B5. Per-channel divergence checks

The diagnostic-retry wrapper from NB2 is not duplicated in NB4 —
instead, NB4 just calls `mdl.ModelBuild(...)` directly and inspects
the resulting `idata` for divergences:

```python
idata = mdl.get_inference_data()
if hasattr(idata, 'sample_stats') and 'diverging' in idata.sample_stats:
    divergences = idata.sample_stats.diverging
    num_divergences = int(divergences.sum())
    total_samples   = divergences.size
    print(f"\nNumber of divergences: {num_divergences}")
    print(f"Divergence rate: {num_divergences / total_samples:.2%}")
```

There's **no retry** at the taxonomy level — if the fit diverges
heavily, NB4 prints a warning but continues. This is a deliberate
trade-off: a noisy per-channel taxonomy fit produces noisy
decomposition shares, but those shares are then **constrained to
sum to the overall model's per-channel attribution** via the
`error correction` step in `ModelDiagnostics.get_melted_data_for_business_diagnostics`
(see [Doc 02 Section 9.7](02_rapidmmm_library_internals.md)). So
even a poor taxonomy fit produces output that sums correctly to the
overall model's predicted contribution at the channel level —
which is what matters for downstream attribution validity.

The validation step at the end of NB4 (Section B7 below) enforces
this invariant by asserting that the taxonomy sum matches the
overall sum (with a 15% tolerance for Email Simon Data because of
the recalibration).

### B6. Per-channel model registration in Unity Catalog

Each per-channel NB4 invocation registers its own model in Unity
Catalog:

```python
wrappedModel = RapidMMMModelWrapper(mdl)
prediction_params = {"kpi": 'FS Submits'}
signature = infer_signature(train_data_for_model,
    np.array(wrappedModel.predict(None, model_input=train_data_for_model,
                                  params=prediction_params)))
mlflow.pyfunc.log_model(f"fs_submits_taxonomy_mdl/{channel_network_wop}",
                        python_model=wrappedModel, signature=signature)
model_name = f"{catalog}.{gold_schema}.mmm_fs_submits_taxonomy{channel_network_wop}"
model_version = mlflow.register_model(
    f"runs:/{child_run_id}/fs_submits_taxonomy_mdl/{channel_network_wop}", model_name
)
client.set_registered_model_tag(model_name, key="model_type", value="Taxonomy")
client.set_registered_model_tag(model_name, key="business_kpi", value="FS Submits")
client.set_model_version_tag(name=model_name, version=model_version.version,
                             key="version", value=final_model_version_int)
```

The `channel_network_wop` variable (computed as
`channel_network.replace('|', '_').replace(' ', '_')`) becomes part
of both the MLflow path and the Unity Catalog model name. For FS
Submits this produces ~15 distinct registered models per version:

| Per-channel registered model name (FS Submits) |
|---|
| `marketing.rapidmmm_gold.mmm_fs_submits_taxonomy_App_Apple_Search` |
| `marketing.rapidmmm_gold.mmm_fs_submits_taxonomy_App_Google_UAC` |
| `marketing.rapidmmm_gold.mmm_fs_submits_taxonomy_Audio_Radio` |
| `marketing.rapidmmm_gold.mmm_fs_submits_taxonomy_Display_Media_Agency` |
| `marketing.rapidmmm_gold.mmm_fs_submits_taxonomy_Display_Video_Demand_Gen` |
| `marketing.rapidmmm_gold.mmm_fs_submits_taxonomy_Email_Simon_Data` |
| `marketing.rapidmmm_gold.mmm_fs_submits_taxonomy_Online_Video_Media_Agency` |
| `marketing.rapidmmm_gold.mmm_fs_submits_taxonomy_Owned_Social_Facebook` |
| `marketing.rapidmmm_gold.mmm_fs_submits_taxonomy_Owned_Social_TikTok` |
| `marketing.rapidmmm_gold.mmm_fs_submits_taxonomy_Paid_Social_Facebook` |
| `marketing.rapidmmm_gold.mmm_fs_submits_taxonomy_Paid_Social_Pinterest` |
| `marketing.rapidmmm_gold.mmm_fs_submits_taxonomy_Paid_Social_TikTok` |
| `marketing.rapidmmm_gold.mmm_fs_submits_taxonomy_SEM_Google_Search` |
| `marketing.rapidmmm_gold.mmm_fs_submits_taxonomy_SEM_Microsoft_Search` |
| `marketing.rapidmmm_gold.mmm_fs_submits_taxonomy_Connected_TV_Media_Agency` |
| `marketing.rapidmmm_gold.mmm_fs_submits_taxonomy_Linear_TV_Media_Agency` |

Each model carries a `version` tag matching `final_model_version_int`
and is loadable independently — downstream analysts can `load_model
("models:/.../mmm_fs_submits_taxonomy_Paid_Social_Facebook/<vN>")` to
re-predict on new data for that single channel without re-fitting.

### B7. Post-processing per channel — predictions, melted, recalibration, funnel

After model registration, NB4 runs the same post-processing chain as
NB2's Section B5–B6, but **only for this channel-network's data**:

1. **Predictions on train, holdout, train+holdout.** Same
   `MoDi.generate_predictions(...)` calls. Train/holdout/(both)
   actual-vs-predicted plots are saved to MLflow as artifacts.
2. **Model stats** (R², RMSE, MAPE) written to `mmm_model_output_stat`
   with `model_type='Taxonomy'` and `channel_network=<channel>_Train`
   or `_Holdout`.
3. **Melted contribution table** built via the same trio of calls
   (`get_melted_data_for_business_diagnostics`,
   `merge_spend_data_w_melted`,
   `merge_impressions_data_w_melted`) — but the inputs are the
   *taxonomy* versions: `mmm_input_preprocessing_taxonomy_spend_data`,
   `mmm_fs_submits_adstock_transformed_data`,
   `mmm_input_preprocessing_taxonomy_data`.
4. **Spark-ready DataFrame** for the staging table:

   ```python
   taxonomy = MoDi.get_spark_ready_df_from_melted(melted,
       taxonomy_order = ['channel', 'network', 'lob', 'campaign_super'],
       version = final_model_version,
   )
   taxonomy["train_holdout"] = np.where(
       taxonomy["week_monday"] < holdout_start_week, "Train", "Holdout"
   )
   taxonomy_df = spark.createDataFrame(taxonomy)\
                      .withColumn("channel_network", lit(channel_network_wop))
   taxonomy_df.write.format("delta").mode("overwrite")\
       .option("replaceWhere", f"channel_network = '{channel_network_wop}'")\
       .insertInto(f"{catalog}.{silver_schema}.mmm_fs_submits_taxonomy_model_output_staging")
   ```

   The `replaceWhere channel_network = '...'` predicate is what
   makes the parallel writes safe — each NB4 invocation overwrites
   only its own slice. If a re-run of the same channel happens
   later, it cleanly replaces just that channel's rows.

### B8. Taxonomy AOT recalibration — Email Simon Data only

After writing the direct-effect Spark-ready output to staging, NB4
conditionally applies AOT recalibration to the melted DataFrame **for
Email Simon Data only**:

```python
if channel_network == '|Email|Simon Data':
    adjusted_target_aot_value = get_yaml_value('config_param.yml',
                                               'adjusted_target_aot_value')
    melted = recalibrate_channel_AOT_taxonomy(
        df=melted,
        channel_to_recalibrate=channel_network,
        target_value=adjusted_target_aot_value,
    )
else:
    print(f"Channel {channel_network} is not eligible for recalibration.")
```

The `adjusted_target_aot_value` was computed and persisted to
`config_param.yml` by NB2 (see
[Doc 05 Section B9](05_fs_submits_overall_model_track.md) for the
overall-level recalibration math). NB4 reads it back and applies it
to the taxonomy-level melted DataFrame for Email Simon Data.

The taxonomy recalibration function is **simpler** than the overall
version — it doesn't split Direct vs Funnel rows because at the
taxonomy level, all rows for this channel are conceptually "direct"
(the funnel effects haven't been applied yet — that's the next step):

```python
def recalibrate_channel_AOT_taxonomy(df, channel_to_recalibrate, target_value):
    df_result = df.copy()
    df_result['impv'] = df_result['impressions'] / df_result['predicted'].replace(0, 1e-6)
    df_result['recalibrated_value'] = (df_result['predicted'] * df_result['impv']) / target_value
    df_result['diff_pred_calibrated'] = df_result['predicted'] - df_result['recalibrated_value']
    df_result.fillna(0, inplace=True)
    df_result['predicted'] = df_result['recalibrated_value']
    df_result.drop(columns=['recalibrated_value', 'diff_pred_calibrated', 'impv'],
                   inplace=True, errors='ignore')
    return df_result
```

For each row in the Email Simon Data melted DataFrame:

$$
\hat{y}_{E,d,t}^{\text{tax,recal}}
\;=\; \frac{\hat{y}_{E,d,t}^{\text{tax,MMM}} \cdot \text{impv}_{d,t}}{\text{adjusted\_target}}
\;=\; \frac{\text{impressions}_{E,d,t}}{\text{adjusted\_target}}
$$

The algebra simplifies the same way as the overall-level
recalibration: the recalibrated value is just `impressions /
adjusted_target` per row, regardless of the MMM-fitted coefficient.

**Notably absent: an intercept adjustment.** The overall-level
recalibration in NB2 pushed the difference between MMM and
recalibrated values into the per-DMA intercept α to preserve total
predicted FS Submits. At the taxonomy level, there is no intercept
(`modeltype='Taxonomy'` omits it). So the difference between MMM
prediction and recalibrated prediction is simply **dropped** — the
taxonomy-level recalibration **does not preserve the total** at the
DMA-week level.

This is why the validation step at the end (Section B9) accepts a
15% tolerance for Email Simon Data's overall-vs-taxonomy sum
comparison (instead of requiring exact match like the other
channels). The 15% absorbs the taxonomy-level total drift introduced
by the recalibration.

### B9. Taxonomy funnel effects — propagating Visits' taxonomy attribution

After the per-channel direct-effect melted DataFrame is built (and
recalibrated for Email Simon Data), NB4 applies the **taxonomy-level
funnel-effect transform**. This is the second of the two
attribution-propagation calls in `rapidmmm.Utils.FunnelEffects`
(see [Doc 02 Section 7.3](02_rapidmmm_library_internals.md) for the
algorithm).

**Inputs.** Four data sources, all already in memory:

```python
fs_funnel = spark.table(...mmm_model_combined_output_overall_level)\
              .filter((col("type") == "Funnel Effect")
                    & (col("version") == final_model_version)
                    & (col("business_kpi") == "FS Submits")).toPandas()

taxonomy_level = spark.table(...mmm_model_combined_output_taxonomy_level)\
                   .withColumnRenamed("core_campaign_super","campaign_super")\
                   .withColumnRenamed("core_lob","lob")\
                   .filter((col("version") == final_model_version)
                         & (col("business_kpi") == "Visits")).toPandas()

overall_level = spark.table(...mmm_model_combined_output_overall_level)\
                  .filter((col("version") == final_model_version)
                        & (col("business_kpi") == "Visits")).toPandas()
```

- `fs_funnel` — FS Submits' overall-level funnel-effect rows (from
  NB2's output, filtered to `type = 'Funnel Effect'`). These are
  the channel-network-level funnel contributions that need to be
  decomposed into taxonomy variants.
- `taxonomy_level` — Visits' combined-output taxonomy table (with
  both Direct and Funnel rows for Visits at full taxonomy grain).
- `overall_level` — Visits' combined-output overall table (used to
  compute ratios between Visits' channel-network total and its
  taxonomy sub-totals).
- `melted` — FS Submits' per-channel taxonomy melted DataFrame
  (after the AOT recalibration if Email Simon Data).

**The call:**

```python
funnel_taxonomy = fne.funnel_effects_taxonomy(
    nodes_data = {
        'node1_data_overall':       overall_level,         # Visits overall
        'nodel1_data_taxonomy':     taxonomy_level,        # Visits taxonomy
        'node2_data_funnel_effect': fs_funnel,             # FS Submits overall funnel rows
        'node2_data_taxonomy':      melted,                # FS Submits taxonomy direct
    },
    tax_order = taxo_order,                                # ['channel','network','lob','campaign_super']
)
```

**What it does, in three conceptual steps:**

**Step 1.** For each Visits channel-network $(c, n)$ at $(d, t)$,
compute the per-taxonomy proportion within that channel-network:

$$
\pi^{(\text{Vparent})}_{c,n,L,S,\,d,t} \;=\; \frac{\hat{y}^{(\text{Visits tax})}_{c,n,L,S,\,d,t}}{\hat{y}^{(\text{Visits overall})}_{c,n,\,d,t}}
$$

where $(L, S)$ is `(lob, campaign_super)`. So this is "out of all the
Visits attributed to (channel, network) at $(d,t)$, what share went
to this (LOB, campaign_super) subcategory?"

**Step 2.** For each FS Submits overall-level funnel-effect row at
$(d, t)$ — which is "the FS Submits attribution to channel-network
$(c, n)$ that flowed through the Visits funnel" — multiply by the
Visits-level taxonomy proportion to get FS Submits' funnel-effect
attribution at the taxonomy level:

$$
\hat{y}^{(\text{FS tax-funnel})}_{c,n,L,S,\,d,t} \;=\; \hat{y}^{(\text{FS overall-funnel})}_{c,n,\,d,t} \;\cdot\; \pi^{(\text{Vparent})}_{c,n,L,S,\,d,t}
$$

**Step 3.** Concatenate these new funnel-effect rows (tagged `type =
'Funnel Effect'`) with the FS Submits direct-effect taxonomy melted
DataFrame (tagged `type = 'Direct Effect'`). Output: a unified
DataFrame with both attribution types at full taxonomy grain.

**Conceptual reading.** "FS Submits attribution to (channel, network,
LOB, campaign_super) = (the direct effect from the FS Submits
taxonomy model on this row) + (the funnel effect = the FS Submits
attribution to (channel, network) that flowed via Visits, allocated
across taxonomy variants in the same proportion that Visits' own
taxonomy attribution split out)."

This is the **second nested attribution propagation** — the first
was Visits → FS Submits at the channel-network level (in NB2); the
second is Visits-taxonomy → FS-Submits-taxonomy at the taxonomy level
(here in NB4).

> **Interview angle — "How does funnel attribution work at taxonomy
> level?"** *"It's a two-layer propagation. (1) At the overall level
> (channel × network), NB2 computes FS Submits' funnel rows: the
> share of FS Submits' prediction that came from the Visits-variable
> coefficient, allocated across Visits channels by their direct-effect
> shares. (2) At the taxonomy level, NB4 takes those FS Submits
> overall funnel rows and further decomposes them into
> (channel × network × LOB × campaign_super) cells, allocating in
> proportion to how Visits' own taxonomy attribution split within
> each channel-network. The math:
> `FS_tax_funnel(c,n,L,S,d,t) = FS_overall_funnel(c,n,d,t) ×
> Visits_tax(c,n,L,S,d,t) / Visits_overall(c,n,d,t)`. Direct effect
> rows come from the FS Submits taxonomy model's own coefficient.
> Stored separately with `type` column so Marketing can see whether
> a specific (channel × LOB) row got its credit from intent
> (direct) or from awareness funnel (funnel)."*

### B10. Validation — comparing overall sum to taxonomy sum

After funnel effects are applied, NB4 validates the per-channel
taxonomy sum against the overall model's sum for the same channel-
network:

```python
df_pd = spark.sql(f"""
    SELECT channel, network, sum(predicted) as predicted
    FROM {catalog}.{gold_schema}.mmm_model_combined_output_overall_level
    WHERE business_kpi = 'FS Submits' AND version = '{final_model_version}'
    GROUP BY channel, network
""").toPandas()
df_pd['channel_network'] = "|" + df_pd['channel'] + "|" + df_pd['network']
df_filtered = df_pd[df_pd['channel_network'] == channelgrouping]

sum_pred_overall_model = df_filtered['predicted'].sum()
sum_pred_taxonomy      = funnel_taxonomy['predicted'].sum()

if channel_network_key == '|Email|Simon Data':
    tolerance = 0.15 * abs(sum_pred_overall_model)
    if abs(sum_pred_overall_model - sum_pred_taxonomy) >= tolerance:
        raise ValueError(...)
else:
    if int(sum_pred_overall_model) != int(sum_pred_taxonomy):
        raise ValueError(...)
```

**The invariant.** Every channel's taxonomy attribution (direct +
funnel) must sum to its overall attribution. This guarantees that
when you UNION ALL the 15 per-channel taxonomy outputs in NB6, the
total FS Submits attribution at the taxonomy level matches the total
at the overall level — no missing or extra contribution.

**Why 15% tolerance for Email Simon Data.** The taxonomy AOT
recalibration (Section B8) doesn't preserve the total at the
taxonomy level (it has no intercept to absorb the difference). The
overall model did preserve the total at the overall level via the
intercept adjustment. So Email Simon Data's taxonomy sum will be
slightly off from its overall sum, by an amount determined by the
recalibration's per-row deltas. 15% is the empirical tolerance the
team has established as acceptable; other channels have no
recalibration so they must match exactly.

If validation fails, NB4 raises `ValueError` and the parallel task
fails — the bi-weekly job halts and on-call investigates. This is
the right behavior: a taxonomy that doesn't sum to its overall would
silently mis-attribute downstream.

### B11. Final per-channel writes — the combined Spark-ready DataFrame

After funnel effects + validation, NB4 writes the per-channel
combined output to the second staging table:

```python
funnel_effect_data_df = MoDi.get_spark_ready_df_from_melted(
    funnel_taxonomy,
    taxonomy_order = ['channel','network','lob','campaign_super'],
    version = final_model_version,
    funnel_effects = True,
)
funnel_effect_data_df['funneleffect_variable'] = np.where(
    funnel_effect_data_df['funneleffect_variable'] == '', 'Visits',
    funnel_effect_data_df['funneleffect_variable'],
)
funnel_effect_data_df["train_holdout"] = np.where(
    funnel_effect_data_df["week_monday"] < holdout_start_week, "Train", "Holdout"
)
# Drop tactic/initiative columns (they're always 'NA' for 2025+ models)
historical_output = spark.sql(f"select * from {catalog}.{gold_schema}.mmm_model_combined_output_taxonomy_level limit 100")\
    .withColumnRenamed("core_campaign_super", "campaign_super")\
    .withColumnRenamed("core_lob", "lob").toPandas()
historical_output.drop(['tactic','initiative'], axis=1, inplace=True)
Taxonomy_model_output_fe = funnel_effect_data_df[historical_output.columns].copy()
Taxonomy_model_output_fe_spdf = spark.createDataFrame(Taxonomy_model_output_fe)\
    .withColumn("channel_network", lit(channel_network_wop))
Taxonomy_model_output_fe_spdf.write.format("delta").mode("overwrite")\
    .option("replaceWhere", f"channel_network = '{channel_network_wop}'")\
    .insertInto(f"{catalog}.{silver_schema}.mmm_fs_submits_combined_taxonomy_output_staging")
```

After this, the NB4 task for this specific channel-network is done.
The MLflow nested run for this channel is closed. The other 14
parallel NB4 invocations finish independently and each populate
their own slice of the same two staging tables.

---

## Part C — Notebook 5 (Single Variable Channel)

[`5_mmm_fs_submits_taxonomy_single_variable_channel.py`](D:/MMM_Learning/mmm_model/mmm_fs_submits/5_mmm_fs_submits_taxonomy_single_variable_channel.py)
runs once (not in parallel) as the "Taxonomy_Single_Variable" task.
It is currently a no-op for FS Submits because no FS Submits channel
satisfies both `cnt_dict[ch] == 1` AND `ch in list_with_DE`. But the
notebook is structurally important — it exists for completeness, and
it would activate if a future KPI run had a single-variable DE
channel.

### C1. When this notebook runs (the conditions)

The notebook computes:

```python
single_all = [i for i in cnt_dict.keys() if cnt_dict[i] == 1]
single_DE  = [i for i in single_all if i in list_with_DE]
if not single_DE:
    dbutils.notebook.exit(f"No single variable DE channels. Skipping subsequent executions.")
```

If `single_DE` is empty (the FS Submits case), NB5 exits immediately
and writes nothing. If it's non-empty (some other KPI scenario), NB5
proceeds to allocate.

### C2. What it does when active — direct allocation from the overall model

For each channel-network in `single_DE`, NB5:

1. Reads the channel's row(s) from
   `mmm_model_output_overall_level` (NB2's direct-only output) and
   `mmm_model_combined_output_overall_level` (NB2's with-funnel
   output) for the current version and KPI.
2. Joins to a small `fields` DataFrame derived from the taxonomy
   feature column names — which extracts the (channel, network,
   lob, campaign_super) tuple for this channel's single taxonomy
   variant.
3. Sets `modeltype = 'Taxonomy'` on the rows.
4. Writes them as the taxonomy attribution for this channel.

```python
output_overall['modeltype'] = 'Taxonomy'
output_overall_df = spark.createDataFrame(output_overall)
output_overall_df.write.format("delta").option("overwriteSchema", "true")\
    .mode("overwrite")\
    .saveAsTable(f"{catalog}.{silver_schema}.mmm_fs_submits_taxonomy_single_var_channel")
```

Same for the combined output table.

**The conceptual move.** Instead of fitting a Bayesian regression
with one predictor (which would just recover the prior mean), NB5
**directly assigns the overall model's per-channel contribution to
the single taxonomy variant**. This is exact attribution — no model
needed — because by definition, if a channel has only one taxonomy
variant, all of its overall-level effect must come from that
variant.

### C3. Why the fallback exists

Two scenarios where NB5 activates:

**1. A new KPI with a small channel mix.** A future KPI might have a
channel where only one (LOB × campaign_super) combination is active
— in which case it's both a Direct-Effect channel (because it
appears in the overall model) and a single-variable channel (because
it has only one taxonomy row). NB5 handles it without trying to fit
a degenerate regression.

**2. Configuration churn.** The team might temporarily run with one
channel-network restricted to a single LOB/super combination for
testing. Without NB5, that channel's taxonomy output would be missing
from the gold tables.

The notebook is small (~520 lines, mostly boilerplate and table
DDLs) but its existence makes the system robust to taxonomy-shape
changes without code changes — the only intervention required is
updating `cnt_dict` and the DE/noDE lists.

---

## Part D — Notebook 6 (Taxonomy Output Merge)

[`6_mmm_fs_submits_taxonomy_output_merge.py`](D:/MMM_Learning/mmm_model/mmm_fs_submits/6_mmm_fs_submits_taxonomy_output_merge.py)
runs once after all 15 parallel NB4 invocations complete and NB5
either runs or no-ops. It does **two UNION ALL operations** and
writes the final two gold taxonomy tables.

### D1. The two unions

**Direct-effect taxonomy:**

```sql
SELECT model_dma_id, dmacode, week_monday, channel, network, lob,
       campaign_super, model_idv, model_dv, coefficient,
       coef_hdi_2point5_pct, coef_hdi_97point5_pct, predicted_initial,
       predicted_2point5_pct_hdi, predicted, predicted_97point5_pct_hdi,
       spend, impressions, business_kpi, modeltype, mcmc_id, version,
       run_time, p_data_date, train_holdout
FROM <catalog>.<silver_schema>.mmm_fs_submits_taxonomy_model_output_staging
UNION ALL
SELECT same columns
FROM <catalog>.<silver_schema>.mmm_fs_submits_taxonomy_single_var_channel
```

**Combined (after-funnel) taxonomy:**

Same UNION ALL between `..._combined_taxonomy_output_staging` and
`..._combined_taxonomy_single_var_channel`, but the column list
adds `type` and `funneleffect_variable`.

The unions are unweighted — each row of either source becomes one
row of the output. The `channel_network` partition column is dropped
in the SELECT (it's a silver-only artifact for the staging tables;
the gold tables don't need it since they're keyed by `(business_kpi,
version, channel, network, lob, campaign_super)`).

### D2. Column standardization — `lob` → `core_lob`, `campaign_super` → `core_campaign_super`

Before writing to gold, NB6 renames the taxonomy columns to match
the canonical gold-table schema:

```python
taxonomy_final_output = (
    taxonomy_final_output
        .withColumn("tactic", lit("NA"))
        .withColumn("initiative", lit("NA"))
        .withColumnRenamed("campaign_super", "core_campaign_super")
        .withColumnRenamed("lob", "core_lob")
        .select("model_dma_id", "dmacode", "week_monday",
                "channel", "network",
                "core_campaign_super", "core_lob",
                "tactic", "initiative",
                "model_idv", "model_dv",
                "coefficient", "coef_hdi_2point5_pct", "coef_hdi_97point5_pct",
                "predicted_initial", "predicted_2point5_pct_hdi",
                "predicted", "predicted_97point5_pct_hdi",
                "spend", "impressions",
                "business_kpi", "modeltype", "mcmc_id",
                "version", "run_time", "p_data_date", "train_holdout")
)
```

**Why the renames.** Upstream marketing data has two taxonomy fields
each: `lob` / `core_lob` and `campaign_super` / `core_campaign_super`,
where the non-`core_` ones are the original reporting-team
classifications and the `core_` ones are the MMM-team-normalized
classifications (see
[Doc 04 Section 3.1](04_data_lineage_and_schemas.md) for the bronze
table's column list). The MMM models use the `core_*` versions
internally (the silver preprocessing already standardizes), but the
in-memory pandas DataFrames in NB3 / NB4 / NB6 use the shorter
`lob` / `campaign_super` names. The rename at gold-write time aligns
back to the canonical `core_*` names used by every other Zillow team
that reads these tables.

**Why `tactic = 'NA'` and `initiative = 'NA'`.** The gold taxonomy
tables historically had `tactic` and `initiative` columns (5-level
and 6-level taxonomies from pre-2025 models). The 2025+ models
collapsed to 4-level `(channel, network, lob, campaign_super)`, but
the columns remain in the gold schema for backwards compatibility.
NB6 fills them with the literal string `'NA'` on every row.

### D3. Outputs

Two final gold writes:

```python
taxonomy_final_output.write.mode("overwrite").format("delta")\
    .option("replaceWhere", f"business_kpi = 'FS Submits' AND version = '{final_model_version}'")\
    .saveAsTable(f"{catalog}.{gold_schema}.mmm_model_output_taxonomy_level")

taxonomy_combined_final_output.write.mode("overwrite").format("delta")\
    .option("replaceWhere", f"business_kpi = 'FS Submits' AND version = '{final_model_version}'")\
    .saveAsTable(f"{catalog}.{gold_schema}.mmm_model_combined_output_taxonomy_level")
```

These are the canonical **gold taxonomy tables** for FS Submits at
this version. After NB6 completes, the taxonomy portion of the
FS Submits chain is done — NB7 (overall response curves) and NB8
(taxonomy response curves) consume these tables next.

---

## Summary — the NB3 → NB4 → NB5 → NB6 chain

| Stage | Notebook | Key action | Output |
|---|---|---|---|
| Adstock + scale + Hill at taxonomy grain | NB3 | Re-apply the NB1 transformations to the wider taxonomy DataFrame | `mmm_fs_submits_taxonomy_model_input` + 2 empty staging tables |
| Compute cnt_dict | NB3 | Count taxonomy variants per channel-network; write to `config_param.yml` | `cnt_dict` map persisted |
| For each channel in DE ∪ noDE (×15 parallel) | NB4 | (a) if single-var DE, skip; (b) build DE or noDE data; (c) fit Bayesian Taxonomy model; (d) register UC model; (e) build melted; (f) AOT recal if Email; (g) funnel effects; (h) validate; (i) write to staging | 2 staging-table slices per channel |
| For single-var DE channels | NB5 | Direct allocation of overall model output (no fit) | 2 single-var tables |
| UNION ALL + rename + final write | NB6 | UNION ALL staging ∪ single-var, rename lob/campaign_super → core_*, write gold | `mmm_model_output_taxonomy_level` + `mmm_model_combined_output_taxonomy_level` |

**The 4-notebook chain at a glance.**

```
NB3 (single task, sequential)
  └─ reads silver taxonomy + overall melted; writes input + staging shells
       │
       ▼
NB4 (15 parallel tasks, one per channel-network)
  ├─ task for Owned Social|Facebook      ──┐
  ├─ task for Display|Media Agency       ──┤
  ├─ task for Linear TV|Media Agency     ──┤
  ├─ task for Connected TV|Media Agency  ──┤
  ├─ task for Paid Social|TikTok         ──┤
  ├─ task for Paid Social|Facebook       ──┤
  ├─ task for SEM|Google Search          ──┤  all write to the same 2
  ├─ task for SEM|Google Performance Max ──┤  staging tables, partitioned
  ├─ task for Email|Simon Data           ──┤  by replaceWhere channel_network
  ├─ task for Email|Sparkpost            ──┤
  ├─ task for Paid Social|Pinterest      ──┤
  ├─ task for SEM|Microsoft Search       ──┤
  ├─ task for App|Apple Search           ──┤
  ├─ task for Owned Social|TikTok        ──┤
  └─ task for Online Video|Media Agency  ──┘
       │
       ▼
NB5 (single task, no-op for FS Submits)
  └─ if any single-variable DE channels existed, allocate directly
       │
       ▼
NB6 (single task, sequential)
  └─ UNION ALL → rename → write 2 gold taxonomy tables
```

---

## Interview-angle recap

> **Interview angle — "How does your model scale to a deeper
> taxonomy?"** *"Three architectural choices. (1) Granularity split:
> overall model fits at channel × network only (~25 features); a
> separate set of taxonomy models fits at channel × network × LOB ×
> campaign_super (~70 features total, but split into 15 per-channel-
> network sub-models of ~5 features each). (2) Per-channel sub-model
> isolation: each channel-network's taxonomy decomposition is its
> own Bayesian model, with the dependent variable constructed from
> the overall model's per-channel attribution — so the taxonomy
> models are decomposing a known total, not estimating it from
> scratch. (3) Parallel execution: the 15 sub-models run as parallel
> Databricks tasks on CPU clusters (~15-30 minutes each in parallel
> on a 1-3 CPU autoscale cluster), writing non-overlapping slices to
> shared staging tables via `replaceWhere`. The scaling is sub-
> linear in taxonomy depth because the parallelism absorbs the
> additional models."*

> **Interview angle — "How is taxonomy contribution calibrated to
> business expectations?"** *"Two mechanisms. (1) Per-channel
> contribution invariant — the taxonomy model's job is decomposition,
> not estimation. The dependent variable is the overall model's
> per-channel attribution, and `get_melted_data_for_business_diagnostics`
> applies an error-correction step (Doc 02 Section 9.7) that
> proportionally rescales the taxonomy contributions to sum to the
> actual KPI per DMA-week. (2) AOT recalibration for Email Simon
> Data: the taxonomy melted DataFrame for Email is recalibrated to
> match the AOT-derived `adjusted_target_aot_value` set by NB2 (the
> overall model), so the taxonomy attribution matches AOT ground
> truth. (3) Validation: at the end of NB4 for each channel, the
> sum of taxonomy contributions is compared against the overall
> model's per-channel attribution. Exact match required for all
> channels except Email Simon Data, which has a 15% tolerance to
> account for the recalibration's per-row deltas that aren't
> absorbed into an intercept at the taxonomy level."*

> **Interview angle — "Walk me through the difference between
> Direct-Effect and no-Direct-Effect channels in your taxonomy
> setup."** *"Two classifications in `config_param.yml`. (1)
> `list_with_DE` channels (e.g., Paid Social Facebook, SEM Google
> Search, Email Simon Data) — these have a real, identifiable
> direct relationship with FS Submits in the overall model. Their
> taxonomy models fit a regression decomposing the overall per-
> channel attribution into per-(LOB × campaign_super) shares. (2)
> `list_noDE` channels (e.g., Linear TV, Connected TV, OOH, Online
> Video) — these have no direct effect on FS Submits in the overall
> model (they're upper-funnel awareness channels); their FS Submits
> attribution flows entirely through Visits. Their taxonomy models
> fit a regression with target = 0 (coefficients shrink to zero,
> producing zero direct effect), and then the funnel-effect step
> propagates the upstream Visits-level taxonomy attribution
> proportionally to give them their FS Submits attribution. Both
> types use the same Bayesian model class — the difference is
> entirely in how the dependent variable is constructed in the data
> prep step."*

---

**Next:** Read [07_response_curves_and_stability.md](07_response_curves_and_stability.md)
for NB7 (overall response curves), NB8 (taxonomy response curves),
and NB9 (stability loop) — the downstream artifacts that consume the
attribution tables this chain produced and turn them into the
budget-optimization output that Marketing actually uses.
