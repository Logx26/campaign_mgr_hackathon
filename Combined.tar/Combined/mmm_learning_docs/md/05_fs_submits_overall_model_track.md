---
doc_id: 05
title: FS Submits — Overall Model Track (Notebooks 1 and 2)
companion_docs:
  - 00_mmm_ecosystem_overview.md (system map)
  - 01_mmm_methodology_primer.md (the math behind every step here)
  - 02_rapidmmm_library_internals.md (the library classes called in this notebook)
  - 03_shared_utils_and_upstream_preprocessing.md (where the input silver tables come from)
  - 04_data_lineage_and_schemas.md (the tables read and written here)
  - 06_fs_submits_taxonomy_chain.md (next doc — picks up at NB3)
---

# 05 — FS Submits Overall Model Track (Notebooks 1 and 2)

> **What this doc is.** The first end-to-end walk through actual KPI
> notebook code. Specifically, the two notebooks that together produce
> FS Submits' overall-level direct-and-funnel attribution. Notebook 1
> turns silver preprocessing data into model-ready features; Notebook 2
> fits the Bayesian model, applies funnel effects from Visits, recalibrates
> Email Simon Data against AOT-measured incrementality, and writes the
> two gold output tables.
>
> **Why FS Submits specifically.** FS Submits is the primary monetizable
> Zillow event (For-Sale lead → Premier Agent connection → revenue) and
> the canonical reference KPI in this codebase. The four non-ZHL KPIs
> share this notebook structure almost exactly — once you understand
> FS Submits, you understand Visits, Rental Visits, and MF Submits by
> delta.
>
> **The chain at a glance.**
>
> ```text
>   mmm_input_preprocessing_overall_data   (silver, KPI-agnostic — from MMM Input Job)
>                       │
>                       ▼
>     NB1 — Feature Engineering
>       adstock → SoV scale → split → MeanScale →
>       Atan (specific cols) → Hill → holidays + seasonal + anomaly flags
>                       │
>                       ▼
>           mmm_fs_submits_final_data_for_modeling   (silver)
>                       │
>                       ▼
>     NB2 — Overall Model
>       Bayesian hierarchical fit (NUTS) → diagnostics gate (≤3 retries) →
>       register in Unity Catalog → predict on train + holdout →
>       melted attribution → funnel effects from Visits →
>       AOT recalibration for Email Simon Data → gold writes
>                       │
>                       ▼
>      mmm_model_output_overall_level             (direct effect only)
>      mmm_model_combined_output_overall_level   (direct + funnel + AOT recal)
> ```
>
> **Math depth.** Heavy in Part B (the Bayesian model definition, the
> funnel-effect attribution, and the AOT recalibration are all derived).
> Part A is mostly orchestration over already-explained transforms.

---

## Part A — Notebook 1 (Feature Engineering)

[`1_mmm_fs_submits_feature_engineering.py`](D:/MMM_Learning/mmm_model/mmm_fs_submits/1_mmm_fs_submits_feature_engineering.py)
runs as the "Feature_Engineering" task in the MMM FS Submits Job. It
reads `mmm_input_preprocessing_overall_data` (the silver table from the
MMM Input Job) and writes three per-KPI silver outputs.

### A1. Inputs, version handling, MLflow setup

The notebook's setup phase does five things, in order:

**Widgets.** Eleven widget parameters: `catalog, silver_schema, gold_schema,
environment, ml_experiment_path, train_start_week, train_end_week,
holdout_start_week, holdout_end_week, model_version_number, job_name,
job_id, run_id`. Defaults are dev-friendly (`sandbox_desa`,
`9999-12-31` sentinels for dates, `"NA"` for version).

**Environment bootstrap** (dev only):

```python
if environment == "development":
    silver_schema, gold_schema, ml_experiment_path, experiment_id = \
        create_or_get_dev_environment_variables(
            'mmm_fs_submits', catalog, silver_schema, gold_schema, ml_experiment_path
        )
    dbutils.notebook.run(path=str(mmm_final_table_creation_notebook_path),
                          timeout_seconds=1200)
```

This rewires the schemas to `dev_{username}` and bootstraps the gold
tables with the latest prod snapshot (see [Doc 03 Section 2.5](03_shared_utils_and_upstream_preprocessing.md)).

**Version auto-increment.** The same pattern used everywhere — read
max `vN` from `mmm_model_combined_output_overall_level WHERE business_kpi
= 'FS Submits'`, increment to `vN+1`, set `latest_model_version =
'vN'` (for downstream stability comparisons).

**Date window derivation.** When all four date widgets are the sentinel
`'9999-12-31'`, calls `get_train_holdout_dates(catalog, gold_schema,
'FS Submits', latest_model_version)` to derive the canonical
(train_start, train_end, holdout_start, holdout_end,
response_curves_start) 5-tuple (see [Doc 03 Section 2.2](03_shared_utils_and_upstream_preprocessing.md)
for the derivation rules).

**MLflow run hygiene.**

```python
clean_active_runs_for_experiment(ml_experiment_path)
parent_run_id = get_or_create_parent_run(
    experiment_id, run_name_prefix=f"mmm_fs_submits_{final_model_version}_"
)
mlflow.start_run(
    run_name=f"mmm_fs_submits_feature_engineering_{final_model_version}_"
             + date.today().strftime("%Y_%m_%d"),
    nested=True,
)
mlflow.set_tag("mlflow.parentRunId", parent_run_id)
mlflow.set_tag("run_type", "child")
```

Establishes a single parent MLflow run for the entire bi-weekly FS
Submits session (under which NB1, NB2, NB3, NB4×15 parallel, NB6, NB7,
NB8, NB9 will all log as nested child runs).

### A2. The transformation pipeline at a glance

A single diagram of the stages, in execution order:

```
silver mmm_input_preprocessing_overall_data
                │
                ▼
[rename Delta-sanitized cols → pipe-separated names]   (using mmm_input_config.yml mapping)
                │
                ▼
[fillna(0) on remaining nulls]
                │
                ▼
[drop config-excluded channel|networks]   (config_param.yml: excluded_channel_network_list)
                │
                ▼
[adstock per channel-network]   (FeatureEngineeringAdStock, with params from
                                 adstock_hill_best_params)
                │
                ▼
[merge macroeconomic features from feature store]   (mmm_automation_exogenous_feature_store)
                │
                ▼
[SoV scaling on 3 specific channels]   (config_param.yml: sov_cols)
                │
                ▼
[split train ← holdout based on train_holdout column]
                │
                ▼
[MeanScalingRegional fit on train, transform train + holdout]   (excluding SoV cols)
                │
                ▼
[Atan transform on 8 specific columns]   (config_param.yml: transform_cols_atan)
                │
                ▼
[Sigmoid transform — config-toggleable, currently None for FS Submits]
                │
                ▼
[Hill transform on all impression columns]   (per-channel slope + shape from
                                              Saturation_best_params)
                │
                ▼
[merge 5 holiday one-hot flags]   (Christmas, Independence, Thanksgiving, NY, Memorial)
                │
                ▼
[merge per-DMA seasonal component from multiplicative STL of Visits time series]
                │
                ▼
[add date flags for known anomalies]   (config_param.yml: date_flags = {2024-01-08 dip})
                │
                ▼
[concat train + holdout, write 3 silver tables]
```

The eight-step "transform" sub-flow is the single piece that's
KPI-specific — choice of channels excluded, the SoV-targeted columns,
the Atan-targeted columns, and (most importantly) the per-channel adstock
+ Hill parameters all come from `config_param.yml`.

### A3. Adstock — applied per channel, with Linear TV as the worked example

`FeatureEngineeringAdStock` is the orchestrator class (see
[Doc 02 Section 2.2](02_rapidmmm_library_internals.md)). It receives
`params_dict = config_param.yml::adstock_hill_best_params`, which for
FS Submits has 26 channel-network entries.

The interesting one is **Linear TV|Media Agency**:

```yaml
'|Linear TV|Media Agency':
  AdStock: Delayed
  params:
    max_lag: 9
    decay_rate: 0.9
    delay: 5
  Saturation_best_params:
    slope: 0.371
    shape: 0.009
```

These adstock parameters mean: weight kernel
$w_i = 0.9^{(i - 5)^2}$ for lags $i \in \{0, 1, \ldots, 9\}$. The peak
weight occurs at lag 5 (where $0.9^0 = 1$), and falls off
*quadratically* away from that peak:

| Lag $i$ | $(i - 5)^2$ | $w_i = 0.9^{(i-5)^2}$ | Normalized weight |
|---|---|---|---|
| 0 | 25 | 0.072 | 0.013 |
| 1 | 16 | 0.185 | 0.034 |
| 2 | 9 | 0.387 | 0.072 |
| 3 | 4 | 0.656 | 0.121 |
| 4 | 1 | 0.900 | 0.166 |
| 5 | 0 | **1.000** ← peak | 0.184 |
| 6 | 1 | 0.900 | 0.166 |
| 7 | 4 | 0.656 | 0.121 |
| 8 | 9 | 0.387 | 0.072 |
| 9 | 16 | 0.185 | 0.034 |

**Business reading.** Linear TV's effect on FS Submits peaks five weeks
after the spot airs and remains material through weeks 3–7 (where the
normalized weights are still > 12%). This is consistent with how
broadcast advertising builds in long-term memory before driving lower-
funnel action — a TV ad someone saw in week $t$ might make them search
for "homes for sale near me" in week $t + 5$, click an SEM ad, and
convert.

Contrast with **SEM|Google Search**, which is intent-driven:

```yaml
'|SEM|Google Search':
  AdStock: Delayed
  params:
    max_lag: 1
    decay_rate: 0.05
    delay: 1
```

$w_0 = 0.05^1 = 0.05$, $w_1 = 0.05^0 = 1$. Normalized: 0.05 and 0.95. So
SEM contribution at week $t$ is **95% from week $t$** + 5% from the
prior week — almost all same-week effect. People search, see the ad,
and submit within days.

The full list of channel-by-channel adstock variants for FS Submits is
in `config_param.yml`. The pattern: **awareness channels (Linear TV,
Connected TV, OOH, Online Video) have long delayed adstock; intent
channels (SEM, App, Push) have near-zero adstock; social channels
(Paid/Owned Facebook, TikTok, Pinterest) are somewhere in between**.

The implementation invariant: after this stage, each channel-network
has been replaced by a single adstocked column with the parameter suffix
encoded in its name, e.g.,
`impressions|Linear TV|Media Agency_delayed_lag_9_decay_0.9_delay_5`.
The downstream pipeline never needs to re-derive the parameters because
they're baked into the column name itself.

### A4. SoV scaling — three FS Submits channels

After adstock and macroeconomic merge, three channels get **Share of
Voice scaling** (rather than using raw adstocked impressions):

```yaml
sov_cols:
- impressions|Paid Social|Pinterest_exponential_decay_0.4_length_3
- impressions|Paid Social|TikTok_delayed_lag_2_decay_0.2_delay_0
- impressions|Display|Media Agency_delayed_lag_5_decay_0.8_delay_2
```

For each row (DMA × week), each SoV column is divided by the **sum of
all adstocked impression columns** in that row:

$$
\text{SoV}_{c, d, t} = \frac{\tilde{x}_{c, d, t}}{\sum_{c'} \tilde{x}_{c', d, t}}
$$

In code:

```python
adstock_merged_data_sov[sov_cols] = adstock_merged_data_sov.apply(
    lambda x: x[sov_cols] / x[impression_cols_transformed].sum(),
    axis=1,
)
```

**Why these three.** Pinterest, TikTok, and Display Media Agency are
campaign-burst channels — they spend in concentrated short bursts then
go quiet. Raw adstocked impressions would tell the model "10× more
impact in burst weeks" but the *competitive attention dimension* is
what actually drives effect for these channels (other competitors are
also active during the same retail moments). SoV captures "share of
brand voice in this DMA-week" — bounded in [0, 1], natively normalizes
out the burstiness.

The other 23 channels keep their raw adstocked values because their
spend is smooth enough that absolute volume predicts effect linearly
within the plausible range.

### A5. MeanScalingRegional — the train/holdout contract

After SoV, the data is split into train (`train_holdout == "Train"`) and
holdout (`train_holdout == "Holdout"`). Then `MeanScalingRegional` is
applied — **but only to the non-SoV columns** (since SoV is already
bounded in [0, 1] and re-scaling would distort the bound):

```python
msr = MeanScalingRegional(
    regioncol='dmacode', Train=True,
    columns=list([i for i in adstock_merged_data_exc.columns
                  if i not in ['dmacode', 'dma_regionid', 'week_monday', 'train_holdout']]),
)
train_scaled_data_exc = msr.fit(data=train_selected_input_data_exc)\
                          .transform(data=train_selected_input_data_exc)
holdout_scaled_data_exc = msr.transform(data=holdout_selected_input_data_exc)
```

The contract is **fit on train, transform on holdout** — the same
per-DMA means computed from training data are reapplied to holdout.
This prevents leakage: if holdout means leaked into the scaler, the
model would see a future-information signal during training. After
this transform, every (non-SoV) impression column has been
divided by its DMA-specific training mean — making the model
coefficients **elasticity-like** in interpretation (see
[Doc 01 Section 6.5](01_mmm_methodology_primer.md)).

The SoV columns are then re-joined into the scaled DataFrames so the
final feature matrix has both scaled-raw and SoV-bounded variables.

### A6. Atan (specific cols) then Hill (all cols) — the saturation order

Two non-linear transforms are applied after scaling:

**Atan first**, on 8 specific FS Submits channels (per
`config_param.yml::transform_cols_atan`):

```yaml
transform_cols_atan:
- impressions|App|Google UAC_delayed_lag_1_decay_0.3_delay_0
- impressions|Online Video|Media Agency_delayed_lag_8_decay_0.8_delay_4
- impressions|Native|Media Agency_exponential_decay_0.7_length_6
- impressions|Paid Social|Facebook_delayed_lag_1_decay_0.05_delay_1
- impressions|Owned Social|TikTok_exponential_decay_0.7_length_5
- impressions|Email|Sparkpost_exponential_decay_0.3_length_2
- impressions|Email|Simon Data_exponential_decay_0.6_length_1
- impressions|SEM|Google Search_delayed_lag_1_decay_0.05_delay_1
```

Atan compresses heavy-tailed values into a bounded range without
flipping the sign. For these eight channels, the post-MeanScaling values
have outlier weeks (rare bursts that dominate the distribution); Atan
pulls those outliers in without distorting the rest of the distribution.

**Hill second**, on **all** impression columns. The per-channel slope
+ saturation come from `Saturation_best_params` in the adstock config.
Example for Linear TV:

```yaml
'|Linear TV|Media Agency':
  Saturation_best_params:
    slope: 0.371   # very gentle
    shape: 0.009   # saturation kicks in very early
```

Slope 0.371 < 1 means concave from the start (immediate diminishing
returns — Linear TV is already near saturation at current spend
levels). Shape 0.009 is tiny — saturation begins almost immediately
above zero. This combination encodes "Linear TV's marginal impact on
FS Submits is small and quickly saturates" — which is consistent with
the fact that FS Submits is a lower-funnel KPI and TV is upper-funnel.

The order **Atan-then-Hill** matters: Atan compresses outliers so they
don't dominate the Hill curve fit, then Hill applies the (per-channel
parameterized) saturation. If Hill ran first on an unscaled heavy-
tailed input, the outliers would push the curve into the asymptote and
the saturation parameter would be meaningless.

The Sigmoid transform (`transform_cols_sigmoid: null` for FS Submits)
is config-toggleable but currently not used. If it were enabled, it
would run *after* Atan and *before* Hill.

### A7. Holidays, seasonality, and the January 2024 anomaly flag

After feature engineering, three exogenous features are merged in.

**Holidays.** The shared holidays table (`marketing.rapidmmm_silver.mmm_holidays`)
contains every US holiday through 2032. The notebook joins it to the
day-grain calendar, pivots into one-hot indicators per holiday name,
then selects the five federal holidays specified in `config_param.yml::holiday_var_list`:

```yaml
holiday_var_list:
- Christmas Day
- Independence Day
- Thanksgiving
- New Year's Day
- Memorial Day
```

These become 5 new columns (each 0 or 1) in the modeling DataFrame.
The Bayesian model fits a coefficient for each; the sign is
unconstrained (controls can be negative).

**Seasonal component via multiplicative STL.** The notebook re-queries
the historical Visits data (`data_name = 'visits' AND metric =
'visits'`, since 2020-01-01), aggregates to per-DMA × week, fills
missing weeks via seasonal week-of-year averaging, then runs
`statsmodels.tsa.seasonal.seasonal_decompose(x, model='multiplicative')`
per DMA. The `.seasonal` component is extracted, joined back to the
modeling data on `(dmacode, week_monday)`, and becomes the `seasonal`
column.

For the holdout period (which is *future* relative to the training
data), the seasonal value is computed from the week-of-year averages
of the training seasonal component:

```python
seasonal_pattern = seasonal.groupby(['dmacode', 'weekofyear'])['seasonal'].mean().reset_index()
holdout_hill_transformed_data['weekofyear'] = holdout_hill_transformed_data['week_monday'].dt.isocalendar().week
holdout_hill_transformed_data = holdout_hill_transformed_data.merge(
    seasonal_pattern, on=['dmacode', 'weekofyear'], how='left'
)
```

So the holdout's seasonal value at week 15 of 2025 = average of the
training seasonal component for week 15 across all prior years for that
DMA.

**Why use Visits' seasonal pattern for FS Submits?** Because the
seasonal demand for *buying a home* drives both Visits and FS Submits in
parallel, and Visits has much richer historical data (back to 2020).
Using FS Submits' own time series would have shorter history and more
noise.

**Anomaly date flags.** FS Submits has one known anomaly:

```yaml
date_flags:
  fs_submits_2024_01_08_dip_flag: '2024-01-08'
```

For the week of 2024-01-08, an upstream data issue caused FS Submits to
register an unusual dip. Without a flag, the model would absorb that
dip into the coefficients (under-attributing the channels active that
week). The flag becomes a single-week one-hot indicator, the model
fits a coefficient on it (which absorbs the dip), and the other
coefficients are protected from distortion.

### A8. Outputs

Three Delta tables get written by NB1 via `intermediate_and_meta_table_write`:

| Table | Contents |
|---|---|
| `mmm_fs_submits_adstock_transformed_data` | Adstocked impressions (one column per channel-network with adstock suffix in name) + dma keys + train_holdout flag + target columns. Used by NB2's melted-attribution step. |
| `mmm_fs_submits_final_data_for_modeling` | The fully-transformed modeling DataFrame — adstocked + (SoV-scaled where applicable) + MeanScaled + Atan + Hill + holidays + seasonal + anomaly flag + train_holdout flag. **The input to the Bayesian model.** |
| `mmm_fs_submits_corr_post_fe` | Long-form correlation matrix of all features post-transform — for EDA / QC dashboards |

Each Delta write goes through `intermediate_and_meta_table_write`, which
also appends a row to `mmm_model_job_metadata_detail` (in stage/prod)
recording the job_id, run_id, delta_table_version, and dates_list_used.

The MLflow child run is then closed. The next task (NB2) starts a fresh
nested run under the same parent.

> **Interview angle — "Walk me through your feature-engineering pipeline."**
> *"Twelve stages in NB1, all driven by config. Start with the shared
> silver preprocessing table (already validated against the
> taxonomy whitelist and pivoted to wide format). Drop a small set of
> excluded channel-networks per config. Apply per-channel adstock —
> which variant and which parameters are dispatched from
> `adstock_hill_best_params` in the config YAML, so adding a channel
> means a config change, not a code change. Merge in macroeconomic
> variables from the Databricks Feature Store. Apply SoV scaling to
> three campaign-burst channels — Pinterest, TikTok, Display Media
> Agency. Split into train and holdout. Apply per-DMA mean scaling so
> coefficients become elasticity-like, fit on train and reapply to
> holdout. Apply Atan to 8 heavy-tailed channels — these are channels
> with rare burst weeks that would otherwise dominate the next step.
> Apply Hill saturation to all impression columns, with per-channel
> slope and saturation from config. Merge five federal holiday one-hot
> flags. Compute a per-DMA seasonal component from a multiplicative
> STL decomposition of historical Visits, applied as a regression
> control. Add manual date flags for known anomalies (FS Submits has
> one: a January 2024 data dip). Concatenate train + holdout, write
> three silver tables. The whole pipeline is config-driven — no
> business decisions live in code."*

---

## Part B — Notebook 2 (Overall Model Build and Post-Processing)

[`2_mmm_fs_submits_overall_model.py`](D:/MMM_Learning/mmm_model/mmm_fs_submits/2_mmm_fs_submits_overall_model.py)
is where the actual Bayesian model gets fit, predictions get generated,
funnel effects from Visits get layered in, Email Simon Data gets
recalibrated against AOT, and the final gold tables get written.

### B1. Reading the modeling data + priors

**Read silver, restore pipe-separated names:**

```python
data = spark.table(f"{catalog}.{silver_schema}.mmm_fs_submits_final_data_for_modeling")
mapping = get_yaml_value('config_table_mapping.yml', 'mmm_fs_submits_final_data_for_modeling')
reverse_mapping = {v: k for k, v in mapping.items()}
for old_name, new_name in reverse_mapping.items():
    if old_name in data.columns:
        data = data.withColumnRenamed(old_name, new_name)
data = data.toPandas().sort_values(['dmacode', 'week_monday']).reset_index(drop=True)
```

**Drop config-excluded channels.** A second exclusion list runs at the
model-input layer (separate from the NB1 `excluded_channel_network_list`):

```yaml
exclude_channels_bfr_model:
- App|Apple Search
- App|Google UAC
- Audio|Media Agency
- Audio|Radio
- Online Video|YouTube
- Display|Video Demand Gen
- SEM|Microsoft Search
- App|Facebook
- Native|Media Agency
- Owned Social|TikTok
- Online Video|Media Agency
```

These are channels whose direct effect on FS Submits is empirically
weak — they're in the silver table (because other KPIs like Visits need
them) but get dropped before the FS Submits model fit so the design
matrix is more identifiable. **Critically, dropping these here does
not eliminate their effect on FS Submits — most of them will still
get attribution via the funnel-effect step (Section B7) because they
drove Visits which drove FS Submits.**

**Split train and holdout:**

```python
train_data = data[data["train_holdout"] == "Train"].copy()
holdout_data = data[data["train_holdout"] == "Holdout"].copy()
```

**Define feature columns:**

```python
train_x_col = list(train_data.columns.difference(
    ['dma_regionid', 'week_monday', 'dmacode', target_variable]
))
```

**Load priors:**

```python
priors = pd.read_csv(f"{artifacts_file_path}/mmm_fs_submits_priors.csv")
priors["Mean"].fillna(0, inplace=True)
```

The priors CSV is the most important configuration artifact for the
model. A few example rows from
[`mmm_fs_submits_priors.csv`](D:/MMM_Learning/mmm_model/mmm_fs_submits/artifacts/mmm_fs_submits_priors.csv):

| `column` (with adstock suffix) | Mean | Sd | Interpretation |
|---|---|---|---|
| `impressions\|Paid Social\|Facebook_delayed_lag_1_decay_0.05_delay_1` | **5.0** | **0.02** | **Extremely informative** — coefficient is essentially pinned at 5.0, the data can shift it by at most ±0.04. This is a previously-AOT-calibrated value the team trusts. |
| `impressions\|Paid Social\|Pinterest_exponential_decay_0.4_length_3` | 10.0 | 0.014 | Same pattern — pinned at 10.0 |
| `impressions\|SEM\|Google Search_delayed_lag_1_decay_0.05_delay_1` | 0.159 | 0.0001 | Pinned at 0.159 — SEM Google Search elasticity is treated as known |
| `impressions\|Native\|Media Agency_exponential_decay_0.7_length_6` | 0.054 | 0.026 | Mildly informative — central estimate from prior version, some movement allowed |
| `impressions\|Owned Social\|Facebook_exponential_decay_0.6_length_3` | 0.0066 | 0.0013 | Tight prior on a small value |
| `impressions\|Email\|Iterable_exponential_decay_0.3_length_2` | 0.0 | **1.0** | **Uninformative** — Mean=0 Sd=1 says "let the data decide" |
| `impressions\|Email\|Simon Data_exponential_decay_0.6_length_1` | 0.0 | 1.0 | Same — uninformative |
| `impressions\|Email\|Sparkpost_exponential_decay_0.3_length_2` | 0.0 | 1.0 | Same — uninformative |
| `impressions\|Push\|null_delayed_lag_1_decay_0.01_delay_0` | 0.0 | 1.0 | Same — uninformative |
| `impressions\|Operational Emails\|Iterable_Simon Data_delayed_lag_1_decay_0.01_delay_0` | 0.0 | 1.0 | Same |

**The asymmetry is intentional.** Two patterns are visible:

1. **Pinned channels** (Paid Social Facebook, Pinterest, SEM, Native,
   Owned Social Facebook, etc.) — channels where the team has high
   confidence in the previous version's coefficient (often validated
   against AOT). Sd ≤ 0.03. These coefficients are essentially
   locked across runs to prevent drift.

2. **Uninformative-prior channels** (all four Email variants, Push,
   Operational Emails) — channels that **will be recalibrated by AOT
   post-fit** (in the case of Email Simon Data, Section B9) or that have
   weak/noisy signal where the team prefers to let each run's data
   re-determine the coefficient. Sd = 1.0 effectively means a flat
   prior on the truncated half-line.

For the math of how `Mean` and `Sd` feed the NumPyro model, see
[Doc 02 Section 4.2](02_rapidmmm_library_internals.md) — these become
the `prior_mu` and `prior_sd` arrays passed to `TruncatedNormal(low=0)`
for impression coefficients and `Normal()` for controls.

### B2. The Bayesian model construction

NB2 instantiates `rapidmmm.Model.BayesianModel.Model` with FS Submits-
specific arguments and fits via NUTS:

```python
mdl = mt.Model(
    region_col = ['dmacode'],
    X_col = train_x_col,                          # ~15-20 cols after exclusions
    y_col = target_variable,                       # 'value|leads|fs_submits'
    priors = priors,
    hierarchical = True,
    samples = 2000,
    warmup = 1000,
    nonnegative = True,                            # truncated priors on impressions
    modeltype = 'Overall',                         # includes per-DMA α intercept
    channelgrouping = None,                        # default 'ChannelNetwork'
)
```

The model that gets built — written out as a generative
probabilistic program — is, for each DMA $d \in \{1, \ldots, D\}$ and
week $t$:

**Hyperpriors (population-level):**

$$
\mu_\alpha \sim \text{TN}(0, 1; \text{low}=0)
\qquad
\sigma_\alpha \sim \text{HalfNormal}(5)
$$

For impression channels $c$ (with informative or uninformative priors
from the CSV):

$$
\mu_{\beta_c}^{(+)} \sim \text{TN}\!\left(\text{prior\_mu}_c, \text{prior\_sd}_c; \text{low}=0\right)
$$

For non-impression controls $k$ (holidays, seasonal, macroeconomic,
anomaly flags):

$$
\mu_{\beta_k}^{(0)} \sim \mathcal{N}\!\left(\text{prior\_mu}_k, \text{prior\_sd}_k\right)
$$

For both:

$$
\sigma_{\beta_c} \sim \text{HalfNormal}\!\left(\text{prior\_sigma\_sd}_c\right)
$$

**DMA-level random effects (partial pooling):**

$$
\alpha_d \sim \text{TN}(\mu_\alpha, \sigma_\alpha; \text{low}=0)
$$

$$
\beta_{c,d}^{(+)} \sim \text{TN}\!\left(\mu_{\beta_c}^{(+)}, \sigma_{\beta_c}; \text{low}=0\right)
\qquad
\text{(impression channels)}
$$

$$
\beta_{k,d}^{(0)} \sim \mathcal{N}\!\left(\mu_{\beta_k}^{(0)}, \sigma_{\beta_k}\right)
\qquad
\text{(controls)}
$$

**Data-level mean (linear combination, post-transform features):**

$$
\hat{y}_{d,t} = \alpha_d
   + \sum_{c \in \text{impressions}} \beta_{c,d}^{(+)} \cdot \bar{x}_{c,d,t}
   + \sum_{k \in \text{controls}}    \beta_{k,d}^{(0)} \cdot z_{k,d,t}
$$

where $\bar{x}_{c,d,t}$ is the channel $c$'s adstocked + SoV-or-MeanScaled
+ (Atan or not) + Hill-saturated feature value at $(d, t)$, and
$z_{k,d,t}$ is the control's scaled value (or, for holiday flags and
anomaly flags, a 0/1 indicator).

**Likelihood:**

$$
\sigma \sim \text{HalfNormal}(5)
\qquad
y_{d,t} \sim \mathcal{N}\!\left(\hat{y}_{d,t}, \sigma\right)
$$

**Concrete intuition for FS Submits.** The model says: "FS Submits in
DMA $d$ at week $t$ is the sum of (a) an always-positive baseline
$\alpha_d$ that the model lets vary per DMA, (b) the saturated
adstocked impressions of each channel, each weighted by a non-negative
DMA-specific coefficient drawn from a shared per-channel population
prior, and (c) the holidays, macroeconomic indicators, seasonal
pattern, and anomaly flags weighted by unrestricted DMA-specific
coefficients. Each observation has noise $\sigma$ shared across all
DMA-weeks."

The hierarchical partial pooling — DMA coefficients drawn from a
shared per-channel population mean — is what makes this work: NYC and
rural-PA can have different SEM coefficients, but both are pulled
toward the national mean by an amount proportional to how much their
local data supports their estimate.

> **Interview angle — "How is your MMM model formulated mathematically?"**
> *"It's a hierarchical Bayesian regression at DMA-week level. For FS
> Submits the dependent variable is `value|leads|fs_submits` per
> `(dma × week)`. The mean is a linear combination: a per-DMA intercept
> α_d plus channel coefficients β_{c,d} times saturated-adstocked
> impressions plus control coefficients γ_{k,d} times macroeconomic
> indices and holiday flags. The per-DMA coefficients are partially
> pooled — each is drawn from a per-channel population distribution
> whose mean is itself a random variable with a TruncatedNormal prior
> for media (non-negativity) and Normal prior for controls. The prior
> hyperparameters come from a CSV that's hand-tuned per channel —
> pinned tightly (Sd ~0.01) for channels validated against AOT, and
> uninformative (Sd 1.0) for channels we plan to recalibrate post-fit.
> Likelihood is Normal(ŷ, σ). The whole thing is fit with NumPyro NUTS
> at 2000 samples and 1000 warmup on a single chain."*

### B3. MCMC sampling and the diagnostic retry wrapper

The fit itself is wrapped in a custom retry loop defined in NB2 at
line 372: `run_model_with_accept_prob_and_divergence_check`. The full
function is described in
[Doc 02 Section 4.5](02_rapidmmm_library_internals.md); the essential
shape:

```python
def run_model_with_accept_prob_and_divergence_check(mdl, data, threshold_accept_prob,
                                                    max_divergences, max_retries=3,
                                                    num_chains=1):
    for attempt in range(max_retries):
        mdl_mcmc = mdl.ModelBuild(data, num_chains=num_chains)
        extra_fields = mdl_mcmc.get_extra_fields()
        mean_accept_prob = jnp.mean(extra_fields["accept_prob"])
        divergence_count = int(jnp.sum(extra_fields["diverging"]))

        accept_prob_ok = min_thresh <= mean_accept_prob <= max_thresh
        divergence_ok  = divergence_count <= max_divergences

        if accept_prob_ok and divergence_ok:
            return mdl_mcmc
    raise RuntimeError(...)
```

The thresholds come from `config_param.yml`:

```yaml
perc_divergence: 0.15        # divergences ≤ 15% of samples = 300 out of 2000
threshold_accept_prob:
- 0.6                         # mean accept_prob ≥ 0.6
- 1                           # mean accept_prob ≤ 1
```

**Why each check matters:**

| Diagnostic | Failure mode | Implication |
|---|---|---|
| **Mean acceptance probability too low** (< 0.6) | NUTS step size is too large — proposals frequently rejected → chain barely moves | Posterior summary is noise, coefficients are unreliable |
| **Mean acceptance probability too high** (~ 1.0) | NUTS step size is too small — proposals always accepted, but each step is tiny → chain barely moves the other way | Long-range correlations not explored, posterior may be biased |
| **Too many divergences** (> 300) | The leapfrog integrator hit a region of extreme posterior curvature and the numerical solution blew up | Posterior geometry is pathological — typically from informative priors plus high multicollinearity. The samples are not trustworthy. |

**Why retry up to 3 times.** A single bad seed can produce a marginal
failure even when the model is well-specified — NUTS is stochastic and
warmup sometimes lands in a bad starting position. Three retries
catches transient instability without masking genuine model
mis-specification (which would fail all three).

**What happens if all 3 fail.** `RuntimeError` is raised with the
specific failure reasons. The Databricks task fails, the bi-weekly
job halts at this point, and on-call gets paged. This is the right
behavior — a model that won't converge should not silently produce
output that downstream consumers use for budget allocation.

> **Interview angle — "How do you handle MCMC convergence failures in
> production?"** *"Two-layer defense. (1) Inline retry: after each
> ModelBuild call, the wrapper reads `accept_prob` and `diverging`
> from NUTS's extra_fields and checks against config-driven
> thresholds. If either fails, we retry up to 3 times with a fresh
> RNG seed — handles transient instability from bad starting
> positions. (2) Hard fail on persistent failure: after 3 retries, we
> raise RuntimeError with the specific failure reason, the Databricks
> task fails, on-call gets paged, and the run does not proceed to
> write any gold output. The diagnostic thresholds are pinned in
> config (`perc_divergence: 0.15` for the divergence cap; accept_prob
> in [0.6, 1.0]) so they're code-reviewable. The fail-fast behavior
> is intentional — silently emitting a bad posterior would mis-allocate
> millions in marketing budget downstream."*

### B4. Model registration in Unity Catalog

After successful fit, the model is wrapped and logged to MLflow:

```python
wrappedModel = RapidMMMModelWrapper(mdl)
prediction_params = {"kpi": 'FS Submits'}
signature = infer_signature(
    train_data,
    np.array(wrappedModel.predict(None, model_input=train_data, params=prediction_params))
)
mlflow.pyfunc.log_model("fs_submits_overall_mdl",
                        python_model=wrappedModel, signature=signature)

model_name = f"{catalog}.{gold_schema}.mmm_fs_submits_overall_model"
model_version = mlflow.register_model(f"runs:/{run_id}/fs_submits_overall_mdl", model_name)

client = MlflowClient()
client.set_registered_model_tag(model_name, key="model_type",  value="Overall")
client.set_registered_model_tag(model_name, key="business_kpi", value="FS Submits")
client.set_model_version_tag(name=model_name, version=model_version.version,
                             key="version", value=final_model_version_int)
```

`RapidMMMModelWrapper` (defined in `common_functions.py` — see
[Doc 03 Section 2.4](03_shared_utils_and_upstream_preprocessing.md))
makes the NumPyro model serveable as an MLflow `pyfunc`. The wrapper's
`predict` method internally creates a `ModelDiagnostics` instance and
calls `generate_predictions`, which uses `numpyro.infer.Predictive` to
draw posterior predictive samples and return their mean.

Before registering, the code searches Unity Catalog for any existing
version of the model with the same `version` tag and deletes it — this
makes the registration idempotent for re-runs (re-running the same
version overwrites the prior registration rather than creating a v.N+1
of the registered model on top of the prior v.N).

**Why register a Bayesian model in Unity Catalog?** Three reasons:
(1) cross-team discoverability — analysts in the
`incrementality-layer` project or in ad-hoc notebooks can `mlflow.pyfunc.load_model
("models:/marketing.rapidmmm_gold.mmm_fs_submits_overall_model/<version>")`
and get the exact same predict surface. (2) Versioning — the
registered-model version + the `version` tag together let you load any
historical model and re-run it. (3) Lineage — Unity Catalog tracks
which Databricks run produced each registered model version, integrating
with the broader Zillow governance.

### B5. Predictions on train + holdout, model statistics

The fit produces the in-memory `mdl` object. `ModelDiagnostics` is then
instantiated:

```python
MoDi = md.ModelDiagnostics(mdl)
MoDi.business_kpi = 'FS Submits'
data1, summary = MoDi.generate_az_data_and_summary()
```

`summary` is the ArviZ summary DataFrame — for every parameter
(`α[d]`, `B_<channel>[d]`, etc.) it gives the posterior mean, SD, and
95% HDI lower/upper bounds.

**Predictions on train.** Compute the posterior predictive mean for
each (dma, week) in training data:

```python
train_pred = MoDi.generate_predictions(train_data)
# train_pred is now an n_obs-length array of predicted FS Submits per (dma, week)
# It's also added to train_data['pred']
fig1, fig2 = MoDi.generate_actual_vs_predicted_plot(train_data)
```

**Predictions on holdout.** The holdout DMA codes must be encoded with
the same `LabelEncoder` the model fit used:

```python
holdout_data["dmas"] = mdl.dma_encoder.transform(holdout_data[mdl.region_col].values)
holdout_pred = MoDi.generate_predictions(holdout_data)
```

**Model statistics** — $R^2$, RMSE, MAPE for train and holdout:

```python
model_stat_train   = MoDi.generate_model_statistics(train_data)
model_stat_holdout = MoDi.generate_model_statistics(holdout_data)
```

Each returns a `(R², RMSE, MAPE)` tuple. These get written to
`mmm_model_output_stat` with `model_type='Overall', business_kpi='FS
Submits', version=<vN>, channel_network ∈ {'Train', 'Holdout'}` (via
two separate Spark writes with `replaceWhere` predicates).

**High-variance DMA filtering for holdout stats.** Some DMAs have very
unstable holdout predictions because their training-window FS Submits
levels were unusually noisy. Before recording the final holdout stats,
NB2 identifies high-variance DMAs (per-DMA prediction error > 20% of
actuals) and re-computes stats on the filtered subset:

```python
actuals_preds_agg = holdout_data.groupby(['dmacode']).agg({
    target_variable: 'sum', 'pred': 'sum'
}).sort_values(by=target_variable, ascending=False)

actuals_preds_agg['pct_variance'] = np.where(
    actuals_preds_agg[target_variable] != 0,
    (actuals_preds_agg[target_variable] - actuals_preds_agg['pred']).abs() / actuals_preds_agg[target_variable],
    np.nan,
)
high_variance_dmas = actuals_preds_agg[actuals_preds_agg['pct_variance'] > 0.20]
holdout_dmas_removed_data = holdout_data[~holdout_data['dmacode'].isin(high_variance_dmas['dmacode'].unique())]
model_stat_holdout_dmas_removed = MoDi.generate_model_statistics(holdout_dmas_removed_data)
```

The filtered stat is what gets written to `mmm_model_output_stat` for
the `channel_network='Holdout'` row. This is a defensible cleanup —
the model isn't expected to nail every DMA in a 4-week holdout, and a
few high-variance DMAs (often the smallest ones with sparse data)
shouldn't penalize the headline metric.

### B6. The melted DataFrame and cost-pers (before funnel)

After predictions, NB2 builds the **melted contribution table** — the
single most important artifact in the chain. It's an attribution table:
one row per (dma × week × feature variable) with that variable's
contribution to the predicted KPI.

The build uses three input DataFrames:

```python
# 1. Spend data (unscaled, original dollars)
spend_data = read mmm_input_preprocessing_overall_spend_data, restore pipe names, toPandas

# 2. Adstock-transformed data (post-adstock impressions in original units)
adstock_transformed_data = read mmm_fs_submits_adstock_transformed_data, restore, toPandas

# 3. The raw silver preprocessing data with impressions
data_w_imps = read mmm_input_preprocessing_overall_data, restore, toPandas
```

Then call `ModelDiagnostics.get_melted_data_for_business_diagnostics`
(see [Doc 02 Section 9.7](02_rapidmmm_library_internals.md) for the
algorithm):

```python
melted = MoDi.get_melted_data_for_business_diagnostics(
    train_holdout_data, train_x_col, adstock_transformed_data
)
melted = MoDi.merge_spend_data_w_melted(melted, spend_data)
melted = MoDi.merge_impressions_data_w_melted(melted, data_w_imps)
```

The output has one row per (`dma × week × feature_variable`) with
columns: `dmacode, week_monday, variable, value, value|leads|fs_submits_mean,
column, coefficient, coef_hdi_2point5_pct, coef_hdi_97point5_pct,
predicted_initial, predicted_2point5_pct_hdi, predicted_97point5_pct_hdi,
predicted, value|leads|fs_submits, adjusted, channel, spend, impressions`.

The `predicted` column is each feature's contribution to the (dma,
week) prediction. Summing `predicted` over all features in a (dma,
week) gives the model's total predicted FS Submits for that cell.

**Cost-pers (cost per submission) before funnel.**

```python
cost_pers = melted[['variable', 'channel', 'spend', 'impressions', 'predicted']]\
              .groupby(['variable', 'channel']).sum().reset_index()
cost_pers['cp'] = cost_pers['spend'] / cost_pers['predicted']
display(cost_pers[cost_pers['cp'] > 0])
```

This is the headline "what does each channel cost per FS Submit" view
**from the direct-effect attribution only** — without funnel effects.
Channels with no direct effect (because they were excluded from the
model by `exclude_channels_bfr_model`) won't appear here; they'll
appear in the post-funnel cost-per table.

The melted DataFrame is then written to silver
(`mmm_fs_submits_overall_model_melted_data`) for downstream consumption
by NB4 (which uses it as the node-1 data for taxonomy-level funnel
allocation later in the chain).

The direct-effect Spark-ready DataFrame is then written to the gold
overall-level table:

```python
df = MoDi.get_spark_ready_df_from_melted(
    melted=melted, funnel_effects=False, taxonomy_order=["channel", "network"],
    version=final_model_version,
)
df["train_holdout"] = np.where(df["week_monday"] < holdout_start_week, "Train", "Holdout")
overall_model_output_spdf.write.mode("overwrite").format("delta")\
    .option("replaceWhere", f"business_kpi = 'FS Submits' AND version = '{final_model_version}'")\
    .saveAsTable(f"{catalog}.{gold_schema}.mmm_model_output_overall_level")
```

This `mmm_model_output_overall_level` table holds only direct effects —
it's the "channel coefficients × features" attribution without funnel
allocation. Consumers who want the full attribution including funnel
should query `mmm_model_combined_output_overall_level` instead (written
in Section B7 below).

### B7. Funnel effects — Visits flowing into FS Submits

The funnel step is the post-fit redistribution where Visits' per-channel
attribution gets allocated forward into FS Submits' per-channel
attribution. The mechanism is implemented in
`rapidmmm.Utils.FunnelEffects.funnel_effects` (see
[Doc 02 Section 7.2](02_rapidmmm_library_internals.md) for the full
algorithm; [Doc 01 Section 8](01_mmm_methodology_primer.md) for the
math).

NB2 first reads Visits' previously-written melted DataFrame using
**Delta Time Travel** to ensure it gets the *exact* version produced by
this same bi-weekly run:

```python
visits_delta_table_version = spark.sql(f"""
    select distinct delta_table_version
    from {catalog}.{silver_schema}.mmm_model_job_metadata_detail
    where business_kpi = 'Visits'
      and model_version = '{final_model_version}'
      and table_name = '{catalog}.{silver_schema}.mmm_visits_overall_model_melted_data'
""").collect()[0][0]

visits_output = spark.sql(f"""
    select * from {catalog}.{silver_schema}.mmm_visits_overall_model_melted_data
    version as of {visits_delta_table_version}
""").toPandas()
```

This is critical for reproducibility — the FS Submits job runs *after*
the Visits job in the bi-weekly cycle, and there's a window where the
Visits table could have been re-written (by a manual rerun) between
when this FS Submits job started and now. Delta Time Travel pins
exactly to the Delta version that the v.N Visits run produced,
identified via the job metadata table.

After a small column rename (the Delta column `value_visits_visits`
needs to become the pipe-separated `value|visits|visits` that
`FunnelEffects` expects), the function is called:

```python
funnel_effect_data = fne.funnel_effects(
    nodes=[target_variable_node1, target_variable],   # ['value|visits|visits', 'value|leads|fs_submits']
    nodes_data={'node1_data': visits_output, 'node2_data': melted},
)
```

The output `funnel_effect_data` has the same schema as the FS Submits
melted DataFrame **plus** a `Type` column (`'Direct Effect'` or
`'Funnel Effect'`). Direct-effect rows are the original melted rows
(one per FS Submits channel × dma × week). Funnel-effect rows are the
new per-channel allocations: for each Visits channel $c$ at (dma, week),
the function computes "the share of FS Submits attributable to the
Visits-variable term in the FS Submits regression, multiplied by
channel $c$'s share of total Visits prediction at this (dma, week)" —
and appends those as rows tagged `'Funnel Effect'`.

After this step, channels like Linear TV (which has no direct effect on
FS Submits but drives lots of Visits) get a meaningful contribution to
FS Submits via the funnel step.

### B8. validate_funnel_effects — the four invariants

NB2 then runs four validation checks on `funnel_effect_data` via the
inline `validate_funnel_effects` function:

```python
validate_funnel_effects(melted, funnel_effect_data, visits_output,
                        ['Direct Effect', 'Funnel Effect'])
```

The four checks:

| Check | Test | Why it must hold |
|---|---|---|
| **1. Type exhaustiveness** | Both `'Direct Effect'` and `'Funnel Effect'` appear; their row counts sum to the total | Guarantees the Type tagging is complete — no row was orphaned |
| **2. Spend balance** | Total spend in (FS Submits melted ∪ Visits melted exclusive) = total spend in funnel output | Spend should not be double-counted nor lost during attribution. If a channel's spend appears in both melted DataFrames, it should be counted once in the output. |
| **3. Monotonicity** | For each channel that received funnel-effect allocation, its total contribution in the funnel output is ≥ its contribution in the direct-only melted DataFrame | Funnel attribution only adds — it never subtracts from a channel's direct effect |
| **4. Parent-KPI cap** | Sum of all `'Funnel Effect'` rows in FS Submits ≤ total Visits prediction | Funnel effects are derived from Visits' contributions, so the total funnel pool cannot exceed Visits' total predicted volume — that would be creating FS Submits attribution out of nowhere |

Check 4 is the tightest. If it fails, something is fundamentally wrong
with the attribution (likely a column rename or version mismatch).
The function `raise ValueError` on any failure; the task fails loudly
rather than emitting silent garbage downstream.

### B9. AOT recalibration for Email Simon Data — the math in full

This is the most algorithmically interesting step in NB2. Email Simon
Data has a known MMM bias — emails go to users with existing intent, so
the MMM coefficient consistently *overstates* incrementality. AOT
(Always-On Testing) geo-experiments measure the true incrementality;
the recalibration replaces the MMM Email contribution with the
AOT-derived rate, then shifts the difference into the intercept α to
keep the total prediction unchanged.

**Step 1 — pull `send_per_incremental` from AOT.** The notebook runs a
Spark SQL query against two tables: `marketing.marketingde_gold.b2c_measurments_fact`
for sends and `marketing.always_on_testing_gold.email_pooled_results`
for AOT-measured cost-per-incremental. The query covers the last year
of data for Email|Simon Data (and Braze) Buyer-campaign-super,
filtered to Multi Product + PA - Customer LOB:

```sql
WITH sends AS (
  SELECT process_date, 'FS Submits' as metric, SUM(sends) as sends
  FROM marketing.marketingde_gold.b2c_measurments_fact
  WHERE channel = 'Email' AND ad_network in ('Simon Data', 'Braze')
    AND process_date BETWEEN DATE('<min_date>') AND DATE('<max_date>')
    AND core_campaign_super = 'Buyer' AND lower(brand) LIKE '%zillow%'
    AND isdaily = '1' AND lower(utm_campaign) NOT LIKE '%reengage%'
    AND core_lob IN ('Multi Product', 'PA - Customer')
    AND core_campaign_initiative NOT IN ('Post Submit')
  GROUP BY 1, 2
),
final AS (
  SELECT date, ..., s.sends/p.cost_per AS total_incrementals
  FROM marketing.always_on_testing_gold.email_pooled_results AS p
  RIGHT JOIN sends AS s ON s.process_date = p.date AND p.metric_type = s.metric
  WHERE channel = 'Email' AND source = 'E2E' AND p.metric_type IN ('FS Submits')
    AND p.date BETWEEN DATE('<min_date>') AND DATE('<max_date>')
)
SELECT
  metric_type, '5' as att_w_days,
  sum(sends) as total_sends,
  sum(total_incrementals) as total_incrementals,
  sum(sends)/sum(total_incrementals) as send_per_incremental
FROM final WHERE att_w_days in ('5', '7') GROUP BY 1, 2
```

The output `send_per_incremental` (call it $\text{spi}$) is the
**AOT-measured number of email sends needed to produce one incremental
FS Submit**. As of the v62 run referenced in
`config_param.yml::adjusted_target_aot_value: 45325.11`, the value
sits in the thousands-of-sends-per-submit range (after the in-function
recalibration, see below).

**Step 2 — compute the recalibration target.** The MMM model's
prediction for Email Simon Data at any (dma, week) is
$\hat{y}_{E,d,t}^{\text{MMM}}$. The AOT-implied prediction is simply

$$
\hat{y}_{E,d,t}^{\text{AOT}} = \frac{\text{impressions}_{E,d,t}}{\text{spi}}
$$

(In the code, "impressions" for Email is actually "sends" — the source
data has impressions = sends for the Email channel because each email
is exactly one send.) This is the recalibration target: replace the
MMM prediction for Email with the impressions/spi ratio.

**Step 3 — adjust for the funnel effect rows.** This is the nuance the
PDF documentation omits but the code implements carefully:

Email Simon Data appears in the post-funnel DataFrame in **two row
types** — `'Direct Effect'` rows (the MMM's own coefficient on Email)
and `'Funnel Effect'` rows (Email's allocation from the Visits funnel,
since Email also affects Visits which affects FS Submits). The
recalibration should **only adjust Direct Effect rows** because the
Funnel Effect rows were derived from Visits' attribution, not from
Email's direct coefficient.

So the code computes a per-channel-aggregated direct-only target:

$$
\text{imp\_total}_E = \sum_{d,t} \text{impressions}_{E,d,t}
$$

$$
\text{imp\_direct}_E = \sum_{d,t,\, \text{Type=Direct}} \text{impressions}_{E,d,t}
$$

$$
\text{pred\_funnel}_E = \sum_{d,t,\, \text{Type=Funnel}} \hat{y}_{E,d,t}^{\text{MMM}}
$$

The target *total* prediction for Email (direct + funnel combined) at
the AOT-measured rate is:

$$
\text{target\_total\_pred}_E = \frac{\text{imp\_total}_E}{\text{spi}}
$$

Subtracting the unchanged funnel contribution gives the target for the
direct effect alone:

$$
\text{pred\_direct\_scaled}_E = \text{target\_total\_pred}_E - \text{pred\_funnel}_E
$$

The **adjusted target rate** (the AOT-derived value, recalibrated for
Email's direct-only attribution after backing out funnel) is:

$$
\text{adjusted\_target} = \frac{\text{imp\_direct}_E}{\text{pred\_direct\_scaled}_E}
$$

In code:

```python
imp_total   = filtered_data['impressions'].sum()
imp_direct  = filtered_data.loc[filtered_data['Type'] == 'Direct Effect', 'impressions'].sum()
pred_funnel = filtered_data.loc[filtered_data['Type'] == 'Funnel Effect', 'predicted'].sum()
target_total_pred = imp_total / target_value          # target_value = spi
pred_direct_scaled = target_total_pred - pred_funnel
adjusted_target = float(imp_direct / pred_direct_scaled)
```

**Step 4 — recalibrate per-row Direct Effect predictions.** For each
Direct Effect row $(d, t)$:

$$
\hat{y}_{E,d,t}^{\text{recal}} = \frac{\hat{y}_{E,d,t}^{\text{MMM}} \cdot \text{impv}_{d,t}}{\text{adjusted\_target}}
\qquad \text{where} \qquad
\text{impv}_{d,t} = \frac{\text{impressions}_{E,d,t}}{\hat{y}_{E,d,t}^{\text{MMM}}}
$$

The two factors cancel algebraically:

$$
\hat{y}_{E,d,t}^{\text{recal}} = \frac{\text{impressions}_{E,d,t}}{\text{adjusted\_target}}
$$

So the recalibrated direct effect for Email at $(d, t)$ is simply the
impressions divided by the adjusted-target rate — exactly the AOT-
measured rate applied to that DMA-week.

In code:

```python
filtered_data['impv'] = filtered_data['impressions'] / filtered_data['predicted'].replace(0, 1e-6)
filtered_data['recalibrated_value'] = filtered_data.apply(
    lambda row: (row['predicted'] * row['impv']) / adjusted_target
                if row['Type'] == 'Direct Effect' else row['predicted'],
    axis=1,
)
```

**Step 5 — push the difference into the intercept.** The recalibration
changes the per-row Email prediction; to keep the total prediction at
each (dma, week) unchanged, the difference is absorbed by the per-DMA
intercept α:

$$
\Delta_{d,t} = \hat{y}_{E,d,t}^{\text{MMM}} - \hat{y}_{E,d,t}^{\text{recal}}
$$

$$
\alpha_{d,t}^{\text{new}} = \alpha_{d,t}^{\text{old}} + \sum_{\text{Direct rows for Email}} \Delta_{d,t}
$$

In code:

```python
filtered_data['diff_pred_calibrated'] = filtered_data['predicted'] - filtered_data['recalibrated_value']
intercept_df = filtered_data.groupby(['dmacode', 'week_monday', 'variable']).agg({
    'diff_pred_calibrated': 'sum'
}).reset_index()
df_result = df_result.merge(intercept_df, on=['dmacode', 'week_monday', 'variable'], how='left')
intercept_mask = df_result['variable'] == 'α'
df_result.loc[intercept_mask, 'predicted'] += df_result.loc[intercept_mask, 'diff_pred_calibrated'].fillna(0)
```

The total $\sum_v \hat{y}_{v,d,t}^{\text{post-recal}}$ at each (dma,
week) equals the pre-recalibration total — the recalibration is a
**zero-sum redistribution** between the Email channel rows and the
intercept rows. Marketing's view of "what did Email do" changes; the
overall predicted FS Submits at each (dma, week) does not.

**Step 6 — persist the adjusted target back to config.** For
observability, the final `adjusted_target` is written back to
`config_param.yml`:

```python
add_mapping('config_param.yml', 'adjusted_target_aot_value', adjusted_target)
```

This is why the YAML has the `adjusted_target_aot_value: 45325.11`
line — it's the post-recalibration AOT target rate from the most
recent run, persisted for reference.

**Why preserve total predicted FS Submits.** Two reasons. (1) The
model's total prediction is what's compared against actual FS Submits
for $R^2$ / RMSE / MAPE; changing it would break those stats and
trigger spurious holdout-error alarms. (2) Marketing budget allocation
sums per-channel contributions to total predicted KPI — if
recalibration changed the total, the post-recal allocation would be
inconsistent with the pre-recal validation.

> **Interview angle — "Why and how do you recalibrate Email?"** *"Two
> issues with the MMM-only attribution for Email. (1) Email goes to
> users with existing intent (they signed up for alerts), so the MMM
> systematically overstates Email's marginal incrementality. (2) We
> have ground truth: continuous AOT geo-experiments measure the
> actual incremental visits and submits per email send. We use the
> AOT-measured 'sends per incremental submit' rate as the truth and
> recalibrate the MMM output to match. The procedure is: (a) pull the
> latest year of AOT data to compute `spi = sum(sends) /
> sum(incrementals)`. (b) Compute the target total Email prediction
> = total impressions / spi. (c) Subtract Email's funnel-effect
> contribution (which is derived from Visits, not from the Email
> coefficient itself) to get the target for Email's direct effect
> alone. (d) Compute an adjusted target rate
> `imp_direct / pred_direct_scaled` and apply it row-by-row to Email's
> Direct Effect rows. (e) Push the difference into the per-DMA
> intercept α so the total predicted FS Submits at each (dma, week) is
> unchanged. The result: Marketing's view of Email's contribution
> matches AOT ground truth, but the model's total prediction (used for
> validation) stays intact. We persist the final adjusted_target back
> to `config_param.yml` as audit."*

### B10. Outputs

The recalibrated `funnel_effect_data` is converted to the final gold
schema and written:

```python
funnel_effect_data.rename(columns={'Type': 'type'}, inplace=True)
funnel_effect_data_df = MoDi.get_spark_ready_df_from_melted(
    funnel_effect_data, taxonomy_order=['channel', 'network'],
    version=final_model_version, funnel_effects=True,
)
funnel_effect_data_df['funneleffect_variable'] = np.where(
    funnel_effect_data_df['funneleffect_variable'] == '', 'Visits',
    funnel_effect_data_df['funneleffect_variable'],
)
funnel_effect_data_df["train_holdout"] = np.where(
    funnel_effect_data_df["week_monday"] < holdout_start_week, "Train", "Holdout"
)
overall_model_output_fe_spdf.write.mode("overwrite").format("delta")\
    .option("replaceWhere", f"business_kpi = 'FS Submits' AND version = '{final_model_version}'")\
    .saveAsTable(f"{catalog}.{gold_schema}.mmm_model_combined_output_overall_level")
```

The `funneleffect_variable` column is the parent-KPI tag on funnel
rows (set to `'Visits'` here) and the current KPI tag on direct rows
(set to `'FS Submits'` earlier in `get_spark_ready_df_from_melted`).

The two output tables NB2 has written:

| Table | Rows for FS Submits v.N |
|---|---|
| `mmm_model_output_overall_level` | Direct effect only — per (dma × week × variable), with the FS Submits coefficient × value attribution |
| `mmm_model_combined_output_overall_level` | Direct + Funnel — same rows plus per-channel funnel allocations from Visits, plus the AOT-recalibrated Email rows and the absorbed intercept adjustments |

The MLflow nested run is closed. The bi-weekly chain continues at NB3
(taxonomy model input), covered in [Doc 06](06_fs_submits_taxonomy_chain.md).

---

## Summary — the NB1 + NB2 chain

| Stage | Module / function | Input | Output |
|---|---|---|---|
| Read silver, restore names | `get_yaml_value` + `withColumnRenamed` | `mmm_input_preprocessing_overall_data` | wide pandas DataFrame with pipe-separated cols |
| Drop excluded channels | `excluded_channel_network_list` filter | pandas DataFrame | smaller pandas DataFrame |
| Adstock | `FeatureEngineeringAdStock` | wide impressions | adstocked impressions with suffix names |
| Merge macro feature store | `fs.read_table` | adstocked + (silver feature store) | enriched DataFrame |
| SoV scaling | inline lambda | enriched DataFrame | three columns rescaled to share-of-voice |
| Split + MeanScale | `MeanScalingRegional` | enriched DataFrame | train + holdout scaled (excl. SoV) |
| Atan + Hill | `AtanTransform`, `HillTransform` | scaled DataFrame | saturated features |
| Holiday + seasonal + anomaly merges | `seasonal_decompose`, manual pivots | saturated DataFrame | full modeling features |
| Write 3 silver tables | `intermediate_and_meta_table_write` | full DataFrame | `mmm_fs_submits_*` |
| --- end NB1 --- | | | |
| Read modeling data, restore names | get_yaml_value + rename | `mmm_fs_submits_final_data_for_modeling` | pandas modeling DataFrame |
| Drop `exclude_channels_bfr_model` | filter | DataFrame | smaller DataFrame |
| Split train/holdout | filter on `train_holdout` | DataFrame | (train, holdout) pair |
| Load priors | `pd.read_csv` | `mmm_fs_submits_priors.csv` | priors DataFrame |
| Fit Bayesian model | `Model.Model.ModelBuild` via retry wrapper | (train, priors) | fitted `Model` + posterior samples |
| Diagnostic gate | inline `run_model_with_accept_prob_and_divergence_check` | MCMC outputs | passes or RuntimeError |
| Register in Unity Catalog | `RapidMMMModelWrapper` + `mlflow.register_model` | fitted `Model` | UC model registration |
| Predictions on train/holdout | `ModelDiagnostics.generate_predictions` | (model, data) | predictions, stats |
| Build melted contribution table | `ModelDiagnostics.get_melted_data_for_business_diagnostics` | (model, data, adstock_data) | per-(dma × week × variable) attribution |
| Apply funnel effect (Visits → FS Submits) | `FunnelEffects.funnel_effects` | (Visits melted, FS Submits melted) | enhanced melted DataFrame with Type column |
| Validate funnel | inline `validate_funnel_effects` | (melted, funnel_data, visits) | passes or ValueError |
| Recalibrate Email Simon Data | inline `recalibrate_channel_AOT` + AOT SQL | (funnel_data, spi from AOT) | recalibrated melted + adjusted α |
| Write gold tables | `df.write.replaceWhere` | recalibrated melted | `mmm_model_output_overall_level` + `mmm_model_combined_output_overall_level` |

**Next:** Read [06_fs_submits_taxonomy_chain.md](06_fs_submits_taxonomy_chain.md)
for NB3–NB6 — the taxonomy fan-out, the 15-way parallel per-channel
fits, the single-variable shortcut, and the merge into the gold
taxonomy table.
