---
doc_id: 00
title: MMM Ecosystem Overview
companion_docs:
  - 01_mmm_methodology_primer.md (math: adstock, Hill, hierarchical Bayes, NUTS, funnel effects)
  - 02_rapidmmm_library_internals.md (the in-house Python package)
  - 03_shared_utils_and_upstream_preprocessing.md (common_functions, configs, jobs)
  - 04_data_lineage_and_schemas.md (every Delta table in the system)
  - 05_fs_submits_overall_model_track.md (NB1 + NB2 deep dive)
  - 06_fs_submits_taxonomy_track.md (NB3 + NB4 + NB5 + NB6 deep dive)
  - 07_fs_submits_response_curves_and_stability.md (NB7 + NB8 + NB9 — downstream outputs)
  - 08_other_kpis_comparative.md (Visits / FS / ZHL / Rentals / MF differences)
  - 09_operations_and_interview_capstone.md (schema migrations + interview prep)
---

# 00 — Zillow MMM Ecosystem: The Single Map

> **What this doc is.** The single map of the production MMM system at Zillow.
> Read it first. After reading, you should be able to answer in an interview:
> *what KPIs the system models, what notebooks exist, what tables they produce,
> what jobs run when, and how data flows from raw → gold → Tableau.*
>
> **What this doc is not.** A theory primer (→ Doc 01), a code walkthrough
> (→ Docs 02–08), or a critique (→ Doc 09). Almost no math, almost no code.

---

## 1. Executive summary

Zillow runs a **bi-weekly, hierarchical Bayesian Marketing Mix Model (MMM)** that
measures how paid-media impressions across ~25 channel-networks drive five
business KPIs at the DMA-week level. The system fits separate models per KPI
using `numpyro` + JAX (NUTS sampler), applies **adstock** (carryover) and **Hill
saturation** (diminishing returns) on impressions, propagates **funnel effects**
between KPIs (e.g., Visits → FS Submits), emits **response curves** for budget
optimization, and runs a **stability check** vs the prior model version. All
outputs land in Delta tables that feed Tableau dashboards used by the Marketing
team to allocate spend across channels.

The orchestration sits on **Databricks Asset Bundles** (DAB) with two jobs:
an **MMM Input Job** that builds the common silver layer, and one **MMM `<KPI>`
Job** per KPI that runs ~27 tasks (feature engineering → overall model → 15
parallel taxonomy models → merge → response curves → stability). Code lives in
**`mmm_model/`** (KPI-specific notebooks + shared utilities) on top of the
in-house **`rapidmmm`** Python package (Bayesian modeling primitives).

> **Interview angle — "What is MMM?"** Marketing Mix Modeling is a top-down
> attribution method that uses **aggregated** (region × time) historical data to
> estimate how much of a business outcome is driven by each marketing channel,
> after controlling for non-marketing drivers (seasonality, macroeconomy,
> holidays). Unlike user-level multi-touch attribution (MTA), MMM does not need
> cookies/IDs — it works on aggregated impressions/spend, so it survived the
> iOS-14 / cookie deprecation era and is the **only** attribution method that can
> measure offline channels (TV, OOH, Audio) credibly.

> **Interview angle — "Why does Zillow use MMM?"** Three reasons: (1) Zillow
> spends across ~25 channel-networks including offline channels (Linear TV,
> Connected TV, OOH, Radio) that MTA can't measure; (2) the business needs a
> **budget allocator** with response curves, not a click-attribution report; and
> (3) MMM provides **funnel-aware** measurement — e.g., a TV ad that drives a
> Visit which becomes an FS Submit gets credit for both, not just the last
> touch.

---

## 2. The five KPIs

Each KPI is a **separately-fit MMM model** with its own notebooks, priors, and
config. Three are *upper-funnel* (top-of-funnel awareness/traffic) and two are
*lower-funnel* (lead submissions). The lower-funnel KPIs use the upper-funnel
KPI as a **node-1 input** for funnel-effect attribution.

| # | KPI | Funnel position | Target variable (in `mmm_business_metrics`) | Node-1 KPI (funnel parent) | LOB / business meaning |
|---|---|---|---|---|---|
| 1 | **Visits** | Top of funnel | `value\|visits\|visits` | none (root) | Zillow.com page visits — the broad traffic signal that feeds FS Submits |
| 2 | **FS Submits** | Mid funnel | `value\|leads\|fs_submits` | Visits | For-Sale (FS) lead form submissions → Premier Agent (PA) connections; the primary monetizable Zillow event |
| 3 | **ZHL Submits** | Mid funnel | (ZHL-specific) | (uses internal OMP imps split; no upstream funnel) | Zillow Home Loans applications |
| 4 | **Rental Visits** | Top of funnel (Rentals) | `value\|rentalsmetrics_zillowbrand\|rental_visits` | none (root for the Rentals funnel) | Visits to rental listings on Zillow / StreetEasy / Trulia |
| 5 | **MF Submits** | Mid funnel (Rentals) | `value\|rentalsmetrics_zillowbrand\|fr_bdp_submits` | Rental Visits | Multi-Family rental lead submissions ("FR-BDP" = For-Rent Building Detail Page) |

**Granularity for every KPI:** observation = `(dmacode × week_monday)`. There are
~210 DMAs (Nielsen Designated Market Areas) and weeks are Monday-anchored. So a
typical training set is `210 × 104 weeks ≈ 22,000 rows` per KPI.

> **Interview angle — "Why DMA-level instead of national?"** Three reasons:
> (1) **Hierarchical signal**: DMAs vary in spend, impressions, and conversion
> rates by 10–100×; pooling them via a hierarchical prior lets each DMA borrow
> strength from the others while still having its own coefficients
> (`β[dma, channel]`). (2) **More observations**: a national model has ~104
> rows/year; a DMA model has ~22,000 rows/year, which is essential for
> identifying coefficients on 20+ channels. (3) **TV/regional alignment**:
> DMAs are *defined* by Nielsen as TV-buying regions, so DMA-level Linear TV
> and Connected TV impressions are directly addressable; rolling them up to
> national throws away the cross-DMA variation that identifies TV's
> coefficient.

---

## 3. System layers — raw → gold

ASCII view of the end-to-end data flow. Read left-to-right.

```
┌─────────────────────────┐   ┌────────────────────────────────┐   ┌──────────────────────────────────────┐   ┌─────────────────────────────────┐   ┌──────────────┐
│   RAW SOURCE TABLES     │   │  SILVER: preprocessed inputs   │   │   SILVER: per-KPI feature-engineered │   │   GOLD: model outputs + curves  │   │   TABLEAU    │
│  (marketingde_gold)     │   │  (rapidmmm_silver — shared)    │   │   tables + staging (rapidmmm_silver) │   │     (rapidmmm_gold)             │   │  dashboards  │
├─────────────────────────┤   ├────────────────────────────────┤   ├──────────────────────────────────────┤   ├─────────────────────────────────┤   ├──────────────┤
│ mmm_marketing_metrics   │──▶│ mmm_input_preprocessing_       │──▶│ mmm_<kpi>_adstock_transformed_data   │──▶│ mmm_model_output_overall_level  │──▶│ MMM           │
│   (impressions, spend,  │   │   overall_data / _rentals      │   │ mmm_<kpi>_final_data_for_modeling    │   │   (direct effect only)          │   │ Observability │
│    by channel/network/  │   │ mmm_input_preprocessing_       │   │ mmm_<kpi>_overall_model_melted_data  │   │ mmm_model_combined_output_      │   │ Reports       │
│    LOB/campaign_super)  │   │   taxonomy_data                │   │ mmm_<kpi>_overall_model_prediction_  │   │   overall_level                 │   │               │
│                         │   │ mmm_input_preprocessing_       │   │   data                               │   │   (direct + funnel effect)      │   │ MMM EDA / QC  │
│ mmm_business_metrics    │──▶│   overall_spend_data           │   │ mmm_<kpi>_taxonomy_model_input       │   │ mmm_model_output_taxonomy_level │   │               │
│   (visits, fs_submits,  │   │ mmm_input_preprocessing_       │   │ mmm_<kpi>_taxonomy_model_output_     │   │ mmm_model_combined_output_      │   │ Budget        │
│    econometrics,        │   │   taxonomy_spend_data          │   │   staging                            │   │   taxonomy_level                │   │ Allocator     │
│    googletrends,        │   │ mmm_automation_exogenous_      │   │ mmm_<kpi>_combined_taxonomy_output_  │   │ mmm_response_curves_overall_    │   │ (downstream   │
│    interest_rate,       │◀──│   feature_store (smoothed      │   │   staging                            │   │   level (+ _reporting)          │   │  consumer)    │
│    rental metrics)      │   │   macros — feature store)      │   │ mmm_<kpi>_taxonomy_single_var_       │   │ mmm_response_curves_taxonomy_   │   │               │
│                         │   │                                │   │   channel                            │   │   level (+ _reporting)          │   │               │
│ mmm_calendar            │   │ mmm_holidays                   │   │ mmm_<kpi>_corr_post_fe               │   │ mmm_model_output_overall_       │   │               │
│ mmm_holidays            │   │ mmm_model_job_metadata_detail  │   │                                      │   │   level_stability               │   │               │
│ mmm_regionmapping       │   │ mmm_model_output_stat          │   │                                      │   │ mmm_model_output_taxonomy_      │   │               │
│                         │   │ vw_mmm_input_preprocessing_    │   │                                      │   │   level_stability               │   │               │
│                         │   │   overall_data (UNION view)    │   │                                      │   │ Unity Catalog model registry    │   │               │
└─────────────────────────┘   └────────────────────────────────┘   └──────────────────────────────────────┘   └─────────────────────────────────┘   └──────────────┘
        Source-of-truth                MMM Input Job                       MMM <KPI> Job — Feature Eng                MMM <KPI> Job — Model + RC
        (other teams own these)        (Tuesday 12 PM PST)                 + Overall Model                            + Stability Loop
                                                                           (Thursday 12 PM PST)                       (Thursday 12 PM PST)
```

**Layer responsibilities:**

| Layer | What lives there | Refresh cadence | Who writes |
|---|---|---|---|
| **Raw source** (`marketing.marketingde_gold`) | Marketing facts (impressions/spend) and business facts (KPI events, econometrics) | Daily (owned by upstream DE team) | Marketing DE team |
| **Silver — common** (`marketing.rapidmmm_silver` from MMM Input Job) | Cleaned, pivoted, taxonomy-validated input tables shared by all KPIs + the exogenous feature store | Bi-weekly (Tuesday) | `shared_utils/mmm_input_data_preprocessing.py` |
| **Silver — per-KPI** (`rapidmmm_silver` from MMM `<KPI>` Job) | Per-KPI feature-engineered tables, melted contributions, taxonomy staging tables | Bi-weekly (Thursday) | KPI notebooks 1, 3, 4, 5 |
| **Gold** (`marketing.rapidmmm_gold`) | Final model outputs, response curves, stability reports — versioned via `version` column | Append per run; reporting tables overwrite | KPI notebooks 2, 6, 7, 8, 9 |
| **Tableau** | Marketing-facing dashboards (Observability, EDA, Budget Allocator) | Reads gold | (consumer, not part of MMM repo) |

**Environment matrix** (set via job widget parameters):

| Environment | Catalog | Silver schema | Gold schema |
|---|---|---|---|
| **Prod** | `marketing` | `rapidmmm_silver` | `rapidmmm_gold` |
| **Stage** | `stage_marketing` | `rapidmmm_silver` | `rapidmmm_gold` |
| **Dev / Lab** | `sandbox_desa` | `dev_{username}` or `mads_team` | `dev_{username}` or `mads_team` |

---

## 4. The two Databricks jobs

The system is just **two DAB-defined jobs** per environment, scheduled
bi-weekly. (Per KPI: each KPI has its own `MMM <KPI> Job`, but the *structure*
of all five is nearly identical.)

### 4.1 MMM Input Job (shared, runs first)

| Property | Value |
|---|---|
| **Schedule** | Every Tuesday 12 PM PST; the `mmm_bi_weekly_check` task gates on ISO-week parity (odd → run, even → skip) so effective cadence is bi-weekly |
| **Tasks** | 5 sequential: bi-weekly check → if/else condition → business-data availability check ∥ marketing-data availability check → preprocessing → feature store |
| **Cluster** | GPU: Spark 16.2.x-gpu-ml-scala2.12, g5.xlarge driver + 1–3 g5.xlarge workers (autoscale) |
| **Outputs** | The shared silver tables (`mmm_input_preprocessing_*`, `mmm_automation_exogenous_feature_store`) — these are reused by **all** KPI jobs |
| **Notebooks invoked** | `shared_utils/mmm_week_condition_check.py`, `shared_utils/mmm_dataset_availability_check.py`, `shared_utils/mmm_input_data_preprocessing.py`, `shared_utils/mmm_exogeneous_feature_store.py` |

### 4.2 MMM `<KPI>` Job (one per KPI, runs after Input Job)

| Property | Value |
|---|---|
| **Schedule** | Every Thursday 12 PM PST (gated by bi-weekly check) — 2 days after Input Job to allow buffer |
| **Tasks** | ~27 (bi-weekly check + 11 logical steps, with the Taxonomy step fanning out to 15 parallel sub-tasks, one per channel-network) |
| **Cluster split** | GPU cluster (g6e.xlarge driver, g4dn.xlarge workers) for **feature engineering** and **overall model** (NUTS sampling benefits from GPU); CPU cluster (r6i.8xlarge/r6i.4xlarge) for the **taxonomy fan-out** and **response curves** |
| **Outputs** | Per-KPI silver tables + appends to the 10 gold output tables with a new `version` (`vN+1`) |

**Per-KPI Job task DAG (high-level):**

```
mmm_bi_weekly_check
   ↓
mmm_input_bi_weekly_condition_check
   ↓
business_data_availability_check
   ↓
Feature_Engineering              ──── reads silver inputs from Input Job
   ↓
Overall_Model                    ──── trains hierarchical Bayesian model, applies funnel effects (parent KPI)
   ↓
Taxonomy_Model_Input             ──── adstock + scale + Hill at channel|network|lob|campaign_super
   ↓
Taxonomy_Model  ╳ 15 in parallel ──── one notebook run per channel-network combination
   ↓
Taxonomy_Single_Variable         ──── attributes single-variant channels from overall model
   ↓
Taxonomy_Output_Merge            ──── UNION ALL staging tables into final gold taxonomy tables
   ↓
Overall_Response_Curves          ──── fits Hill response curves (DMA + national)
   ↓
Taxonomy_Response_Curves         ──── fits Hill curves at channel|network|campaign_super
   ↓
Stability_Loop                   ──── compares v_curr vs v_prev → writes stability tables
```

**Parameter inheritance.** All ~27 tasks share a common widget contract:
`catalog`, `silver_schema`, `gold_schema`, `environment`, `ml_experiment_path`,
`model_version_number` (default `"NA"` → auto-increment), and date widgets
(`train_start_week`, `train_end_week`, `holdout_start_week`, `holdout_end_week`,
default `"9999-12-31"` → derive via `get_train_holdout_dates` in
`common_functions.py`). This means a single re-run of any task can be aligned
to a specific historic version simply by overriding `model_version_number=N`
and the date widgets.

> **Interview angle — "How do you orchestrate a multi-KPI MMM in production?"**
> The right answer is *separation of concerns* via a layered DAG:
> - **One shared upstream job** (Input Job) produces preprocessed silver tables
>   so the five KPI models can't drift on input definitions.
> - **One job per KPI** so a single KPI's training can be re-run / debugged
>   without re-running the others.
> - **Parallel fan-out within a KPI job** — the 15+ channel-network taxonomy
>   models are independent given the overall model, so they're run in parallel
>   on CPU clusters while the GPU-hungry overall model gets dedicated hardware.
> - **Cluster-type separation by workload** — NUTS sampling benefits from GPU,
>   per-channel curve-fitting and Spark merges don't.
> - **Idempotent writes with `replaceWhere`** — every Delta write is keyed by
>   `business_kpi AND version`, so a re-run of any task overwrites only the
>   slice it owns, never anyone else's.

> **Interview angle — "How do you handle bi-weekly retraining?"** Three
> mechanisms: (1) **Schedule gate**: Databricks only natively supports weekly
> cron, so we schedule weekly and the first task (`mmm_week_condition_check`)
> short-circuits on even ISO weeks via `dbutils.jobs.taskValues.set`. (2)
> **Auto-versioning**: each run reads `MAX(version)` from the gold table for
> that KPI, increments, and writes as `vN+1` — no manual version bookkeeping.
> (3) **Auto date windowing**: `get_train_holdout_dates` derives `train_start =
> last_run's min_week + 2 weeks`, `holdout_end = "15th if past mid-month else
> last day of last month"`, so the training window rolls forward
> deterministically each run.

---

## 5. Notebook inventory

### 5.1 The standard 9-notebook chain (4 of 5 KPIs)

Four KPIs (`mmm_visits`, `mmm_fs_submits`, `mmm_rental_visits`, `mmm_mf_submits`)
follow this exact 9-notebook structure. ZHL is the exception (see Section 5.3).

```mermaid
flowchart TD
    subgraph SU["shared_utils/  (cross-KPI)"]
        S1[common_functions.py<br/>helpers + MLflow + dates]
        S2[mmm_input_config.yml<br/>allowed channels + column mappings]
        S3[mmm_input_data_preprocessing.py<br/>raw → silver]
        S4[mmm_exogeneous_feature_store.py<br/>smoothed macros]
        S5[mmm_week_condition_check.py]
        S6[mmm_dataset_availability_check.py]
        S7[mmm_model_output_table_creation.py<br/>bootstraps dev tables]
    end

    subgraph KPI["mmm_<kpi>/  (per-KPI, e.g. mmm_mf_submits)"]
        N1[1_feature_engineering.py<br/>adstock + scale + Atan + Hill + holidays + seasonal]
        N2[2_overall_model.py<br/>NUTS fit + funnel effects vs parent KPI]
        N3[3_taxonomy_model_input.py<br/>adstock + scale + Hill at taxonomy level]
        N4[4_taxonomy_model.py<br/>per-channel-network NUTS fits, runs in parallel]
        N5[5_taxonomy_single_variable_channel.py<br/>handles single-variant channels]
        N6[6_taxonomy_output_merge.py<br/>UNION staging → gold taxonomy tables]
        N7[7_overall_response_curves.py<br/>Hill curves + stability check]
        N8[8_taxonomy_response_curves.py<br/>Hill curves at campaign_super level]
        N9[9_stability_loop.py<br/>v_curr vs v_prev comparison]

        N1 --> N2 --> N3 --> N4 --> N5 --> N6 --> N7 --> N8 --> N9
    end

    subgraph RM["rapidmmm Python package (PyPI artifact)"]
        R1[FeatureEngineering<br/>Adstock + Hill + Atan + Sigmoid + Scaling]
        R2[Model.BayesianModel<br/>hierarchical NUTS via numpyro]
        R3[Model.ResponseCurves<br/>scipy.curve_fit Hill]
        R4[Model.FeatureSelection<br/>LASSO + VIF]
        R5[PreProcessing<br/>MarketingMetricsData + BusinessMetricsData]
        R6[PostProcessing.ModelDiagnostics<br/>melted contributions + plots]
        R7[Utils.FunnelEffects<br/>parent→child attribution]
        R8[TimeSeries<br/>Decomposition + MovingAverages]
    end

    S1 -.->|%run| N1
    S1 -.->|%run| N2
    S1 -.->|%run| N3
    S1 -.->|%run| N4
    S1 -.->|%run| N6
    S1 -.->|%run| N7
    S1 -.->|%run| N8
    S1 -.->|%run| N9
    S2 -.->|reads| N1
    S2 -.->|reads| N3
    S3 -.->|outputs feed| N1
    S4 -.->|feature store feeds| N1

    R1 -.->|imports| N1
    R1 -.->|imports| N3
    R2 -.->|imports| N2
    R2 -.->|imports| N4
    R6 -.->|imports| N2
    R6 -.->|imports| N4
    R7 -.->|imports| N2
    R7 -.->|imports| N4
    R3 -.->|imports| N7
    R3 -.->|imports| N8
    R5 -.->|imports| S3
    R8 -.->|imports| S4

    style SU fill:#f0f4ff
    style KPI fill:#fff4e8
    style RM fill:#e8f5e8
```

### 5.2 What each notebook actually does (one line)

| # | Notebook | Reads from | Writes to |
|---|---|---|---|
| 1 | `feature_engineering` | shared silver `mmm_input_preprocessing_overall_data[_rentals]`, exogenous feature store, holiday calendar | `mmm_<kpi>_adstock_transformed_data`, `mmm_<kpi>_final_data_for_modeling` |
| 2 | `overall_model` | notebook 1's output + `artifacts/mmm_<kpi>_priors.csv` | Registers MLflow model in Unity Catalog; appends to gold `mmm_model_output_overall_level` (direct effect) and `mmm_model_combined_output_overall_level` (direct + funnel) |
| 3 | `taxonomy_model_input` | shared silver `mmm_input_preprocessing_taxonomy_data` | `mmm_<kpi>_taxonomy_model_input` + two empty staging tables ready for the parallel fan-out |
| 4 | `taxonomy_model` (×15 parallel) | notebook 3's output + notebook 2's melted output + parent-KPI overall+taxonomy data | Per-channel writes to `mmm_<kpi>_taxonomy_model_output_staging` and `mmm_<kpi>_combined_taxonomy_output_staging` via `replaceWhere channel_network = ...` |
| 5 | `taxonomy_single_variable_channel` | overall model output for single-variant channels | `mmm_<kpi>_taxonomy_single_var_channel` |
| 6 | `taxonomy_output_merge` | All four staging tables from notebooks 4 + 5 | Final gold tables `mmm_model_output_taxonomy_level` + `mmm_model_combined_output_taxonomy_level` |
| 7 | `overall_response_curves` | `mmm_model_combined_output_overall_level` (current version) | `mmm_response_curves_overall_level` + `mmm_response_curves_overall_level_reporting` |
| 8 | `taxonomy_response_curves` | `mmm_model_combined_output_taxonomy_level` (current version) | `mmm_response_curves_taxonomy_level` + `mmm_response_curves_taxonomy_level_reporting` |
| 9 | `stability_loop` | Latest 2 versions of both combined output tables | `mmm_model_output_overall_level_stability` + `mmm_model_output_taxonomy_level_stability`; sends Slack notification on prod completion |

### 5.3 ZHL is the exception

`mmm_zhl_submits/` has 9 notebooks but a **different structure** because ZHL
has its own raw OMP impressions source (Owned Marketing Pages) that's not
captured by the shared input preprocessing:

| # | ZHL notebook | What changes vs the standard chain |
|---|---|---|
| 1 | `input_data_preprocessing` | **ZHL-specific** preprocessing (not the shared one) — writes `mmm_zhl_preprocessing_overall_data` |
| 2 | `taxonomy_model_input` | Taxonomy input prep |
| 3 | `omp_imps_taxonomy_model_input` | **Extra notebook** — OMP impressions split out separately |
| 4 | `taxonomy_model` | Standard taxonomy model |
| 5 | `omp_imps_taxonomy_model` | **Extra notebook** — taxonomy model just for OMP impressions |
| 6 | `taxonomy_model_post_processing` | Merges OMP and non-OMP results |
| 7–9 | `overall_response_curves`, `taxonomy_response_curves`, `stability_loop` | Same as standard chain |

Importantly, **ZHL has no `feature_engineering` notebook and no `overall_model`
notebook**: ZHL Submits is treated entirely as a taxonomy-direct model because
of the OMP source split. ZHL also doesn't have a funnel-parent KPI (it's a
direct lower-funnel KPI).

### 5.4 Schema-migration / admin notebooks (one-shot)

`mmm_model/mmm_table_changes/` holds 12 one-shot scripts that have already
been run to evolve the gold schema (backups, column renames, p_data_date type
change, table additions, etc.). They are **not part of any scheduled job** and
exist only as historical artifacts of past migrations. The most important is
`rapidmmm_schema.yml`, which is the dbt-style source-of-truth for gold table
column descriptions that gets pushed to Unity Catalog via
`mmm_tables_metadata_addition.py`.

---

## 6. Table inventory

The numbers below are exact counts of distinct tables I observed across the
notebooks; the row count in `All_Tables_Description.csv` is 560 because each
column gets its own row.

### 6.1 Raw source tables (read-only inputs)

| Table | Purpose | Read by |
|---|---|---|
| `marketing.marketingde_gold.mmm_marketing_metrics` | Source of truth for impressions, clicks, spend at `dmacode × week × channel × network × LOB × campaign_super × tactic × initiative` | `mmm_input_data_preprocessing.py`, response-curve notebooks (for `init_val_df`) |
| `marketing.marketingde_gold.mmm_business_metrics` | Source of truth for KPI events + econometrics + Google Trends + mortgage rates etc. at `dmacode × week × data_name × metric` | `mmm_input_data_preprocessing.py`, all KPI feature-engineering notebooks |
| `marketing.marketingde_silver.mmm_calendar` | Day-grain calendar with week anchor | KPI feature-engineering notebooks (holiday merge) |
| `marketing.rapidmmm_silver.mmm_holidays` | USA holiday list through 2032 | KPI feature-engineering notebooks |
| `marketing.marketingde_silver.mmm_regionmapping` | DMA name ↔ dmacode mapping | `rapidmmm.PostProcessing.BusinessDiagnostics.get_dma_dict` |

### 6.2 Silver — shared (produced by MMM Input Job)

| Table | Producer | Consumer notebooks | Refresh |
|---|---|---|---|
| `mmm_input_preprocessing_overall_data` | `mmm_input_data_preprocessing.py` | Visits NB 1, FS Submits NB 1 | Overwrite per Input run |
| `mmm_input_preprocessing_overall_data_rentals` | `mmm_input_data_preprocessing.py` | Rental Visits NB 1, MF Submits NB 1 | Overwrite |
| `mmm_input_preprocessing_taxonomy_data` | `mmm_input_data_preprocessing.py` | All KPIs' NB 3 | Overwrite |
| `mmm_input_preprocessing_overall_spend_data` | `mmm_input_data_preprocessing.py` | Visits NB 2, FS Submits NB 2 | Overwrite |
| `mmm_input_preprocessing_overall_spend_data_rentals` | `mmm_input_data_preprocessing.py` | Rental Visits NB 2, MF Submits NB 2 | Overwrite |
| `mmm_input_preprocessing_taxonomy_spend_data` | `mmm_input_data_preprocessing.py` | All KPIs' NB 4 | Overwrite |
| `mmm_zhl_preprocessing_overall_data` | ZHL NB 1 | ZHL downstream | Overwrite |
| `mmm_automation_exogenous_feature_store` | `mmm_exogeneous_feature_store.py` | All KPIs' NB 1 | Merge (upsert) |
| `vw_mmm_input_preprocessing_overall_data` | `mmm_input_data_preprocessing.py` (CREATE OR REPLACE VIEW) | EDA / QC | View — recomputed |
| `mmm_<kpi>_corr_input_data_overall` | `mmm_input_data_preprocessing.py` | EDA only | Overwrite |
| `mmm_<kpi>_corr_post_fe` | KPI NB 1 | EDA only | Overwrite |

### 6.3 Silver — per-KPI (produced by `<KPI>` Job)

| Table pattern | Producer | Consumer |
|---|---|---|
| `mmm_<kpi>_adstock_transformed_data` | NB 1 | NB 2, NB 4, NB 5 (for raw impression context) |
| `mmm_<kpi>_final_data_for_modeling` | NB 1 | NB 2 |
| `mmm_<kpi>_overall_model_prediction_data` | NB 2 | EDA + diagnostics |
| `mmm_<kpi>_overall_model_melted_data` | NB 2 | NB 4 (the per-channel data builder uses node-1 contributions from here) |
| `mmm_<kpi>_overall_model_melted_spark_ready` | NB 2 | downstream consumers / debugging |
| `mmm_<kpi>_taxonomy_model_input` | NB 3 | NB 4, NB 5 |
| `mmm_<kpi>_taxonomy_model_output_staging` | NB 4 (×15 parallel writes) | NB 6 |
| `mmm_<kpi>_combined_taxonomy_output_staging` | NB 4 (×15 parallel writes) | NB 6 |
| `mmm_<kpi>_taxonomy_single_var_channel` | NB 5 | NB 6 |
| `mmm_<kpi>_combined_taxonomy_single_var_channel` | NB 5 | NB 6 |
| `mmm_model_output_stat` (shared) | NB 2, NB 4 | Diagnostics |
| `mmm_model_job_metadata_detail` (shared, prod/stage only) | every Delta write via `intermediate_and_meta_table_write` in `common_functions.py` | Audit / job tracking |

### 6.4 Gold tables (the canonical model outputs)

These are the tables consumed by Tableau and the downstream `incrementality-layer`.

| Table | What's in it | Granularity | Append vs overwrite |
|---|---|---|---|
| `mmm_model_output_overall_level` | Channel × network direct-effect contributions, with coefficients + HDI bounds + predicted + spend + impressions | dma × week × channel × network × model_variable | Append per version (`replaceWhere business_kpi AND version`) |
| `mmm_model_output_taxonomy_level` | Same but at full taxonomy (channel × network × campaign_super × lob) | dma × week × channel × network × campaign_super × lob | Append per version |
| `mmm_model_combined_output_overall_level` | Overall direct effect **plus** funnel-effect attributions from upstream KPI (e.g., Visits → FS Submits funnel rows tagged `Funnel Effect`) | Same as overall + `type` and `funneleffect_variable` columns | Append per version |
| `mmm_model_combined_output_taxonomy_level` | Same as taxonomy + funnel effects | Same as taxonomy + `type`, `funneleffect_variable` | Append per version |
| `mmm_response_curves_overall_level` | Hill curve params (`bottom`, `top`, `slope`, `saturation`, `r_2`) per channel × network, both DMA and national | (dmacode∈{nan, dmacode}) × channel × network | Append per version |
| `mmm_response_curves_taxonomy_level` | Same at channel × network × campaign_super | + campaign_super | Append per version |
| `mmm_response_curves_overall_level_reporting` | 150-point spend → predicted curve sampled from above, for direct Tableau plotting | channel × network × spend grid | **Overwrite** (only latest) |
| `mmm_response_curves_taxonomy_level_reporting` | Same at campaign_super level | + campaign_super | **Overwrite** |
| `mmm_model_output_overall_level_stability` | Per channel × network: `return_lower/higher` (HDI bounds / impressions) for both versions, overlap %, point-estimate %, `Final_Stability` | channel × network × (version_curr, version_prev) | Append per version pair |
| `mmm_model_output_taxonomy_level_stability` | Same at campaign × LOB × channel × network | Adds campaign_super, core_lob | Append per version pair |
| `mmm_dmamapping` | DMA code → DMA name | dmacode | Periodic refresh |
| `mmmrapid_budget_allocation` | Output of the downstream budget optimizer (consumes RC tables) | file_name × budget_amt × goal | Append per optimization run |

### 6.5 Reading the gold tables: which one do I actually want?

| Question | Table to query |
|---|---|
| "What did channel X drive last week?" | `mmm_model_combined_output_overall_level` filtered to the latest `version` |
| "What did campaign super Y in LOB Z drive?" | `mmm_model_combined_output_taxonomy_level` |
| "If I spent $X on channel Y, what do I get?" | `mmm_response_curves_overall_level_reporting` (Tableau-ready 150-point grid) |
| "Did channel X's ROI shift between versions?" | `mmm_model_output_overall_level_stability` |
| "What did this MMM run actually look like (job ID, version, when)?" | `mmm_model_job_metadata_detail` |

> **Interview angle — "What are the alternatives to MMM and why pick MMM
> here?"** Three alternatives and their failure modes for Zillow:
> - **Multi-Touch Attribution (MTA)** — needs user IDs. Can't measure TV/OOH/
>   Audio. iOS-14 broke its accuracy for app installs (App|Apple Search).
> - **Incrementality testing (geo-experiments / A/B)** — gold standard but
>   slow, expensive, and only tests one channel at a time. Zillow uses these
>   for *calibration* (the Email Simon Data recalibration uses AOT) but can't
>   afford to run them on all 25 channel-networks every two weeks.
> - **Last-click attribution** — over-credits bottom-of-funnel channels (SEM
>   branded) and under-credits awareness channels (Linear TV, Connected TV).
>   This is what MMM exists to fix.
>
> So the production stack uses **MMM as the budget-allocation primary**,
> **AOT geo-experiments as the calibration layer** (recalibrating MMM where it
> systematically over/under-credits a channel — see Email Simon Data
> recalibration), and **last-click for in-platform optimization** (which ads
> to bid on inside SEM, separately from MMM).

---

## 7. Versioning + metadata conventions

Every gold table row carries a consistent metadata header so any historical
slice is reproducible.

| Column | Type | Where it comes from |
|---|---|---|
| `version` | string `vN` | Auto-incremented per KPI per run: `MAX(vN) + 1` from `mmm_model_combined_output_overall_level WHERE business_kpi = '<KPI>'`. Override-able via `model_version_number` widget. |
| `business_kpi` | string | Hardcoded per KPI notebook (e.g., `"MF Submits"`) |
| `mcmc_id` | string | `<channel_network><YYYYMMDDHHMMSS>` set in `BayesianModel.Model.__init__` — uniquely identifies one MCMC run |
| `modeltype` | string | `"Overall"` or `"Taxonomy"` (set by `BayesianModel.Model.modeltype`) |
| `run_time` | string | `datetime.now().strftime("%Y-%m-%d %H:%M:%S")` at write time |
| `p_data_date` | date | `date.today()` at write time — used by downstream consumers to find latest data per KPI via `MAX(p_data_date) GROUP BY business_kpi` |
| `train_holdout` | string | `"Train"` or `"Holdout"` — set by comparing `week_monday < holdout_start_week` |
| `type` (combined tables only) | string | `"Direct Effect"` or `"Funnel Effect"` — set by `FunnelEffects.funnel_effects()` |
| `funneleffect_variable` (combined tables only) | string | The parent KPI name (e.g., `"Visits"`) on funnel rows; blank on direct rows |

**Auto-version logic** (every notebook does this same dance):

```text
if model_version_number == "NA":
    max_v = SELECT MAX(version) FROM gold.mmm_model_combined_output_overall_level
            WHERE business_kpi = '<KPI>'    # extracts integer from 'vN'
    final_model_version = f"v{max_v + 1}"
    latest_model_version = f"v{max_v}"      # used by stability comparison
else:
    final_model_version = f"v{model_version_number}"
    latest_model_version = f"v{int(model_version_number) - 1}"
```

**Idempotent writes.** Every gold write is `mode("overwrite")` +
`replaceWhere business_kpi = '<KPI>' AND version = '<vN>'`, so re-running a
job with the same `model_version_number` is safe — it overwrites only that
KPI's slice of that version. This means the standard recovery from a failed
run is **just re-run with `model_version_number=N` to the same N**, no
manual cleanup.

**Job metadata audit.** `intermediate_and_meta_table_write()` in
`common_functions.py` writes both the data and a metadata row to
`mmm_model_job_metadata_detail` containing `business_kpi, model_version,
job_id, job_name, run_id, table_name, delta_table_version, environment,
dates_list_used`. This lets you trace any output table row back to the exact
Databricks job execution that produced it — critical for prod debugging.

---

## 8. Reading roadmap for the rest of this learning library

Read in this order; each doc assumes you've read the ones before it.

| Doc | Title | Purpose | Why now |
|---|---|---|---|
| **00** | MMM Ecosystem Overview | The single map | You're here |
| **01** | Modeling theory (adstock, Hill, hierarchical Bayes, NUTS, funnel effects) | The math, with intuition | Read before any deep dive — you need the equations to read the code |
| **02** | The `rapidmmm` library tour | What each module does, how the classes interact | Once you know the theory, see the implementation |
| **03** | Shared utilities + orchestration | `common_functions`, `mmm_input_config.yml`, Databricks job structure | Now you can read the per-KPI notebooks |
| **04** | Data Lineage and Schema Catalogue | Every Delta table and column in the system | The searchable schema reference |
| **05** | FS Submits — Overall Model Track | Notebooks 1 and 2 for FS Submits | The primary KPI deep dive (math-heavy) |
| **06** | FS Submits — Taxonomy Track | Notebooks 3–6 for FS Submits | The 15-way parallel taxonomy fan-out |
| **07** | FS Submits — Response Curves and Stability | Notebooks 7–9 for FS Submits | Marketing-facing deliverables |
| **08** | Other KPIs — Comparative (Visits / ZHL / Rentals / MF) | How each KPI differs from FS Submits | Once FS Submits is in your head, the others are deltas |
| **09** | Operations and Interview Capstone | Schema migrations + 30-question interview prep | Final — production engineering + interview rehearsal |

**Glossary refresher** (referenced consistently across all docs):

| Term | Definition |
|---|---|
| **DMA** | Designated Market Area — Nielsen US TV market, ~210 of them, identified by `dmacode` |
| **LOB** | Line of Business — PA, Rentals, ZHL, Seller, Multi Product, ZGMI, New Con - Builder, Agent Advertising |
| **Campaign Super** | Marketing-campaign category — Buyer, Brand, Rental, Agent, Elevate, NonMarketing |
| **Taxonomy** | The 4-level hierarchy `channel × network × lob × campaign_super` (`taxo_order` in config) |
| **AOT** | Always-On Testing — geo-experiment incrementality tests used to calibrate MMM |
| **SoV** | Share of Voice — your impressions ÷ total impressions in that DMA-week |
| **Adstock** | Carryover transform — this week's impressions affect future weeks (lagged effect) |
| **Hill transform** | Saturation curve — doubling impressions does NOT double effect (diminishing returns) |
| **NUTS** | No-U-Turn Sampler — the MCMC algorithm used by `numpyro` for posterior sampling |
| **HDI** | Highest Density Interval — Bayesian equivalent of a confidence interval (the system uses 95% HDI by default) |
| **Funnel effect** | Indirect attribution — the share of *Visits* contributions attributable to a channel that also gets credited proportionally for *FS Submits* |
| **Direct effect** | The contribution a channel makes directly to a KPI in its own model — vs the funnel effect propagated from upstream |
| **Node 1 / Node 2** | Funnel-effects terminology: node 1 is the parent KPI (e.g., Visits), node 2 is the child KPI (e.g., FS Submits) |
| **`vN`** | Model version — a monotonically-incrementing integer per KPI |
| **`p_data_date`** | The date the data was written; used by reporting consumers to find the latest run |

> **Common interview questions you should be able to answer cold after this doc:**
> 1. *"Walk me through Zillow's MMM end-to-end at a high level."* — Use Section 3 + Section 4.
> 2. *"How many KPIs and why those five?"* — Use Section 2.
> 3. *"What's the difference between the overall and taxonomy models?"* —
>    Overall = channel × network only (broader prior, fewer features);
>    Taxonomy = channel × network × LOB × campaign_super (15 separate models,
>    one per channel-network, with the dependent variable rebuilt from the
>    overall model's predictions). See Docs 05 and 06.
> 4. *"Why are there two output tables — `_overall_level` and
>    `_combined_output_overall_level`?"* — The first is direct effect only;
>    the second adds funnel-effect rows showing how upstream KPI channels
>    propagate. See Doc 01 Section 8 (funnel attribution).
> 5. *"What happens on a bi-weekly Thursday run?"* — Cron fires, week-parity
>    check runs, ~27 tasks execute, model version increments, ~10 gold tables
>    get a new `version` slice, Tableau dashboards auto-refresh on read.
> 6. *"How do you know if a new model version is trustworthy?"* — The
>    stability loop (Notebook 9) compares the current version's per-channel
>    ROI against the previous version, flagging channels whose HDI bands
>    don't overlap >50% AND whose point estimate moved >25%. See Doc 07.

---

**Next:** Read [01_modeling_theory.md](01_modeling_theory.md) for adstock, Hill,
hierarchical Bayesian regression, NUTS, and funnel-effect math — the
prerequisites for reading any production notebook.
