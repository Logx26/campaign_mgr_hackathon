---
doc_id: 02
title: rapidmmm Library Internals — Every Class, Every Formula, Every Code Path
companion_docs:
  - 00_mmm_ecosystem_overview.md (system map)
  - 01_mmm_methodology_primer.md (the math this code implements)
  - 03_shared_utilities_and_orchestration.md (how notebooks call this library)
  - 05_fs_submits_feature_engineering_and_overall_model.md (the library in production)
---

# 02 — rapidmmm Library Internals

> **What this doc is.** A class-by-class, file-by-file tour of the in-house
> `rapidmmm` Python package (`rapidmmm/`). Every KPI notebook in the
> production codebase imports from this library. After reading, you should
> be able to look at any `import rapidmmm.X.Y` line and know exactly what
> gets executed.
>
> **Math depth.** Heavy in Section 4 (BayesianModel — the actual NumPyro
> probabilistic model) and Section 7 (FunnelEffects — the attribution algorithm).
> All other sections are prose + tables; code snippets only where they
> clarify a non-obvious algorithm.
>
> **Prerequisites.** Read Doc 01 first — the math here is the
> implementation of formulas derived there.

> **Package version covered.** `rapidmmm v1.1.19` per
> [`rapidmmm/_version.py`](D:/MMM_Learning/rapidmmm-main/rapidmmm/_version.py).

---

## 1. Package overview

`rapidmmm` is published to ZG Artifactory as a private wheel
(`rapidmmm-1.1.19-py3-none-any.whl`). The Databricks job clusters install
it via `pip install rapidmmm -i https://artifactory.zgtools.net/...`.

It exposes six sub-packages, each focused on one stage of the MMM
lifecycle.

```mermaid
flowchart LR
    subgraph PRE["PreProcessing"]
      MM[MarketingMetricsData]
      BM[BusinessMetricsData]
      DE[DataExploration.PlotlyVisualizer]
    end

    subgraph FE["FeatureEngineering"]
      FEadstock[FeatureEngineering<br/>Adstock + Hill + Atan + Sigmoid<br/>+ Grid search]
      FEscale[FeatureScaling<br/>MeanScalingRegional]
    end

    subgraph TS["TimeSeries"]
      MA[MovingAverages.Smoothing]
      DC[Decomposition.DetectSeasonality]
    end

    subgraph MOD["Model"]
      BAY[BayesianModel.Model<br/>NumPyro/NUTS hierarchical]
      RC[ResponseCurves.ResponseCurveFit<br/>Hill curve via scipy.curve_fit]
      FS[FeatureSelection<br/>LASSO grid + VIF clustering]
    end

    subgraph POST["PostProcessing"]
      MD[ModelDiagnostics<br/>az.summary + predictions + melted contributions]
      BD[BusinessDiagnostics<br/>contribution plots + cost-per]
    end

    subgraph UT["Utils"]
      FUN[FunnelEffects<br/>two-node attribution]
      CONN[*Connect.py<br/>AWS/Hive/Native/Trino connectors]
      CO[channel_outputs.csv]
    end

    PRE -->|silver tables| FE
    FE --> MOD
    TS --> FE
    FE --> POST
    MOD --> POST
    MOD --> FUN
    FUN --> POST

    style PRE fill:#eef
    style FE fill:#fef
    style TS fill:#efe
    style MOD fill:#fee
    style POST fill:#ffe
    style UT fill:#eff
```

**Which notebooks import what** (from the `mmm_mf_submits` chain — the four
non-ZHL KPIs follow this same pattern):

| Notebook | rapidmmm imports |
|---|---|
| `1_*_feature_engineering.py` | `FeatureEngineering.FeatureEngineering as fe`, `FeatureEngineering.FeatureScaling.MeanScalingRegional`, `FeatureEngineering.FeatureEngineering.{SigmoidTransform, AtanTransform}`, `TimeSeries.MovingAverages as ma`, `TimeSeries.Decomposition as sd`, `Model.FeatureSelection as fse` |
| `2_*_overall_model.py` | `Model.BayesianModel as mt`, `PostProcessing.ModelDiagnostics as md`, `Utils.FunnelEffects.FunnelEffects as fne` |
| `3_*_taxonomy_model_input.py` | Same FE imports as notebook 1 (minus seasonality) |
| `4_*_taxonomy_model.py` | `Model.BayesianModel`, `PostProcessing.{ModelDiagnostics, BusinessDiagnostics}`, `Utils.FunnelEffects` |
| `5_*_taxonomy_single_variable_channel.py` | No rapidmmm imports — pure pandas + PySpark |
| `6_*_taxonomy_output_merge.py` | No rapidmmm imports — UNION ALL on staging tables |
| `7_*_overall_response_curves.py` | `Model.ResponseCurves as rc` |
| `8_*_taxonomy_response_curves.py` | `Model.ResponseCurves as rc` |
| `9_*_stability_loop.py` | No rapidmmm imports — pure pandas + PySpark |

**Shared utilities** (`mmm_model/shared_utils/mmm_input_data_preprocessing.py`)
import `PreProcessing.MarketingMetricsData`, `PreProcessing.BusinessMetricsData`,
and `PreProcessing.DataExploration.PlotlyVisualizer as pviz`. So the
PreProcessing modules **are** in the production path, just one layer up
from the KPI notebooks.

The `Model.FeatureSelection` import in notebooks 1 and 3 is **vestigial** —
the class is imported but **never called** in any production KPI notebook
(see Section 6 below). The actual feature selection was done during initial
development; current production uses fixed config-driven channel lists.

> **The boundary between library and notebooks.** The library owns *pure
> functions over data* — transforms, model fits, attribution math,
> plotting helpers. The notebooks own *orchestration over Delta tables* —
> reading silver, calling the library, writing gold, MLflow logging, job
> metadata. This split is what makes the library re-usable: every KPI
> notebook builds the same hierarchical Bayesian model by calling
> `rapidmmm.Model.BayesianModel.Model(...)`, but each chooses its own
> features, priors, and target.

---

## 2. `FeatureEngineering.FeatureEngineering` — Adstock and saturation

[`FeatureEngineering.py`](D:/MMM_Learning/rapidmmm-main/rapidmmm/FeatureEngineering/FeatureEngineering.py)
contains 9 classes spanning ~800 lines. The classes are sklearn-style
(`fit` / `transform`) so they compose with sklearn pipelines, but in this
codebase they're always called directly.

### 2.1 The transforms at a glance

| Class | Purpose | Formula | Notebook usage |
|---|---|---|---|
| `ExponentialAdStock(decay, length)` | Geometric carryover via `scipy.signal.convolve2d` | $\tilde{x}_t = \sum_{i=0}^{L} \lambda^i \cdot x_{t-i}$ (un-normalized) | Used for `SEM\|Google Performance Max` in MF Submits config |
| `DelayedAdStock(max_lag, decay_rate, delay)` | Bell-shaped delayed carryover | $w_i = \lambda^{(i-\delta)^2}$ (normalized) | The dominant variant — used by Linear TV, Connected TV, OOH, Owned Social, etc. |
| `GeometricAdStock(max_lag, decay_rate)` | Geometric (normalized exponential) | $w_i = \lambda^i$ (normalized) | Historical (older Visits priors) |
| `WeibullAdStock(shape_k, scale, dist_type)` | Weibull-PDF weighted lags | Robyn-style PDF weights | Defined but not in current production configs |
| `AddLags(max_lag)` | Raw lagged values as separate features | $w_i = 1$ at lag $i$ | Grid search only — never in production |
| `HillTransform(slope, saturation)` | Hill saturation | $\text{Hill}(x) = 1 / (1 + (x/K)^{-s})$ | All channels post-adstock |
| `AtanTransform()` | arctan saturation | $\text{Atan}(x) = \arctan(x)$ | Specific channels per config — heavy-tailed features |
| `SigmoidTransform()` | Sigmoid saturation | $\sigma(x) = 1/(1+e^{-x})$ | Config-toggleable, currently null in MF Submits |
| `ExponentialTransform(a)` | $1 - e^{-ax}$ saturation | $1 - e^{-ax}$ | Defined but not used in production |

The two orchestrator classes that glue these together:

| Class | What it does |
|---|---|
| `FeatureEngineeringAdStockGrid(grid_dict, regioncol, datecol)` | Grid search — applies all combinations of adstock parameters and returns one column per combination. Used with `FeatureSelectionGridSearch` for tuning. **Not in production runs.** |
| `FeatureEngineeringAdStock(params_dict, regioncol, datecol)` | Per-channel orchestrator — `params_dict` is a dict keyed by channel-network identifier, mapping each to `{'AdStock': <variant>, 'params': {...}}`. **This is the production entry point.** |

### 2.2 The production entry point: `FeatureEngineeringAdStock`

The class is instantiated once per KPI notebook with the config-loaded
parameter dictionary:

```python
adstock = fe.FeatureEngineeringAdStock(
    params_dict=config,        # from config_param.yml::adstock_hill_best_params
    datecol='week_monday',
    regioncol='dmacode',
)
adstock_transform_data = adstock.fit_transform(
    cols_X=impression_columns,
    data=data,
    channel_list=channel_network_keys,  # ['|App|Apple Search', '|App|Facebook', ...]
)
```

Inside `fit_transform` → `FeatureEngineeringMultipleVars`, for each
channel-network key in `channel_list`:

1. Look up the channel's params in `params_dict[key]` to find the
   AdStock variant name and parameters.
2. Resolve the transform class via the lookup
   `Transformdict = {'Exponential': ExponentialAdStock, 'Delayed': DelayedAdStock, ...}`.
3. Instantiate the transform with the parameters: `ads = transform_cls(**params)`.
4. For each column matching the channel-network key (`[c for c in cols_X if key in c]`):
   - If `params['max_lag'] == 0` (no carryover), short-circuit to a simple
     groupby-sum.
   - Otherwise, sort by `[dmacode, week_monday]`, group by `dmacode`, and
     apply `ads.fit(x).transform(x)` per DMA.
5. Rename the output column with the adstock's `prefix` attribute, e.g.,
   `_delayed_lag_6_decay_0.5_delay_4` — this is why every adstocked column
   in `mmm_<kpi>_adstock_transformed_data` has the parameter suffix in its
   name.

The reason it groups by DMA: adstock is a *temporal* convolution, so each
DMA's time series must be processed independently. If you naively
convolved the entire stacked dataset, lag-1 of DMA-2's first week would
incorrectly inherit DMA-1's last week.

### 2.3 Delayed adstock — the formula and its kernel

`DelayedAdStock` is the most commonly-used variant in production. The
weight kernel and the convolution itself are implemented in
`compute_adstock` (lines 116–141). For each media variable
$j$, lag $i$, with parameters $(L, \lambda, \delta)$:

$$
w_i = \lambda^{(i - \delta)^2}, \qquad i \in \{0, 1, \ldots, L-1\}
$$

$$
\tilde{x}_t = \frac{\sum_{i=0}^{L-1} w_i \cdot x_{t-i}}{\sum_{i=0}^{L-1} w_i}
$$

The implementation:

```python
# DelayedAdStock.compute_adstock — the core ~7 lines
for media_index in range(lagged_X.shape[1]):
    lag_weights = np.arange(lagged_X.shape[2])
    lag_weights = np.power(
        list(self.decay_rate)[media_index],
        (lag_weights - list(self.delay)[media_index]) ** 2
    )
    carryover_X[:, media_index] = (
        np.dot(lagged_X[:, media_index, :], lag_weights) / lag_weights.sum()
    )
```

The 3-D `lagged_X` tensor has shape `(n_obs, n_features, max_lag)` and is
built by repeatedly rolling the input by `np.roll` with zeros pre-padded.
The kernel is normalized by `lag_weights.sum()` — so the average level of
the series is preserved (an all-1's series stays at 1).

**Why $(i-\delta)^2$ and not $|i-\delta|$?** Squaring distance produces a
narrower, more bell-shaped weight distribution. With $\lambda = 0.5$, the
weight at distance 2 from the peak drops to $0.5^4 = 0.0625$ (squared) vs
$0.5^2 = 0.25$ (linear). The squared form models advertising memory better
empirically — the influence of a past impression doesn't decay
exponentially with time-since but rather drops off sharply once it's
outside the "peak window."

### 2.4 Exponential adstock — the convolution variant

`ExponentialAdStock` uses `scipy.signal.convolve2d` directly with an
un-normalized kernel:

```python
# ExponentialAdStock — fit builds the kernel; transform convolves
self.sliding_window_ = (
    self.decay ** np.arange(self.length + 1)
).reshape(-1, 1)
# in transform:
convolution = convolve2d(X, self.sliding_window_)
if self.length > 0:
    convolution = convolution[:-self.length]
```

The kernel is $\mathbf{w} = (1, \lambda, \lambda^2, \ldots, \lambda^L)$.
The truncation `convolution[:-self.length]` removes the trailing edge
artifacts from `convolve2d` (which returns `len(x) + len(w) - 1`
elements).

Critically — and this is a real difference between the two variants —
`ExponentialAdStock` does **not normalize** by `lag_weights.sum()`. So
where `DelayedAdStock` produces adstocked values comparable in scale to
the original input, `ExponentialAdStock` can produce values up to
$\sum_i \lambda^i \approx 1/(1-\lambda)$ times larger than the input.
For `SEM|Google Performance Max` (`decay=0.89, length=26`), the maximum
amplification factor is approximately $1/(1-0.89) \approx 9.1\times$ —
the adstocked values are 9× the raw impressions. This is fine for the
downstream Hill+model pipeline (mean-scaling absorbs the absolute level)
but worth knowing when debugging.

### 2.5 Hill, Atan, Sigmoid — the saturation transforms

All three follow the same sklearn pattern of `fit` (validates
dimensions; doesn't fit any parameters) and `transform` (applies the
formula). The formulas:

**`HillTransform(slope, saturation)`** — line 399:

```python
def Hill(self, X):
    return 1 / (1 + np.power(np.divide(X, self.saturation), -self.slope))
```

implementing

$$
\text{Hill}(x) = \frac{1}{1 + (x/K)^{-s}} = \frac{x^s}{K^s + x^s}
$$

Output bounded in $(0, 1)$; equals 0.5 at $x = K$.

**`SigmoidTransform()`** — line 436:

```python
def Sigmoid(self, X):
    return 1 / (1 + np.exp(-X))
```

implementing $\sigma(x) = 1/(1+e^{-x})$. Output bounded in $(0, 1)$;
equals 0.5 at $x = 0$.

**`AtanTransform()`** — line 472 (note: uses a Python for-loop):

```python
def arctan(self, X):
    x_Atan = np.zeros((X.shape[0],))
    for i in range(X.shape[0]):
        x_Atan[i] = math.atan(X[i])
    return x_Atan
```

implementing $\arctan(x)$. Output bounded in $(-\pi/2, \pi/2)$.

For the math derivations and business interpretations of these curves see
[Doc 01 Section 4](01_mmm_methodology_primer.md#4-saturation--modeling-diminishing-returns).

> **Interview angle — "How do you handle adstock and saturation in
> code?"** *"`rapidmmm.FeatureEngineering.FeatureEngineering` has
> sklearn-style transformer classes for each variant.
> `FeatureEngineeringAdStock` is the orchestrator that takes a per-channel
> params dict from `config_param.yml`, dispatches to the right adstock
> class, groups by DMA (so the convolution doesn't bleed across regions),
> and returns a DataFrame with one adstocked column per input — the
> column name includes the parameter suffix so the downstream pipeline
> can identify the variant. Saturation is then applied on top in the
> notebook: arctan first on heavy-tailed columns (specific to channel
> per `transform_cols_atan` config), optionally sigmoid (currently null),
> then Hill with per-channel slope and saturation from config."*

---

## 3. `FeatureEngineering.FeatureScaling.MeanScalingRegional`

[`FeatureScaling.py`](D:/MMM_Learning/rapidmmm-main/rapidmmm/FeatureEngineering/FeatureScaling.py)
is a 100-line class implementing one transform: divide each variable by
its per-region mean.

### 3.1 The contract

```python
msr = MeanScalingRegional(
    regioncol='dmacode',
    Train=True,                # forward transform; False = inverse
    columns=[...],             # which cols to scale (excludes dmacode, week_monday)
)
train_scaled = msr.fit(train_data).transform(train_data)
holdout_scaled = msr.transform(holdout_data)   # uses train means
```

`fit` computes `self.means = train_data[[regioncol] + columns].groupby(regioncol).mean()`
— a `(n_regions × n_columns)` DataFrame of per-DMA means.

`transform` (when `Train=True`) does for each column $c$:

$$
x_{c,d,t}^{\text{scaled}} = \frac{x_{c,d,t}}{\overline{x}_{c,d}}
$$

where $\overline{x}_{c,d}$ is the column $c$ mean within DMA $d$ over the
training window.

`transform` (when `Train=False`) does the inverse — multiplies by the
stored means — used when you need to convert model-space predictions back
to original units.

### 3.2 Why per-region scaling specifically

A national scaler (divide by global mean) would normalize the overall
level but **not** the cross-DMA variation. Per-DMA scaling makes each
DMA's series have mean ≈ 1 in its own scale, which means:

- A unit change in scaled impressions is the **same fractional change**
  across all DMAs ("1% above this DMA's typical level"), making
  coefficients comparable across DMAs.
- Coefficients become **elasticity-like**: $\beta_c = 0.05$ means "a 1%
  rise above the DMA's normal impression level produces a 0.05% rise in
  the KPI relative to its normal level."
- NUTS numerical stability is much better — all features are O(1) instead
  of varying over 6 orders of magnitude across channels.

### 3.3 Train-fit, holdout-transform contract

The notebook always splits `train_data` and `holdout_data` *before*
scaling, fits the scaler on train only, then applies `transform` to
holdout using the trained means. This prevents leakage — if the holdout
mean leaked in, the model would see a future-information signal during
training.

For details on how this fits into the full feature-engineering pipeline,
see [Doc 05 Section scaling](05_fs_submits_feature_engineering_and_overall_model.md).

---

## 4. `Model.BayesianModel` — the NumPyro hierarchical model (deep dive)

This is the heart of the library.
[`BayesianModel.py`](D:/MMM_Learning/rapidmmm-main/rapidmmm/Model/BayesianModel.py)
is 388 lines and contains one production class: `Model`. It wraps a
NumPyro probabilistic-program function, fits it with the NUTS sampler,
and exposes the fitted MCMC object and posterior samples.

### 4.1 The constructor

```python
class Model:
    def __init__(
        self,
        region_col,        # 'dmacode' — used to LabelEncoder the regions
        X_col,             # list of feature columns — impressions, controls
        y_col,             # KPI column name
        hierarchical,      # True in production; False is untested
        samples,           # 2000 in production
        warmup,            # 1000 in production
        nonnegative=True,  # True → impression coefficients use TruncatedNormal
        priors=None,       # pandas DataFrame from priors.csv (Mean, Sd, optionally Sigma_Sd)
        modeltype='Overall',  # 'Overall' includes intercept α; 'Taxonomy' omits it
        channelgrouping=None, # tag for the model; default 'ChannelNetwork'
        checkpoint=False,    # JAX checkpointing for memory-bound runs
    )
```

Three details worth flagging:

1. **`region_col`** can be a single column name OR a list of column names.
   The KPI notebooks pass `['dmacode']`. The class wraps it with a
   `LabelEncoder` so DMA codes become contiguous integers 0..D-1 (NumPyro
   needs integer indices).

2. **`priors`** is the CSV DataFrame from `mmm_<kpi>_priors.csv`. The
   class only consults it for columns containing the literal substring
   `"impressions|"`. Non-impression columns (controls) always use default
   priors regardless of what `priors` contains.

3. **`modeltype`** controls whether the model includes an intercept α.
   - `'Overall'` — includes per-DMA α (the model's baseline; non-zero
     when nothing else explains the KPI level).
   - `'Taxonomy'` — omits α entirely. The taxonomy-level dependent
     variable is *already* the residual after the overall model's
     attribution (see Doc 06), so an intercept would double-count the
     baseline.

4. **`channelgrouping`** is a string label that namespaces the model
   instance. It becomes the prefix of `self.modelid` (which is
   `channelgrouping + YYYYMMDDHHMMSS`), and that `modelid` is what
   gets written to the `mcmc_id` column of every gold output row.
   For Overall models (NB2) the default `None` resolves to
   `'ChannelNetwork'`. For per-channel Taxonomy models (NB4) the
   notebook passes the literal channel-network string (e.g.
   `'|Paid Social|Facebook'`) so each per-channel run gets a uniquely-
   identifiable `mcmc_id` like `|Paid Social|Facebook20251215093122`.
   This lets downstream consumers tell which of the 15+ parallel
   taxonomy models produced any given output row.

### 4.2 The probabilistic model in full

The function passed to NumPyro is built by `_base_model_fn(include_intercept)`
which closes over the constructor's prior arrays. Here is the model in
mathematical form first, then the actual `numpyro.sample` calls.

**The math** — for $C$ predictors split into $C^+$ impression channels
(non-negative) and $C^0$ controls (unrestricted), $D$ DMAs, $N$
observations indexed by DMA $d_n$ and predictor vector $\mathbf{x}_n$:

**Hyperpriors (population-level):**

$$
\mu_{\alpha} \sim \text{TN}(0, 1; \text{low}=0) \qquad \sigma_{\alpha} \sim \text{HalfNormal}(5)
$$

$$
\boldsymbol{\mu}_{\beta}^{(0)} \sim \mathcal{N}(\boldsymbol{\mu}_{\text{prior}}^{(0)}, \boldsymbol{\sigma}_{\text{prior}}^{(0)}) \qquad \text{for controls}
$$

$$
\boldsymbol{\mu}_{\beta}^{(+)} \sim \text{TN}(\boldsymbol{\mu}_{\text{prior}}^{(+)}, \boldsymbol{\sigma}_{\text{prior}}^{(+)}; \text{low}=0) \qquad \text{for impressions}
$$

$$
\boldsymbol{\sigma}_{\beta} \sim \text{HalfNormal}(\boldsymbol{\sigma}_{\text{sigma-prior}})
$$

**DMA-level coefficients (the partial-pooling layer):**

$$
\alpha_d \sim \text{TN}(\mu_\alpha, \sigma_\alpha; \text{low}=0) \quad \text{if include\_intercept}
$$

$$
\boldsymbol{\beta}_d^{(0)} \sim \mathcal{N}(\boldsymbol{\mu}_\beta^{(0)}, \boldsymbol{\sigma}_\beta^{(0)}) \quad \text{(broadcast to } D \text{ DMAs)}
$$

$$
\boldsymbol{\beta}_d^{(+)} \sim \text{TN}(\boldsymbol{\mu}_\beta^{(+)}, \boldsymbol{\sigma}_\beta^{(+)}; \text{low}=0) \quad \text{(broadcast to } D \text{ DMAs)}
$$

**Likelihood (data layer):**

$$
\hat{y}_n = \mathbf{B}_{d_n, :} \cdot \mathbf{x}_n + \alpha_{d_n}
$$

$$
\sigma \sim \text{HalfNormal}(5)
$$

$$
y_n \sim \mathcal{N}(\hat{y}_n, \sigma)
$$

where $\mathbf{B}$ is the $(D \times C)$ matrix obtained by stitching
$\boldsymbol{\beta}^{(0)}$ and $\boldsymbol{\beta}^{(+)}$ back together
via `_merge_grouped_vector`.

**The NumPyro implementation** — line 176 onward (`model_fn`):

```python
def model_fn(dmas, n_dma, x_data_dict, n_predictors, y_data):
    mu_alpha = numpyro.sample("mu_alpha", dist.TruncatedNormal(0.0, 1, low=0.0))
    sigma_alpha = numpyro.sample("sigma_alpha", dist.HalfNormal(5.0))

    mB_raw_normal = numpyro.sample("mB_raw_normal", dist.Normal(mu_normal, sd_normal))
    mB_raw_trunc  = numpyro.sample("mB_raw_trunc",
                                   dist.TruncatedNormal(mu_trunc, sd_trunc, low=0.0))
    mB_raw = _merge_grouped_vector(mB_raw_normal, mB_raw_trunc,
                                   is_normal_mask, is_trunc_mask, n_predictors)

    sigma_b = numpyro.sample("sigma_b", dist.HalfNormal(sigma_sd_prior_array))

    if include_intercept:
        alpha = numpyro.sample("alpha",
            dist.TruncatedNormal(mu_alpha, sigma_alpha, low=0.0).expand([n_dma]))
    else:
        alpha = jnp.zeros(n_dma)

    normal_coeffs = numpyro.sample("B_normal",
        dist.Normal(broadcast(mB_raw[is_normal_mask], (n_dma, n_normal)),
                    broadcast(sigma_b[is_normal_mask], (n_dma, n_normal))).to_event(1))
    trunc_coeffs = numpyro.sample("B_trunc",
        dist.TruncatedNormal(broadcast(mB_raw[is_trunc_mask], (n_dma, n_trunc)),
                             broadcast(sigma_b[is_trunc_mask], (n_dma, n_trunc)),
                             low=0.0).to_event(1))

    B = jnp.zeros((n_dma, n_predictors))
    B = B.at[:, is_normal_mask].set(normal_coeffs)
    B = B.at[:, is_trunc_mask].set(trunc_coeffs)

    X_array = jnp.stack([x_data_dict[c] for c in x_col_names], axis=1)
    predictions = vmap(lambda B_row, x_row: jnp.sum(B_row * x_row))(B[dmas], X_array)
    y_hat = predictions + alpha[dmas]

    sigma = numpyro.sample("sigma", dist.HalfNormal(5.0))
    numpyro.sample("obs", dist.Normal(y_hat, sigma), obs=y_data)
```

A few implementation subtleties worth noting:

**The "grouped" predictor split** — every parameter at the population
level is split into two arrays (`*_normal`, `*_trunc`) by the
`is_impression_mask` (`True` where the column name contains
`"impressions|"`). This lets the truncation be applied only to the
impression coefficients, while controls remain unrestricted. The
`_merge_grouped_vector` static method (line 135) stitches them back into
a single vector indexed in the original column order, so downstream
attribution (predictions, melted contributions) doesn't need to know
which were truncated.

**`.to_event(1)` matters.** When you `expand` a distribution and want
NumPyro to treat the resulting batch as a single event (so its log-prob
gets summed over the batch dimension), you mark the rightmost dimension
as event with `.to_event(1)`. Without this, NumPyro would treat each
`(dma, channel)` pair as an independent observation in the prior — which
would still be correct but verbose; `.to_event(1)` keeps the
implementation tighter.

**`vmap` over predictions.** `vmap(lambda B_row, x_row: jnp.sum(B_row * x_row))`
vectorizes the per-observation dot product across all $N$ observations.
This is JAX's natural way to express the "for each row, multiply
coefficients by features and sum" — it compiles to a single fused
GPU/CPU kernel.

**`checkpoint` flag** — when `True`, wraps the per-observation
prediction in `jax.checkpoint` so JAX recomputes activations during
backprop instead of storing them. Trades compute for memory; needed for
very large taxonomy models with many predictors. Default `False` in
production.

### 4.3 Non-negativity — exactly how it's enforced

The constructor's `nonnegative=True` flag is the source of the
`is_trunc_mask`:

```python
if self.nonnegative:
    is_trunc_mask = self.is_impression_mask
    is_normal_mask = ~self.is_impression_mask
else:
    is_trunc_mask = jnp.zeros_like(self.is_impression_mask, dtype=bool)
    is_normal_mask = jnp.ones_like(self.is_impression_mask, dtype=bool)
```

So `nonnegative=True` means "any column whose name contains
`'impressions|'` gets a TruncatedNormal prior with `low=0.0`; everything
else gets a plain Normal." When `False`, all columns get Normal priors —
making the model unconstrained. **All KPI notebooks pass
`nonnegative=True`**; the unconstrained mode exists for diagnostic
purposes (debugging whether non-negativity is binding) and isn't used in
production.

### 4.4 `ModelBuild` — fitting via NUTS

```python
def ModelBuild(self, df, num_chains=1, rng_seed=0):
    self._prepare_priors(df)
    dmas, n_dma, x_data_dict, n_predictors, y_data = self._prepare_data(df)
    include_intercept = (self.modeltype == "Overall")
    model_fn = partial(self._base_model_fn(include_intercept=include_intercept))
    self.model_fn = model_fn

    # JIT sanity check — fails loudly if any param produces NaN/inf at init
    jitted_model = jit(numpyro.handlers.seed(model_fn, rng_seed),
                       static_argnames=["n_predictors", "n_dma"])
    _ = jitted_model(dmas, n_dma, x_data_dict, n_predictors, y_data)

    kernel = NUTS(model_fn)
    self.mcmc = MCMC(kernel, num_samples=self.samples, num_warmup=self.warmup,
                     num_chains=num_chains)

    rng_keys = (random.split(random.PRNGKey(rng_seed), num_chains)
                if num_chains > 1 else random.PRNGKey(rng_seed))
    self.mcmc.run(rng_keys, dmas, n_dma, x_data_dict, n_predictors, y_data,
                  extra_fields=('accept_prob', 'diverging'))

    self.posterior_samples = jax.device_get(
        self.mcmc.get_samples(group_by_chain=False))
    return self.mcmc
```

**Defaults that are not exposed:**

- `target_accept_prob` of NUTS — NumPyro's default of 0.8 is left
  unchanged. This means NUTS dual-averaging tunes the step size during
  warmup so the average MH acceptance rate is 0.8. The notebook-level
  wrapper (see Section 4.5 below) then checks whether the *actual* acceptance
  hit ≥ 0.6.
- `max_tree_depth` — NumPyro's default of 10 is used. (A NUTS tree of
  depth $d$ allows up to $2^d - 1 = 1023$ leapfrog steps per sample.)
- `num_chains=1` is the production default. Multi-chain support is
  commented as "leaving out for now due to instability" — the dataset is
  large enough that single-chain effective sample size is sufficient.

**The JIT pre-flight check.** Lines 257–266 do a `jit`-compile of the
model and call it once with the data, *before* starting MCMC. This
catches structural errors (NaN priors, shape mismatches, type
incompatibilities) in seconds instead of after a 30-minute warmup run.
If the JIT compile fails, the print statement `❌ JIT failed:` shows up
in the Databricks notebook output — very useful for debugging.

**Posterior storage.** `self.posterior_samples` is the in-memory dict of
posterior samples for every parameter, moved from device (GPU) to host
RAM. This dict is what gets passed to `numpyro.infer.Predictive` inside
`ModelDiagnostics.generate_predictions` (see Section 9 below) to make
out-of-sample predictions on the holdout set.

### 4.5 Diagnostic accessors — how the retry wrapper uses them

Each KPI's overall-model notebook wraps `ModelBuild` in
`run_model_with_accept_prob_and_divergence_check` (defined in NB2). The
wrapper retrieves `accept_prob` and `diverging` from `extra_fields`:

```python
mdl_mcmc = mdl.ModelBuild(data, num_chains=num_chains)
extra_fields = mdl_mcmc.get_extra_fields()
mean_accept_prob = jnp.mean(extra_fields["accept_prob"])
divergence_count = int(jnp.sum(extra_fields["diverging"]))
```

These two fields are populated by NUTS because `ModelBuild` passed
`extra_fields=('accept_prob', 'diverging')` to `mcmc.run`. Each is a
length-`num_samples` array — `accept_prob[i]` is the MH acceptance
probability for sample $i$, and `diverging[i]` is a bool indicating
divergence on sample $i$.

The wrapper then checks:

- `0.6 ≤ mean_accept_prob ≤ 1.0`
- `divergence_count ≤ 0.15 × num_samples` (i.e., ≤ 300 of 2000)

If either fails, it retries up to 3 times (each retry uses a fresh
RNG seed). If all 3 retries fail, it raises `RuntimeError` with the
exact failure reason. See [Doc 01 Section 7.3](01_mmm_methodology_primer.md)
for the methodology.

### 4.6 `get_inference_data()` — renaming for ArviZ summaries

Line 307 onward — converts the raw NumPyro MCMC into an
`arviz.InferenceData` object and renames the grouped parameters into
per-predictor names:

| Internal name (raw) | Renamed (per-predictor) |
|---|---|
| `mB_raw_normal[i]` | `mB_<col_name>` for each non-impression column |
| `mB_raw_trunc[i]` | `mB_<col_name>` for each impression column |
| `B_normal[d, i]` | `B_<col_name>` for each non-impression column |
| `B_trunc[d, i]` | `B_<col_name>` for each impression column |
| `sigma_b[i]` | `σ_β_<col_name>` (Greek-letter naming!) |
| `alpha` | `α` |
| `mu_alpha` | `μ_α` |
| `sigma` | `σ` |
| `sigma_alpha` | `σ_α` |

This is purely cosmetic but matters downstream — `az.summary(idata,
var_names=["B_impressions|SEM|Google Search_delayed_...", "α"])` only
works if these renamed variables exist on the InferenceData object.
`ModelDiagnostics` (Section 9) uses the renamed names everywhere.

### 4.7 Prediction at inference time

`ModelDiagnostics.generate_predictions(data)` reuses the fitted model:

```python
predictive = Predictive(
    self.model.model_fn,                       # the same function NUTS saw
    posterior_samples=self.model.posterior_samples,
    return_sites=["obs"],                      # the likelihood node
)
samples_predictive = predictive(rng_key, dmas, n_dma, x_data_dict,
                                n_predictors, y_data=None)
pred_mean = jnp.mean(samples_predictive["obs"], axis=0)
```

`numpyro.infer.Predictive` re-runs the model function with the posterior
samples held fixed, drawing from the likelihood `obs ~ Normal(y_hat, σ)`
to produce a `(num_samples × n_obs)` prediction array. Averaging across
the sample axis gives the **posterior predictive mean** — the canonical
"predicted value" the codebase uses for $R^2$, MAPE, and Tableau
reporting.

> **Interview angle — "Walk me through your MMM model definition."**
> *"It's a hierarchical Bayesian regression at DMA-week level fit with
> NumPyro's NUTS. Population-level hyperparameters: TruncatedNormal(0,1)
> for the mean intercept, HalfNormal(5) for its standard deviation;
> TruncatedNormal(prior_mu, prior_sd) for each media coefficient's
> population mean (using priors from the previous version's posterior
> means), HalfNormal(prior_sigma_sd) for its standard deviation. DMA-level
> coefficients are then drawn from those population distributions —
> TruncatedNormal for media (enforcing non-negativity), Normal for
> non-media controls (which can be negative — mortgage rate hurts FS
> Submits). The data-level mean is the linear combination per DMA-week,
> with likelihood Normal(y_hat, σ) and σ ~ HalfNormal(5). The 'taxonomy'
> mode of the same class omits the intercept because the dependent
> variable for taxonomy is already a residual from the overall model."*

> **Interview angle — "How is your MMM model parallelized /
> productionized?"** *"Three layers. (1) Within a model fit: NumPyro
> compiles the whole posterior to a single XLA program via JAX, then
> NUTS runs on GPU — a 2000-sample, ~3000-parameter fit takes 10–30
> minutes on g6e.xlarge. The model uses `vmap` over observations and
> `to_event(1)` on per-DMA coefficient batches to maximize GPU
> utilization. (2) Across taxonomy channels within a KPI: the 15
> channel-network taxonomy models for a single KPI run as 15 parallel
> Databricks tasks on CPU clusters — each is a separate notebook
> invocation that writes its slice via Delta `replaceWhere
> channel_network = '...'`. (3) Across KPIs: the five KPI jobs are
> independent and only share the upstream silver layer from the MMM
> Input Job. There's no cross-KPI synchronization needed at training
> time — each KPI runs as its own bi-weekly job."*

---

## 5. `Model.ResponseCurves.ResponseCurveFit`

[`ResponseCurves.py`](D:/MMM_Learning/rapidmmm-main/rapidmmm/Model/ResponseCurves.py)
— 312 lines, one class. Fits a Hill curve to per-channel `predicted` vs
`spend` data using `scipy.optimize.curve_fit`.

### 5.1 The fitted curve

$$
R(s) = \text{bottom} + (\text{top} - \text{bottom}) \cdot \frac{s^{\text{slope}}}{\text{saturation}^{\text{slope}} + s^{\text{slope}}}
$$

In the codebase `bottom_param=False` (the production default), so
`bottom` is forced to 0:

$$
R(s) = \text{top} \cdot \frac{s^{\text{slope}}}{\text{saturation}^{\text{slope}} + s^{\text{slope}}}
$$

### 5.2 Constructor and `Modellevel`

```python
response = rc.ResponseCurveFit(
    data=channel_data,        # subset for one channel: dmacode, week_monday, impressions, predicted, spend
    bottom_param=False,
    Datecol='week_monday',
    Modellevel='Overall' or 'DMA',
)
result = response.fit_model(title=..., x_label='spend', y_label=...)
```

The two `Modellevel` modes:

- **`'Overall'`** — aggregate over all DMAs to national weekly totals.
  Compute a single universal CPI = `total spend / total impressions`,
  reconstruct spend = `impressions × CPI`, fit one Hill curve. Returns
  fitted parameters as attributes (`response.top`, `.slope`,
  `.saturation`, `.r_2`, `.figure`).

- **`'DMA'`** — fit one Hill curve **per dmacode**. Computes a *per-DMA*
  CPI (`dma_spend / dma_impressions`) for each DMA, reconstructs spend
  per-DMA, fits one curve per DMA. Returns a DataFrame of `(dmacode,
  bottom, top, slope, saturation, r_2)` — one row per DMA. Used to
  produce per-DMA response curves stored in the gold response-curves
  table.

**Why reconstruct spend from impressions × CPI rather than use the raw
spend column.** The model was fit on adstocked impressions (after
carryover convolution), not on raw spend. Using the raw weekly spend
on the X-axis of the response-curve fit would mismatch the model's
input space — adstocked impressions in week $t$ include carryover from
prior weeks, but the spend in week $t$ does not include the spend
that *generated* that carryover. Reconstructing `spend = impressions ×
CPI` uses the model's actual input scale on the X-axis (because the
"impressions" column in the input data is the *adstocked* version
that the model saw), then scales it to dollars via the constant CPI
so the response curve reads in dollars for Marketing-facing
interpretation. The TV-specific notebook-level adjustment that
multiplies impressions by `model_idv` (see Doc 07 Section A3) is a
further refinement on top of this for Connected TV and Linear TV
specifically.

### 5.3 The curve-fit setup

`get_param` builds initial guesses and bounds from the data:

| Parameter | Initial value | Lower bound | Upper bound |
|---|---|---|---|
| `top` | `max(y_data)` | `max - 0.5 * range(y)` | `max + 0.5 * range(y)` |
| `bottom` | `min(y_data)` | `min - 0.5 * range(y)` | `min + 0.5 * range(y)` |
| `saturation` | `0.5 * (X[-1] - X[0])` | `X[0] * 0.1` | `X[-1] * 10` |
| `slope` | 1 | 0.01 | 100 |

The initial values and bounds let scipy explore reasonable parameter
space without diverging. The wide saturation bound `X[-1] * 10` lets
extrapolation be meaningful for budget scenarios beyond observed spend.

### 5.4 Failure handling

If `scipy.curve_fit` raises `RuntimeError` (it couldn't converge),
`OverflowError` (numerical issues with extreme parameters), or
`ValueError` (bad data shape), `fit_model` catches the exception, sets
`r_2 = 0`, prints the error, and appends zero parameters to the result.
This means the downstream notebook 7/8 can iterate over all channels
without crashing on any single failure; it just sees `r_2 = 0` rows that
get filtered out later.

### 5.5 The response-curve stability check

This check lives in the **notebook**, not the library. Notebook 7
(`7_*_overall_response_curves.py`) defines `predict_stability(bottom,
top, slope, saturation, X)` that evaluates the fitted Hill function at
$X = \$100M$ and $\$300M$. If either evaluation produces `inf` (from
`X**slope` overflow), the channel is tagged `stability_status =
'unstable'` and excluded from the reporting table. See
[Doc 07 Section stability](07_response_curves_and_stability.md) for details.

---

## 6. `Model.FeatureSelection`

[`FeatureSelection.py`](D:/MMM_Learning/rapidmmm-main/rapidmmm/Model/FeatureSelection.py)
— 239 lines, two classes.

### 6.1 What it provides

**`FeatureSelectionGridSearch(train)`** — LASSO-based selector. Given a
matrix of multiple engineered variants of the same channel (different
adstock params), fits a LASSO and returns the column with the highest
absolute LASSO coefficient. Designed to compose with
`FeatureEngineeringAdStockGrid` for adstock-parameter tuning.

**`FeatureSelectionVIF(train, y_col, X_cols)`** — Multi-step VIF +
clustering pipeline:

1. **Mutual-information percentile filter** — keep the top 50% of
   columns by mutual information with $y$.
2. **VIF filter** — drop columns with Variance Inflation Factor > 10
   (multicollinear with the rest).
3. **Hierarchical clustering** — for columns with $|\rho| \geq 0.6$,
   compute the Spearman correlation distance matrix, do Ward's linkage,
   cluster at distance threshold 1, and keep one column per cluster.
4. **Final VIF filter** — re-check VIF ≤ 10 on the surviving set.

### 6.2 Is it actually used in production?

`Model.FeatureSelection as fse` is imported in notebooks 1 and 3 of every
KPI but **never invoked** — no call to `fse.FeatureSelectionVIF(...)` or
`fse.FeatureSelectionGridSearch(...)` appears anywhere in the production
notebooks I read.

The production channel list is **fixed in config**
(`config_param.yml::adstock_hill_best_params` keys define exactly which
channel-networks enter the model) and reviewed manually by the analytics
team. The VIF-based selector exists for the developer doing initial
model exploration in a lab notebook — once a final feature set is
chosen, it's locked in and `Model.FeatureSelection` becomes dead code.

The import remains because some now-deprecated NB1 cells may have once
used it. If you trace through `mmm_mf_submits/1_mmm_mf_submits_feature_engineering.py`,
the line `import rapidmmm.Model.FeatureSelection as fse` (line 108) is
followed by exactly zero calls to `fse.*`.

---

## 7. `Utils.FunnelEffects` — the attribution algorithm (deep dive)

[`FunnelEffects.py`](D:/MMM_Learning/rapidmmm-main/rapidmmm/Utils/FunnelEffects.py)
— 144 lines, one class with two static methods. This is the second
math-heavy module after `BayesianModel`. It implements the funnel-effect
attribution described in [Doc 01 Section 8](01_mmm_methodology_primer.md#8-funnel-attribution).

### 7.1 The two-node assumption

The functions assume exactly two KPIs in a funnel:

- **Node 1 (parent)** — the upstream KPI, e.g., Visits or Rental Visits.
- **Node 2 (child)** — the downstream KPI, e.g., FS Submits or MF
  Submits.

The child KPI's regression includes the parent KPI as a control variable
(`value|visits|visits` appears in FS Submits' `X_col`). After both
models are fit, FunnelEffects redistributes the child model's
"parent-variable contribution" into per-channel contributions based on
the parent model's per-channel decomposition.

### 7.2 `funnel_effects(nodes, nodes_data)` — overall-level math

The function signature in the notebook calling pattern:

```python
funnel_effect_data = fne.funnel_effects(
    nodes=['value|visits|visits', 'value|leads|fs_submits'],  # [parent_var, child_var]
    nodes_data={
        'node1_data': visits_melted_df,   # parent KPI melted (channel × dma × week → predicted)
        'node2_data': fs_submits_melted_df,  # child KPI melted, including a row for the parent variable
    },
)
```

The algorithm in 4 steps:

**Step 1.** Compute the share of the child KPI's prediction attributed
to the parent variable, per (dmacode, week):

```python
prop_2 = nodes_data['node2_data'][['dmacode','week_monday','variable','predicted']]\
            .groupby(['dmacode','week_monday','variable']).sum().reset_index()
prop_agg_2 = nodes_data['node2_data'][['dmacode','week_monday','predicted']]\
            .groupby(['dmacode','week_monday']).sum().reset_index()
prop_2 = prop_2.merge(prop_agg_2, on=['dmacode','week_monday'])
prop_2['percent_2'] = prop_2['predicted'] / prop_2['predicted_agg']
prop_2 = prop_2[prop_2['variable'] == nodes[0]].reset_index(drop=True)
```

Mathematically: for each (dmacode $d$, week $t$),

$$
\pi^{(2)}_{d,t} = \frac{\hat{y}^{(\text{child})}_{d,t, \text{parent\_var}}}{\sum_{v} \hat{y}^{(\text{child})}_{d,t, v}}
$$

This is the fraction of the child KPI's prediction at $(d,t)$ that comes
from the parent-variable term in the child regression.

**Step 2.** Compute each channel's share of the parent KPI prediction,
per (dmacode, week):

```python
prop_1 = nodes_data['node1_data']
prop_agg_1 = prop_1[['dmacode','week_monday','predicted']]\
             .groupby(['dmacode','week_monday']).sum().reset_index()
prop_1 = prop_1.merge(prop_agg_1, on=['dmacode','week_monday'])
prop_1['percent_1'] = prop_1['predicted'] / prop_1['predicted_agg']
```

That is,

$$
\pi^{(1)}_{c,d,t} = \frac{\hat{y}^{(\text{parent})}_{c,d,t}}{\sum_{c'} \hat{y}^{(\text{parent})}_{c',d,t}}
$$

**Step 3.** Allocate the parent variable's child-KPI contribution back
to each channel:

```python
prop_1 = prop_1.merge(prop_2[['dmacode','week_monday','predicted_nd1','percent_2']],
                      on=['dmacode','week_monday'])
prop_1['funnel_perc'] = prop_1['percent_1'] * prop_1['percent_2']
prop_1['predicted_adj'] = prop_1['predicted_nd1'] * prop_1['percent_1']
```

`predicted_nd1` (renamed from `predicted` in the merge) is the per-row
total child-KPI prediction at $(d,t)$. The funnel-effect contribution of
channel $c$:

$$
\text{FunnelEffect}_{c, d, t} = \hat{y}^{(\text{child}, \text{total})}_{d,t} \cdot \pi^{(2)}_{d,t} \cdot \pi^{(1)}_{c, d, t}
$$

Equivalently — substituting $\pi^{(2)}_{d,t} =
\hat{y}^{(\text{child})}_{d,t, \text{parent\_var}} / \hat{y}^{(\text{child}, \text{total})}_{d,t}$
and cancelling:

$$
\text{FunnelEffect}_{c, d, t} = \hat{y}^{(\text{child})}_{d,t, \text{parent\_var}} \cdot \pi^{(1)}_{c, d, t}
$$

i.e., the child model's parent-variable contribution at $(d,t)$,
allocated proportionally across channels by their parent-model shares.

**Step 4.** Replace the per-channel `variable`, `column`, `channel`,
`adjusted` columns in `prop_1` with their child-KPI counterparts (so the
funnel rows look like child-KPI rows for downstream consumers), set
`predicted = predicted_adj`, and concatenate `prop_1` (now tagged `Type
= 'Funnel Effect'`) onto the child-only `node2_data` rows (tagged `Type
= 'Direct Effect'`).

The output `final_data` has the schema of `node2_data` plus a `Type`
column. Direct-effect rows are the child model's per-channel direct
predictions; funnel-effect rows are the channel attributions derived
from the parent model.

### 7.3 `funnel_effects_taxonomy(nodes_data, tax_order)` — the taxonomy variant

For the taxonomy chain, the math is the same in spirit but operates on
the 4-level hierarchy `(channel, network, lob, campaign_super)` rather
than just `(channel, network)`.

The notebook 4 calling pattern:

```python
funnel_taxonomy = fne.funnel_effects_taxonomy(
    nodes=['value|rentalsmetrics_zillowbrand|rental_visits',
           'value|rentalsmetrics_zillowbrand|fr_bdp_submits'],
    nodes_data={
        'node1_data_overall': rental_visits_overall_combined,        # parent overall combined gold
        'nodel1_data_taxonomy': rental_visits_taxonomy_combined,     # parent taxonomy combined gold
        'node2_data_funnel_effect': mf_submits_overall_funnel_rows,  # child overall funnel rows
        'node2_data_taxonomy': mf_submits_taxonomy_melted,           # child taxonomy melted
    },
    tax_order=['channel','network','lob','campaign_super'],
)
```

The algorithm conceptually:

1. Take the parent KPI's **taxonomy-level** per-channel-network shares
   (parent's `predicted` ÷ parent's overall `predicted` summed at the
   `(channel, network)` level, then proportionally split into per-tax
   shares).
2. Apply those shares to the child KPI's **overall-level** funnel-effect
   rows (which contain the per-channel-network funnel contribution from
   the overall model).
3. The result: per-(channel, network, lob, campaign_super) funnel rows
   for the child KPI's taxonomy table.

A validation invariant: the predicted-sum at the (channel, network)
level after taxonomy funnel must match the overall combined output's
predicted-sum for the same (channel, network). The notebook 4
`validate` step at line 1100 of `4_mmm_mf_submits_taxonomy_model.py`
enforces this within a 1% tolerance for Email Simon Data (which is
recalibrated) and exact match for everything else.

### 7.4 Why FunnelEffects is a separate utility

This is a *post-fit* operation — both the parent and child models are
already trained and their per-DMA, per-week, per-channel predictions
already exist. FunnelEffects doesn't touch any model fitting. It's pure
proportional re-allocation of already-computed quantities.

Two consequences:

1. **You can re-run attribution without re-fitting models.** If you
   change the attribution rule (e.g., add a third KPI to the funnel), you
   re-run FunnelEffects on the same posterior outputs — no MCMC needed.
2. **The math is identical to a Shapley-value approximation under the
   assumption that the parent KPI's per-channel contributions are
   independent and proportional.** It's a *proportional allocation*, not
   a full Shapley calculation — but the production approximation is
   fast (closed-form, O(N) in observations) and the validation checks in
   notebook 2 guarantee the attribution is consistent (sums balance,
   no double-counting).

> **Interview angle — "How does your funnel attribution work?"** *"After
> fitting separate hierarchical Bayesian models for the parent KPI
> (Visits or Rental Visits) and child KPI (FS Submits or MF Submits),
> we apply post-hoc proportional attribution via the FunnelEffects
> utility. For each DMA-week, we compute (a) the share of the child
> KPI's prediction that came from the parent-variable coefficient, and
> (b) each channel's share of the parent KPI's prediction. Multiplying
> these two gives each channel's funnel-effect contribution to the child
> KPI. The output stores 'Direct Effect' rows (from the child's own
> coefficient) and 'Funnel Effect' rows (from the upstream allocation)
> separately, so Marketing can see whether a channel works via intent
> or via awareness. Four validation invariants — spend balance, type
> exhaustiveness, monotonicity, parent-KPI cap — guard against
> attribution bugs."*

---

## 8. `TimeSeries.MovingAverages` + `Decomposition`

Two small utility modules.

### 8.1 `MovingAverages.Smoothing(Type)`

64 lines.
`Smoothing(Type='Exponential')` exposes `transform(X, alpha)` which
applies an exponential moving average with custom alpha:

$$
m_t = \alpha \cdot X_t + (1 - \alpha) \cdot m_{t-1}, \qquad m_0 = X_0
$$

`Type='Simple'` shortcuts to $\alpha = 0.5$.

**Used by:** `mmm_exogeneous_feature_store.py` (shared utility) to smooth
macroeconomic features before publishing them to the Databricks feature
store. The default `alpha = 0.3` in `variable_smoothing` produces a
relatively conservative smoothing (heavy weighting on history) that
removes spiky weekly noise from things like Google Trends indices and
for-sale-inventory counts.

### 8.2 `Decomposition.DetectSeasonality`

23 lines. Wraps `statsmodels.tsa.seasonal.seasonal_decompose` in
multiplicative mode:

```python
decomposition = seasonal_decompose(X, model='multiplicative')
# returns object with .seasonal, .trend, .resid components
```

**Used by:** KPI notebook 1 (`feature_engineering`) to extract the
seasonal component of historical Visits or Rental Visits and merge it as
the `seasonal` feature in the modeling dataset. Multiplicative
decomposition is appropriate because KPI levels vary across DMAs by 100×
— additive decomposition would oversize the seasonal swing for large
DMAs and undersize it for small ones.

---

## 9. `PostProcessing.ModelDiagnostics`

[`ModelDiagnostics.py`](D:/MMM_Learning/rapidmmm-main/rapidmmm/PostProcessing/ModelDiagnostics.py)
— 408 lines, one class. Everything needed for post-fit analysis +
producing Spark-ready output tables.

### 9.1 The class contract

```python
MoDi = md.ModelDiagnostics(mdl)            # mdl is the fitted Model from Section 4
MoDi.business_kpi = 'MF Submits'           # KPI tag for downstream tables
```

The constructor immediately calls `mdl.get_inference_data()` to get an
ArviZ InferenceData object with the renamed parameters (Section 4.6), and stores
it as `self.idata`.

### 9.2 Posterior summaries — `generate_az_data_and_summary()`

```python
idata, summary = MoDi.generate_az_data_and_summary()
```

Internally:

```python
var_names = ["α"] if modeltype == "Overall" else []
var_names += [f"B_{c}" for c in X_col]
summary = az.summary(idata, var_names=var_names, hdi_prob=0.95)
```

`az.summary` returns a DataFrame with columns `mean, sd, hdi_2.5%, hdi_97.5%,
mcse_mean, mcse_sd, ess_bulk, ess_tail, r_hat` indexed by parameter name
(e.g., `B_impressions|SEM|Google Search_delayed_lag_1_decay_0.0_delay_0[12]`
where `[12]` is the DMA index). The method then parses the parameter
names to extract the DMA index and the base column name, returning the
flattened DataFrame for downstream joins.

### 9.3 Predictions — `generate_predictions(data)`

See Section 4.7 above for the algorithm. The notebook calls this on both train
and holdout DataFrames after fitting.

### 9.4 Plots — train + holdout actual-vs-predicted

`generate_actual_vs_predicted_plot(data)` builds two Plotly figures:

- A scatter plot of `y` vs `pred`
- A line plot of `y` and `pred` aggregated to national-weekly level over
  time

Both are written to disk as PNG and logged to MLflow under
`overall_model_plots/`. The notebook 2 of every KPI generates these for
train, holdout, train+holdout combined, and train+(holdout-with-high-
variance-DMAs-removed). The combined plots are the headline visual in
the model-validation review.

### 9.5 Model stats — $R^2$, RMSE, MAPE

`generate_model_statistics(data)`:

```python
R_sq = corr(y, pred) ** 2
rmse = sqrt(mean((y - pred)**2))
mape = mean(|(y - pred) / y|) * 100
```

Returns `(R_sq, rmse, mape)` tuple. Notebook 2 writes these to
`mmm_model_output_stat` table tagged by `model_type, channel_network,
business_kpi, version`.

### 9.6 Residual diagnostics — Q-Q + histogram

`generate_residual_plots(data)` produces the residual KDE histogram
and a Q-Q plot vs the normal distribution. Used during model review to
check the Normal-likelihood assumption ($\varepsilon \sim \mathcal{N}(0,
\sigma^2)$). Logged to MLflow.

### 9.7 The melted contribution table — `get_melted_data_for_business_diagnostics`

This is the most important method in the class — it's what produces the
attribution table that gets fed into FunnelEffects and ultimately into
the gold output tables.

**Inputs:**

- `data` — the modeling DataFrame with all features and `y`
- `col_list` — the list of model feature columns (the `X_col`)
- `data_m` — the un-scaled DataFrame (used to compute the per-DMA mean
  of $y$ for the elasticity reconstruction)

**Algorithm:**

1. Compute `y_col_mean` = mean of $y$ per DMA from `data_m`.
2. Pull the coefficients (mean + HDI bounds) for every column from
   `self.model_summary`.
3. Melt `data` from wide to long: one row per (dma, week, variable).
4. Join coefficients and `y_col_mean` to each row.
5. Compute `predicted_initial = coefficient × value × y_mean` —
   reversing the mean-scaling to get the contribution in original KPI
   units.
6. For `modeltype == 'Taxonomy'`, perform an additional **error-
   correction step**: rescale the predicted contributions so they sum
   exactly to the actual KPI per (dma, week). This guards against the
   model producing a sum that's slightly off from the actual KPI (which
   would propagate as attribution drift downstream).
7. Apply the same rescaling to the HDI bounds.
8. Strip the adstock-prefix from the column names (`_delayed_lag_...`,
   `_exponential_...`, `_geometric_...`, `_weibull_...`) so the
   `adjusted` and `channel` fields hold human-readable channel-network
   names.

The output is one row per (`dma × week × variable`) with columns:
`dmacode, week_monday, variable, value, y_col_mean, column, coefficient,
coef_hdi_2point5_pct, coef_hdi_97point5_pct, predicted_initial,
predicted_2point5_pct_hdi, predicted_97point5_pct_hdi, predicted, y,
adjusted, channel`.

This melted DataFrame is the input to FunnelEffects (Section 7) and eventually
to `get_spark_ready_df_from_melted` (Section 9.8 below).

### 9.8 Spark-ready output — `get_spark_ready_df_from_melted`

```python
df = MoDi.get_spark_ready_df_from_melted(
    melted=melted_with_funnel_effects,
    taxonomy_order=["channel", "network", "campaign_super", "lob"],
    version=final_model_version,
    funnel_effects=True,   # adds 'type' and 'funneleffect_variable' columns
)
```

This is the final transformation before writing to gold. It:

1. Splits the `adjusted` column on `|` into the components of `taxonomy_order`
   (so `B_impressions|SEM|Google Search` becomes `channel='SEM',
   network='Google Search'`).
2. Renames the modeling columns to their gold-table names (`value →
   model_idv`, `y → model_dv`, `dmas → model_dma_id`, `variable →
   model_variable`).
3. Adds metadata columns: `business_kpi, modeltype, mcmc_id, version,
   run_time, p_data_date`.
4. If `funnel_effects=True`, adds `funneleffect_variable` (set to the
   business_kpi on direct rows, blank on funnel rows — the notebook then
   updates the blank values to the parent KPI name).

The returned DataFrame has exactly the schema of
`mmm_model_combined_output_overall_level` or
`mmm_model_combined_output_taxonomy_level` (depending on
`taxonomy_order` length), ready for Delta write.

### 9.9 The model wrapper for MLflow Unity Catalog

The class doesn't define this itself, but
`shared_utils/common_functions.py` defines `RapidMMMModelWrapper(mlflow.pyfunc.PythonModel)`:

```python
class RapidMMMModelWrapper(mlflow.pyfunc.PythonModel):
    def __init__(self, model):
        self.model = model

    def predict(self, context, model_input, params=None):
        MoDi = md.ModelDiagnostics(self.model)
        MoDi.business_kpi = params.get("kpi")
        return MoDi.generate_predictions(model_input)
```

This wrapper is what gets logged to MLflow + Unity Catalog under each
KPI's model name. At inference time, downstream consumers
(`incrementality-layer`, ad-hoc analysts) can load the model, call
`predict(data, params={'kpi': 'MF Submits'})`, and get posterior-mean
predictions on a new DataFrame — without needing to re-fit MCMC.

---

## 10. `PostProcessing.BusinessDiagnostics`

[`BusinessDiagnostics.py`](D:/MMM_Learning/rapidmmm-main/rapidmmm/PostProcessing/BusinessDiagnostics.py)
— 290 lines of free functions (no classes).

This is the "business-readable" visual layer. The functions:

| Function | What it shows | Where called |
|---|---|---|
| `generate_channel_contribution_chart` | Stacked bar of contribution per channel over time | Ad-hoc analysis / EDA |
| `generate_cost_pers_bubble_chart` | Scatter of predicted KPI vs cost-per-KPI, sized by spend, colored by channel | Ad-hoc |
| `generate_percentage_uplift_waterfall_chart` | Waterfall showing each channel's % contribution to total predicted KPI | Ad-hoc |
| `generate_top_10_DMA_chart` | Per-DMA spend bar chart for top 10 DMAs | Ad-hoc |
| `get_dma_dict()` | Loads DMA name lookup from `mmm_regionmapping` | Used by other functions |

A helper `group_channel` consolidates the "Others" bucket — collapses
control variables (econmetrics, googletrends, etc.) into base groupings
and treats holiday dummies as the "Holidays" group.

This module is **not called from production notebooks** (the gold tables
contain raw values that Tableau renders). It exists for ad-hoc analyst
exploration in Databricks lab notebooks.

---

## 11. `PreProcessing` modules

Three submodules. All used at the *input* layer
(`shared_utils/mmm_input_data_preprocessing.py`), not in the per-KPI
notebooks.

### 11.1 `MarketingMetricsData.MarketingMetricsData`

```python
MD = MarketingMetricsData(QUERY=marketing_sql, time_var='week_monday')
MD.retrieve_data_and_clean()       # executes query, standardizes dtypes, drops -1/0 DMAs
MD.filter_date_range(start, end)
MD.build_channel_network_map()
df_pivot = MD.get_pivoted_impressions_for_mmm(columns=['channel','network','lob','campaign_super'])
unpivoted = MD.unpivot_data_for_mmm(df_pivot, sep='|')
```

Internally calls `rapidmmm.Utils.PySparkNativeConn.execute_query`. The
class handles:

- Column standardization (date conversion, dtype casting)
- Null filling (`channel='null'`, etc. — these become the literal string
  `"null"` in the taxonomy)
- US-territory filtering (`dmacode != -1, 0`)
- `treat_channel_output_levels` — uses `channel_outputs.csv` to set
  irrelevant taxonomy levels to `"null"` per channel (e.g., Push has no
  `network` so it's set to `"null"`)
- Pivot/unpivot to/from the wide modeling format
- A channel-network map (`self.channel_network_map = {channel: [networks]}`)
  for downstream lookups

### 11.2 `BusinessMetricsData.BusinessMetricsData`

Same pattern, but for business metrics:

```python
BD = BusinessMetricsData(QUERY=business_sql)
BD.retrieve_data_and_clean()
BD.filter_date_range(start, end)
df_pivot = BD.get_pivoted_data()
unpivoted = BD.unpivot_data_for_mmm(df_pivot)
df_bd = BD.select_data_names_for_mmm(unpivoted, selected_data_name=[...])
```

Special handling: for `data_name` in `{googletrends, econmetricsmsa,
brandawareness, mortgagemetrics}`, `add_aggregate_level_data` and
`get_pivoted_data` compute the **mean** (not the sum) across DMAs —
because these are indices/rates, not counts, so summing them is
nonsensical.

### 11.3 `DataExploration.PlotlyVisualizer`

A grab-bag of Plotly visualization functions for inspecting the
marketing/business data: `show_total_spend_over_time`,
`show_channel_dual_axis_plot`, `show_channel_all_networks_plot`,
`show_correlation_matrix`, `show_dma_variability_graph`,
`show_dma_channel_facet_plot`, and others. Imported by
`mmm_input_data_preprocessing.py` but not called in the current
production version of that notebook — historical / EDA artifact.

---

## 12. `Utils.*Connect` + `channel_outputs.csv`

### 12.1 The connector modules

| Module | What it provides | Used by |
|---|---|---|
| `PySparkNativeConn.execute_query(query)` | Gets active Spark session, runs SQL, returns pandas. The default connector. | `MarketingMetricsData`, `BusinessMetricsData`, `PlotlyVisualizer.get_dma_dict`, `BusinessDiagnostics.get_dma_dict` |
| `PySparkHiveConn` | Hive-on-Spark via `aip_spark_sdk.SparkManager`. Functions: `read_table_from_hive`, `write_csv_into_external_table`, `write_pandas_df_into_external_table`. | Legacy — not used by current production notebooks |
| `AWSConnect.upload_file_to_s3 / get_pickle_obj_from_s3_loc` | Boto3 helpers for arbitrary S3 I/O. | Available for ad-hoc use; not called from production |
| `TrinoConnect.execute_query(query)` | Trino client with interactive credential prompt. | Marked deprecated in README; only useful from a lab notebook |

The de-facto production connector is **`PySparkNativeConn`** — every
production code path goes through `spark.sql(...).toPandas()` (or
equivalent) inside this single module. The other connectors exist for
historical reasons and would be removed if the library were spring-cleaned.

### 12.2 `channel_outputs.csv` — the taxonomy-shape reference

A 14-row CSV listing the *taxonomy levels each channel uses*. Example:

```text
Channel,Outputs
Audio,Campaign_Super - Channel - Ad Network - LOB - initiative
Push,Campaign_Super - Channel - Tactic
Linear TV,Campaign_Super - Channel - Ad Network - LOB - Tactic
SEM,Campaign_Super - Channel - Ad Network - LOB - Tactic - Initiative
```

`MarketingMetricsData.treat_channel_output_levels()` reads this and, for
each channel, sets the taxonomy levels *not* listed as `"null"`. So a
Push row in the unpivoted output has `network = "null", lob = "null",
campaign_super = "null"` (only Tactic is meaningful for Push), while a
SEM row has all six levels populated.

This is how the codebase deals with the fact that different channels
have different *natural* taxonomy depths — Push doesn't have an ad-
network concept, but SEM does. Putting `"null"` (the literal string) in
the irrelevant levels keeps the data shape rectangular while making it
clear those levels aren't business-meaningful.

---

## 13. Build and deploy

### 13.1 `pyproject.toml`

Key dependency constraints (relevant pieces):

| Package | Version constraint | Why |
|---|---|---|
| `python` | `>=3.10, <3.13` | NumPyro on JAX requires modern Python |
| `numpy` | `>=1.26.2, <=1.26.4` | **Pinned to <2.0** because `arviz < 1.0` is incompatible with NumPy 2 |
| `jax` / `jaxlib` | `>=0.4.20, <0.6.0` | Constrained for Databricks compat |
| `jax-cuda12-plugin` | `>=0.4.20, <0.6.0`, Linux-only | GPU JAX plugin — Mac falls back to CPU JAX |
| `numpyro` | `>=0.13.2, <0.20` | `numpyro 0.20+` requires `jax >= 0.7`, breaking the version-pin chain |
| `arviz` | `>=0.18.0, <1.0` | 0.18+ fixes a scipy Gaussian bug; 1.0 needs numpy>=2 |
| `pyspark` | `>=3.5.5, <4` | Databricks 16.2.x bundles 3.5 |
| `cloudpickle` | `<3` | MLflow compatibility |
| `scikit-learn`, `scipy`, `pandas` | Standard modern versions | |

The constraint chain is interesting — newer NumPyro requires newer JAX,
which requires newer ArviZ, which requires newer NumPy, which breaks
PySpark / Databricks. So the library is **pinned at the highest
compatible version of everything that runs on Databricks 16.2**, and
the team accepts that this lags upstream by 6–12 months.

### 13.2 `Dockerfile`

Base image: `nvidia/cuda:12.6.0-devel-ubuntu24.04` (CUDA-enabled because
the production cluster uses GPU NUTS).

Build steps:

1. Install Python 3.12, Poetry, build dependencies
2. Copy `pyproject.toml` + `poetry.lock`, run `poetry install --no-root`
3. Copy `rapidmmm/` source, run `poetry build` to produce
   `dist/rapidmmm-1.1.19-py3-none-any.whl`
4. Set up non-root `app` user (Wiz IaC security policy)
5. `ENTRYPOINT ["entrypoint.sh"]` — the entrypoint script is what runs
   in CI to produce the artifact

The Docker image isn't used at production runtime — it's a *build* image
for producing the wheel. The Databricks cluster doesn't run the
container; it `pip install`s the wheel.

### 13.3 GitLab CI

`.gitlab-ci.yml` extends two upstream pipeline templates:
`devex/archetypes/pipeline-templates/poetry-templates` (Poetry build/test/
publish workflow) and `core-tech/zgsec/appsec/zgsec-cicd-templates` (ZG
security scanning).

Stages: `update_version → build → test → publish`.

The `update_version` stage writes the Git tag's SEMVER value to
`rapidmmm/_version.py`. The build and test stages use the Dockerfile.
Publishing pushes the built wheel to ZG Artifactory at
`https://artifactory.zgtools.net/artifactory/api/pypi/zg-pypi/simple`,
which is the index the Databricks job clusters install from.

`AUTO_VERSION` is `"false"`, so a release requires an explicit Git tag —
no accidental auto-bumps.

### 13.4 Test coverage

`tests/test_dummy.py` exists and is essentially empty. There is **no
real unit-test coverage** for the library. Verification of new versions
happens at the *integration* level — the team runs the bi-weekly job in
the stage environment and inspects MLflow outputs before promoting the
wheel to prod. This is a real gap and should be called out in any
critique of the system (see Doc 09).

---

## 14. The library/notebook responsibility boundary

| Responsibility | Owner |
|---|---|
| Adstock + Hill + Atan + Sigmoid math | Library — `FeatureEngineering.FeatureEngineering` |
| Per-DMA mean scaling | Library — `FeatureScaling.MeanScalingRegional` |
| Hierarchical Bayesian model definition | Library — `Model.BayesianModel.Model._base_model_fn` |
| NUTS sampling | Library — wraps `numpyro.infer.MCMC` |
| Diagnostic retry logic (accept_prob, divergences, max_retries=3) | **Notebook** — `run_model_with_accept_prob_and_divergence_check` defined in every KPI's NB2 |
| Choice of which channels enter the model | **Notebook + config** — `config_param.yml::adstock_hill_best_params` keys |
| Adstock parameter values | **Config** — `config_param.yml` |
| Hill saturation parameter values | **Config** — `config_param.yml` |
| Channel priors (Mean, Sd) | **CSV** — `mmm_<kpi>_priors.csv` |
| Funnel attribution algorithm | Library — `Utils.FunnelEffects` |
| Decision of which KPIs are funnel-linked | **Notebook** — hardcoded `nodes` parameter in NB2 |
| Response-curve Hill fit (per channel, per DMA) | Library — `Model.ResponseCurves.ResponseCurveFit` |
| Response-curve stability check (overflow on $100M/$300M predictions) | **Notebook** — `predict_stability` defined in NB7/NB8 |
| Channel × version stability comparison (HDI overlap, point-estimate %) | **Notebook** — entirely in NB9, no library helper |
| Email Simon Data recalibration | **Notebook** — not in library; lives in NB2 of each KPI |
| Taxonomy recalibration factors | **Notebook + config** — not in library |
| MLflow logging | **Notebook** — uses `mlflow` directly |
| Unity Catalog model registration | **Notebook** — uses `mlflow.register_model` + `MlflowClient` |
| Delta table writes (silver + gold) | **Notebook** — via `intermediate_and_meta_table_write` from `common_functions.py` |
| Job orchestration / cluster config | **Databricks Asset Bundle** (databricks.yml — outside this repo's scope) |

**The boundary is "math vs orchestration."** The library is a collection
of pure mathematical operations; the notebooks orchestrate reads, calls,
writes, and policy. This split is enforced by the library not knowing
*anything* about Delta tables, MLflow, or Databricks — every test in
`tests/test_dummy.py` could in principle run on a developer laptop with
just pandas, JAX, and NumPyro installed.

---

## 15. Quick lookup — "which file owns this concept?"

| Concept | File | Class / function |
|---|---|---|
| Geometric / exponential adstock convolution | `FeatureEngineering/FeatureEngineering.py` | `ExponentialAdStock`, `GeometricAdStock` |
| Delayed adstock (the production default) | `FeatureEngineering/FeatureEngineering.py` | `DelayedAdStock` |
| Per-channel adstock orchestrator | `FeatureEngineering/FeatureEngineering.py` | `FeatureEngineeringAdStock` |
| Hill saturation curve | `FeatureEngineering/FeatureEngineering.py` | `HillTransform` |
| Arctan / Sigmoid saturation | `FeatureEngineering/FeatureEngineering.py` | `AtanTransform`, `SigmoidTransform` |
| Mean scaling per region | `FeatureEngineering/FeatureScaling.py` | `MeanScalingRegional` |
| Hierarchical Bayesian model definition | `Model/BayesianModel.py` | `Model._base_model_fn` |
| NUTS MCMC fit | `Model/BayesianModel.py` | `Model.ModelBuild` |
| Posterior summaries with renamed parameters | `Model/BayesianModel.py` | `Model.get_inference_data` |
| Response-curve Hill fit | `Model/ResponseCurves.py` | `ResponseCurveFit.fit_model` |
| LASSO + VIF feature selection (dead code in production) | `Model/FeatureSelection.py` | `FeatureSelectionGridSearch`, `FeatureSelectionVIF` |
| Funnel attribution overall | `Utils/FunnelEffects.py` | `FunnelEffects.funnel_effects` |
| Funnel attribution taxonomy | `Utils/FunnelEffects.py` | `FunnelEffects.funnel_effects_taxonomy` |
| Exponential moving average | `TimeSeries/MovingAverages.py` | `Smoothing` |
| Multiplicative seasonal decomposition | `TimeSeries/Decomposition.py` | `DetectSeasonality` |
| Predictions from a fitted model | `PostProcessing/ModelDiagnostics.py` | `ModelDiagnostics.generate_predictions` |
| Posterior summaries (R², RMSE, MAPE) | `PostProcessing/ModelDiagnostics.py` | `ModelDiagnostics.generate_model_statistics` |
| The melted contribution table | `PostProcessing/ModelDiagnostics.py` | `ModelDiagnostics.get_melted_data_for_business_diagnostics` |
| Spark-ready Delta-format DataFrame | `PostProcessing/ModelDiagnostics.py` | `ModelDiagnostics.get_spark_ready_df_from_melted` |
| Channel contribution / cost-per visualizations | `PostProcessing/BusinessDiagnostics.py` | Free functions |
| Marketing data loader from Spark SQL | `PreProcessing/MarketingMetricsData.py` | `MarketingMetricsData` |
| Business data loader from Spark SQL | `PreProcessing/BusinessMetricsData.py` | `BusinessMetricsData` |
| Native Spark SQL execution | `Utils/PySparkNativeConn.py` | `execute_query` |
| MMM channel taxonomy depths | `Utils/channel_outputs.csv` | reference data |

---

**Next:** Read [03_shared_utilities_and_orchestration.md](03_shared_utilities_and_orchestration.md)
for how the KPI notebooks wire the library together via the shared
helpers in `common_functions.py`, the config-driven mappings, and the
Databricks Asset Bundle orchestration.
