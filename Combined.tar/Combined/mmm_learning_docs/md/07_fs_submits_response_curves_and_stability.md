---
doc_id: 07
title: FS Submits — Response Curves and Stability (Notebooks 7, 8, 9)
companion_docs:
  - 00_mmm_ecosystem_overview.md (system map)
  - 01_mmm_methodology_primer.md (response-curve and stability theory)
  - 02_rapidmmm_library_internals.md (ResponseCurves library class)
  - 04_data_lineage_and_schemas.md (the gold response-curve + stability tables)
  - 05_fs_submits_overall_model_track.md (NB2 wrote the input to NB7)
  - 06_fs_submits_taxonomy_track.md (NB6 wrote the input to NB8)
---

# 07 — FS Submits Response Curves and Stability (Notebooks 7, 8, 9)

> **What this doc is.** The final three notebooks of the FS Submits
> chain — the two response-curve fits (NB7 overall, NB8 taxonomy) and
> the stability loop (NB9). Together they produce the
> Marketing-facing deliverables: per-channel spend → expected KPI
> curves used for budget planning, and a stability tagging that tells
> Marketing whether to trust the new version's per-channel ROI
> estimates relative to the prior version.
>
> **Why these three are the final deliverables.** The gold
> attribution tables NB6 wrote (`mmm_model_combined_output_*_level`)
> are **inputs** to budget planning, not the planning artifact
> itself. Marketing planners need (a) a function `spend → predicted
> KPI` so they can ask "if I shift $5M from Linear TV to Paid
> Social, what happens to FS Submits?" — that's the response curves.
> They need (b) a flag telling them which per-channel numbers
> changed significantly vs the prior version — that's the stability
> loop. Without these two artifacts, the gold tables are just a
> dense data dump.
>
> **Math depth.** Lighter than Docs 05/06 — most of the math
> (Hill saturation, mROAS, HDI overlap) was already covered in
> [Doc 01 Sections 9 and 10](01_mmm_methodology_primer.md). This
> doc focuses on the production interpretation: TV's special
> impression-to-spend adjustment, the per-DMA vs national fit
> trade-off, the spend-floor filter, the numerical-overflow
> stability check, and the Tableau-ready reporting tables.

---

## Part A — Notebook 7 (Overall Response Curves)

[`7_mmm_fs_submits_overall_response_curves.py`](D:/MMM_Learning/mmm_model/mmm_fs_submits/7_mmm_fs_submits_overall_response_curves.py)
runs after NB6 (Taxonomy Output Merge) completes. It reads the
gold-level combined attribution table written by NB2, fits a Hill
response curve per channel-network at both the national and per-DMA
levels, and writes two gold tables — one with the fitted curve
parameters and one with a 150-point sampled grid for direct Tableau
plotting.

### A1. Why response curves are the actual deliverable

The Bayesian model in NB2 produces per-channel coefficients
$\beta_{c,d}$ at the per-DMA level. Marketing planners can't act on
coefficients directly — they need to answer questions like:

- "We currently spend $8M/quarter on Linear TV. If we increase that
  to $12M, how many additional FS Submits would we expect?"
- "We have a $50M incremental budget. Where should we spend it for
  maximum FS Submits?"
- "Channel X's cost per submit is $50; channel Y's is $80. Should we
  shift dollars from Y to X?"

These all require a **function** mapping spend to expected KPI per
channel. The model's coefficients alone don't give you this — they
operate on adstocked + saturated impressions, not on dollars. The
response curve is the dollar-denominated function that translates
the model's posterior into actionable budget math.

The response curve also lets the team compute the **marginal ROAS**
at any spend level (the derivative of the curve), which is the
quantity that drives optimal budget allocation under a budget
constraint (the Lagrangian first-order condition is "marginal ROAS
must be equalized across channels at the optimum" — see
[Doc 01 Section 9.3](01_mmm_methodology_primer.md)).

> **Interview angle — "What do you deliver to the business after
> fitting the model?"** *"Three artifacts, in order of business
> importance. (1) Response curves per channel — a function mapping
> proposed weekly spend to expected weekly KPI contribution, sampled
> at 150 spend points and stored in a Tableau-ready reporting table.
> The budget allocator team uses these to optimize spend allocation
> under a budget constraint. (2) Per-channel attribution tables —
> the gold combined-output tables showing how the most recent
> quarter's KPI got attributed across channels, with both direct
> and funnel-effect contributions. (3) A stability tagging — for
> every channel × network, a Stable/Unstable flag comparing this
> version's per-channel ROI to the prior version's, so Marketing
> knows which numbers are trustworthy and which need investigation
> before reallocation. The response curve is what they act on; the
> attribution table is what they explain to leadership; the
> stability check is what they trust."*

### A2. Input data — reading the combined gold table

```python
output_overall = spark.sql(f"""
    SELECT * FROM {catalog}.{gold_schema}.mmm_model_combined_output_overall_level
    WHERE channel != 'Others'
      AND week_monday >= TO_DATE('{response_curves_start_week}', 'yyyy-MM-dd')
      AND version = '{final_model_version}'
      AND business_kpi = 'FS Submits'
""").toPandas()
```

Three filters:

- **`channel != 'Others'`** — drops the catch-all bucket that holds
  the intercept and exogenous control contributions (holidays,
  seasonal, macroeconomic). These don't have a spend dimension and
  so don't have a response curve.
- **`week_monday >= response_curves_start_week`** — restricts to the
  most recent year of data. The `response_curves_start_week` comes
  from `get_train_holdout_dates` and equals `holdout_end_week - 1
  year`. Using only recent data keeps the curve fit responsive to
  current spend levels (rather than averaging in years-old spend
  patterns that may no longer be representative).
- **`version = final_model_version AND business_kpi = 'FS Submits'`**
  — current run's slice only.

After reading, NB7 applies two more filters via `spend_agg`:

```python
spend_agg = output_overall[['channel','network','spend','predicted']]\
              .groupby(['channel','network']).sum().reset_index()
spend_agg = spend_agg[spend_agg['spend_agg'] >= 100000].reset_index(drop=True)
spend_agg = spend_agg[spend_agg['predicted_agg'] > 0].reset_index(drop=True)
```

**Spend floor of $100K** — channels with less than $100K of total
spend in the response-curves window are dropped. A response curve
fit on a sparse channel is unreliable; the per-week-spend
distribution doesn't span enough of the saturation range to
identify the Hill parameters. The $100K threshold is empirical —
the team's experience is that anything below this can't produce a
trustworthy curve.

**Positive predicted-aggregate filter** — channels with zero or
negative total predicted contribution are dropped. This catches noDE
channels whose Direct Effect rows all shrank to zero (so the
direct-effect curve would be degenerate); they still appear in the
combined output via funnel-effect rows, but those are excluded from
the curve fit.

Finally, NB7 applies a **config-driven channel exclusion** on top of
the spend floor:

```yaml
exclude_channels_bfr_rc_overall:
- Owned Social
- Media Solutions
- Email
- Operational Emails
```

These are channels for which the team has decided not to produce
overall-level response curves. Reasons differ per channel: Owned
Social is organic (no spend dimension), Media Solutions is partner-
managed (Zillow doesn't directly choose spend), Email is recalibrated
post-hoc against AOT so the model's curve is meaningless, and
Operational Emails are non-marketing. The `exclude_networks_bfr_rc_overall`
list is empty for FS Submits — only channel-level exclusions apply.

The result is `channel_networks` — a DataFrame of the channel-network
combinations that get a response curve fit. For FS Submits with the
current config, this typically resolves to ~12–15 channels.

### A3. The TV special-casing — why Linear TV and Connected TV are different

The two TV channels need an adjustment that no other channel needs.
Inside both `response_curves_channelnetworks_dma` and
`response_curves_channelnetworks_overall`:

```python
if i == 'Connected TV' or i == 'Linear TV':
    # We need to fix the impressions to look like ad-stock; and convert that into spend;
    avgs = channel_data[['dmacode','impressions']].groupby('dmacode').mean().reset_index()
    avgs.columns = ['dmacode','imp_avg']
    channel_data = channel_data.merge(avgs, on='dmacode')
    channel_data['impressions'] = channel_data['imp_avg'] * channel_data['model_idv']
```

This replaces the actual `impressions` column for TV with
`(per-DMA mean impressions) × (model_idv at this row)`.

**Why TV gets this treatment.** Two reasons:

1. **TV "impressions" aren't really impressions — they're GRPs.**
   Linear TV impressions in `mmm_marketing_metrics` are actually
   Gross Rating Points (GRPs) — a TV-industry metric that measures
   "average household impressions per 100 households in the target
   demographic." A GRP isn't a count of individual ad views; it's
   an aggregate-reach measure. Treating GRPs as raw impressions
   in a spend-to-impressions ratio gives a meaningless CPI.

2. **The model fit on adstocked impressions, but spend wasn't
   adstocked.** When `ResponseCurveFit(Modellevel='Overall')`
   reconstructs spend as `impressions × universal_CPI` (see
   [Doc 02 Section 5.2](02_rapidmmm_library_internals.md)), the
   `impressions` column for non-TV channels is the *raw* impressions
   that maps cleanly to the dollar spend that bought them. But for
   TV, the model's `model_idv` column holds the *adstocked +
   Hill-saturated* feature value (because TV has long carryover with
   `max_lag=9, decay=0.9, delay=5` per the config) — the raw
   impressions and the model's input value are very different scales.

   The fix: replace `impressions` with
   `mean_impressions_per_dma × model_idv`. This rescales TV's
   impression axis so that (a) the per-DMA mean impressions becomes
   the unit, and (b) the model_idv (which is the post-Hill saturated
   value the regression actually saw) becomes the multiplier. The
   result is a TV-specific "impressions equivalent" that aligns with
   the model's input scale, so the universal CPI reconstruction
   produces meaningful spend values.

The other channels don't need this because their adstock is short
and their model_idv is close to their raw impressions on a per-week
basis. TV's long delayed adstock makes its model input value
diverge from its raw impressions enough that the special-casing is
required.

> **Interview angle — "Why do you treat TV differently in response
> curves?"** *"Two reasons specific to TV. (1) TV impressions in the
> source data are actually GRPs — Gross Rating Points, an aggregate-
> reach metric — not a count of individual ad views. The raw
> impressions number doesn't have a clean spend-to-impressions ratio
> like online channels do. (2) TV has the longest delayed adstock in
> the model: Linear TV uses `max_lag=9, decay=0.9, delay=5`, so the
> adstocked feature value the regression fit on includes carryover
> from up to 9 weeks back. The raw impressions in any single week
> diverge significantly from the model's input value. The
> response-curve notebooks replace TV's impressions column with
> `(per-DMA mean impressions) × model_idv`, which gives an
> impressions-equivalent that aligns with the model's actual input
> scale. Other channels with short or no adstock don't need this
> adjustment because their raw impressions and adstocked values are
> close enough in any given week."*

For Email specifically, the function uses a different rewrite:

```python
elif i == 'Email':
    channel_data['spend'] = channel_data['impressions']
```

Email's "spend" is replaced with its impressions count (i.e., number
of sends). This is because Email's cost-per-incremental is measured
in sends-per-incremental-submit (the AOT ground truth used for
recalibration in NB2), not dollars. For Email the response curve's
X-axis is "number of sends per week" rather than dollars. Later, the
`independentvar` column on the gold table gets set to `'Impressions'`
for Email rows specifically, vs `'Spend'` for everyone else, so
downstream consumers know how to interpret the X-axis.

### A4. The two fit functions — DMA-level and Overall-level

NB7 calls **two** fit functions in sequence, producing curves at two
granularities. Both ultimately wrap `rc.ResponseCurveFit`:

**Per-DMA fits** — `response_curves_channelnetworks_dma(...)`. For
each (channel, network), instantiates
`rc.ResponseCurveFit(data=channel_data, bottom_param=False,
Datecol='week_monday', Modellevel='DMA')`. The `Modellevel='DMA'`
mode fits **one Hill curve per `dmacode`** (~210 curves per channel).
Returns a DataFrame with `(dmacode, bottom, top, slope, saturation,
r_2)` rows.

**Overall fits** — `response_curves_channelnetworks_overall(...)`.
For each (channel, network), same `ResponseCurveFit` but with
`Modellevel='Overall'`. Fits **one national-level Hill curve** by
aggregating all DMAs together and reconstructing a single national
weekly time series of (spend, predicted) pairs. Returns one row per
channel: `(dmacode=NaN, bottom, top, slope, saturation, r_2,
channel, network)`.

**When each is used.**

| Mode | Use case |
|---|---|
| **DMA** | Regional budget questions: "If I spend $X more on Paid Social in NYC vs $X more in Chicago, where do I get more incremental FS Submits?" — needs per-DMA marginal ROAS, hence per-DMA curves |
| **Overall** | National budget planning: "If I shift $5M from Linear TV to Paid Social nationally, what happens?" — needs single national curve per channel |

Both sets of curves get written to the same gold table
`mmm_response_curves_overall_level` differentiated by the
`modellevel` column (`'DMA'` or `'Overall'`). For DMA rows, `dmacode`
is populated; for Overall rows, it's NaN.

**Why both.** The DMA curves are more granular but harder to use
directly in a national budget allocator (you'd need to optimize 25
channels × 210 DMAs = 5,250 variables simultaneously). The overall
curves are easier to optimize against but lose regional heterogeneity.
The team produces both, lets the budget allocator use either depending
on the question, and lets Marketing dashboards in Tableau filter to
the appropriate level.

### A5. The numerical-stability sanity check

After both fit calls, NB7 runs `predict_stability(...)` on each
overall-level curve to verify it doesn't produce infinity at extreme
spend levels:

```python
def predict_stability(bottom, top, slope, saturation, X):
    stable = True
    try:
        slp_prm = X ** slope
    except OverflowError:
        slp_prm = float('inf'); stable = False
    try:
        sat_slp = np.power(saturation, slope)
    except OverflowError:
        sat_slp = float('inf'); stable = False
    try:
        if slp_prm == float('inf') or sat_slp == float('inf'):
            out = float('inf'); stable = False
        else:
            out = bottom + (top - bottom) * slp_prm / (sat_slp + slp_prm)
    except ZeroDivisionError:
        out = float('inf'); stable = False
    return {'predicted': out, 'stability': 'stable' if stable else 'unstable'}

spend_levels = [100000000, 300000000]
stability_result_df = pd.DataFrame([
    {'channel': row['channel'], 'network': row['network'], 'spend': spend,
     'predicted_output': result['predicted'], 'stability': result['stability']}
    for _, row in final_overall.iterrows() for spend in spend_levels
    for result in [predict_stability(row['bottom'], row['top'], row['slope'], row['saturation'], spend)]
])
```

The test evaluates each fitted Hill curve at two stress-test spend
levels: $100M and $300M. If either evaluation produces `inf` (from a
`X**slope` overflow with extreme slope values like > 100, or from a
zero saturation), the channel is tagged `unstable`.

**Why this check exists.** `scipy.optimize.curve_fit` doesn't always
converge to economically meaningful parameters. A channel with sparse
high-spend weeks might have a fit where `slope > 50`; at $100M
spend, $100M^50 overflows IEEE 754 doubles and the curve produces
`inf`. A downstream Tableau dashboard plotting `predicted = top *
slp_prm / (sat_slp + slp_prm)` with `slp_prm = inf` would show a
flat line at `top` for every spend value, hiding the real
saturation. The stability tag lets the reporting layer filter these
out:

```python
WHERE channel != 'Email'
  AND a.modellevel = 'Overall'
  AND a.stability_status = 'stable'   ← only stable curves enter the reporting table
```

So `unstable` curves still exist in the canonical
`mmm_response_curves_overall_level` table (for audit), but they're
excluded from `mmm_response_curves_overall_level_reporting` which is
what Tableau actually plots.

The merge step propagates the per-channel stability tag across both
DMA and Overall rows for the same channel-network:

```python
stability_result['overall_stability'] = stability_result\
    .groupby(['channel', 'network'])['stability']\
    .transform(lambda x: 'unstable' if 'unstable' in x.values else 'stable')
```

If any sub-evaluation of the channel is unstable, the entire channel
gets tagged unstable — conservative but safe.

### A6. The reporting table — 150 spend points × curve evaluations

After writing the canonical curves table, NB7 generates the
Tableau-ready reporting table by sampling each stable Overall curve
at 150 spend points:

```python
def get_rc_df():
    rc_dff = spark.sql(f"""
        SELECT a.*
        FROM {catalog}.{gold_schema}.mmm_response_curves_overall_level a
        JOIN (SELECT business_kpi, MAX(p_data_date) AS max_date
              FROM {catalog}.{gold_schema}.mmm_response_curves_overall_level
              GROUP BY business_kpi) b
          ON a.business_kpi = b.business_kpi AND a.p_data_date = b.max_date
        WHERE channel != 'Email'
          AND a.modellevel = 'Overall'
          AND a.stability_status = 'stable'
    """).toPandas()
    # ... pull last-year actual spend per channel for X-axis anchor ...
    return rc_dff

overall_rc = get_rc_df()

# For each (kpi, version, channel_network):
#   spends = [i * (last_year_avg_weekly_spend / 50) for i in range(0, 150)]
#   spends = [s for s in spends if s <= 100M]
#   predicted = [predict(bottom, top, slope, saturation, s / 52) * 52 for s in spends]
```

The spend grid runs from 0 to roughly 3× the channel's current
spend level, capped at $100M, in 150 increments. For each spend
point, the Hill curve is evaluated:

```python
predicted = predict(bottom, top, slope, saturation, spend / 52) * 52
```

The `/ 52` and `* 52` are because **the model was fit on weekly data
but the curve is plotted in annualized dollars**. Dividing the
annual spend by 52 gives the equivalent weekly spend; the Hill curve
produces a weekly predicted KPI; multiplying by 52 annualizes back.

Without the / 52 and * 52, you'd be applying the Hill curve outside
its training-data range (the model never saw a single week with $100M
spend; that's a quarterly or annual figure). The division pulls the
spend into the per-week range the model was trained on.

The output `mmm_response_curves_overall_level_reporting` has columns
`(business_kpi, version, channel_network, spend, predicted)` —
exactly what Tableau's plotting backend needs. It's `mode("overwrite")`
in the write so only the latest version per KPI is retained
(reporting tables don't append per version like the canonical tables
do — they replace).

### A7. Outputs

NB7 writes two gold tables:

| Table | Contents |
|---|---|
| `mmm_response_curves_overall_level` | Canonical fitted Hill parameters per (channel, network), both at DMA and Overall levels, with `stability_status`. **Append per version.** |
| `mmm_response_curves_overall_level_reporting` | 150-point sampled `(spend, predicted)` grid per channel-network for direct Tableau plotting. Stable Overall-level curves only. **Overwrite per run (latest version only).** |

---

## Part B — Notebook 8 (Taxonomy Response Curves)

[`8_mmm_fs_submits_taxonomy_response_curves.py`](D:/MMM_Learning/mmm_model/mmm_fs_submits/8_mmm_fs_submits_taxonomy_response_curves.py)
is structurally parallel to NB7 but reads the **taxonomy-level**
combined gold table and fits curves at the **campaign_super**
granularity within each (channel, network).

### B1. What changes vs NB7

| Aspect | NB7 (Overall) | NB8 (Taxonomy) |
|---|---|---|
| Source gold table | `mmm_model_combined_output_overall_level` | `mmm_model_combined_output_taxonomy_level` |
| Granularity of fit | (channel, network) | (channel, network, campaign_super) |
| LOB inclusion | not relevant | LOB aggregated away (column set to NaN); curves at campaign_super level only |
| Mode names | `'Overall'`, `'DMA'` | `'Overall Campaign_Super'`, `'DMA Campaign_Super'` |
| Exclusion config | `exclude_channels_bfr_rc_overall` | `exclude_channels_bfr_rc_tax` |
| TV special-casing | yes (same logic) | yes (same logic) |
| Spend floor | $100K per (channel, network) | $100K per (campaign_super, channel, network) |
| `campaign_super = 'null'` filter | n/a | dropped — these are null-taxonomy rows from the source data |
| `campaign_super = 'Zillow Offers'` filter | n/a | dropped — legacy campaign super, no longer in production |
| Output table — canonical | `mmm_response_curves_overall_level` | `mmm_response_curves_taxonomy_level` |
| Output table — reporting | `mmm_response_curves_overall_level_reporting` | `mmm_response_curves_taxonomy_level_reporting` |

### B2. Aggregation to campaign_super level

The taxonomy gold table has rows at full
`(channel × network × lob × campaign_super)` granularity. NB8
aggregates over LOB before fitting:

```python
b2c_grp = output_taxonomy[['dmacode','week_monday','campaign_super',
                            'channel','network','spend','impressions',
                            'predicted','model_idv']]\
            .groupby(['dmacode','week_monday','campaign_super',
                      'channel','network']).sum().reset_index()
```

So instead of, say, 6 Hill curves for Paid Social Facebook (one per
LOB-campaign_super combination), NB8 produces 2–3 (one per
campaign_super, e.g., Buyer, Brand, Multi-Product). LOB heterogeneity
is averaged out. The team's business decision: marketing budget
allocation happens at the campaign_super level (Buyer dollars vs
Brand dollars vs Rental dollars), not at the LOB level — so the
response curves are produced at the granularity Marketing actually
uses.

After fitting, the `lob` column is filled with `np.nan` in the output
DataFrame, and `tactic` and `initiative` are filled with the literal
string `'NA'` at write time (matching the gold schema's
backward-compatible columns from pre-2025 models).

### B3. The error-safe try/except wrapper

NB8's overall-level fit function wraps each `ResponseCurveFit` call
in try/except:

```python
try:
    response = rc.ResponseCurveFit(...)
    response.fit_model(...)
    # ... append params ...
except ValueError:
    # Append zeros for all params
    bt.append(0); tp.append(0); slp.append(0); st.append(0); r2.append(0)
    ch.append(i); nwk.append(j); cs.append(k); lb.append(np.nan)
```

If `scipy.curve_fit` raises `ValueError` (typically because the input
data has insufficient variation or the initial-parameter bounds can't
contain a valid fit), the channel-network-campaign_super combination
still appears in the output with zero parameters — and gets filtered
out by the downstream `r_2 > 0` and `stability_status = 'stable'`
filters when building the reporting table.

This is more permissive than NB7 (which doesn't have the try/except)
because the taxonomy level has more cells and a higher chance of any
single cell having degenerate data. Failing one cell shouldn't fail
the whole notebook.

### B4. The reporting table — split-back to columns

The reporting build is the same 150-point spend grid evaluation, but
the join-key string is more complex:

```python
rc_dff['channel_network_campaign'] = rc_dff['channel'] + '|' + rc_dff['network'] + '|' + rc_dff['core_campaign_super']
```

After the curve evaluation, NB8 splits this composite key back into
three columns for Tableau:

```python
taxonomy_response_curves = taxonomy_response_curves.select(
    "business_kpi", "version", "spend", "predicted",
    split(taxonomy_response_curves.channel_network_campaign, '\\|').alias("split_values")
).select(
    "business_kpi", "version",
    taxonomy_response_curves.split_values.getItem(0).alias("channel"),
    taxonomy_response_curves.split_values.getItem(1).alias("network"),
    taxonomy_response_curves.split_values.getItem(2).alias("core_campaign_super"),
    "spend", "predicted",
).select(
    "business_kpi", "version",
    concat("channel", lit("|"), "network").alias("channel_network"),
    "core_campaign_super", "spend", "predicted"
)
```

The result columns: `(business_kpi, version, channel_network,
core_campaign_super, spend, predicted)`. The `channel_network` is
the concatenated identifier (e.g., `'Paid Social|Facebook'`) and
`core_campaign_super` is the separate column — exactly the shape
Tableau's `mmm_response_curves_taxonomy_level_reporting` consumer
expects.

### B5. Outputs

| Table | Contents |
|---|---|
| `mmm_response_curves_taxonomy_level` | Canonical Hill parameters per (channel × network × campaign_super), both at `'Overall Campaign_Super'` and `'DMA Campaign_Super'` levels, with stability_status. Includes `tactic='NA'` and `initiative='NA'` and `core_lob` (set to NaN string). |
| `mmm_response_curves_taxonomy_level_reporting` | 150-point sampled `(spend, predicted)` grid per (channel × network × core_campaign_super), stable curves only. Overwrite per run. |

After NB8 completes, both response-curve gold tables for FS Submits
v.N are populated. NB9 (stability loop) runs next.

---

## Part C — Notebook 9 (Stability Loop)

[`9_mmm_fs_submits_stability_loop.py`](D:/MMM_Learning/mmm_model/mmm_fs_submits/9_mmm_fs_submits_stability_loop.py)
is the **last task** of the FS Submits Job. It compares the per-
channel ROI of the current version against the prior version and tags
each channel-network combination as Stable or Unstable. This is the
"go/no-go" trust signal that Marketing leadership reads before
acting on the new version's numbers.

### C1. The stability methodology recap

The two-dimensional stability test (also covered in
[Doc 01 Section 10](01_mmm_methodology_primer.md)):

For each channel-network at both Overall and Taxonomy granularity:

**Step 1.** Aggregate over the whole window to get scalar metrics:

$$
\text{return}_c^{(v)} = \frac{\sum_{d,t} \hat{y}_{c,d,t}^{(v)}}{\sum_{d,t} \text{impressions}_{c,d,t}}
$$

$$
\text{return\_lower}_c^{(v)} = \frac{\sum_{d,t} \hat{y}_{c,d,t}^{(v),\,2.5\%}}{\sum_{d,t} \text{impressions}_{c,d,t}}
\qquad
\text{return\_higher}_c^{(v)} = \frac{\sum_{d,t} \hat{y}_{c,d,t}^{(v),\,97.5\%}}{\sum_{d,t} \text{impressions}_{c,d,t}}
$$

where $\hat{y}^{(v)}_{c,d,t}$ is the predicted contribution of
channel $c$ in DMA $d$ at week $t$ under version $v$, and the 2.5% /
97.5% quantiles come from the HDI bounds stored in the gold table.

**Step 2.** Two stability tests, run independently:

**Test A — point-estimate drift:**

$$
\text{PE\_drift}_c = \left|\frac{\text{return}_c^{(v_{N+1})} - \text{return}_c^{(v_N)}}{\text{return}_c^{(v_N)}}\right| \times 100
$$

Pass if $\text{PE\_drift}_c \leq 25\%$ (default `point_estimate_percent`).

**Test B — HDI overlap:**

$$
\text{overlap\_min} = \max(\text{return\_lower}^{(v_{N+1})}, \text{return\_lower}^{(v_N)})
\qquad
\text{overlap\_max} = \min(\text{return\_higher}^{(v_{N+1})}, \text{return\_higher}^{(v_N)})
$$

$$
\text{overlap\_range} = \max(0, \text{overlap\_max} - \text{overlap\_min})
$$

$$
\text{HDI\_overlap}_c = \frac{\text{overlap\_range}}{\text{return\_higher}^{(v_{N+1})} - \text{return\_lower}^{(v_{N+1})}} \times 100
$$

Pass if $\text{HDI\_overlap}_c > 50\%$ (default `overlap_stability_percent`).

**Final stability** — a channel is `Stable` if **either** test
passes (lenient — only flag as Unstable when both fail):

```python
df_merged['Final_Stability'] = df_merged.apply(
    lambda row: 'Stable' if 'Stable' in [row['return_stability_PE'],
                                          row['Overlap_stability']]
                else row['return_stability_PE'],
    axis=1
)
```

### C2. The class structure — why object-oriented here

NB9 is **the only notebook in the codebase structured as classes**
rather than imperative cells. It defines:

| Class | Purpose |
|---|---|
| `MMMDataLoader(spark_session)` | Loads the latest 2 versions of any KPI's combined output table — `_get_latest_versions(table, kpi)` finds them, `load_dataframes(table, kpi)` returns `(df_latest, df_prev)` |
| `MMMDataAggregatorOverall(df)` | Filters by date range and aggregates per `(channel, network)` to compute `return`, `return_lower`, `return_higher` |
| `MMMDataAggregatorTax(df)` | Same as above but at `(core_campaign_super, core_lob, channel, network)` granularity |
| `StabilityAnalyzerOverall()` | Joins the two versions' aggregates, computes overlap and PE drift, assigns Stable/Unstable tags |
| `StabilityAnalyzerTax()` | Same at taxonomy granularity |

The pattern:

```python
loader   = MMMDataLoader(spark)
df_latest, df_prev = loader.load_dataframes(table, business_kpi)

agg_latest = MMMDataAggregatorOverall(df_latest)
tf1_agg = agg_latest.aggregate(agg_latest.filter_by_weeks(start, end))

agg_prev = MMMDataAggregatorOverall(df_prev)
tf2_agg = agg_prev.aggregate(agg_prev.filter_by_weeks(start, end))

analyzer = StabilityAnalyzerOverall()
result_df = analyzer.merge_and_score(tf1_agg, tf2_agg, version_info)
```

**Why object-oriented in this single notebook.** The same five
classes are used **twice** in NB9 — once for the overall comparison
and once for the taxonomy comparison. Without classes, the same
~80 lines of aggregation + merge + score logic would be duplicated.
With classes, the differences (overall vs taxonomy grouping keys)
are encapsulated in `MMMDataAggregatorOverall` vs
`MMMDataAggregatorTax`, and the main flow runs the same pipeline
twice with different aggregator instances.

**Cross-KPI reusability.** Beyond the within-notebook reuse, the
classes also let NB9 of *other* KPIs (Visits, Rental Visits, MF
Submits) use literally the same code with no edits — only the
`business_kpi` parameter differs. In fact, comparing the FS Submits
NB9 and the MF Submits NB9, they are essentially the same file with
the `business_kpi` constant changed. The object-oriented structure
makes this single-source-of-truth maintenance possible.

> **Interview angle — "What stability criteria do you enforce?"**
> *"A two-dimensional test, both computed per channel-network at
> both overall and taxonomy granularity, comparing the latest model
> version to the immediately prior version. Dimension one is
> point-estimate drift: the percentage change in `return =
> sum(predicted) / sum(impressions)` between versions; flagged
> Unstable if drift > 25%. Dimension two is credible-interval
> overlap: the overlap between the two versions' HDI bands on
> return, normalized by the current HDI width; flagged Unstable if
> overlap ≤ 50%. The final tag is Stable if **either** dimension is
> Stable (lenient — only flag as Unstable when both fail). The
> thresholds are widget parameters (`point_estimate_percent`,
> `overlap_stability_percent`) so they can be tuned without code
> changes. The Stable/Unstable tag goes to a gold table that
> Tableau consumes — Marketing reviews the Unstable channels before
> shifting budget based on the new version's numbers."*

> **Interview angle — "How do you tell if your new model is
> trustworthy vs the old one?"** *"The stability loop in NB9 of
> every KPI's bi-weekly job. After fitting the new version (v.N+1),
> we load both v.N+1 and v.N from the gold combined-output table,
> aggregate per channel-network to compute predicted-per-impression
> ratios with HDI bounds, and run two tests: (a) is the point
> estimate within 25% of last version's? (b) does at least 50% of
> the new HDI overlap with the prior HDI? If either passes, we tag
> Stable. If both fail, we tag Unstable and that channel goes to a
> Tableau dashboard for analyst review. We never *block* a release
> based on instability — the philosophy is to surface change, not
> prevent it. The lenient OR rule is deliberate: a channel that
> jumped 30% on the point estimate but still overlaps the prior
> HDI by 60% has just gotten more certain (narrower band), not
> actually changed direction — that's Stable. A channel that's only
> 5% off on the point estimate but has near-zero HDI overlap (e.g.,
> because the uncertainty band shifted entirely) is Unstable —
> something fundamental moved. Both tests catch different failure
> modes, and the OR rule keeps us from over-flagging."*

### C3. The channel whitelist

NB9's final filter (lines 206 and 354 of the notebook):

```python
overall_output = result_df.loc[(result_df['channel'].isin([
    'App', 'Audio', 'Display', 'Paid Social', 'SEM',
    'Connected TV', 'Linear TV', 'Owned Social'
])) & (~result_df['return_stability_PE_perc'].isna()), ['channel', 'network', ...]]
```

Only channels in this 8-channel whitelist appear in the stability
output. Why this whitelist?

| Channel | Why included? |
|---|---|
| App | Paid app installs are the second-largest paid acquisition channel |
| Audio | Includes Radio and Audio Media Agency — significant brand-building spend |
| Display | Programmatic display is a major paid channel |
| Paid Social | Facebook, TikTok, Pinterest paid — the largest discretionary lever |
| SEM | Google + Microsoft Search — the largest single-channel spend |
| Connected TV | The growing streaming-TV channel |
| Linear TV | Traditional broadcast TV — long carryover, major brand-building |
| Owned Social | Organic Facebook + TikTok — included for reference even though no direct spend |

**Excluded from the whitelist:** Email (recalibrated against AOT, so
stability is judged by AOT consistency not by version-over-version
MMM drift), Operational Emails (non-marketing), OOH (out of home —
small spend), Native (small spend), Media Solutions (partner-managed,
not Zillow-controlled spend allocation), Push (sparse and small),
Online Video YouTube (small spend), and any rentals-specific channel
that doesn't apply to FS Submits.

The whitelist matches the channels Marketing's budget allocator
actually moves dollars between. Including channels Marketing doesn't
control would just create noise in the Stability dashboard.

Additionally, `~result_df['return_stability_PE_perc'].isna()` drops
rows where the point-estimate drift couldn't be computed (typically
because the prior version's `return` was zero, making the percentage
calculation undefined).

A second filter removes channels with all-zero HDI bounds (no
meaningful uncertainty estimate):

```python
overall_output = overall_output[~(
    (overall_output['return_lower_curr'] == 0) &
    (overall_output['return_higher_curr'] == 0) &
    (overall_output['return_lower_prev'] == 0) &
    (overall_output['return_higher_prev'] == 0)
)]
```

These rows would always show 0% HDI overlap mechanically, which
isn't a real signal — better to exclude than confuse.

### C4. The Slack notification — the chain's "I'm done" signal

At the very end of NB9, after both stability tables are written:

```python
if environment == 'prod':
    send_slack_message(f"✅ The MMM FS Submits Overall Taxonomy Job has been successfully completed for version {latest_version}")
```

This is the **only** Slack notification in the entire FS Submits
chain. NB1 through NB8 don't notify Slack at all. The reason: this
is the last task of the bi-weekly job, and Marketing analysts who
watch the channel rely on a single "the new version is ready" ping
rather than 9 separate "task N complete" pings. The notification
includes the version number (`latest_version` = the v.N+1 that was
just produced) so the analyst can immediately query the gold tables
or load the Tableau dashboards.

The send only fires in `prod` — dev and stage runs don't notify,
preventing Slack noise from developer experimentation.

### C5. Outputs

NB9 writes two gold tables:

| Table | Granularity | Contents |
|---|---|---|
| `mmm_model_output_overall_level_stability` | `(channel × network × version_curr × version_prev)` | All 21 columns described in [Doc 04 Section 6.7](04_data_lineage_and_schemas.md): spend, impressions, return bounds for both versions, overlap_range, PE drift, Final_Stability tag, p_data_date for both versions, business_kpi, run_time |
| `mmm_model_output_taxonomy_level_stability` | + core_campaign_super, core_lob | Same metrics at full taxonomy grain |

Both are append-by-version-pair (`replaceWhere business_kpi AND
version_curr AND version_prev`), so running v.N+2 later appends a
new comparison `(v.N+2, v.N+1)` without clobbering the previous
`(v.N+1, v.N)` row.

---

## Closing — what the bi-weekly FS Submits job produced in total

After NB9 completes, the bi-weekly FS Submits job has populated
every gold table for the new version. Inventory of all v.N+1 writes
from this job (across NB2, NB6, NB7, NB8, NB9):

| Gold table | Notebook | What this version contains |
|---|---|---|
| `mmm_model_output_overall_level` | NB2 | Direct-effect per-channel attribution at (channel × network) |
| `mmm_model_combined_output_overall_level` | NB2 | Direct + funnel + AOT-recalibrated Email at (channel × network) |
| `mmm_model_output_taxonomy_level` | NB6 | Direct-effect at full taxonomy (channel × network × LOB × campaign_super) |
| `mmm_model_combined_output_taxonomy_level` | NB6 | Direct + funnel + AOT-recal at full taxonomy |
| `mmm_response_curves_overall_level` | NB7 | Hill curve params per (channel × network) at DMA and Overall levels, with stability tag |
| `mmm_response_curves_overall_level_reporting` | NB7 | 150-point spend → predicted grid for Tableau (latest version only — overwrite) |
| `mmm_response_curves_taxonomy_level` | NB8 | Hill curve params per (channel × network × campaign_super) at DMA and Overall levels |
| `mmm_response_curves_taxonomy_level_reporting` | NB8 | 150-point grid at taxonomy granularity for Tableau (latest version only) |
| `mmm_model_output_overall_level_stability` | NB9 | Per-channel stability comparing v.N+1 to v.N |
| `mmm_model_output_taxonomy_level_stability` | NB9 | Same at taxonomy granularity |

Plus silver intermediate tables (adstock_transformed, final_data_for_modeling,
overall_model_melted, two staging tables for taxonomy outputs, etc.)
and ~16 newly-registered Unity Catalog models (1 overall + 15
per-channel taxonomy). And one Slack ping confirming the
~90-minute bi-weekly chain succeeded.

The four KPI jobs that share this exact 9-notebook structure
(Visits, FS Submits, Rental Visits, MF Submits) each produce their
own slice of these same tables (filtered by `business_kpi`), all
in the same gold schema. The ZHL Submits job — with its different
9-notebook structure — produces only some of these (overall direct,
overall combined, taxonomy direct, taxonomy combined, response
curves, stability) but not the FS-Submits-specific Email
recalibration since ZHL is independently modeled.

---

## The full FS Submits bi-weekly DAG, end-to-end

Putting NB1 through NB9 together visually:

```
                       Bi-weekly Thursday 12:00 PM PST trigger
                                            │
                                            ▼
                          mmm_bi_weekly_check (week-parity gate)
                                            │
                                            ▼
                      business_data_availability_check (parallel with marketing)
                                            │
                                            ▼ (GPU cluster)
                         NB1 — Feature Engineering
                  reads silver, writes 3 per-KPI silver tables
                                            │
                                            ▼ (GPU cluster)
                         NB2 — Overall Model
              Bayesian fit → predictions → melted → funnel from Visits
                → AOT recal Email → write 2 gold overall tables
                                            │
                                            ▼ (CPU cluster)
                         NB3 — Taxonomy Model Input
            reads silver tax + melted → adstock + scale + Hill →
              writes taxonomy input + 2 empty staging tables
                                            │
                                            ▼ (CPU cluster, 15 parallel)
                         NB4 — Taxonomy Model (×15)
        per channel-network: DE or noDE prep → Bayesian fit →
          UC register → melted → AOT recal if Email → funnel from Visits-tax →
            validate → write to 2 staging tables via replaceWhere channel_network
                                            │
                                            ▼ (CPU cluster, sequential)
                         NB5 — Taxonomy Single Variable
              currently no-op for FS Submits; would handle single-var DE channels
                                            │
                                            ▼ (CPU cluster)
                         NB6 — Taxonomy Output Merge
            UNION ALL staging ∪ single-var → rename lob/campaign_super →
              write 2 gold taxonomy tables
                                            │
                                            ▼ (CPU cluster)
                         NB7 — Overall Response Curves
              reads gold combined-overall → fit Hill per channel-network
                (DMA + Overall) → numerical stability check → write 2 RC tables
                                            │
                                            ▼ (CPU cluster)
                         NB8 — Taxonomy Response Curves
              reads gold combined-taxonomy → fit Hill per channel × network × campaign_super
                → numerical stability check → write 2 taxonomy RC tables
                                            │
                                            ▼ (CPU cluster)
                         NB9 — Stability Loop
            load v.N+1 + v.N → aggregate per channel → compute return
              + HDI bounds → 2D stability test → write 2 stability tables
                → Slack notification on prod
```

The whole chain typically completes in 60–90 minutes of wall-clock
time. The GPU-heavy steps (NB1 + NB2) take ~30–40 minutes; the
parallel taxonomy fan-out (NB4 ×15 on a 1–5 CPU autoscale cluster)
takes ~20–30 minutes; the response-curve and stability steps
(NB6–NB9) take a few minutes each.

---

> **Interview angle — "How do you build response curves from a
> Bayesian MMM?"** *"Three steps after the model is fit. (1) Read
> the gold per-channel attribution table for the current version
> and the last year of data. (2) For each channel-network, fit a
> Hill saturation curve `predicted = top × spend^slope / (saturation^slope
> + spend^slope)` via `scipy.curve_fit` — once at the per-DMA level
> (one curve per DMA × channel) and once at the national level
> (single curve per channel, aggregating DMAs and reconstructing
> spend from impressions via a universal CPI). For TV channels
> specifically we replace impressions with `(per-DMA mean
> impressions × model_idv)` to convert GRPs into a spend-equivalent
> the curve fit can use. (3) Run a numerical stability check
> evaluating each fitted curve at $100M and $300M spend; if either
> overflows IEEE 754 doubles, tag the curve unstable and exclude
> from the Tableau reporting layer. Then sample each stable
> national-level curve at 150 weekly spend points from 0 to
> 3×current spend (capped at $100M), evaluate the Hill function at
> each, and write a `(channel_network, spend, predicted)` reporting
> table that Tableau plots directly without runtime computation."*

---

**Next:** Read [08_business_kpi_walkthroughs.md](08_business_kpi_walkthroughs.md)
for a side-by-side comparison of how Visits, ZHL Submits, Rental
Visits, and MF Submits differ from the FS Submits chain you've now
walked through end-to-end. Most differences are small deltas in
config; ZHL's structural difference (no separate feature_engineering
or overall_model notebooks, OMP impressions split) is the major
exception that doc covers in detail.
