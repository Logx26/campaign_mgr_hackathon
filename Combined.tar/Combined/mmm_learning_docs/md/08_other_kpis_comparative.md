---
doc_id: 08
title: Other KPIs — Visits, ZHL Submits, Rental Visits, MF Submits (Delta from FS Submits)
companion_docs:
  - 00_mmm_ecosystem_overview.md (system map)
  - 03_shared_utils_and_upstream_preprocessing.md (the silver layer all KPIs share)
  - 05_fs_submits_overall_model_track.md (FS Submits NB1 + NB2 baseline)
  - 06_fs_submits_taxonomy_track.md (FS Submits NB3 + NB4 + NB5 + NB6 baseline)
  - 07_fs_submits_response_curves_and_stability.md (FS Submits NB7 + NB8 + NB9 baseline)
---

# 08 — Other KPIs: Visits, ZHL Submits, Rental Visits, MF Submits

> **What this doc is.** A delta-only walkthrough of the four KPIs
> besides FS Submits. After Docs 05–07 you understand FS Submits
> end-to-end. This doc explains what's *different* about each of the
> other four — never re-explaining transformations, Bayesian theory,
> or notebook plumbing that's identical to FS Submits.
>
> **Why delta-only.** The four non-ZHL KPIs run the same 9-notebook
> chain with the same library calls — the differences are config
> (priors, channel exclusions, recalibration flags) and target
> variable. Re-explaining the chain five times would be wasteful.
> ZHL is the structural exception and gets the deepest treatment in
> this doc.

---

## 1. Comparison table — the whole landscape at a glance

| KPI | Target variable | Funnel parent | Funnel child(ren) | Notebook count | Structural diffs vs FS Submits | Recalibrations | Notable channel/data exclusions |
|---|---|---|---|---|---|---|---|
| **Visits** | `value\|visits\|visits` | **(none — funnel root)** | FS Submits | 9 + 1 validation notebook | None — standard 9-notebook chain plus a manual NB for ad-hoc model loading | AOT recal on Email Simon Data; **App-pair recal** (App\|Google UAC scaled to App\|Apple Search CPV) | Excludes `OOH\|Media Agency` and `App\|Facebook` before model; excludes Owned Social/Media Solutions/Email/Operational Emails from RC |
| **FS Submits** | `value\|leads\|fs_submits` | Visits | (terminal — no downstream KPI) | 9 | (baseline — Docs 05–07 covered this) | AOT recal on Email Simon Data only | Excludes 11 channels via `exclude_channels_bfr_model`; relies on funnel from Visits to re-attribute most channels |
| **ZHL Submits** | `value\|zhl_leads_visits\|zhl_submits_purchase` (per ZHL-specific config) | **(none — independent)** | (terminal) | 9 — **structurally different**: NB1 is ZHL-specific input preprocessing, NB3+NB5 are OMP-impressions split notebooks, NB6 is a dedicated post-processing notebook | No AOT recal — ZHL is independently modeled | OMP (Owned Marketing Pages) impressions handled in a **separate parallel taxonomy chain**, then merged in NB6 |
| **Rental Visits** | `value\|rentalsmetrics_zillowbrand\|rental_visits` | **(none — funnel root for rentals)** | MF Submits | 9 | None — standard chain on the rentals-filtered silver table | **App-pair recal** (App\|Google UAC scaled to App\|Apple Search CPV); no Email recal (no AOT for rentals Email) | Reads `mmm_input_preprocessing_overall_data_rentals` (the rentals-only filtered variant); excludes `Email\|Sparkpost` from model |
| **MF Submits** | `value\|rentalsmetrics_zillowbrand\|fr_bdp_submits` | Rental Visits | (terminal) | 9 | None — standard chain | No recalibration | Excludes 7 channels including all App, Audio, Email\|Iterable, Media Solutions, before model |

**Two-funnel structure** — the system has two independent funnels,
each with one parent and one child:

```
                     ┌─────────┐                ┌─────────┐
                     │ Visits  │────funnel────▶ │FS Submits│
                     └─────────┘                └─────────┘
                       (parent)                   (child)
                       runs alone               needs Visits

                     ┌──────────────┐          ┌──────────────┐
                     │Rental Visits │──funnel─▶│  MF Submits  │
                     └──────────────┘          └──────────────┘
                          (parent)                  (child)
                       runs alone              needs Rental Visits

                     ┌────────────┐
                     │ZHL Submits │   ◀── no funnel parent or child
                     └────────────┘       (independent model)
```

This means the bi-weekly schedule has an implicit dependency:
**FS Submits must run after Visits** (it reads Visits' melted data
via Delta Time Travel for the funnel attribution), and **MF Submits
must run after Rental Visits**. ZHL has no such dependency. See
Section 7 for the schedule.

---

## 2. MMM Visits — the funnel-parent of FS Submits

Visits is the most-attended-to KPI in the system because it
**propagates downstream**. Its per-channel attribution becomes the
input to FS Submits' funnel-effect step. If Visits is wrong, FS
Submits is wrong, and Marketing's budget allocation is wrong.

### 2.1 What's the same as FS Submits

Almost everything structurally — same 9-notebook chain, same
`shared_utils`, same `rapidmmm` library, same bi-weekly Thursday
schedule, same hierarchical Bayesian NUTS model class, same
`MeanScalingRegional` + `Atan` + `Hill` feature pipeline, same
parallel taxonomy fan-out across `list_with_DE ∪ list_noDE` channels,
same `funnel_effects_taxonomy` propagation (but operating on the
parent → child relationship within Visits' own taxonomy, since
Visits doesn't have an upstream funnel parent), same NB7/NB8/NB9
chain for response curves and stability.

### 2.2 What's different

**(1) No funnel parent — Visits is the root.** Visits doesn't read
any prior KPI's melted data in NB2. There is no "node 1" KPI feeding
into Visits; Visits' own per-channel coefficients are the *only*
attribution source. The funnel-effect machinery in Visits NB2 is
mostly a no-op at the overall level — the combined output table for
Visits just tags every row as `type = 'Direct Effect'` (with
`funneleffect_variable = 'Visits'` — see line 1128–1130 of the
validation notebook). At the taxonomy level (NB4), the funnel
mechanism is applied *within Visits' own taxonomy* — distributing
the overall per-channel attribution across (LOB × campaign_super)
sub-cells using its own taxonomy proportions.

**(2) Dual recalibration logic — both AOT and App-pair.** Visits has
**two** recalibration mechanisms (configured by two flags):

```yaml
aot_recalibration_flag: true       # → AOT recal on Email Simon Data
channel_recalibration_flag: true   # → App-pair recal
channel_to_recalibrate_email:
- '|Email|Simon Data'
channel_to_recalibrate:
- target: '|App|Apple Search'
  recalibrate: '|App|Google UAC'
```

The Email AOT recal is the same mechanism as FS Submits (see
[Doc 05 Section B9](05_fs_submits_overall_model_track.md)). The
**App-pair recal is new** — it forces `App|Google UAC`'s cost-per-
visit to match `App|Apple Search`'s. The motivation: the AOT
incrementality data for app installs measures cumulative effect
across the App channel collectively, not per-network. The model
might attribute differently between Apple Search and Google UAC for
the same dollar of incremental App spend; the recal pins Google UAC's
implied CPV to Apple Search's so the two channels' attributions are
consistent with each other.

The math in `recalibrate_channel` (defined in the Visits NB2 / its
validation notebook):

```python
if strategy == "App":
    filtered_data['recalibrated_visits'] = filtered_data['spend'] / target_value
    # target_value = cost_pers.loc[cleaned_variable == '|App|Apple Search', 'cpv']
```

For each Google UAC row at (DMA, week):

$$
\hat{y}_{\text{Google UAC}}^{\text{recal}} = \frac{\text{spend}_{\text{Google UAC}}}{\text{cpv}_{\text{Apple Search}}}
$$

The difference between MMM's Google UAC prediction and this
recalibrated value gets pushed into the intercept α to preserve total
prediction — same intercept-absorption mechanism as the Email recal.

**(3) The `mmm_visits_overall_model_validation.py` extra notebook.**
This 11th file in the `mmm_visits/` directory is a *manual*
validation tool — not part of the scheduled bi-weekly job. Reading
the actual contents:

- It hardcodes `environment = 'stage'`, `holdout_start_week =
  '2025-09-08'`, `model_version_number = '19'` (i.e., values are
  baked in rather than read from widgets).
- The model fitting code (`mt.Model(...)`, `mdl.ModelBuild(...)`,
  `mlflow.register_model(...)`) is commented out.
- It loads an **already-registered Unity Catalog model**:
  `mlflow.pyfunc.load_model("models:/stage_marketing.rapidmmm_gold.mmm_visits_overall_model/40")`
- It re-runs the post-processing chain (predictions, plots,
  stats, recalibration) on the loaded model.

**What this notebook is for.** It's a debugger / re-runner — when
the analytics team wants to validate or rerun the post-processing
for a specific historical Visits model version without re-fitting
the model itself. The fitted model is loaded from Unity Catalog (the
RapidMMMModelWrapper bridge), and the post-fit chain (predictions,
melted contributions, recalibration) is re-executed. This is useful
when:

- A bug is found in the post-processing pipeline and you want to
  re-emit corrected gold-table rows for a historical version.
- You want to experimentally try a different recalibration target
  on an existing model without re-burning GPU on MCMC.
- You want to inspect coefficient summaries (`MoDi.generate_az_data_and_summary()`)
  on a specific historical version.

The notebook intentionally has the writes commented out
(`# train_stat.write...` etc.) — it's a read-only inspection tool.
This is the **only KPI that has such an extra utility notebook** in
production; the other four don't have an equivalent.

**(4) Different prior values.** Visits' priors CSV
(`mmm_visits_priors.csv`) has noticeably different Mean values from
FS Submits, reflecting that Visits responds to different channels
than FS Submits does. Examples:

| Channel | Visits Mean | FS Submits Mean | Reading |
|---|---|---|---|
| `impressions\|Paid Social\|Pinterest` | **2.0** | 10.0 | Pinterest drives 5× higher elasticity to FS Submits than to Visits — purchase-intent visits convert better to submits than generic visits |
| `impressions\|Audio\|Radio` | **0.8** | (uninformative, Sd=1.0) | Radio has strong Visits effect but no validated FS Submits effect |
| `impressions\|Online Video\|YouTube` | **0.2** | (uninformative) | YouTube drives Visits but the Submits funnel-effect path is unreliable |
| `impressions\|Push\|null` | **0.04865** | (uninformative) | Push notifications drive Visits but FS Submits direct effect is small |
| `impressions\|SEM\|Google Search` | **0.1** | 0.159 | SEM drives both, slightly higher on FS Submits |
| `impressions\|Linear TV\|Media Agency` | **0.128** | (uninformative) | TV is a Visits driver; its FS Submits effect comes via the funnel |

The pattern: **awareness-and-traffic channels (TV, Radio, YouTube,
Push) have tight informative priors on Visits but uninformative
priors on FS Submits** — because the team trusts the Visits estimate
(or has AOT-derived ground truth) and lets FS Submits get its
attribution via the funnel from Visits rather than directly. **Lower-
funnel intent channels (SEM, Paid Social) have informative priors
on both** because they have meaningful direct effect on both KPIs.

**(5) Holiday + anomaly flag differences.** Visits config has
`date_flags: {june_3_dip_flag: '2024-06-03'}` — a different anomaly
than FS Submits' January 2024 dip. This corresponds to the
"June 8th bug fix" mentioned in the Visits PDF: "Added a flag for
June 8, 2024 to account for the unusual dip which was a bot issue."
Bot traffic distorted the week, requiring a manual indicator.

**(6) Different `excluded_channel_network_list`.** Visits excludes
only `impressions|App|Facebook` (a single channel). FS Submits
excludes both `impressions|OOH|Media Agency` and
`impressions|App|Facebook`. The OOH exclusion for FS Submits is
because OOH is an awareness channel with no plausible direct effect
on submits — it works only through the Visits funnel. For Visits
itself, OOH is included because Visits *is* the awareness measure.

### 2.3 Why Visits is the linchpin KPI

Because FS Submits depends on Visits' output via the funnel-effect
step, and because the bi-weekly schedule has FS Submits running
after Visits (reading Visits' melted output via Delta Time Travel),
**any quality issue with Visits cascades into FS Submits**. The team
treats Visits with extra care: the validation notebook exists,
informative priors are kept tight, App-pair recalibration ensures
two-way consistency, and the stability check at NB9 is monitored
closely before any FS Submits run is allowed to proceed.

> **Interview angle — "What's different about a funnel-parent KPI vs
> a funnel-child KPI?"** *"Three things. (1) The parent has no
> upstream funnel — its NB2 doesn't read any prior KPI's melted
> table, so its 'combined' output is identical to its direct output
> aside from the type column. The child's NB2 reads the parent's
> melted data via Delta Time Travel and runs FunnelEffects to
> generate the additional funnel-effect rows. (2) The parent's
> stability matters more — its per-channel attribution propagates
> into the child's funnel attribution, so any noise in the parent
> compounds downstream. The team treats Visits (parent of FS
> Submits) with extra care: tighter priors on tested channels, a
> manual validation notebook for ad-hoc re-runs, an additional App-
> pair recalibration. (3) The parent's run must complete before the
> child's run can start in the bi-weekly schedule — this is enforced
> via Databricks task dependencies, not via the parent's notebook
> calling the child."*

---

## 3. MMM ZHL Submits — the structurally different KPI

Zillow Home Loans (ZHL) is Zillow's in-house mortgage business. ZHL
Submits are submissions to the mortgage application flow. The
attribution problem for ZHL is fundamentally different from the
other four KPIs because of one source-data fact: **a significant
fraction of ZHL applications come from Zillow's own owned web
properties (OMP = Owned Marketing Pages)**, which don't appear in
the standard marketing metrics table. ZHL needed a separate
treatment to capture this.

### 3.1 What OMP is and why it forces a structural difference

**OMP** = **Owned Marketing Pages** — Zillow's own pages
(specifically homepage modules, for-sale property detail pages
[`fshdp`], for-rent property detail pages [`frhdp`]) that surface
ZHL mortgage CTAs to users browsing Zillow. A user looking at a home
listing might see a "Get pre-approved" widget that funnels them
into the ZHL application flow. These OMP "impressions" aren't
purchased ad impressions — they're free organic display surface that
Zillow controls.

OMP is therefore:
- **Excluded from the shared `mmm_input_data_preprocessing.py`**
  (the SQL explicitly filters `AND channel != 'OMP'`)
- **Handled exclusively inside the ZHL notebooks** — never enters
  the silver tables that Visits / FS Submits / Rental Visits / MF
  Submits read

For ZHL alone, OMP is a **major attribution source** that has to be
modeled. The team's solution: split the ZHL chain into two parallel
sub-chains — one for paid marketing channels, one for OMP — fit
both, and merge them in a dedicated post-processing notebook.

### 3.2 The ZHL 9-notebook structure (vs the standard 9)

| # | Standard KPI notebook | ZHL notebook | What changed |
|---|---|---|---|
| 1 | `feature_engineering.py` | **`input_data_preprocessing.py`** | ZHL has its own input preprocessing (not the shared one) — it reads from `mmm_business_metrics` for `zhl_leads_visits` data_name (ZHL-specific source) plus the ZHL OMP impressions from a different upstream source. Writes `mmm_zhl_preprocessing_overall_data` (the ZHL-specific silver table) |
| 2 | `overall_model.py` | **`taxonomy_model_input.py`** | **No separate Overall model.** ZHL Submits doesn't decompose Overall → Taxonomy like the other KPIs. The taxonomy IS the model. NB2 here builds the *main* taxonomy feature input (paid channels) |
| 3 | `taxonomy_model_input.py` | **`omp_imps_taxonomy_model_input.py`** | **New: OMP-specific taxonomy feature input.** Builds adstocked + scaled + Hill-transformed OMP impressions at full taxonomy granularity, using the `adstock_hill_best_params_omp` config (separate parameter set tuned for OMP impressions) |
| 4 | `taxonomy_model.py` | `taxonomy_model.py` | Same as standard — per-channel parallel Bayesian fits on the main (paid) taxonomy input. Uses `cnt_dict` and `list_with_DE` for the channel selection |
| 5 | `taxonomy_single_variable_channel.py` | **`omp_imps_taxonomy_model.py`** | **New: OMP-specific taxonomy model.** Per-OMP-channel parallel Bayesian fits on the OMP taxonomy input. Uses `cnt_dict_omp` (separate count dictionary). Produces OMP-channel-level attribution rows |
| 6 | `taxonomy_output_merge.py` | **`taxonomy_model_post_processing.py`** | **New: dedicated post-processing notebook.** Merges the main taxonomy output and the OMP taxonomy output, applies funnel effects (within ZHL's own taxonomy), produces final gold rows |
| 7 | `overall_response_curves.py` | `overall_response_curves.py` | Same as standard — fits response curves over the merged ZHL output |
| 8 | `taxonomy_response_curves.py` | `taxonomy_response_curves.py` | Same — fits curves at campaign_super granularity |
| 9 | `stability_loop.py` | `stability_loop.py` | Same — the OO stability classes work for any KPI |

So **3 of the 9 notebooks are ZHL-specific** (NB1, NB3, NB5, NB6 —
that's 4 actually, with NB2 also being rewired to be the taxonomy
input rather than the overall model). The remaining 5 (NB4, NB7, NB8,
NB9, and the taxonomy_model itself) are structurally identical to
the standard chain.

### 3.3 The dual-config structure in `config_param.yml`

ZHL's config is much larger than other KPIs' because it carries
**two complete parameter sets** — one for paid channels, one for OMP:

```yaml
adstock_hill_best_params:            # paid channels
  '|App|Apple Search': {...}
  ...
  '|OMP|OMP': {...}                  # OMP appears in main config too
                                     # (a placeholder for completeness)

adstock_hill_best_params_omp:        # OMP-specific parameter set
  '|App|Apple Search': {...}         # different slope/shape for OMP context
  ...

cnt_dict:                            # paid channel counts
  '|App|Apple Search': 2
  '|OMP|OMP': 1                      # OMP listed
  ...

cnt_dict_omp:                        # OMP channel counts
  '|App|Apple Search': 2             # same channel keys but counted in OMP table
  ...

transform_cols_atan:                 # paid Atan targets
transform_cols_atan_omp:             # OMP Atan targets (slightly different)

allowed_channels_and_networks: [...]  # ZHL has its OWN whitelist (overrides the shared one)
business_metrics_sources_ZHL: [...]   # ZHL-specific data_name list
selected_exogenous_variables_ZHL:    # ZHL-specific exogenous variables
- visits
- app_installs
- fs_submits           # ZHL uses FS Submits as an exogenous control!
- unemployment_rate
- consumer_price
- zhl_submits_purchase
```

Note that **FS Submits is itself a control variable for ZHL** —
because users who fill an FS Submits form are higher-intent leads
who are also more likely to apply for a mortgage. ZHL uses FS Submits
as an exogenous predictor rather than as a parent in a funnel-effect
sense (because the directionality is more nuanced).

### 3.4 The OMP impressions split — what NB3 + NB5 actually do

The split:

- **Main taxonomy chain** (NB2 → NB4): treats paid channels (App,
  Display, SEM, Paid Social, etc.) at full taxonomy granularity.
  Produces per-(channel × network × LOB × campaign_super) ZHL
  Submits attribution for *paid* media.
- **OMP taxonomy chain** (NB3 → NB5): treats OMP impressions
  separately. Uses the same channel features but **adstocked with
  different parameters** (the OMP impressions have shorter carryover
  because users on OMP pages convert faster than after seeing a
  display ad). Produces per-OMP-row ZHL Submits attribution.

The two chains run as **independent Databricks tasks in the ZHL
job** — both can run in parallel after NB1 completes.

### 3.5 NB6 — `taxonomy_model_post_processing.py` — merging the two chains

The dedicated NB6 post-processing notebook does what NB6 + NB7 do
for the other KPIs (the output merge) plus what's missing from the
ZHL chain (the funnel-effects + recalibration steps that would
normally live in the Overall model NB2):

1. Reads both staging tables — main taxonomy output and OMP
   taxonomy output.
2. UNIONs them with appropriate channel/network tagging (OMP rows
   tagged as `channel = 'OMP'`).
3. Applies any cross-cutting recalibration (e.g., normalizing OMP
   contribution to match an AOT-derived target if such data exists).
4. Writes the final ZHL gold tables
   (`mmm_model_output_taxonomy_level`,
   `mmm_model_combined_output_taxonomy_level`) with
   `business_kpi = 'ZHL Submits'`.

Because there's no Overall model output for ZHL, the
`mmm_model_output_overall_level` and
`mmm_model_combined_output_overall_level` tables receive ZHL rows
only by aggregating the taxonomy output back up to the
(channel × network) level — that aggregation also happens in NB6.

### 3.6 What ZHL doesn't do

- **No AOT Email recalibration.** The ZHL AOT measurement
  infrastructure doesn't have an Email-specific ground truth ready,
  so ZHL's Email channels aren't recalibrated (their MMM
  coefficients are used directly).
- **No funnel parent.** ZHL doesn't depend on Visits or any other
  KPI's melted data for funnel-effect attribution. It's
  self-contained.
- **No App-pair recalibration.** Unlike Visits and Rental Visits.

> **Interview angle — "Walk me through one MMM that's structurally
> different — why?"** *"ZHL Submits is the odd one out in our
> 5-KPI system. Three structural differences. (1) ZHL has its own
> input preprocessing notebook (NB1 of the ZHL chain) because
> Owned Marketing Pages — Zillow.com property detail pages and
> homepage modules that surface mortgage CTAs — generate a major
> share of ZHL submissions but aren't in the shared
> `mmm_marketing_metrics` table. The shared preprocessing
> explicitly filters out `channel = 'OMP'`. (2) ZHL has no Overall
> model — its taxonomy model IS the model. The two-stage Overall
> → Taxonomy decomposition that the other four KPIs use (where the
> taxonomy decomposes the overall per-channel attribution) doesn't
> make sense for ZHL because OMP impressions and paid impressions
> have very different scales and attribution mechanics. (3) ZHL's
> taxonomy is split into two parallel chains — NB2 + NB4 for paid
> channels, NB3 + NB5 for OMP impressions — with different adstock
> + Hill parameters per chain. NB6 is a dedicated post-processing
> notebook that merges the two chains into the final gold tables.
> The reason for this design: OMP has fundamentally different
> response dynamics from paid media (users on OMP pages are already
> on Zillow with high intent), so fitting them with the same
> parameters would mis-estimate both. The downside is more code to
> maintain — but ZHL is a different enough product that the
> separate machinery is justified."*

---

## 4. MMM Rental Visits — the funnel-parent for the rentals funnel

### 4.1 What's the same

Identical 9-notebook structure to FS Submits. Same library, same
shared utils, same gold tables. Same NUTS configuration (2000
samples, 1000 warmup). Same stability check methodology.

### 4.2 What's different

**(1) Reads the rentals-filtered silver table.** Rental Visits NB1
reads `mmm_input_preprocessing_overall_data_rentals` instead of
`mmm_input_preprocessing_overall_data`. The `_rentals` variant
(see [Doc 03 Section 4.3](03_shared_utils_and_upstream_preprocessing.md))
has rows with `campaign_super in ('Agent', 'Brand', 'Elevate')` and
`lob in ('ZGMI - Customer', 'ZHL - Customer')` already removed by
the shared preprocessing. So Rental Visits never sees Agent campaigns
or Brand campaigns or ZHL/ZGMI campaigns — these don't affect
Rentals demand.

**(2) Target variable.** `value|rentalsmetrics_zillowbrand|rental_visits`
— specifically the Zillow Brand rentals visits (not StreetEasy or
other brand variants). This is the top-of-funnel for the rentals
business.

**(3) No funnel parent — root KPI for the rentals funnel.** Like
Visits, Rental Visits is the funnel root. Its NB2's combined-output
tagging is `type = 'Direct Effect'` only at the overall level
(no Funnel Effect rows).

**(4) App-pair recalibration enabled.** Same as Visits — the App
channel's Apple Search vs Google UAC asymmetry is corrected:

```yaml
channel_to_recalibrate:
- target: App|Apple Search
  recalibrate: App|Google UAC
channel_recalibration_flag: true
```

No `aot_recalibration_flag` — Rental Visits has no Email AOT
recalibration because no AOT geo-test exists for Rentals Email.

**(5) Different adstock parameters per channel.** The Hill saturation
parameters and adstock max_lag/decay/delay values differ from FS
Submits because Rental Visits' response dynamics differ. For example,
Linear TV uses `max_lag=7, decay=0.8, delay=4` for Rental Visits vs
`max_lag=9, decay=0.9, delay=5` for FS Submits — Rentals has a
slightly shorter TV memory because rental decisions happen faster
than home-purchase decisions.

**(6) Smaller priors CSV.** Fewer channels with tight informative
priors compared to Visits or FS Submits — Rentals has less AOT
ground truth across channels, so more channels start with
uninformative priors and let the data dominate.

**(7) Different `excluded_channel_network_list`.** Only
`impressions|Email|Sparkpost` is excluded before the Rental Visits
model. The other variants (App|Facebook, OOH, etc.) are kept because
they have measurable Rental Visits effect even if they don't have FS
Submits effect.

**(8) Different exogenous variables.** Notably:
- Adds `value|rental_metrics|rental_daily_listings_sm` — the supply-
  side control for rentals (more listings → more visits)
- Adds `value|googletrends|rentals_index_sm` — rental search intent

These don't appear in FS Submits' macro_econ_vars_selected because
FS Submits is about home buying, not renting.

### 4.3 The rentals-only silver table — why a separate read

Recall from [Doc 03 Section 4](03_shared_utils_and_upstream_preprocessing.md)
that the shared preprocessing notebook produces *both*
`mmm_input_preprocessing_overall_data` and
`mmm_input_preprocessing_overall_data_rentals`. The rentals-flavored
one filters out Agent, Brand, Elevate campaign_supers and ZHL/ZGMI
LOBs. This means:

- Rentals model sees only rentals-relevant channel-network-LOB-
  campaign_super combinations.
- The Rentals model never has to ask "is this Brand campaign
  contributing to Rental Visits?" — Brand campaigns are pre-filtered
  out at the silver layer.

The trade-off: if Brand campaigns *do* somehow drive Rental Visits
(e.g., a Multi-Product Brand TV spot mentions Zillow Rentals), the
model can't capture that effect because it never sees the impressions.
The team's business judgment is this trade-off is acceptable —
Brand spend is too small a fraction of Rentals' driver mix to be
worth the modeling noise from including it.

---

## 5. MMM MF Submits — the funnel-child for Multi-Family rentals

MF Submits ("Multi-Family Submits") are rental lead submissions
specifically for multi-family (apartment) buildings. "FR-BDP" in the
target variable name = "For-Rent Building Detail Page" — the
multifamily property listing page where users submit interest.

### 5.1 What's the same

Identical 9-notebook chain to FS Submits, same library, same gold
tables. Reads the rentals-flavored silver table like Rental Visits
does. Uses the same parallel taxonomy fan-out machinery in NB4.

### 5.2 What's different

**(1) Funnel parent is Rental Visits, not Visits.** MF Submits NB2
reads `mmm_rental_visits_overall_model_melted_data` (not the FS
Submits' Visits version). The Delta Time Travel pattern reads the
exact version produced by the same bi-weekly run:

```python
rental_visits_delta_table_version = spark.sql(f"""
    SELECT distinct delta_table_version FROM ... mmm_model_job_metadata_detail
    WHERE business_kpi = 'Rental Visits' AND model_version = '{final_model_version}'
      AND table_name = '{catalog}.{silver_schema}.mmm_rental_visits_overall_model_melted_data'
""").collect()[0][0]

rental_visits_output = spark.sql(f"""
    SELECT * FROM {catalog}.{silver_schema}.mmm_rental_visits_overall_model_melted_data
    VERSION AS OF {rental_visits_delta_table_version}
""").toPandas()
```

Then the standard `fne.funnel_effects(nodes=[target_variable_node1,
target_variable], nodes_data={...})` call propagates Rental Visits'
per-channel attribution into MF Submits.

**(2) Target variable.** `value|rentalsmetrics_zillowbrand|fr_bdp_submits`.

**(3) No recalibration.** Neither AOT nor channel-pair. MF Submits
doesn't have an AOT measurement infrastructure mature enough to feed
back into the model. The MMM coefficients are used directly.

**(4) Smaller channel set.** The MF config excludes more channels at
the model-input stage than FS Submits does — `exclude_channels_bfr_model`
lists App|Apple Search, App|Facebook, App|Google UAC, Audio|Media
Agency, Audio|Radio, Email|Iterable, Media Solutions|Facebook. MF
Submits is a smaller-scale product than FS Submits (multi-family
rentals are a subset of all rentals), so many channels don't have
sufficient signal to identify a direct MF Submits effect — they go
entirely through the funnel from Rental Visits.

**(5) Different adstock parameters.** MF's `Linear TV|Media Agency`
uses `max_lag=6, decay=0.5, delay=1` — much shorter than FS Submits
(max_lag=9, decay=0.9, delay=5) or Visits (max_lag=5, decay=0.4,
delay=3). The intuition: a TV spot influencing MF rental search
within a week or two is plausible (people watching TV → searching for
apartments soon after); influencing it 8 weeks later is not.

**(6) Smaller priors CSV.** Like Rental Visits, MF Submits has fewer
tight informative priors — most channels start with `Mean=0, Sd=1`
uninformative priors that let the data drive the estimate.

**(7) `taxonomy_removal_map` config.** MF Submits' config has a small
map specifying specific taxonomy variants to remove from the modeling
input (e.g., `'|SEM|Google Search': ['impressions|SEM|Google Search|PA - Customer|Buyer_...']`).
These are individual taxonomy cells that the team has determined have
zero MF Submits attribution and should be dropped to reduce
multicollinearity in the per-channel taxonomy regression. Rental
Visits has similar entries; FS Submits doesn't use this map.

---

## 6. Shared infrastructure — confirming the reuse pattern

After describing the four KPIs as deltas from FS Submits, the central
observation is how *much* infrastructure is shared. The complete
inventory of shared vs KPI-specific files:

| Component | Shared | KPI-specific |
|---|---|---|
| `rapidmmm` Python library (FeatureEngineering, Model, PostProcessing, Utils, etc.) | **All** five KPIs | None |
| `shared_utils/common_functions.py` (date logic, MLflow wrappers, Delta writes, RapidMMMModelWrapper, dev bootstrap) | **All** five KPIs | None |
| `shared_utils/mmm_input_config.yml` (taxonomy whitelist, business metric sources, column mappings) | **All four** non-ZHL KPIs (ZHL has its own input pipeline) | ZHL extends with `business_metrics_sources_ZHL`, `selected_exogenous_variables_ZHL` in its own config |
| `shared_utils/mmm_input_data_preprocessing.py` (MMM Input Job preprocessing) | **All four** non-ZHL KPIs read the silver tables it writes | ZHL has its own NB1 instead |
| `shared_utils/mmm_exogeneous_feature_store.py` (smoothed macroeconomic features) | **All** five KPIs read the feature store table | None |
| `shared_utils/mmm_model_output_table_creation.py` (gold table DDLs) | **All** five KPIs write to the same physical gold tables | None — partitioned by `business_kpi` column |
| `shared_utils/mmm_week_condition_check.py` (bi-weekly gate) | **All** Databricks jobs (Input + 5 KPI jobs) | None |
| `shared_utils/mmm_dataset_availability_check.py` (upstream-freshness check) | **All** Databricks jobs | None |
| Silver preprocessing tables (`mmm_input_preprocessing_*`) | Visits, FS Submits read the `_overall_data`; Rental Visits, MF Submits read `_overall_data_rentals` | ZHL has `mmm_zhl_preprocessing_overall_data` (its own preprocessing's output) |
| Gold model-output tables (4 tables) | **All** five KPIs write rows tagged by `business_kpi` | None — one physical table per output type |
| Gold response-curve tables (4 tables) | **All** five KPIs | None |
| Gold stability tables (2 tables) | **All** five KPIs | None |
| 9-notebook chain per KPI | Visits, FS Submits, Rental Visits, MF Submits use structurally identical chains | ZHL has a structurally different chain (described in Section 3) |
| `config_param.yml` per KPI | Each KPI has its own | All 5 |
| `config_table_mapping.yml` per KPI | Each KPI has its own | All 5 |
| `artifacts/mmm_<kpi>_priors.csv` per KPI | Each KPI has its own | All 5 |

The pattern is **library + shared_utils + silver layer + gold schema
are universal**; **config + priors + per-KPI 9-notebook chain are
specific**. Adding a sixth KPI requires zero changes to anything in
the "shared" column — just create a `mmm_<new_kpi>/` directory with
9 notebooks (copied from a template), 2 configs, and a priors CSV.

> **Interview angle — "How do you avoid code duplication across
> MMMs?"** *"Three layers of reuse. (1) The `rapidmmm` Python library
> owns all the math — adstock variants, Hill saturation,
> hierarchical Bayesian model class, funnel-effects attribution,
> response-curve fitting. Every KPI imports the same library. (2)
> The `shared_utils/` directory owns cross-KPI orchestration —
> date-window derivation, MLflow run hygiene, Delta-write
> idempotency, dev-environment bootstrap, the MLflow pyfunc model
> wrapper. Every notebook does `%run ../shared_utils/common_functions`
> at the top. (3) The silver preprocessing layer is shared — the MMM
> Input Job runs once bi-weekly and produces silver tables that the
> 4 non-ZHL KPIs all read. The only KPI-specific files are the 9-
> notebook chain itself (with KPI name substitution), the 2 YAML
> configs (adstock params, exclusions, recalibration flags), and the
> priors CSV. So adding a sixth KPI is a directory-copy + config-
> edit, not a code-write. ZHL is the architectural exception that
> proves the rule — its differences justify their own deeper
> chain."*

---

## 7. Cross-KPI orchestration — the bi-weekly schedule

All five KPIs run on the same bi-weekly cadence: every other Thursday
at 12 PM PST. The actual ordering matters because of the funnel
dependencies:

```mermaid
gantt
    title Bi-weekly MMM Schedule (Pacific Time, every other week)
    dateFormat HH:mm
    axisFormat %H:%M

    section MMM Input Job
    bi_weekly_check + availability    :i1, 12:00, 5m
    preprocessing                     :i2, after i1, 30m
    feature store smoothing           :i3, after i2, 10m

    section Visits Job (Thursday)
    bi_weekly + avail check           :v1, 12:00, 5m
    NB1 Feature Engineering           :v2, after v1, 15m
    NB2 Overall Model (GPU)           :v3, after v2, 30m
    NB3 Taxonomy Input                :v4, after v3, 5m
    NB4 Taxonomy ×15 parallel         :v5, after v4, 25m
    NB5 Single Variable (no-op)       :v6, after v5, 1m
    NB6 Output Merge                  :v7, after v6, 5m
    NB7 Overall RC                    :v8, after v7, 10m
    NB8 Taxonomy RC                   :v9, after v8, 15m
    NB9 Stability + Slack             :v10, after v9, 5m

    section FS Submits Job (Thursday)
    waits for Visits melted in silver :fs1, after v3, 1m
    NB1 → NB9 chain                   :fs2, after fs1, 100m

    section Rental Visits Job (Thursday)
    bi_weekly + avail                 :rv1, 12:00, 5m
    NB1 → NB9 chain                   :rv2, after rv1, 110m

    section MF Submits Job (Thursday)
    waits for Rental Visits melted    :mf1, after rv2, 1m
    NB1 → NB9 chain                   :mf2, after mf1, 100m

    section ZHL Submits Job (Thursday, independent)
    bi_weekly + avail                 :zhl1, 12:00, 5m
    Full 9-NB chain (different shape) :zhl2, after zhl1, 110m
```

**The dependency tree:**

```
                       MMM Input Job (Tuesday 12pm)
                            │
                            ▼
            (silver layer ready, fed to all KPIs)
                            │
              ┌─────────┬───┴────┬──────────┐
              │         │        │          │
              ▼         ▼        ▼          ▼
           Visits    Rental    ZHL        (Input shared
           (root)    Visits    Submits     by all)
              │       (root)
              ▼         │
       FS Submits       ▼
       (waits for    MF Submits
        Visits NB2   (waits for
        completion)   Rental Visits
                      NB2 completion)
```

**Implementation of the cross-KPI dependency**: it's not a Databricks
job-level dependency — each KPI has its own independent Databricks
job. The dependency is enforced by the **Delta Time Travel read**
inside the child KPI's NB2:

```python
visits_delta_table_version = spark.sql(f"""
    SELECT delta_table_version FROM mmm_model_job_metadata_detail
    WHERE business_kpi = 'Visits' AND model_version = '{final_model_version}'
      AND table_name = '...mmm_visits_overall_model_melted_data'
""").collect()[0][0]
```

If Visits hasn't produced a row in `mmm_model_job_metadata_detail`
for this version yet (i.e., its NB2 hasn't completed), this query
returns nothing and the FS Submits NB2 fails with an empty result. So
the dependency is enforced *at the data layer*, not at the
orchestration layer.

In practice the team schedules the parent KPI jobs (Visits, Rental
Visits, ZHL) to start first and the child KPI jobs (FS Submits, MF
Submits) to start ~30 minutes later, by which time the parent KPI's
NB2 has typically completed.

---

## 8. The multi-KPI architectural narrative for an interview

> **Interview question — "Do you have multiple MMMs? How do they
> relate?"** *"Five MMM models, all running bi-weekly on the same
> infrastructure. The five KPIs split into two funnels plus one
> standalone: Visits → FS Submits (the home-buying funnel), Rental
> Visits → MF Submits (the rental-leasing funnel), and ZHL Submits
> (mortgage applications, modeled independently). The four KPIs in
> the two funnels share an identical 9-notebook chain — same
> Bayesian model class, same feature pipeline, same parallel
> taxonomy fan-out, just different target variables and per-KPI
> configs for adstock params, prior values, and recalibration
> flags. ZHL has a structurally different chain because Owned
> Marketing Pages (Zillow's own property detail pages that surface
> mortgage CTAs) are a major attribution source for ZHL but aren't
> in the shared marketing-metrics table; ZHL handles OMP in a
> parallel sub-chain that gets merged in a dedicated post-processing
> notebook. All five share the same input preprocessing layer
> (except ZHL has its own), the same rapidmmm Python library, the
> same shared_utils Python helpers, the same Unity Catalog gold
> tables (rows partitioned by `business_kpi`), and the same Tableau
> dashboards (with KPI filters)."*

> **Interview question — "How would you add a sixth KPI to this
> system?"** *"Six concrete steps, all KPI-local. (1) Add the
> target variable's metric name to `mmm_input_config.yml`'s
> `business_metrics_sources` and `selected_exogenous_variables` so
> the shared silver layer picks it up. (2) Create
> `mmm_model/mmm_<new_kpi>/` with a 9-notebook chain copied from
> the closest-matching existing KPI as a template (e.g., FS Submits
> if it's a lower-funnel lead-submission KPI), find-and-replacing
> the KPI name and target variable. (3) Author
> `config_param.yml` with adstock parameters per channel (start
> from the parent KPI's config, refine over a few iterations).
> (4) Author `artifacts/mmm_<new_kpi>_priors.csv` (start with
> Mean=0, Sd=1 uninformative priors; tighten over time as you build
> AOT ground truth). (5) Decide funnel linkage: which existing KPI
> is the parent (if any), and wire that into NB2's `nodes`
> parameter. (6) Register a Databricks job in `databricks.yml`.
> The shared infrastructure — input job, library, gold tables,
> audit metadata, stability classes — requires literally zero
> changes."*

---

## Quick comparison of priors — the most opinionated config

The priors CSV is where the team encodes their accumulated knowledge
about which channels work. Comparing the **Paid Social Facebook**
prior across all four standardized KPIs:

| KPI | `impressions\|Paid Social\|Facebook` Mean (prior) | Sd | Reading |
|---|---|---|---|
| **Visits** | 0.02 | 0.0001 | Modest effect, tightly pinned |
| **FS Submits** | **5.0** | 0.02 | **Much larger effect, tightly pinned** (the team has high confidence Paid Social Facebook drives FS Submits strongly) |
| **Rental Visits** | (uninformative or moderate) | (varies) | Less ground truth than Visits |
| **MF Submits** | (uninformative) | (1.0) | Pure data-driven; MF Submits has less AOT validation for Paid Social |

The Mean=5.0, Sd=0.02 prior for Paid Social Facebook on FS Submits
is the single most informative prior in the entire system — it
effectively locks the coefficient at 5.0 ± 0.04, with virtually no
movement allowed by the data. This represents prior AOT validation
that this channel has a very specific elasticity to FS Submits that
the team wants to preserve across model versions.

Compare to Email Simon Data on the same FS Submits — prior is
Mean=0, Sd=1 (totally uninformative). The team **expects** to
overwrite Email's coefficient post-fit via AOT recalibration, so
spending a tight prior on it would be wasted.

The pattern that runs across all KPIs: **tight priors on channels
the team has validated against AOT; uninformative priors on
channels that will be data-determined or post-fit recalibrated**.

---

**Next:** [Doc 09 — Interview Prep and Critique](09_interview_prep_critique.md)
will rehearse the senior-DS interview narrative across all the
material in Docs 00–08, plus offer a measured critique of the
system's known weak points (the manual config-tuning burden, the
absence of unit tests on rapidmmm, the lack of multi-chain MCMC
support, the heuristic stability thresholds). That doc is the final
one in the learning library.
