---
doc_id: 09
title: Operations, Schema Evolution, and the Interview Capstone
companion_docs:
  - All prior docs (00–08) — this doc references and synthesizes them
---

# 09 — Operations, Schema Evolution, and the Interview Capstone

> **What this doc is.** Two combined topics. **Part A** walks through
> the production-engineering layer that the prior docs only touched
> on — the 12 one-off migration scripts in
> [`mmm_table_changes/`](D:/MMM_Learning/mmm_model/mmm_table_changes/),
> the central schema registry, the deploy pipeline, and how this
> system handles the *operational* side of a long-lived ML pipeline
> beyond the bi-weekly training loop. **Part B** is the interview-
> prep capstone: elevator pitches, 30 likely interview questions
> answered against this specific codebase, common traps, a measured
> critique, and a recommended study path.
>
> **The interview lens.** Read Part B with a specific role in mind:
> a senior Data Scientist or ML Engineer interview where you're
> claiming "I worked on / studied the production MMM system at
> Zillow." Every answer is anchored to concrete code in this
> codebase so you can speak from real ground truth.

---

# PART A — Operations and Schema Evolution

## 1. The `mmm_table_changes/` philosophy

The bi-weekly job described in Docs 03–07 is the **steady-state** of
the system — the same notebooks run on the same schedule producing
the same gold tables every two weeks. But a production ML system
that's lived for multiple years inevitably accumulates **schema
evolution events**: columns get added, taxonomy categories get
renamed, data types get corrected, a backfill is needed after a
bug, etc. The bi-weekly job can't handle these one-time events
because they're not part of any steady-state workflow.

The `mmm_table_changes/` directory holds these one-off migration
scripts. Each is a Databricks notebook authored to handle a single
specific evolution event, run **manually** (or via a one-off
Databricks job) at the moment the team decides to apply that change,
and then left in the repository as the durable historical record of
what was changed and how.

**Why this matters for production ML.** Three reasons every
long-running ML system needs a layer like this:

1. **Schema can't be re-derived from the bi-weekly code.** If you
   simply re-run the bi-weekly notebooks after a schema change,
   they'd write into the new schema but the **historical rows**
   (already in the gold table from prior versions) would still be
   in the old schema. You'd get type mismatches, NULL columns, and
   broken downstream queries. Migration scripts explicitly transform
   the historical data to match the new schema.

2. **Bi-weekly code shouldn't carry schema-migration logic.** If
   every NB1 of every KPI checked "is the gold table the new schema
   or the old schema?" and branched accordingly, the steady-state
   code would accumulate cruft. Migration scripts isolate
   evolution from steady state.

3. **Audit trail.** The set of migration scripts in
   `mmm_table_changes/` *is* the durable history of "what changed
   when" — Git commits date them, the script content shows exactly
   the SQL that was applied. A future engineer trying to understand
   why a v15 row has different column values from a v25 row can
   read these scripts to find out.

This is the same idea as **Rails migrations**, **Django migrations**,
**dbt snapshots**, or **Liquibase changelogs** — each migration is a
specific, named, idempotent transformation; collectively they form
the evolution history of the schema.

### 1.1 The defining characteristics of these scripts

All 12 scripts share a structural pattern:

- They take **catalog, silver_schema, gold_schema** widget parameters
  so they can run against any environment (lab, stage, prod).
- They're written as SQL-heavy notebooks with `IDENTIFIER(:catalog
  || '.' || :gold_schema || '.<table>')` parameter substitution —
  meaning the same script body runs cleanly against any
  catalog/schema combination.
- Most begin with a **backup step** — `CREATE TABLE IF NOT EXISTS
  ..._bkp_<date>` — so the prior state is preserved before any
  destructive change. The team's pattern is to apply, validate,
  then drop backups manually after confidence is established.
- Several include `dbutils.notebook.exit("Success")` near the top
  with a comment indicating they've already been run — preventing
  accidental re-execution after the migration has been applied.
- They are **not** scheduled in any bi-weekly job — they run
  manually via a one-off Databricks job or interactive run.

---

## 2. The 12 migration scripts — categorized by theme

Below I group the 12 scripts into six categories and give a
one-paragraph summary of what each does.

### 2.1 Backup scripts

**`mmm_tables_backup.py`** — The general-purpose "before-migration"
snapshot. It creates `CREATE TABLE IF NOT EXISTS <silver>.<table>_bkp_jan2026`
copies of 11 gold tables (overall + combined overall + taxonomy +
combined taxonomy + 2 response-curves + 2 reporting + 3 marketing
incrementality tables). Runs before any major destructive operation.
Idempotent — the `IF NOT EXISTS` means re-running creates no
additional backups; subsequent calls are no-ops. The `_jan2026`
date suffix indicates when this particular backup batch was taken;
a future migration would create a new dated backup with a different
suffix.

### 2.2 Schema-shape changes

**`mmm_table_structure_changes.py`** — Adds the `train_holdout
string` column to `mmm_model_output_overall_level` and
`mmm_model_output_taxonomy_level` in both stage and prod
environments, then backfills the existing rows with `'Train'` (since
all pre-migration rows were training-period attribution, the
backfill is a constant string). This was likely run when the
holdout methodology was introduced in v13 (per the FS Submits PDF).
The script branches on the `environment` widget (`'stage'` or
`'prod'`) and applies the same DDL to the corresponding catalog.

**`mmm_table_p_data_date_change.py`** — Updates the `p_data_date`
column value across 6 gold tables (`mmm_model_output_overall_level`,
`mmm_model_output_taxonomy_level`, `mmm_response_curves_overall_level`,
`mmm_response_curves_taxonomy_level`,
`mmm_model_combined_output_overall_level`,
`mmm_model_combined_output_taxonomy_level`) for a specific
`(business_kpi, model_version)` combination passed as widget
parameters. Used to retroactively correct the `p_data_date` value on
a specific historical version when it was found to be wrong (e.g.,
the bi-weekly run was kicked off late one cycle and the original
date didn't match the canonical run date). Not idempotent — each
re-run overwrites the existing values; safe to re-run because the
target value is parameter-driven.

**`mmm_tables_metadata_addition.py`** — The largest script in the
directory (~300+ lines). Reads
[`rapidmmm_schema.yml`](D:/MMM_Learning/mmm_model/mmm_table_changes/rapidmmm_schema.yml)
and pushes the table + column descriptions to Unity Catalog via
`ALTER TABLE ... SET TBLPROPERTIES ('comment' = '...')` and
`ALTER TABLE ... ALTER COLUMN ... COMMENT '...'`. It includes
`dry_run` mode (prints the SQL without executing), error handling
around each ALTER, and exists/column-exists checks before issuing
the ALTERs. It's effectively a **dbt-style descriptions deployer**
— the YAML is the source of truth, the script is the deployment
mechanism.

### 2.3 Business-naming changes

**`mmm_tables_campaign_lob_rename.py`** — Renames two columns
across 12 gold tables: `campaign_super → core_campaign_super` and
`lob → core_lob`. The "core_" versions are the standardized names
the broader Zillow taxonomy uses; the un-prefixed versions were
historical. To make the rename work on Delta, the script first
enables `delta.columnMapping.mode = 'name'` via `SET TBLPROPERTIES`
(necessary because Delta column renames require column mapping mode
to be enabled), then issues the `ALTER TABLE ... RENAME COLUMN`.
This is **the migration that explains why the in-notebook code
operates on `lob`/`campaign_super` but the gold tables store
`core_lob`/`core_campaign_super`** — see [Doc 06 Section D2](06_fs_submits_taxonomy_track.md)
on the NB6 rename step.

**`mmm_taxonomy_changes_update.py`** — A large script of
`UPDATE` statements that normalize legacy taxonomy values to the
new canonical set across 12+ tables. Specific normalizations
include: `B2C/Mortgage/Move With Zillow → Buyer` for
`campaign_super`; `B2B/B2B Agent → Agent`; `Brand - Broad Reach → Multi
Product` for `lob`; `Rentals MF → Rentals - Partner` for specific
`Media Solutions|Facebook` rows; `TV/Linear TV → Linear TV/Media
Agency`; `TV/Connected TV → Connected TV/Media Agency`;
`OOH/CWW Digital, OOH/UM Digital → OOH/Media Agency`; and similar
network-name consolidations for Online Video, Native, Audio, Display.
This script is **the codified record of the taxonomy consolidation
project** — when the team decided "we have 7 different ways to name
the same Linear TV channel; standardize to one," this is where the
rename was applied across every historical gold row. Long but
mechanical — basically a series of `UPDATE table SET col = 'new_val'
WHERE col = 'old_val'` statements applied to every gold table that
might contain the legacy values.

### 2.4 KPI-specific fixes

**`mmm_zhl_taxonomy_fix.py`** — A targeted fix for ZHL Submits
versions v14, v15, v16. The fix: ZHL's taxonomy outputs had `lob`
and `campaign_super` columns swapped (the wrong column was filled
with which value). The script backs up the three affected versions,
deletes them, and re-inserts the rows with the columns correctly
swapped (`lob as campaign_super, campaign_super as lob` in the
`SELECT`). After validation, the backup tables are dropped. Has an
`is_taxonomy_fix_needed` widget defaulting to `"No"` so accidental
re-runs are no-ops.

**`mmm_zhl_final_table_update.py`** — Specific ZHL Submits fixes:
deletes ZHL Submits v1 from the combined output, renames ZHL Submits
v2 to v1 in the combined output (consolidating two prior versions),
and back-populates `mmm_model_output_overall_level` from
`mmm_model_output_taxonomy_level` for ZHL v1 by aggregating
taxonomy-level rows up to the channel-network level. Recall from
[Doc 08 Section 3](08_other_kpis_comparative.md) that ZHL doesn't
have its own Overall model — this aggregation is how the
`mmm_model_output_overall_level` rows for ZHL get populated. This
script appears to be **the original aggregation** that established
the pattern for ZHL's overall-table population.

**`mmm_fs_submits_rental_visits_prod_fix.py`** — A one-time prod
data fix for FS Submits and Rental Visits. Without reading the
specific content, the file naming convention indicates a targeted
backfill or correction for these two KPIs in production — likely a
specific (KPI, version, channel) slice that needed re-attribution
after a bug was discovered in NB2 of those KPIs.

**`mmm_rental_visits_final_table_update.py`** — Schema update for
the Rental Visits final tables, similar in spirit to the ZHL final-
table update. Likely standardized column types or values for Rental
Visits across its historical versions.

### 2.5 Bug fix scripts

**`mmm_taxonomy_response_curves_fix.py`** — A targeted correction
to the `mmm_response_curves_taxonomy_level` table. The file name
indicates a bug was found in how taxonomy response curves were being
generated (or in the column values produced by NB8 in some specific
historical version), and this script back-corrects the affected
rows.

### 2.6 Combined operations

**`mmm_combined_table_addition.py`** — The script that **created
the `mmm_model_combined_output_overall_level` and
`mmm_model_combined_output_taxonomy_level` tables** in the first
place. Before this migration, the gold layer only had the
`mmm_model_output_*` tables (direct effect only) plus separate
`mmm_model_output_*_funnel_effects` tables (funnel effect only). The
new `_combined_output_*` tables consolidate both into a single table
per granularity with `type` and `funneleffect_variable` columns. The
script: (a) backs up the old funnel-effects tables, (b) creates the
new combined tables with `CREATE TABLE IF NOT EXISTS`, (c) populates
them from the existing direct + funnel-effects sources. This is the
single most architecturally important migration in the directory —
it created the canonical attribution tables that all downstream
consumers now read.

> **Interview angle — "How does this codebase handle schema
> evolution?"** *"There's a dedicated directory `mmm_table_changes/`
> with one-off migration notebooks — 12 of them as of now — each
> handling a specific schema-change event: backups before a big
> change, structural changes like adding the train_holdout column,
> column renames like lob → core_lob (which required enabling
> Delta's column mapping mode first), business-naming normalizations
> (mapping legacy values like 'B2C' to 'Buyer'), KPI-specific data
> fixes for specific (KPI, version) slices, and the architectural
> migration that created the unified `_combined_output_*` tables
> from the prior split direct + funnel tables. The scripts are
> Databricks notebooks with widget-driven catalog/schema parameters,
> typically start with backup tables (`CREATE TABLE IF NOT EXISTS
> ..._bkp_<date>`), use `IDENTIFIER(:catalog || '.' || :schema || '.<table>')`
> parameter substitution so the same notebook runs cleanly against
> any environment, and several have `dbutils.notebook.exit("Success")`
> guards to prevent accidental re-execution. Crucially, they're
> *not* part of the bi-weekly job — they're run manually when the
> team decides to apply a specific change. This separation keeps
> the steady-state pipeline code clean and gives a durable Git-
> recorded audit trail of every historical schema change."*

---

## 3. `rapidmmm_schema.yml` — the central schema registry

[`mmm_table_changes/rapidmmm_schema.yml`](D:/MMM_Learning/mmm_model/mmm_table_changes/rapidmmm_schema.yml)
is a dbt-style schema-description YAML that documents 15 gold tables
(all 11 model-output / response-curve / stability tables plus
`mmm_dmamapping`, `mmm_model_job_metadata_detail`, the legacy
`mmm_model_output_*_funnel_effects` backups, and the downstream
`mmmrapid_budget_allocation` consumer).

For each table the YAML has:

```yaml
- name: mmm_model_combined_output_overall_level
  description: |
    This table contains combined output data at the overall level...
    
    **Understand these abbreviations:**
      DMA: Designated Market Area
      KPI: Key Performance Indicator
      HDI: Highest Density Interval
      MCMC: Markov Chain Monte Carlo
      CWW: Cross-Web-Wide
      SEM: Search Engine Marketing
  columns:
    - name: model_dma_id
      description: This column contains bigint values...
    - name: dmacode
      description: ...
    ... (one entry per column)
```

The YAML is consumed by `mmm_tables_metadata_addition.py` (described
above) — that script reads the YAML, parses each table's
description and per-column descriptions, and applies them to Unity
Catalog as table comments and column comments.

**Why a central schema registry is a common pattern.** Three
reasons:

1. **One source of truth for descriptions.** Without this, every
   notebook that referenced a column would describe it differently
   in comments; analysts reading the Unity Catalog UI would see
   inconsistent or missing descriptions. A central YAML makes
   description quality a one-place edit.

2. **Description quality is reviewable.** YAML changes go through
   Git review; the team can comment on whether a column description
   is accurate and complete before it ships to Unity Catalog. This
   is exactly the dbt model.

3. **Cross-team discoverability.** Other Zillow teams browsing
   Unity Catalog see the descriptions and abbreviation glossary
   without needing access to the MMM repo or knowing who to ask.
   The "what does HDI mean?" question gets answered inline.

The pattern is well-established in the data world (dbt models,
Apache Atlas, OpenMetadata, etc.). This codebase's implementation
is lightweight — no dbt server, just a YAML + a deploy script — but
gets the same benefits.

---

## 4. Deploy + CI/CD

### 4.1 The `rapidmmm` library deploy (GitLab CI)

The in-house `rapidmmm` Python package
([`pyproject.toml`](D:/MMM_Learning/rapidmmm-main/pyproject.toml),
[`.gitlab-ci.yml`](D:/MMM_Learning/rapidmmm-main/.gitlab-ci.yml))
deploys via standard ZG GitLab CI templates:

```yaml
include:
  - project: devex/archetypes/pipeline-templates/poetry-templates
    file: pipeline.yml
  - project: core-tech/zgsec/appsec/zgsec-cicd-templates
    ref: main
    file: pipeline.yml

variables:
  AUTO_VERSION: "false"           # require explicit Git tag for a release
  ARTIFACT_NAME_PREFIX: "rapidmmm-cpu-spark"
  PYTHON_VERSION: "3.12"

stages: [update_version, build, test, publish]

update_version:
  stage: update_version
  script:
    - echo "__version__ = '$SEMVER'" > rapidmmm/_version.py
```

The four CI stages:

1. **`update_version`** — writes the Git tag's SEMVER into
   `rapidmmm/_version.py`.
2. **`build`** — uses the Dockerfile (`FROM nvidia/cuda:12.6.0-devel-ubuntu24.04`,
   Python 3.12 + Poetry) to build the wheel and tarball into
   `dist/`.
3. **`test`** — runs whatever tests exist (`tests/test_dummy.py` is
   essentially empty — see [Doc 02 Section 13.4](02_rapidmmm_library_internals.md)
   on the unit-test coverage gap).
4. **`publish`** — uploads the wheel to ZG Artifactory at
   `https://artifactory.zgtools.net/artifactory/api/pypi/zg-pypi/simple`,
   which is the PyPI-style index the Databricks job clusters install
   from.

The `AUTO_VERSION: "false"` setting means a release requires an
explicit Git tag — there's no auto-bump on every merge.

### 4.2 The Databricks Asset Bundle (DAB) deploy — for the notebooks

The KPI notebooks themselves (and the `shared_utils/`) deploy via
**Databricks Asset Bundles**. Per the FS Submits PDF documentation
([Doc 00 Section 4](00_mmm_ecosystem_overview.md)), the workflow:

**Lab / dev development:**

1. Create a feature branch from `main`.
2. Clone the feature branch into the developer's Databricks
   workspace.
3. Develop / iterate in the lab cluster, manually testing changes.
4. **Deploy to lab via the Databricks UI**: open the cloned folder,
   click the "Deploy" button in the deployments panel, review the
   diff, click "Deploy" again to apply.
5. Once verified, commit and push to the GitLab feature branch.

**Stage and prod deployment** — must go through the CI/CD pipeline:

1. Submitting a merge request triggers the CI/CD pipeline.
2. The pipeline deploys the feature branch to the **stage**
   environment using the **stage service principal**:
   `71e8166b-731e-4ebe-aed8-95485167f887`.
3. Once the MR is approved and merged into `main`, the CI/CD
   pipeline triggers again and deploys to **prod** using the **prod
   service principal**: `472826f2-7cfe-41b2-9be0-c4269626eee3`.

**Critical constraint**: individual users **do not have direct
deploy permissions to stage or prod**. Only the two service
principals do. This enforces:

- All stage/prod changes go through Git history.
- All stage/prod changes go through code review (the MR).
- No "hot patch directly on prod" pathway exists — fix must be
  committed, reviewed, merged.

This is a fundamental production-ML hygiene practice. It also has a
specific consequence in this codebase: when a `mmm_table_changes/`
script needs to run in prod, it's executed by a manual Databricks
job invocation that runs *as* the prod service principal (not as a
developer), so even one-off migrations have the same access
controls as scheduled job runs.

### 4.3 Environment promotion

The full promotion sequence for a change to a KPI notebook:

```
Developer's lab workspace
        │
        │ (interactive iteration)
        ▼
Feature branch in dev
        │
        │ (commit + push)
        ▼
GitLab MR opened
        │
        │ (CI/CD triggered → stage SP deploys)
        ▼
Stage environment
        │
        │ (analytics team reviews stage run output)
        ▼
MR approved + merged to main
        │
        │ (CI/CD triggered → prod SP deploys)
        ▼
Prod environment (next bi-weekly run uses new code)
```

The "analytics team reviews stage run output" step happens during
the 2-day buffer between Tuesday's MMM Input Job and Thursday's
KPI Jobs — there's time for the team to manually run the modified
KPI job in stage, inspect outputs, and only then approve the MR.

---

## 5. What you'd say in a production-ML-engineering interview

Three to five specific talking points about this architecture's
production-engineering quality:

**1. The shared / per-KPI separation is a clean reuse pattern.**
The `rapidmmm` library owns the math, `shared_utils/` owns the
cross-KPI orchestration, and each KPI's directory owns only what's
KPI-specific (configs, priors, 9 notebooks). Adding a 6th KPI is a
directory copy + 3 config edits, not a library or orchestration
change. This avoids the typical "every model is a snowflake" anti-
pattern that plagues most large-scale ML organizations.

**2. The bi-weekly cadence is gated, observable, and recoverable.**
The week-parity check (`mmm_week_condition_check.py`) provides
deterministic bi-weekly scheduling on top of Databricks's
weekly-only cron. The data-availability check
(`mmm_dataset_availability_check.py`) prevents runs on stale data.
Every Delta write goes through `intermediate_and_meta_table_write`
which captures a metadata row with `job_id`, `run_id`,
`delta_table_version`, and the exact `dates_list_used` array — so
any output row is traceable back to its producing job via a simple
SQL join. Re-running a failed task is safe because of the
`replaceWhere business_kpi AND version` idempotency pattern on every
gold write.

**3. The dual-funnel architecture is implemented as data-layer
dependencies, not orchestration-layer dependencies.** The fact that
FS Submits depends on Visits (and MF Submits on Rental Visits) is
not encoded in the Databricks job DAG — each KPI's job is
independent. Instead, the child KPI's NB2 reads the parent KPI's
melted data via **Delta Time Travel pinned to the exact version
produced by the same `model_version_number`**, looked up through the
`mmm_model_job_metadata_detail` audit table. This is more robust
than orchestration-layer dependencies because a re-run of one KPI
doesn't have to invalidate or block the other — version pinning
ensures consistency without requiring tight scheduling coupling.

**4. The migration-script directory is a durable schema-evolution
record.** The 12 scripts in `mmm_table_changes/` collectively form
the audit trail of every schema change since v1. Each script names
itself after the change it implements (`mmm_tables_campaign_lob_rename`,
`mmm_zhl_taxonomy_fix`, etc.), is parameterized for catalog/schema
re-use, typically includes a backup step, and exists in Git history
with the commit message explaining the why. A future engineer asking
"why is the column `core_lob` and not `lob`?" can grep for the
rename script and find the answer.

**5. The honest critique: zero unit-test coverage on the library.**
The `tests/test_dummy.py` in `rapidmmm-main/` is essentially empty.
Verification happens at the integration level — the team runs the
bi-weekly job in stage and inspects MLflow output before promoting
to prod. This is a real gap; a 1500-line library that produces gold
outputs for ~$XB of marketing decisions should have test coverage
on its `BayesianModel`, `FunnelEffects`, `ResponseCurves`, and
`MeanScalingRegional` classes at minimum. Worth flagging in
interviews as the system's most legitimate weakness — but also
worth noting that the **integration-level testing the team does
do** (every bi-weekly stage run is reviewed before prod promotion)
catches real regressions, just less efficiently than unit tests
would.

> **Interview angle — "Walk me through your production deployment
> pattern."** *"Two layers. The Python library `rapidmmm` deploys
> via standard GitLab CI: build a wheel in a CUDA-enabled Docker
> image, publish to ZG Artifactory's PyPI index, which the Databricks
> job clusters install. Release requires an explicit Git tag — no
> auto-bumps. The Databricks notebooks deploy via Databricks Asset
> Bundles through a service-principal-gated pipeline. Individual
> developers iterate in lab workspaces and can manually deploy to
> their own lab, but stage and prod deployments must go through
> GitLab merge requests; the CI pipeline runs as one of two service
> principals (a stage SP and a prod SP), neither of which is
> available to individual developers. This means every prod change
> has a Git commit, a code review, and an audit trail. The
> bi-weekly schedule is set up to leave a 2-day buffer between the
> Tuesday shared Input Job and Thursday KPI jobs, giving the team
> time to validate stage runs before promoting to prod."*

---

# PART B — Interview Capstone

This is the deliverable that ties everything together — the
material you should be able to talk through cold in an interview
setting, anchored to specific code paths in this codebase.

## 6. Elevator pitches

### 6.1 The 30-second pitch ("What was your last project?")

> "I worked on / studied Zillow's production Marketing Mix Modeling
> system — a bi-weekly hierarchical Bayesian regression pipeline
> that measures how ~25 paid-media channels drive five business
> KPIs at DMA-week granularity, with funnel-effect attribution
> between KPIs, response-curve fitting for budget planning, and
> AOT-calibrated recalibration. It's built on NumPyro NUTS, runs on
> Databricks with about 27 tasks per KPI job, writes ~10 gold Delta
> tables that feed Tableau dashboards Marketing uses to allocate
> spend."

### 6.2 The 2-minute pitch (expanded)

> "Zillow runs a five-KPI hierarchical Bayesian MMM that's bi-weekly
> in production. The five KPIs split into two funnels — Visits→FS
> Submits for the home-buying funnel and Rental Visits→MF Submits
> for the rentals funnel — plus ZHL Submits as a standalone for
> mortgage applications.
>
> The architecture is layered. Raw marketing-metrics and business-
> metrics data come from upstream Zillow data engineering. A shared
> MMM Input Job runs every Tuesday and produces six pivot-wide
> silver tables consumed by all four standardized KPIs. Then each
> KPI's bi-weekly job runs Thursday, executing a 9-notebook chain:
> feature engineering (adstock + scaling + Hill saturation), an
> overall channel × network Bayesian model, a taxonomy fan-out
> (15 parallel per-channel-network sub-models at the LOB ×
> campaign_super granularity), output merge, response-curve fits,
> and a stability check comparing the new version to the prior
> version on per-channel ROI.
>
> The math: each model is a hierarchical Bayesian regression with
> DMA-level random effects, truncated-normal priors on media
> coefficients to enforce non-negativity, informative priors from
> the previous version for validated channels, NUTS MCMC with 2000
> samples. A retry wrapper catches divergent or low-acceptance
> chains. Funnel attribution between KPIs happens post-fit by
> proportionally allocating the parent KPI's channel attribution
> based on the parent-variable share in the child's regression. AOT
> geo-experiments calibrate Email and App channels post-fit by
> shifting predictions to the AOT-measured incrementality rate and
> absorbing the difference into the per-DMA intercept to preserve
> total prediction.
>
> The Python codebase is split into a `rapidmmm` library (the math,
> shared across all five KPIs) and per-KPI notebooks plus shared
> utilities. Everything is config-driven via YAML — adstock
> parameters, channel exclusions, recalibration flags — so adding
> a new KPI is a directory copy and a config edit, no library
> changes. Schema evolution is handled in a separate directory of
> one-off migration scripts."

### 6.3 The 10-minute deep-dive (full architecture + math)

When interviewers say "tell me more about the model," cover this in
roughly the order the chain actually runs, anchored to FS Submits
as the concrete example:

**Inputs (1 min).** Marketing metrics from upstream — impressions,
spend, channel/network/LOB/campaign_super taxonomy at DMA-week
granularity. Business metrics — KPI events plus macroeconomic
indices (Google Trends, mortgage rate, for-sale inventory) and
search trends. Holiday calendar. All cleaned and pivot-wide-formatted
by the shared MMM Input Job into six silver tables shared across
KPIs.

**Feature engineering (1 min).** Per-channel adstock convolution
with config-driven parameters (Linear TV uses delayed adstock with
max_lag=9, decay=0.9, delay=5 — peak weight at lag 5 in a quadratic
bell shape; SEM uses essentially zero carryover because it's
intent-driven). SoV scaling for 3 specific channels with bursty
spend patterns. Per-DMA mean scaling so coefficients become
elasticity-like. Atan transform on 8 heavy-tailed channels to
compress outliers. Hill saturation per channel with config-tuned
slope and shape. Holiday + multiplicative STL seasonal + anomaly-
flag merges.

**The Bayesian model (2 min).** Hierarchical: per-DMA coefficients
$\beta_{c,d}$ drawn from a per-channel population distribution
$\mathcal{N}(\mu_{\beta_c}, \sigma_{\beta_c})$, truncated at 0 for
media (non-negativity). Hyperparameters $\mu_{\beta_c}$ themselves
come from CSV priors — tight informative priors (Sd ~0.01) for
channels validated against AOT, uninformative (Sd 1.0) for channels
to be recalibrated post-fit. Per-DMA intercept $\alpha_d$ included
for the overall model, omitted for taxonomy. Linear combination
gives $\hat{y}_{d,t}$, likelihood $y_{d,t} \sim \mathcal{N}(\hat{y}_{d,t},
\sigma)$. Fit via NumPyro NUTS: 2000 samples, 1000 warmup, single
chain. Diagnostic retry wrapper enforces mean accept_prob in
[0.6, 1.0] and divergences < 15% of samples, up to 3 retries.

**Post-fit (1 min).** Posterior summaries via ArviZ. Predictions
via `numpyro.infer.Predictive`. Train + holdout R², RMSE, MAPE.
A "melted contribution table" with per-(DMA × week × variable)
attribution including HDI bounds — this is the linchpin artifact.
The model gets registered in Unity Catalog as an MLflow pyfunc via
a custom `RapidMMMModelWrapper` that bridges NumPyro to MLflow's
predict surface.

**Funnel attribution (1 min).** For each child KPI, the post-fit
step reads the parent KPI's melted data via Delta Time Travel pinned
to the same `model_version_number` (looked up through the audit
metadata table). `FunnelEffects.funnel_effects` then computes:
each channel's funnel-effect contribution to the child KPI =
parent KPI's per-channel prediction × the share of the child KPI
attributed to the parent variable. Direct effect and funnel effect
rows are stored separately with a `type` column. Four invariants
are validated post-attribution: spend balance, type exhaustiveness,
attribution monotonicity, and parent-KPI cap.

**AOT recalibration (1 min).** For Email Simon Data specifically,
the MMM overstates incrementality because emails go to high-intent
users. AOT geo-tests measure the true sends-per-incremental-submit
rate. The recalibration replaces the model's per-row Email
prediction with `impressions / adjusted_target` (where
adjusted_target accounts for the funnel-effect rows that shouldn't
be touched) and pushes the difference into the per-DMA intercept
to preserve the total prediction. The adjusted_target gets persisted
back to config for downstream use by the taxonomy notebook.

**Taxonomy fan-out (1.5 min).** The taxonomy model is split into 15
parallel per-channel-network sub-models rather than a single 70-
predictor hierarchical model. Three reasons: computational
tractability, multicollinearity isolation, per-channel policy
flexibility. For "Direct Effect" channels (channels with meaningful
direct attribution), the sub-model's dependent variable is the
overall model's per-channel attribution normalized by per-DMA mean
KPI; the sub-model decomposes this into per-(LOB × campaign_super)
shares. For "no Direct Effect" channels (awareness channels whose
FS Submits attribution flows entirely through the Visits funnel),
the dependent variable is set to zero and the channel's full
attribution comes from the taxonomy funnel-effect step. Each
sub-model registers its own Unity Catalog model. Taxonomy funnel
effects: each parent KPI's per-(channel × network) attribution gets
allocated across taxonomy variants in the same proportion as the
parent KPI's own taxonomy decomposition.

**Response curves + stability (1 min).** Hill curves fit per channel-
network at both DMA and national levels via `scipy.optimize.curve_fit`,
with TV-specific impression-to-spend-equivalent adjustment because
TV impressions in source data are actually GRPs. Numerical-stability
check filters curves that overflow at $100M / $300M spend.
Tableau-ready reporting tables sample each stable curve at 150
spend points. Stability check (NB9) compares the latest 2 versions
on per-channel-network return (predicted / impressions) using a
two-dimensional test: point-estimate drift < 25% OR HDI band overlap
> 50%. Pass either dimension → Stable; fail both → Unstable.

**The full bi-weekly chain runs in ~60–90 minutes wall-clock**
(GPU for the overall model, CPU for the parallel taxonomy fan-out).
~16 registered models per KPI per version (1 overall + 15 taxonomy).
One Slack notification at the end of NB9 in prod.

---

## 7. 30 likely interview questions, answered

Grouped into four categories. Each answer is anchored to specific
code paths in this codebase.

### 7.1 MMM theory (8 questions)

**Q1. Why use MMM at all when you could use multi-touch
attribution?** *MTA needs cross-channel user identity (cookies,
device IDs). iOS 14 ATT and third-party cookie deprecation broke
most MTA. More fundamentally, MTA cannot measure offline channels
(Linear TV, OOH, Audio) because there's no user touch to attribute.
At Zillow we spend across 25+ channels including offline; MMM is
the only attribution method that covers the full mix uniformly. We
use AOT geo-experiments for ground-truth calibration on selected
channels and last-click for in-platform optimization, with MMM as
the primary budget-allocation engine.*

**Q2. Why Bayesian vs frequentist for MMM?** *Five reasons. (1)
Built-in regularization via priors — handles MMM's intrinsic
multicollinearity better than ridge's single L2 penalty because
priors can be per-channel. (2) Native uncertainty quantification —
the posterior gives HDI bounds per coefficient, used downstream by
the stability check and response-curve confidence bands. (3) Native
fit for hierarchical / partial-pooling structure across DMAs. (4)
Informative priors let us incorporate AOT-derived knowledge (e.g.,
pin Paid Social Facebook's elasticity at AOT-measured value with
Sd=0.02). (5) Yesterday's posterior becomes today's prior — bi-
weekly runs accumulate evidence over time rather than retraining
from scratch.*

**Q3. Explain adstock in your own words.** *Adstock models the
fact that media has memory. A TV ad seen this week creates awareness
that influences behavior in following weeks. Adstock is a discrete
convolution of the raw impressions time series with a decaying
kernel. The dominant variant in this codebase is delayed adstock
with a bell-shaped weight: $w_i = \lambda^{(i-\delta)^2}$, peaked at
$i=\delta$ with width controlled by $\lambda$. For Linear TV we use
max_lag=9, decay=0.9, delay=5 — peak weight five weeks after the
spot airs, meaningful contribution through weeks 3–7. For SEM we
use max_lag=1, decay=0, delay=0 — no carryover because search is
intent-driven and converts within days.*

**Q4. Explain saturation.** *Marketing has diminishing returns —
the 10th million dollars on a channel doesn't produce the same
incremental KPI as the 1st million. The codebase uses the Hill
function $h(x) = x^s / (K^s + x^s)$ where $s$ is slope (controls
curve steepness) and $K$ is the half-saturation point. The Hill
function is bounded in [0,1], passes through 0.5 at $x=K$, and is
analytically invertible (useful for budget optimization). For
specific heavy-tailed channels we apply arctan before Hill to
compress outliers without sign-flipping.*

**Q5. Why hierarchical?** *Three reasons. (1) DMA-level coefficients
capture real heterogeneity — NYC's TV elasticity differs from rural
DMAs by 10× or more. (2) Partial pooling regularizes — DMAs with
weak signal are pulled toward the population mean, preventing
overfit on noisy per-DMA data. (3) Pooling across DMAs gives us
~22,000 observations per year of training data instead of ~104,
which is what makes identifying 20+ channel coefficients
statistically feasible.*

**Q6. How do you handle the identification problem when channels
are spent together?** *Four mechanisms. (1) Informative priors —
when two channels are spent together (multicollinear), the priors
keep both coefficients close to their previously-validated values
rather than letting either over-attribute. (2) Mean scaling reduces
the condition number of the design matrix. (3) The taxonomy split —
instead of one regression with 100+ taxonomy features, we fit the
overall regression on ~25 channel-networks and decompose each into
taxonomy-level pieces via separate per-channel sub-models. (4)
Hierarchical partial pooling acts as additional regularization
against multicollinearity-induced noise.*

**Q7. What's the difference between calibration and validation?**
*Validation checks whether the model fits the data — train/holdout
R², RMSE, MAPE, posterior diagnostics like R-hat and ESS. The
holdout window (last 4 weeks of training data, withheld from the
fit) is the canonical validation set. Calibration, in our system,
specifically means adjusting the model's per-channel attribution to
match independently-measured ground truth from AOT geo-experiments
— it's a post-hoc correction, not a re-fit. Email Simon Data gets
AOT-recalibrated because MMM systematically overstates Email's
direct effect; the recalibration replaces the model's predicted
contribution with impressions/spi where spi is the AOT-measured
sends-per-incremental-submit rate.*

**Q8. What are response curves and why are they the actual
deliverable?** *Response curves are the function spend → expected
KPI per channel, sampled from the fitted model. Marketing planners
can't act on raw coefficients — they need to answer "if I shift $5M
from TV to Paid Social, what happens?" The response curve is what
answers that. We fit Hill curves per channel by aggregating the
model's per-DMA-week predicted contributions and spend, then write
both DMA-level and national-level fits to the gold table plus a
150-point sampled grid for direct Tableau plotting. The marginal
ROAS at any spend level is the derivative of the curve, which drives
optimal budget allocation under a budget constraint (Lagrangian:
marginal ROAS equalized across channels at the optimum).*

### 7.2 This codebase specifically (8 questions)

**Q9. Walk me through NB1 (Feature Engineering) of FS Submits.**
*Twelve config-driven stages: read silver, restore pipe-separated
column names, fillna, drop excluded channels, apply per-channel
adstock dispatching from `adstock_hill_best_params` config, merge
in smoothed macroeconomic features from the Databricks Feature
Store, SoV-scale 3 specific channels (Pinterest, TikTok, Display
Media Agency), split train/holdout, fit MeanScalingRegional on
train and transform both, apply Atan to 8 heavy-tailed channels,
apply Hill with per-channel slope+saturation, merge 5 holiday flags,
merge multiplicative STL seasonal component, add any anomaly date
flags (FS Submits has the Jan 8 2024 dip), concat, write 3 silver
tables.*

**Q10. Walk me through NB2 (Overall Model).** *Read modeling silver
table, drop config-excluded channels (FS Submits excludes ~11
channels that have no direct effect — they get attribution via
funnel from Visits), split train/holdout, load priors CSV. Build
`Model` from `rapidmmm.Model.BayesianModel` with hierarchical=True,
nonnegative=True, modeltype='Overall'. Fit via the
`run_model_with_accept_prob_and_divergence_check` wrapper that
retries up to 3 times if accept_prob ∉ [0.6, 1.0] or divergences >
15% of samples. Wrap in `RapidMMMModelWrapper` and register in Unity
Catalog. Generate train + holdout predictions via
`MoDi.generate_predictions`. Compute R², RMSE, MAPE; filter
high-variance holdout DMAs (>20% error) before final holdout stats.
Build melted contribution table via
`get_melted_data_for_business_diagnostics`. Read Visits' melted
output via Delta Time Travel pinned to the same model version.
Apply `fne.funnel_effects(...)`. Run 4 funnel-validation invariants.
For Email Simon Data: query AOT for spi, compute adjusted_target,
recalibrate Direct Effect rows row-by-row, push the difference into
the per-DMA intercept α. Write two gold tables.*

**Q11. Explain funnel attribution as it's coded in your system.**
*Two-node funnel — parent KPI (Visits) and child KPI (FS Submits)
have separate Bayesian models. After both are fit, FunnelEffects
runs a post-hoc proportional allocation. For each (DMA, week): the
share of the child KPI's prediction attributed to the parent variable
in the child regression × each channel's share of the parent KPI's
prediction = the channel's funnel-effect contribution to the child
KPI. This is stored as new rows tagged `type = 'Funnel Effect'`
alongside the original Direct Effect rows. So Linear TV — which has
no direct FS Submits effect in the model — gets meaningful FS
Submits attribution through the funnel because TV drove Visits which
became Submits.*

**Q12. Explain the taxonomy parallelization.** *Instead of one
hierarchical model with all 70+ taxonomy features, we fit 15
parallel per-channel-network sub-models — one per (channel,
network) combination in `list_with_DE ∪ list_noDE`. Each sub-model
fits on ~5 features at its own channel's taxonomy granularity. The
15 models run as parallel Databricks tasks on a 1-5-node CPU
autoscale cluster, each writing to the same shared staging tables
via `replaceWhere channel_network = '...'`. The parallelism is
data-coordinated, not orchestration-coordinated. Reasons: NumPyro
NUTS scales poorly to 70+ predictors × 210 DMAs, multicollinearity
across channels would be intractable in one model, and each sub-
model can have its own data-prep logic (Direct Effect channels use
the overall model's per-channel attribution as the dependent variable;
no-DE channels use 0).*

**Q13. Explain AOT recalibration step-by-step.** *For Email Simon
Data: (1) SQL-query the b2c_measurments_fact and email_pooled_results
tables for the past year to compute spi = sum(sends) /
sum(incremental_submits). (2) Compute Email's total impressions
across the modeling window — both Direct and Funnel rows. (3)
Compute Email's Funnel-Effect contribution (which we won't touch).
(4) Compute adjusted_target = imp_direct / (imp_total/spi -
pred_funnel) — this rate accounts for the funnel rows that stay
unchanged. (5) For each Direct Effect row at (DMA, week):
recalibrated_value = impressions / adjusted_target (the per-row
algebra simplifies via cancellation). (6) Compute the difference
between original MMM prediction and recalibrated value per row,
aggregate per (DMA, week), and add to the α intercept rows to
preserve total predicted FS Submits. (7) Persist adjusted_target
back to config_param.yml for the taxonomy notebook to read.*

**Q14. Explain the stability check.** *NB9 of every KPI compares
the latest version to the prior version on per-channel return =
sum(predicted) / sum(impressions) over the modeling window. Two
dimensions: (a) point-estimate drift = |return_curr - return_prev|
/ return_prev × 100; flag Unstable if > 25%. (b) HDI overlap = the
overlap range between the two versions' HDI bands on return,
normalized by the current HDI width; flag Stable if > 50%. The final
tag is Stable if either dimension passes (lenient OR rule). Only
flag a channel Unstable when both fail. The thresholds are
config-driven widgets so they're tunable without code change.
Operates at both overall (channel × network) and taxonomy (+
campaign_super, LOB) granularity. Output goes to two gold tables
that feed a Tableau QC dashboard the team reviews before the new
version is acted on.*

**Q15. How do priors evolve over time in your system?** *The CSV
`mmm_<kpi>_priors.csv` per KPI is hand-maintained by the analytics
team. Two patterns: (a) channels validated against AOT get tight
informative priors (Mean = AOT-measured value, Sd very small like
0.01–0.02) so the coefficient stays pinned across versions; (b)
channels expected to be recalibrated post-fit or that have noisy
signal get uninformative priors (Mean=0, Sd=1.0) and let each
version's data drive the estimate. As AOT coverage expands over
time, more channels move from uninformative to informative priors.
The CSV is committed to Git per KPI and reviewed at the start of
each quarter for adjustment.*

**Q16. Explain the MLflow pyfunc wrapper.** *`RapidMMMModelWrapper`
in `common_functions.py` subclasses `mlflow.pyfunc.PythonModel`,
wrapping the fitted `rapidmmm.Model.BayesianModel.Model` object so
it has a `predict(context, model_input, params)` method compatible
with MLflow's serving surface. NumPyro MCMC objects aren't natively
MLflow-serializable; the wrapper internally creates a
`ModelDiagnostics` instance and delegates to `generate_predictions`,
which uses `numpyro.infer.Predictive` with the posterior samples to
draw predictive samples and return their mean. The wrapper accepts
a `kpi` parameter so the same wrapper class serves every KPI's
model. After wrapping, every KPI's overall model and every per-
channel taxonomy model is loadable from anywhere in the Zillow data
ecosystem via `mlflow.pyfunc.load_model("models:/marketing.rapidmmm_gold.mmm_fs_submits_overall_model/<version>")`.*

### 7.3 Production ML / system design (8 questions)

**Q17. How do you schedule a bi-weekly job on Databricks which
only supports weekly cron?** *We schedule weekly cron and the first
task `mmm_week_condition_check.py` short-circuits the job on even
ISO weeks. It computes the current week's ISO number via
`datetime.now(pytz.timezone('US/Pacific')).isocalendar().week` and
sets `dbutils.jobs.taskValues.set(key="run_mmm_jobs", value="Execute"
or "Skip")`. The next task is a Databricks if/else condition task
that reads the value and either proceeds or no-ops the rest of the
DAG.*

**Q18. How do you handle schema evolution in long-lived ML
pipelines?** *We have a dedicated `mmm_table_changes/` directory
with one-off migration notebooks — 12 of them, each handling a
specific schema change event. The scripts are widget-parameterized
for catalog/schema, typically start with backup tables (`CREATE
TABLE IF NOT EXISTS ..._bkp_<date>`), use `IDENTIFIER(:catalog || ...)`
parameter substitution, and several have `dbutils.notebook.exit("Success")`
guards to prevent accidental re-execution. They run manually outside
the bi-weekly job, keeping steady-state pipeline code clean.
Examples: a `train_holdout` column added, `lob → core_lob` renames
(requiring `delta.columnMapping.mode = 'name'` first), legacy value
normalizations like `B2C → Buyer`, the architectural migration that
created the unified `_combined_output_*` tables from the prior
direct + funnel-effects pair.*

**Q19. Why DMA-level training rather than national?** *Three reasons.
(1) Hierarchical signal: DMAs vary in spend, impressions, and
conversion rates by 10–100×; pooling them via a hierarchical prior
lets each DMA have its own coefficient while borrowing strength
from the others. (2) More observations: a national model has ~104
rows/year; a DMA model has ~22,000 — essential for identifying
20+ channel coefficients. (3) TV/regional alignment: DMAs are
defined by Nielsen as TV-buying regions; DMA-level Linear TV
impressions are directly addressable. Rolling them up to national
loses the cross-DMA variation that identifies TV's coefficient.*

**Q20. How do you parallelize MMM training in production?** *Two
layers. (1) Within a model fit: NumPyro JIT-compiles the entire
posterior to a single XLA program via JAX and runs NUTS on GPU.
The model uses `vmap` over observations and `to_event(1)` on
per-DMA coefficient batches for full GPU utilization. (2) Across
the 15 channel-network taxonomy sub-models within a KPI job: these
run as parallel Databricks tasks on a 1-5-node CPU autoscale
cluster, each running an independent NumPyro fit and writing
non-overlapping slices via `replaceWhere channel_network = '...'`.
GPU is used by the overall model (NB2); CPU by the taxonomy fan-out
(NB4 ×15). Different KPI jobs are independent except for the
data-layer dependency between funnel parent and funnel child.*

**Q21. How does your system integrate with MLflow / Unity Catalog?**
*Every model fit gets wrapped in `RapidMMMModelWrapper` (an MLflow
pyfunc bridge for the NumPyro model) and registered to Unity Catalog
under names like `marketing.rapidmmm_gold.mmm_fs_submits_overall_model`
(overall) or `marketing.rapidmmm_gold.mmm_fs_submits_taxonomy_Paid_Social_Facebook`
(per-channel taxonomy). Each registered model has a `version` tag
matching the integer model version, plus `model_type` and
`business_kpi` registered-model-level tags. Before each registration,
the code searches Unity Catalog for any prior registration with the
same `version` tag and deletes it — making the registration
idempotent for re-runs. All MLflow runs are organized as a parent
run per KPI per bi-weekly version with child runs for each notebook
stage. Artifacts (trace plots, correlation matrices, scatter plots)
are logged to the parent's artifact path.*

**Q22. How does environment promotion (dev → stage → prod) work?**
*Developers iterate in lab Databricks workspaces with per-user
schemas (`dev_{username}`) auto-bootstrapped by
`create_or_get_dev_environment_variables` in `common_functions.py`,
using `catalog=sandbox_desa`. Lab deploys are done manually through
the Databricks Asset Bundles UI. To promote to stage, the developer
opens a GitLab MR — the CI/CD pipeline runs as a stage service
principal (`71e8166b-...`) and deploys to the stage catalog
`stage_marketing.rapidmmm_silver/gold`. Once the MR is approved
and merged to main, the pipeline runs again as the prod service
principal (`472826f2-...`) and deploys to the prod catalog
`marketing.rapidmmm_silver/gold`. Critically, individual users
have no direct deploy permissions to stage or prod — only the SPs
do. This enforces Git history + code review for every prod change.*

**Q23. How do you ensure upstream data freshness before running an
ML job?** *We use a shared internal package
`zg_databricks_platform_sdk.availability` (the `poke_delta_table_for_availability`
function) that polls the upstream Delta table's max process date
and asserts it's within an expected window. The MMM Input Job has
two parallel availability-check tasks — one for `mmm_marketing_metrics`,
one for `mmm_business_metrics` — both must pass before any
preprocessing runs. Failure halts the job and alerts data
engineering. Better to fail fast at the upstream check than to fit
a model on stale data and silently produce wrong attributions.*

**Q24. How do you make Delta writes idempotent in this codebase?**
*Two mechanisms. (1) Every gold-table write is `mode("overwrite")`
+ `replaceWhere business_kpi = '<KPI>' AND version = '<vN>'`, which
overwrites only that KPI's slice of that version without touching
other slices. Re-running the same job with the same `model_version_number`
safely overwrites only its own output. (2) The audit metadata write
in `intermediate_and_meta_table_write` uses `replaceWhere business_kpi
AND model_version AND job_id AND table_name`, ensuring re-runs
overwrite their own metadata row without polluting siblings.
Combined, the standard recovery from a failed task is just re-run
the task — no manual cleanup needed.*

### 7.4 Business / partnership (6 questions)

**Q25. How does Marketing use the response curves?** *The response
curves table is sampled at 150 spend points per channel per version
and stored in a Tableau-ready reporting table. Marketing planners
plot the curves in Tableau and use them as the input to a separate
budget-allocation tool (`mmmrapid_budget_allocation`) that takes a
total budget constraint and finds the per-channel spend that
maximizes expected total KPI subject to per-channel min/max
constraints. The Lagrangian first-order condition is "marginal ROAS
equalized across channels at the optimum" — the optimizer iterates
until that holds. Marketing reviews the optimizer's recommended
allocation in a quarterly planning cycle and applies adjustments
based on business priorities not captured in the model (e.g., must
maintain Brand spend above a floor for sponsorship contracts).*

**Q26. How do you communicate stability to stakeholders?** *The
two stability tables (`mmm_model_output_overall_level_stability` and
the taxonomy variant) feed a Tableau QC dashboard showing per-
channel `Final_Stability` (Stable / Unstable), the point-estimate
drift %, the HDI overlap %, and the actual return values for both
versions. Channels flagged Unstable get human review before
Marketing acts on the new numbers. We frame it to stakeholders as
"this number jumped 35% — let's investigate before reallocating
budget against it" rather than "this number is wrong." Most
instabilities have explanations (a known spend pattern change, a
new campaign that started, a creative refresh) that the team can
attribute.*

**Q27. What do you say when Marketing pushes back on a low-
attribution channel?** *Three responses in order. (1) "Direct effect
isn't total effect — let's look at the channel's funnel-effect
contribution to the downstream KPI." Often a channel with low FS
Submits direct effect has substantial FS Submits funnel effect via
Visits. (2) "What does AOT say?" If we have AOT data for the
channel, that's the ground truth; if AOT and MMM disagree, we
recalibrate MMM to AOT. (3) "What changed?" If the channel was
historically high-attribution and just dropped, the stability check
should have flagged it Unstable — that's the actionable signal,
not the level. We don't get into "the model is wrong" debates;
we ground every discussion in observable metrics (funnel
contribution, AOT comparison, stability tag).*

**Q28. How do you handle a channel where the business "knows" the
prior is wrong?** *Two paths. (1) If the business has data backing
their belief — AOT geo-test, vendor lift study — we update the
prior in the next version's CSV with a tight informative prior
centered on the evidence-derived value. The prior CSV is hand-
maintained, so this is a one-line change. (2) If the business has
intuition but no data, we keep the prior uninformative and let the
model speak. Then we publish the model's estimate and compare to
the business intuition; if they disagree persistently, we propose
running an AOT geo-test on that channel to resolve the disagreement
with data. We never override the model with hand-tuned values
without evidence — that path leads to "the MMM agrees with whoever
edits the YAML last," which destroys credibility.*

**Q29. How do you explain credible intervals to non-DS
stakeholders?** *Two-step framing. (1) Drop the term — say "range
of plausible values" or "uncertainty range" instead. (2) Frame in
the action context: "the model estimates this channel's
contribution is between $X and $Y; if we shift budget based on the
midpoint $Z, we should be prepared for outcomes anywhere in this
range." The stability check is a separate framing: "this estimate
overlaps last version's by 60%, so we're confident; this other one
overlaps by 20%, so we should investigate before acting." We never
say "95% confidence interval" — too easy to misinterpret.*

**Q30. What KPI would you add next?** *Realistic answer depends on
business priority, but two natural candidates. (1) **ZHL Visits**
— the analog of Rental Visits for the mortgage funnel: ZHL Submits
currently has no upper-funnel parent in our system. Building
ZHL Visits would let us attribute mortgage applications partly to
awareness-building channels via a funnel-effect mechanism, matching
how FS Submits attribution works. (2) **Premier Agent (PA)
Connections** — currently we model FS Submits (the form
submission); we don't separately model the downstream agent
connection event. A "PA Connections" KPI would add a third-tier
node to the funnel: Visits → FS Submits → PA Connections. The
infrastructure (shared silver layer, library, gold tables) handles
new KPIs without changes — only a new directory of 9 notebooks +
configs is needed.*

---

## 8. Three common interview traps and how to avoid them

### Trap 1 — Confusing model coefficient with channel contribution

**The trap.** "The model says SEM Google Search has coefficient
0.16; therefore SEM contributes 16% to FS Submits."

**Why it's wrong.** The coefficient $\beta_c$ is the model's
elasticity-style multiplier on the scaled, adstocked, Hill-saturated
feature value — *not* the channel's percentage contribution to the
KPI. The actual contribution is
$\beta_c \times \text{feature\_value}_{c,d,t} \times \overline{y}_d$
(see [Doc 02 Section 9.7](02_rapidmmm_library_internals.md) on
`get_melted_data_for_business_diagnostics`). Two channels can have
the same coefficient and very different contributions if one has
10× more impressions.

**How to avoid.** When asked about "what does channel X contribute,"
always answer in terms of `predicted` from the melted table, not the
coefficient. Say: "the coefficient is 0.16, but the channel's actual
contribution depends on its impression volume — let me check the
melted contribution table for the absolute number."

### Trap 2 — Claiming MMM "proves causation"

**The trap.** "Our MMM proves that SEM Google Search caused
$Y million in FS Submits."

**Why it's wrong.** MMM is a *statistical estimation* method, not a
causal identification method. It estimates the response under
observed variation in spend and outcomes, with assumptions:
correctly-specified adstock + saturation, no omitted confounders,
spend levels in the model are not endogenously chosen based on the
KPI. Geo-experiments (AOT) are causally identified; MMM is not by
default. The Bayesian formulation gives uncertainty quantification
but not causal identification.

**How to avoid.** Use the language "the model estimates" or "the
model attributes" — not "caused." When asked about causality, say
"MMM is associational under the standard assumptions; for causal
ground truth on individual channels we run AOT geo-tests and use
those to recalibrate MMM where they disagree."

### Trap 3 — Over-promising on prior interpretability

**The trap.** "The prior says we expected channel X to have
elasticity 5.0."

**Why it's wrong.** A prior with Mean=5.0 and Sd=0.02 means "we
believe the coefficient is 5.0 ± 0.04 with high confidence."
But a prior with Mean=0 and Sd=1.0 (uninformative) does **not**
mean "we believe the coefficient is 0." It means "we have no
strong belief; the data should determine the value." Saying "our
prior is 0 so we expect the channel to be ineffective" misreads
the prior — the *uninformativeness* is the prior content, not the
location.

**How to avoid.** When discussing priors, distinguish between
informative (tight Sd, location matters) and uninformative (wide
Sd, the location is just a centering convenience and the data
determines the answer). For our Email channels with Mean=0 Sd=1,
say "we let the data determine Email's coefficient — we don't have
a strong prior because we plan to AOT-recalibrate Email's
contribution post-fit anyway."

---

## 9. What this codebase does well, and what you'd propose to improve

The interview-grade critique. Not a code-change request — but
articulating both sides shows you understand the system as engineered,
not just as a marketing pitch.

### 9.1 What this codebase handles well

- **Bi-weekly cadence with clean idempotency.** The week-parity
  gate, the auto-version-increment with `replaceWhere`
  predicate-scoped writes, the audit metadata table — together
  these make re-runs safe and traceable.
- **Train + holdout split methodology.** The temporal 4-week
  holdout (introduced in v13) gives a real forward-prediction
  generalization test, with high-variance DMA filtering for
  defensible stats.
- **Stability check.** Comparing 2 versions on per-channel ROI
  using both point-estimate and HDI-overlap criteria is a
  thoughtful methodology. The lenient OR rule + the channel
  whitelist prevent over-flagging while still catching real drift.
- **Recalibration framework.** The AOT calibration for Email, the
  App-pair recalibration for Visits and Rental Visits — these are
  good examples of blending statistical MMM with experimental
  ground truth, with the math correctly preserving the total
  prediction by absorbing the difference into the intercept.
- **Hierarchical priors with informative/uninformative split.**
  Pinning validated channels (AOT-confirmed) tightly while letting
  uninformative channels be data-driven is the right pattern.
- **Multi-KPI architecture with clean reuse.** The shared library
  + shared silver layer + per-KPI config-driven chain is a
  genuinely good design. Adding a 6th KPI is a directory copy.
- **Schema-evolution discipline.** The 12-script `mmm_table_changes/`
  directory is a real audit trail. Most teams don't do this well.

### 9.2 What you'd ask about / propose to improve

These are good interview talking points — articulating thoughtful
improvements signals depth of understanding.

- **Holdout window is short** (4 weeks). For a Bayesian model that
  produces credible intervals, a 4-week holdout is statistically
  thin — only ~840 (DMA × week) cells for stats. A rolling-origin
  cross-validation across multiple 4-week holdout windows would
  give more reliable forward-prediction estimates of the model's
  generalization.

- **Single-chain MCMC** (`num_chains=1`). NumPyro's NUTS is
  configured for single chain (multi-chain is commented out due to
  "instability"). Without multiple chains, the R-hat convergence
  diagnostic is meaningless (R-hat compares between-chain to
  within-chain variance). Re-enabling multi-chain (and debugging
  the instability) would give a much stronger convergence test.

- **Per-channel taxonomy sub-models lose cross-channel
  information.** The 15 parallel sub-models can't share signal
  across channels at the taxonomy level — e.g., if Paid Social
  Facebook's PA-Customer-Buyer attribution shares structure with
  Paid Social TikTok's PA-Customer-Buyer, the current architecture
  can't exploit it. A single hierarchical taxonomy model would
  capture this but is computationally hard. A middle ground: group-
  level priors that pool across the 15 sub-models at the population
  level.

- **No cross-validation across time windows.** The model is fit
  once on the rolling 2-year training window and validated once on
  the 4-week holdout. There's no rolling-origin CV (fit on
  weeks 1–100, test 101–104; fit on 1–101, test 102–105; etc.)
  which would give a more reliable estimate of out-of-sample
  performance over time.

- **Recalibration is hand-tuned per channel.** Email Simon Data gets
  recalibrated; Email Iterable and Email Sparkpost don't (despite
  arguably the same incrementality bias). App|Apple Search and App|
  Google UAC have a recalibration pair (Visits and Rental Visits
  only); App|Facebook has no analog. Whether a channel gets
  recalibrated is a manual decision in the config. A more
  principled approach: a single AOT-aware framework that
  automatically identifies channels with AOT-MMM divergence
  exceeding a threshold and applies recalibration uniformly.

- **No explicit handling of new-channel onboarding.** When a new
  marketing channel is introduced (e.g., a new SEM partner or app
  network), it has no historical data, no prior, and no AOT
  validation. The current process is ad-hoc — add to config with
  uninformative priors, wait several bi-weekly cycles for the data
  to accumulate. A formal onboarding playbook would help.

- **Zero unit-test coverage on the rapidmmm library.**
  `tests/test_dummy.py` is essentially empty. Critical paths
  (Bayesian model definition, funnel attribution, response curve
  fit, mean scaling) have no test coverage. Integration testing in
  stage catches regressions, but unit tests would catch them
  earlier and faster.

- **The stability thresholds are heuristic** (25% point-estimate
  drift, 50% HDI overlap). A principled approach: derive thresholds
  from the historical distribution of bi-weekly drift across
  channels, so an "Unstable" tag corresponds to "more drift than
  90% of historical bi-weekly version-pairs for this channel"
  rather than a fixed percentage.

- **Adstock + Hill parameters are fixed and reviewed quarterly,
  not refit per run.** This is a deliberate choice (the stability
  check requires comparable features across runs) but has a cost:
  if a channel's real adstock dynamics change (e.g., a new TV
  campaign with different creative produces a different memory
  curve), the model misses it until the quarterly review. A
  middle ground: refit adstock annually using a longer historical
  window, freeze for stability between annual refits.

> **Interview angle — "Tell me what you would change about this
> system."** *"A handful of thoughtful improvements rather than
> wholesale changes — the architecture is solid. (1) Add unit-test
> coverage to the library; the integration-test-only approach has
> caught real regressions in stage but earlier feedback would help.
> (2) Re-enable multi-chain MCMC to get meaningful R-hat
> convergence diagnostics — the codebase has it commented out due
> to instability, which is worth investigating. (3) Lengthen the
> holdout window or move to rolling-origin cross-validation for a
> more reliable generalization estimate. (4) Formalize the AOT
> recalibration framework so it's threshold-driven rather than per-
> channel hand-tuned. (5) Build a new-channel onboarding playbook
> so the first few weeks of a new channel's data don't fall through
> the cracks. The list is mostly methodological maturity — the
> bi-weekly cadence, the shared/per-KPI separation, the schema-
> evolution discipline, the recalibration framework, the audit
> trail — these are all good. The work I'd prioritize is on
> validation rigor, not on rebuilding the architecture."*

---

## 10. Recommended ongoing study after these docs

Three layers, prioritized.

### 10.1 Code re-reading

1. **`rapidmmm/Model/BayesianModel.py`** end-to-end with
   [Doc 02 Section 4](02_rapidmmm_library_internals.md) open
   side-by-side. Especially: the `_base_model_fn` function and its
   `numpyro.sample` calls; the `_merge_grouped_vector` static method;
   the `_prepare_priors` and `_prepare_data` helpers; the
   `get_inference_data` renaming map.
2. **`rapidmmm/Utils/FunnelEffects.py`** all 144 lines, with a pen
   and paper. Walk through `funnel_effects(nodes, nodes_data)`
   line-by-line, building each intermediate DataFrame mentally.
3. **`mmm_fs_submits/2_mmm_fs_submits_overall_model.py`** lines
   1042–1316 — the full `recalibrate_channel_AOT` function — with
   [Doc 05 Section B9](05_fs_submits_overall_model_track.md) open.
   Convince yourself the algebra checks out: `(predicted × impv) /
   adjusted_target = impressions / adjusted_target`.

### 10.2 Replicate a small piece yourself

Build a **toy MMM** in Python on your local machine: 5 DMAs, 26 weeks,
3 channels with synthetic spend + KPI data, hierarchical Bayesian
NumPyro fit. Use the exact prior structure from this codebase
(TruncatedNormal for media, Normal for controls, HalfNormal for
hyperpriors). Verify you can:

- Fit NUTS with sensible accept_prob and zero divergences.
- Recover the synthetic coefficients within HDI bounds.
- Apply a manual adstock + Hill before fitting.
- Generate predictions via `numpyro.infer.Predictive`.

This will solidify your understanding of every line of
`BayesianModel.py`.

### 10.3 Background reading

| Topic | Recommended reading |
|---|---|
| MMM methodology overview | Google's "Bayesian Methods for Media Mix Modeling with Carryover and Shape Effects" (Jin, Wang, Sun, Chan, Koehler, 2017) — the foundational reference for the modern Bayesian MMM with adstock and Hill |
| NumPyro + NUTS | The NumPyro documentation tutorials, especially the hierarchical regression and "Bayesian Hierarchical Linear Regression" examples |
| Hamiltonian Monte Carlo intuition | Michael Betancourt's "A Conceptual Introduction to Hamiltonian Monte Carlo" (2017) — the canonical intuition-first treatment of HMC and NUTS |
| Bayesian workflow | Gelman, Vehtari, et al. "Bayesian Workflow" (2020) — methodology for prior choice, posterior checks, model criticism |
| Causal vs associational claims | Pearl & Mackenzie, "The Book of Why" (2018) — readable introduction to why MMM is associational |
| Adstock + Hill in industry | Meta's Robyn documentation — open-source MMM that uses similar adstock + Hill transforms with explicit parameter search |
| Multi-touch attribution context | Lindgren et al. on "MTA failure modes after iOS 14" — to understand the contrast with MMM |
| Marketing budget optimization | Kotler/Keller marketing textbooks for the business framing; combined with the Lagrangian "equalize marginal ROAS" derivation in [Doc 01 Section 9.3](01_mmm_methodology_primer.md) |

### 10.4 The interview prep itself

Three weeks of focused prep before a senior-DS interview should
allocate roughly:

| Week | Focus |
|---|---|
| Week 1 | Re-read Docs 01–02 (math + library). Pen-and-paper derive every equation in Doc 01. Code the toy NumPyro MMM described above. |
| Week 2 | Re-read Docs 05–07 (FS Submits walkthrough). Trace the NB1 → NB9 chain end-to-end with the actual notebooks open. Memorize the funnel-effect algorithm in Doc 06. |
| Week 3 | Rehearse Part B of this doc: deliver the 2-min and 10-min pitches out loud; answer all 30 questions out loud (record yourself if possible). Practice the three trap-avoidance reframings. Prepare 2–3 specific "what would you improve" talking points from Section 9.2. |

The goal is to be able to discuss any aspect of the system — math,
code, production engineering, business interpretation — without
needing to look anything up.

---

## Closing — the meta-narrative

This is the last document in the learning library. The arc the
nine docs together tell:

| Doc | The story it tells |
|---|---|
| 00 | "Here's the system end-to-end at a high level" |
| 01 | "Here's the math the system implements" |
| 02 | "Here's the Python library that codes the math" |
| 03 | "Here's the shared utilities and silver layer" |
| 04 | "Here's every table the system touches" |
| 05 | "Here's the FS Submits overall model in code" |
| 06 | "Here's the FS Submits taxonomy chain in code" |
| 07 | "Here's how FS Submits outputs become Marketing deliverables" |
| 08 | "Here's how the four other KPIs differ" |
| 09 | "Here's the production engineering, and here's how to talk about it" |

If you've read all nine, you should be able to:

- Walk through any of the 5 KPIs' bi-weekly chain in detail.
- Explain the math behind every transformation, prior, and posterior.
- Read any imported function call in any notebook and know what it
  does.
- Query any gold table and interpret every column.
- Diagnose a production failure by tracing through the audit
  metadata.
- Defend the architectural choices in an interview without
  hand-waving.
- Articulate what you'd change in the system and why.

This library is the single source of truth for that level of
understanding. Re-read it before any interview that touches MMM,
Bayesian production ML, or large-scale marketing analytics.
