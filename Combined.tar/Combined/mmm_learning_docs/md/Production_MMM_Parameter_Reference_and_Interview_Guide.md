# Production MMM Parameter Reference & Interview Guide

**Scope:** Real, repository-grounded values only. Every adstock, Hill, prior, sampler, and
implementation choice below was read directly out of the Zillow `mmm_model/` configs/priors
and the `rapidmmm` package. No generic MMM theory is included except where it is needed to
explain a Zillow-specific decision. Where a value is **not** in the repository it is listed in
Section 13 (Known Gaps) rather than guessed.

**Primary sources used**

| What | Where |
|---|---|
| Transform/library code | [rapidmmm-main/rapidmmm/](rapidmmm-main/rapidmmm/) |
| Adstock + Hill values | `mmm_model/<kpi>/config_param.yml` → `adstock_hill_best_params` |
| Bayesian priors | `mmm_model/<kpi>/artifacts/mmm_<kpi>_priors.csv` |
| Sampler / funnel / taxonomy wiring | `mmm_model/<kpi>/2_*_overall_model.py`, `4_*_taxonomy_model.py`, `7_*_overall_response_curves.py`, `9_*_stability_loop.py` |

**The 5 KPIs and their pipeline shape**

| KPI | `business_kpi` | Target column (`y_col`) | Has `2_overall_model`? | Priors CSV? | Funnel upstream (node1) |
|---|---|---|---|---|---|
| Visits | `Visits` | `value\|visits\|visits` | ✅ | ✅ | none (top of funnel) |
| FS Submits | `FS Submits` | `value\|leads\|fs_submits` | ✅ | ✅ | Visits (`value\|visits\|visits`) |
| MF Submits | `MF Submits` | `value\|rentalsmetrics_zillowbrand\|fr_bdp_submits` | ✅ | ✅ | Rental Visits (`value\|rentalsmetrics_zillowbrand\|rental_visits`) |
| Rental Visits | `Rental Visits` | `value\|rentalsmetrics_zillowbrand\|rental_visits` | ✅ | ✅ | none (top of funnel) |
| ZHL Submits | `ZHL Submits` | (taxonomy/OMP-based, no overall NB2) | ❌ | ❌ | exogenous: `visits`, `fs_submits`, `app_installs`, … |

> Source for targets/node1: [2_mmm_fs_submits_overall_model.py:234-235](mmm_model/mmm_fs_submits/2_mmm_fs_submits_overall_model.py#L234-L235), [2_mmm_mf_submits_overall_model.py:221-222](mmm_model/mmm_mf_submits/2_mmm_mf_submits_overall_model.py#L221-L222), [2_mmm_rental_visits_overall_model.py:232](mmm_model/mmm_rental_visits/2_mmm_rental_visits_overall_model.py#L232), [2_mmm_visits_overall_model.py:228](mmm_model/mmm_visits/2_mmm_visits_overall_model.py#L228), ZHL exogenous list [config_param.yml:662-668](mmm_model/mmm_zhl_submits/config_param.yml#L662-L668).

---

## SECTION 1 — Complete Feature Inventory (per KPI)

Feature classes are pulled from each KPI's `config_param.yml` plus the priors CSV (which lists
the exact model column set for Visits). `transform_cols_sigmoid` is `null` in **all five** KPIs —
Sigmoid is wired in code ([FeatureEngineering.py:426-460](rapidmmm-main/rapidmmm/FeatureEngineering/FeatureEngineering.py#L426-L460)) but **applied nowhere**.

### 1.1 Counts at a glance

| Feature class | Visits | FS Submits | MF Submits | Rental Visits | ZHL Submits |
|---|---|---|---|---|---|
| Media channel-networks (`adstock_hill_best_params` keys) | 28 | 27 | 31 | 25 | 27 (+27 OMP set) |
| Macro/economic vars | 5 | 8 | 5 | 7 | 20 (`macro_econ_vars`) |
| Holiday vars | 5 | 5 | 5 | 5 | 5 |
| Seasonality vars | 1 (`seasonal`) | 1 | 1 | 1 | 1 |
| Date-flag controls | 1 | 1 | 0 | 0 | 1 |
| Funnel vars (exogenous KPI) | 0 | 1 (Visits) | 1 (Rental Visits) | 0 | ≥3 (visits, fs_submits, app_installs) |
| Atan-transformed media | 8 | 8 | 2 | 4 | 11 (+11 OMP) |
| SoV-transformed media | 1 | 3 (+5 taxonomy) | 4 | 4 | 0 |
| Sigmoid-transformed media | 0 | 0 | 0 | 0 | 0 |

### 1.2 Control / non-media variables (actual config values)

**Holiday variables — identical across all 5 KPIs** (`holiday_var_list`):
`Christmas Day`, `Independence Day`, `Thanksgiving`, `New Year's Day`, `Memorial Day`.
Refs: [fs config:26-31](mmm_model/mmm_fs_submits/config_param.yml#L26-L31), [visits config:315-320](mmm_model/mmm_visits/config_param.yml#L315-L320), [mf config:18-23](mmm_model/mmm_mf_submits/config_param.yml#L18-L23), [rental config:22-27](mmm_model/mmm_rental_visits/config_param.yml#L22-L27), [zhl config:643-648](mmm_model/mmm_zhl_submits/config_param.yml#L643-L648).

**Seasonality variable** = single column `seasonal`, built by **multiplicative**
`seasonal_decompose` via `DetectSeasonality` and averaged by `dmacode × weekofyear`:
[1_mmm_fs_submits_feature_engineering.py:1000-1095](mmm_model/mmm_fs_submits/1_mmm_fs_submits_feature_engineering.py#L1000-L1095); missing weeks filled with `1` ([2_mmm_mf_submits_overall_model.py:441](mmm_model/mmm_mf_submits/2_mmm_mf_submits_overall_model.py#L441)).

**Date-flag controls** (`date_flags`): Visits `june_3_dip_flag = 2024-06-03` ([config:325-326](mmm_model/mmm_visits/config_param.yml#L325-L326)); FS `fs_submits_2024_01_08_dip_flag = 2024-01-08` ([config:32-33](mmm_model/mmm_fs_submits/config_param.yml#L32-L33)); ZHL `zhl_submits_2024_01_08_dip_flag = 2024-01-08` ([config:649-650](mmm_model/mmm_zhl_submits/config_param.yml#L649-L650)); MF & Rental have no `date_flags`.

**Macro / economic variables** (`macro_econ_vars_selected`):

| KPI | Macro vars (exact config strings) |
|---|---|
| Visits (5) | `econmetricsmsa\|for_sale_inventory_sm`, `econmetricsmsa\|median_sale_price_sm`, `econmetricsmsa\|new_listings_sm`, `econmetricsmsa\|zillow_home_value_index_sm`, `googletrends\|rentals_index_sm` ([config:303-308](mmm_model/mmm_visits/config_param.yml#L303-L308)) |
| FS Submits (8) | `googletrends\|rentals_index_sm`, `appinstalls\|app_installs`, `econmetricsmsa\|for_sale_inventory_sm`, `econmetricsmsa\|new_listings_sm`, `googletrends\|mortgage_index_sm`, `econmetricsmsa\|zillow_home_value_index_sm`, `mortgagemetrics\|interest_rate`, `moodys_unemployment_data\|unemployment_rate_sm` ([config:46-54](mmm_model/mmm_fs_submits/config_param.yml#L46-L54)) |
| MF Submits (5) | `mortgagemetrics\|interest_rate`, `econmetricsmsa\|for_sale_inventory_sm`, `googletrends\|rentals_index_sm`, `econmetricsmsa\|new_listings_sm`, `econmetricsmsa\|zillow_home_value_index_sm` ([config:1-6](mmm_model/mmm_mf_submits/config_param.yml#L1-L6)) |
| Rental Visits (7) | `googletrends\|rentals_index_sm`, `googletrends\|mortgage_index_sm`, `rental_metrics\|rental_daily_listings_sm`, `mortgagemetrics\|interest_rate`, `econmetricsmsa\|zillow_home_value_index_sm`, `econmetricsmsa\|new_listings_sm`, `econmetricsmsa\|for_sale_inventory_sm` ([config:1-8](mmm_model/mmm_rental_visits/config_param.yml#L1-L8)) |
| ZHL Submits (20 `macro_econ_vars`) | full econmetricsmsa block (for_sale_inventory, mean/median_days_to_pending, median_list/sale_price, new_listings, newly_pending_listings, percent_listings_with_price_cut, sales_count_raw, zillow_home_value_index), googletrends (branded/competitive/forsale/mortgage/rentals/zillowoffers index), `mortgagemetrics\|interest_rate`, `moodys_unemployment_data\|unemployment_rate`, `appinstalls\|app_installs`, `moodys_consumer_price_data\|consumer_price` ([config:245-265](mmm_model/mmm_zhl_submits/config_param.yml#L245-L265)) |

**Funnel / exogenous KPI variables**

- FS Submits consumes **Visits** (`value|visits|visits`) — [2_…:235](mmm_model/mmm_fs_submits/2_mmm_fs_submits_overall_model.py#L235).
- MF Submits consumes **Rental Visits** (`value|rentalsmetrics_zillowbrand|rental_visits`) — [2_…:222](mmm_model/mmm_mf_submits/2_mmm_mf_submits_overall_model.py#L222). Visits is also dropped from MF X before modeling ([2_…:268](mmm_model/mmm_mf_submits/2_mmm_mf_submits_overall_model.py#L268)).
- ZHL Submits `selected_exogenous_variables_ZHL`: `visits`, `app_installs`, `fs_submits`, `unemployment_rate`, `consumer_price`, `zhl_submits_purchase` ([config:662-668](mmm_model/mmm_zhl_submits/config_param.yml#L662-L668)).

---

## SECTION 2 — Adstock Parameter Inventory

Adstock type and parameters come **verbatim** from `config_param.yml → adstock_hill_best_params`.
Parameter meaning by type (code: [FeatureEngineering.py](rapidmmm-main/rapidmmm/FeatureEngineering/FeatureEngineering.py)):

- **Delayed** (`DelayedAdStock`, line 69): weights `decay_rate^((lag − delay)^2)`, normalized; uses `max_lag`, `decay_rate`, `delay`.
- **Exponential** (`ExponentialAdStock`, line 14): weights `decay^lag` over `length` lags; uses `decay`, `length`.
- **Geometric** (`GeometricAdStock`, line 158): weights `decay_rate^lag`, normalized; uses `max_lag`, `decay_rate` (no delay).

### 2.1 Visits — adstock ([config:1-245](mmm_model/mmm_visits/config_param.yml#L1-L245))

| Channel\|Network | Type | Decay | Delay | Max Lag | Length |
|---|---|---|---|---|---|
| App\|Apple Search | Delayed | 0.05 | 1 | 1 | — |
| App\|Facebook | Delayed | 0.1 | 1 | 2 | — |
| App\|Google UAC | Delayed | 0.05 | 1 | 1 | — |
| App\|TikTok | Delayed | 0.05 | 1 | 1 | — |
| Audio\|Media Agency | Delayed | 0.1 | 1 | 1 | — |
| Audio\|Radio | Delayed | 0.9 | 3 | 3 | — |
| Display\|Media Agency | Delayed | 0.1 | 1 | 1 | — |
| Display\|Video Demand Gen | Delayed | 0.5 | 3 | 5 | — |
| Online Video\|YouTube | Delayed | 0.03 | 1 | 1 | — |
| Email\|Iterable | Exponential | 0.5 | — | — | 2 |
| Email\|Simon Data | Exponential | 0 | — | — | 0 |
| Email\|Sparkpost | Exponential | 0.5 | — | — | 2 |
| Native\|Media Agency | Geometric | 0.05 | — | 4 | — |
| OOH\|Media Agency | Delayed | 0.03 | 1 | 1 | — |
| Online Video\|Media Agency | Geometric | 0.05 | — | 5 | — |
| Operational Emails\|Iterable_Simon Data | Exponential | 0.5 | — | — | 2 |
| Owned Social\|Facebook | Delayed | 0.04 | 1 | 1 | — |
| Owned Social\|TikTok | Delayed | 0.04 | 1 | 1 | — |
| Paid Social\|Facebook | Delayed | 0.1 | 1 | 2 | — |
| Paid Social\|Pinterest | Exponential | 0.5 | — | — | 2 |
| Paid Social\|TikTok | Exponential | 0.5 | — | — | 2 |
| Push\|null | Delayed | 0.6 | 1 | 5 | — |
| SEM\|Google Search | Delayed | 0.05 | 1 | 1 | — |
| SEM\|Google Performance Max | Delayed | 0.9 | 5 | 9 | — |
| SEM\|Microsoft Search | Delayed | 0.05 | 1 | 1 | — |
| Connected TV\|Media Agency | Delayed | 0.2 | 3 | 8 | — |
| Linear TV\|Media Agency | Delayed | 0.4 | 3 | 5 | — |
| Media Solutions\|Facebook | Delayed | 0.03 | 1 | 1 | — |

### 2.2 FS Submits — adstock ([config:118-349](mmm_model/mmm_fs_submits/config_param.yml#L118-L349))

| Channel\|Network | Type | Decay | Delay | Max Lag | Length |
|---|---|---|---|---|---|
| App\|Apple Search | Delayed | 0.05 | 3 | 4 | — |
| App\|Facebook | Delayed | 0.05 | 2 | 2 | — |
| App\|Google UAC | Delayed | 0.3 | 0 | 1 | — |
| App\|TikTok | Delayed | 0.05 | 1 | 1 | — |
| Audio\|Media Agency | Exponential | 0.7 | — | — | 3 |
| Audio\|Radio | Exponential | 0.7 | — | — | 3 |
| Display\|Media Agency | Delayed | 0.8 | 2 | 5 | — |
| Display\|Video Demand Gen | Delayed | 0.3 | 1 | 3 | — |
| Online Video\|YouTube | Exponential | 0.7 | — | — | 7 |
| Email\|Iterable | Exponential | 0.3 | — | — | 2 |
| Email\|Simon Data | Exponential | 0.6 | — | — | 1 |
| Email\|Sparkpost | Exponential | 0.3 | — | — | 2 |
| Native\|Media Agency | Exponential | 0.7 | — | — | 6 |
| Online Video\|Media Agency | Delayed | 0.8 | 4 | 8 | — |
| Operational Emails\|Iterable_Simon Data | Delayed | 0.01 | 0 | 1 | — |
| Owned Social\|Facebook | Exponential | 0.6 | — | — | 3 |
| Owned Social\|TikTok | Exponential | 0.7 | — | — | 5 |
| Paid Social\|Facebook | Delayed | 0.05 | 1 | 1 | — |
| Paid Social\|Pinterest | Exponential | 0.4 | — | — | 3 |
| Paid Social\|TikTok | Delayed | 0.2 | 0 | 2 | — |
| Push\|null | Delayed | 0.01 | 0 | 1 | — |
| SEM\|Google Search | Delayed | 0.05 | 1 | 1 | — |
| SEM\|Google Performance Max | Delayed | 0.05 | 1 | 1 | — |
| SEM\|Microsoft Search | Exponential | 0.4 | — | — | 3 |
| Connected TV\|Media Agency | Exponential | 0.6 | — | — | 3 |
| Linear TV\|Media Agency | Delayed | 0.9 | 5 | 9 | — |
| Media Solutions\|Facebook | Delayed | 0.1 | 0 | 1 | — |

### 2.3 MF Submits — adstock ([config:54-332](mmm_model/mmm_mf_submits/config_param.yml#L54-L332))

All Delayed **except** SEM\|Google Performance Max (Exponential, decay 0.89, length 26).

| Channel\|Network | Type | Decay | Delay | Max Lag | Length |
|---|---|---|---|---|---|
| App\|Apple Search | Delayed | 0.0 | 0 | 1 | — |
| App\|Facebook | Delayed | 0.05 | 0 | 4 | — |
| App\|Google UAC | Delayed | 0.05 | 0 | 2 | — |
| App\|TikTok | Delayed | 0.05 | 0 | 2 | — |
| Audio\|Media Agency | Delayed | 0.0 | 0 | 1 | — |
| Audio\|Radio | Delayed | 0.05 | 1 | 3 | — |
| Display\|Media Agency | Delayed | 0.0 | 0 | 1 | — |
| Display\|Video Demand Gen | Delayed | 0.05 | 0 | 2 | — |
| Email\|Iterable | Delayed | 0.05 | 0 | 2 | — |
| Email\|Simon Data | Delayed | 0.0 | 0 | 1 | — |
| Email\|Sparkpost | Delayed | 0.05 | 0 | 2 | — |
| Media Solutions\|Facebook | Delayed | 0.8 | 4 | 7 | — |
| Native\|Media Agency | Delayed | 0.0 | 0 | 1 | — |
| OMP\|frhdp | Delayed | 0.8 | 4 | 7 | — |
| OMP\|fshdp | Delayed | 0.8 | 4 | 7 | — |
| OMP\|homepage | Delayed | 0.5 | 4 | 6 | — |
| OOH\|Media Agency | Delayed | 0.5 | 4 | 6 | — |
| Online Video\|Media Agency | Delayed | 0.8 | 4 | 7 | — |
| Owned Social\|Facebook | Delayed | 0.1 | 3 | 4 | — |
| Owned Social\|TikTok | Delayed | 0.1 | 0 | 1 | — |
| Owned Social\|YouTube | Delayed | 0.1 | 0 | 1 | — |
| Paid Social\|Facebook | Delayed | 0.1 | 1 | 2 | — |
| Paid Social\|Pinterest | Delayed | 0.1 | 0 | 1 | — |
| Paid Social\|TikTok | Delayed | 0.1 | 0 | 1 | — |
| Push\|null | Delayed | 0.0 | 0 | 1 | — |
| SEM\|Google Search | Delayed | 0.0 | 0 | 1 | — |
| SEM\|Microsoft Search | Delayed | 0.0 | 0 | 1 | — |
| Connected TV\|Media Agency | Delayed | 0.5 | 4 | 6 | — |
| Linear TV\|Media Agency | Delayed | 0.5 | 1 | 6 | — |
| Operational Emails\|Iterable_Simon Data | Delayed | 0.0 | 3 | 4 | — |
| SEM\|Google Performance Max | Exponential | 0.89 | — | — | 26 |

### 2.4 Rental Visits — adstock ([config:58-282](mmm_model/mmm_rental_visits/config_param.yml#L58-L282))

All Delayed **except** SEM\|Google Performance Max (Exponential, decay 0.84, length 13).

| Channel\|Network | Type | Decay | Delay | Max Lag | Length |
|---|---|---|---|---|---|
| App\|Apple Search | Delayed | 0.05 | 0 | 2 | — |
| App\|Facebook | Delayed | 0.0 | 0 | 1 | — |
| App\|Google UAC | Delayed | 0.05 | 0 | 4 | — |
| Audio\|Media Agency | Delayed | 0.0 | 0 | 1 | — |
| Audio\|Radio | Delayed | 0.0 | 0 | 1 | — |
| Display\|Media Agency | Delayed | 0.0 | 0 | 1 | — |
| Display\|Video Demand Gen | Delayed | 0.0 | 0 | 1 | — |
| Email\|Iterable | Delayed | 0.0 | 0 | 1 | — |
| Email\|Simon Data | Delayed | 0.05 | 0 | 3 | — |
| Media Solutions\|Facebook | Delayed | 0.5 | 4 | 6 | — |
| Native\|Media Agency | Delayed | 0.0 | 2 | 3 | — |
| OOH\|Media Agency | Delayed | 0.8 | 4 | 7 | — |
| Online Video\|Media Agency | Delayed | 0.8 | 4 | 7 | — |
| Owned Social\|Facebook | Delayed | 0.1 | 0 | 1 | — |
| Owned Social\|TikTok | Delayed | 0.1 | 0 | 1 | — |
| Paid Social\|Facebook | Delayed | 0.2 | 0 | 2 | — |
| Paid Social\|Pinterest | Delayed | 0.2 | 0 | 2 | — |
| Paid Social\|TikTok | Delayed | 0.1 | 0 | 1 | — |
| Push\|null | Delayed | 0.0 | 0 | 1 | — |
| SEM\|Google Search | Delayed | 0.05 | 0 | 4 | — |
| SEM\|Microsoft Search | Delayed | 0.0 | 1 | 2 | — |
| Connected TV\|Media Agency | Delayed | 0.8 | 4 | 7 | — |
| Linear TV\|Media Agency | Delayed | 0.8 | 4 | 7 | — |
| Operational Emails\|Iterable_Simon Data | Delayed | 0.0 | 0 | 1 | — |
| SEM\|Google Performance Max | Exponential | 0.84 | — | — | 13 |

### 2.5 ZHL Submits — adstock (main set, all Delayed) ([config:1-244](mmm_model/mmm_zhl_submits/config_param.yml#L1-L244))

> ZHL also carries a parallel `adstock_hill_best_params_omp` set ([config:711-945](mmm_model/mmm_zhl_submits/config_param.yml#L711-L945)) for the OMP (organic-page) sub-model — same channels, slightly different lags.

| Channel\|Network | Type | Decay | Delay | Max Lag |
|---|---|---|---|---|
| App\|Apple Search | Delayed | 0.05 | 0 | 3 |
| App\|Facebook | Delayed | 0 | 0 | 1 |
| App\|Google UAC | Delayed | 0.05 | 0 | 4 |
| Audio\|Media Agency | Delayed | 0.8 | 4 | 7 |
| Audio\|Radio | Delayed | 0.8 | 4 | 7 |
| Display\|Media Agency | Delayed | 0.05 | 0 | 3 |
| Display\|Video Demand Gen | Delayed | 0.05 | 0 | 4 |
| Online Video\|YouTube | Delayed | 0.05 | 0 | 4 |
| Email\|Simon Data | Delayed | 0.05 | 0 | 4 |
| Email\|Sparkpost | Delayed | 0.05 | 0 | 4 |
| Native\|Media Agency | Delayed | 0.2 | 0 | 2 |
| OOH\|Media Agency | Delayed | 0.1 | 1 | 2 |
| OMP\|OMP | Delayed | 0.05 | 0 | 4 |
| Online Video\|Media Agency | Delayed | 0.5 | 4 | 6 |
| Operational Emails\|Iterable_Simon Data | Delayed | 0.05 | 0 | 4 |
| Owned Social\|Facebook | Delayed | 0.2 | 0 | 2 |
| Owned Social\|TikTok | Delayed | 0.2 | 0 | 2 |
| Paid Social\|Facebook | Delayed | 0.05 | 0 | 4 |
| Paid Social\|Pinterest | Delayed | 0.05 | 0 | 4 |
| Paid Social\|TikTok | Delayed | 0.05 | 0 | 4 |
| SEM\|Google Performance Max | Delayed | 0.05 | 0 | 4 |
| Push\|null | Delayed | 0.05 | 0 | 4 |
| SEM\|Google Search | Delayed | 0.05 | 0 | 4 |
| SEM\|Microsoft Search | Delayed | 0.05 | 0 | 2 |
| Connected TV\|Media Agency | Delayed | 0.8 | 4 | 7 |
| Linear TV\|Media Agency | Delayed | 0.8 | 4 | 7 |
| Media Solutions\|Facebook | Delayed | 0.1 | 0 | 1 |

### 2.6 Cross-KPI adstock summary (computed from the tables above)

| Observation | Value |
|---|---|
| Dominant adstock type | **Delayed** (the default for almost every channel in every KPI) |
| Geometric used only in | **Visits**: Native\|Media Agency (max_lag 4), Online Video\|Media Agency (max_lag 5) |
| Exponential used in | Visits (Email\|Iterable/Simon/Sparkpost, Operational Emails, Paid Social Pinterest/TikTok), FS (Audio, Online Video\|YouTube, Email×3, Native, Owned Social ×2, Paid Social Pinterest, SEM Microsoft, Connected TV), MF & Rental (only SEM\|Google Performance Max) |
| Largest lag overall | **max_lag = 9** — SEM\|Google Performance Max (Visits, delay 5) and Linear TV (FS, delay 5) |
| Largest Exponential length | **length = 26** — SEM\|Google Performance Max (MF Submits) |
| Smallest lag | **max_lag = 1 / length = 0** (e.g. Email\|Simon Data in Visits: decay 0, length 0 = effectively no carryover) |
| Most common decay values | **0.05** and **0.0** (MF/Rental/ZHL lean heavily on 0.05; Visits/FS use a wider 0.03–0.9 spread) |
| Highest decay (longest carryover) | **0.9** — Audio\|Radio & SEM\|GPMax (Visits), Linear TV (FS); **0.89/0.84** GPMax (MF/Rental) |
| Channels with delay > 0 (delayed-peak) | TV (Connected/Linear), Online Video\|Media Agency, OOH, Media Solutions, Display Video Demand Gen, SEM\|GPMax, App\|Apple Search (FS), Audio\|Radio (Visits) |

---

## SECTION 3 — Hill Parameter Inventory

Hill is applied as the final saturation step. Code:
`HillTransform.Hill(X) = 1 / (1 + (X / saturation)^(−slope))` — [FeatureEngineering.py:399-401](rapidmmm-main/rapidmmm/FeatureEngineering/FeatureEngineering.py#L399-L401), instantiated as
`HillTransform(slope=slope_value, saturation=shape_value)` ([1_…feature_engineering.py:896-904](mmm_model/mmm_fs_submits/1_mmm_fs_submits_feature_engineering.py#L896-L904)).

So the mapping is: **config `slope` → Hill steepness (Hill coefficient)**, **config `shape` → Hill `saturation` = half-saturation point** (the mean-scaled impression level at which the channel reaches 50% of its maximum transformed response). Because impressions are mean-scaled (≈1.0 at an average week) before Hill, a `shape < 1` saturates *before* average weekly volume (fast), `shape > 1` saturates *after* (slow).

### 3.1 Visits — Hill ([config:1-245](mmm_model/mmm_visits/config_param.yml#L1-L245))

| Channel\|Network | Shape (half-sat) | Slope |
|---|---|---|
| App\|Apple Search | 0.825 | 2.251 |
| App\|Facebook | 0.82 | 2.366 |
| App\|Google UAC | 0.809 | 2.261 |
| App\|TikTok | 0.8 | 2.412 |
| Audio\|Media Agency | 0.815 | 2.265 |
| Audio\|Radio | 0.82 | 2.39 |
| Display\|Media Agency | 0.809 | 2.372 |
| Display\|Video Demand Gen | 0.756 | 2.332 |
| Online Video\|YouTube | 0.794 | 2.297 |
| Email\|Iterable | 0.774 | 2.276 |
| Email\|Simon Data | 0.78 | 2.355 |
| Email\|Sparkpost | 0.801 | 2.237 |
| Native\|Media Agency | 0.768 | 2.295 |
| OOH\|Media Agency | 0.84 | 2.197 |
| Online Video\|Media Agency | 0.768 | 2.253 |
| Operational Emails\|Iterable_Simon Data | 0.766 | 2.331 |
| Owned Social\|Facebook | 0.806 | 2.312 |
| Owned Social\|TikTok | 0.825 | 2.264 |
| Paid Social\|Facebook | 0.757 | 2.196 |
| Paid Social\|Pinterest | 0.78 | 2.243 |
| Paid Social\|TikTok | 0.824 | 2.291 |
| Push\|null | 0.886 | 2.336 |
| SEM\|Google Search | 0.769 | 2.401 |
| SEM\|Google Performance Max | 0.796 | 2.301 |
| SEM\|Microsoft Search | 0.792 | 2.279 |
| Connected TV\|Media Agency | 0.754 | 1.809 |
| Linear TV\|Media Agency | 0.812 | 2.327 |
| Media Solutions\|Facebook | 0.806 | 2.302 |

### 3.2 FS Submits — Hill ([config:118-349](mmm_model/mmm_fs_submits/config_param.yml#L118-L349))

| Channel\|Network | Shape (half-sat) | Slope |
|---|---|---|
| App\|Apple Search | 0.042 | 1.477 |
| App\|Facebook | 1.773 | 2.375 |
| App\|Google UAC | 0.959 | 5.282 |
| App\|TikTok | 1.308 | 3.87 |
| Audio\|Media Agency | 1.326 | 2.153 |
| Audio\|Radio | 0.923 | 3.847 |
| Display\|Media Agency | 1.063 | 2.44 |
| Display\|Video Demand Gen | 0.197 | 2.575 |
| Online Video\|YouTube | 0.351 | 2.592 |
| Email\|Iterable | 0.582 | 5.469 |
| Email\|Simon Data | 0.272 | 3.336 |
| Email\|Sparkpost | 1.671 | 2.064 |
| Native\|Media Agency | 0.675 | 0.625 |
| Online Video\|Media Agency | 1.01 | 4.517 |
| Operational Emails\|Iterable_Simon Data | 1.782 | 2.508 |
| Owned Social\|Facebook | 1.464 | 0.648 |
| Owned Social\|TikTok | 1.449 | 2.685 |
| Paid Social\|Facebook | 1.159 | 3.245 |
| Paid Social\|Pinterest | 1.378 | 1.835 |
| Paid Social\|TikTok | 1.169 | 2.115 |
| Push\|null | 1.049 | 3.599 |
| SEM\|Google Search | 1.075 | 3.046 |
| SEM\|Google Performance Max | 1.075 | 3.046 |
| SEM\|Microsoft Search | 1.612 | 0.879 |
| Connected TV\|Media Agency | 0.312 | 1.227 |
| Linear TV\|Media Agency | 0.009 | 0.371 |
| Media Solutions\|Facebook | 1.514 | 1.131 |

### 3.3 MF Submits — Hill ([config:54-332](mmm_model/mmm_mf_submits/config_param.yml#L54-L332))

| Channel\|Network | Shape | Slope |
|---|---|---|
| App\|Apple Search | 0.388 | 1.561 |
| App\|Facebook | 0.404 | 1.568 |
| App\|Google UAC | 0.401 | 1.515 |
| App\|TikTok | 0.396 | 1.611 |
| Audio\|Media Agency | 0.397 | 1.461 |
| Audio\|Radio | 0.405 | 1.567 |
| Display\|Media Agency | 0.389 | 1.568 |
| Display\|Video Demand Gen | 0.409 | 1.496 |
| Email\|Iterable | 0.4 | 1.535 |
| Email\|Simon Data | 0.415 | 1.448 |
| Email\|Sparkpost | 0.411 | 1.572 |
| Media Solutions\|Facebook | 0.391 | 1.484 |
| Native\|Media Agency | 0.418 | 1.535 |
| OMP\|frhdp | 0.423 | 1.563 |
| OMP\|fshdp | 0.424 | 1.576 |
| OMP\|homepage | 0.368 | 1.352 |
| OOH\|Media Agency | 0.437 | 1.437 |
| Online Video\|Media Agency | 0.421 | 1.569 |
| Owned Social\|Facebook | 0.387 | 1.434 |
| Owned Social\|TikTok | 0.375 | 1.605 |
| Owned Social\|YouTube | 0.406 | 1.542 |
| Paid Social\|Facebook | 0.372 | 1.517 |
| Paid Social\|Pinterest | 0.416 | 1.521 |
| Paid Social\|TikTok | 0.409 | 1.44 |
| Push\|null | 0.438 | 1.539 |
| SEM\|Google Search | 0.392 | 1.492 |
| SEM\|Microsoft Search | 0.383 | 1.456 |
| Connected TV\|Media Agency | 0.402 | 1.243 |
| Linear TV\|Media Agency | 0.402 | 1.429 |
| Operational Emails\|Iterable_Simon Data | 0.406 | 1.568 |
| SEM\|Google Performance Max | 0.394 | 1.52 |

### 3.4 Rental Visits — Hill ([config:58-282](mmm_model/mmm_rental_visits/config_param.yml#L58-L282))

| Channel\|Network | Shape | Slope |
|---|---|---|
| App\|Apple Search | 0.407 | 1.517 |
| App\|Facebook | 0.398 | 1.626 |
| App\|Google UAC | 0.408 | 1.389 |
| Audio\|Media Agency | 0.414 | 1.408 |
| Audio\|Radio | 0.428 | 1.566 |
| Display\|Media Agency | 0.405 | 1.479 |
| Display\|Video Demand Gen | 0.416 | 1.214 |
| Email\|Iterable | 0.391 | 1.556 |
| Email\|Simon Data | 0.406 | 1.503 |
| Media Solutions\|Facebook | 0.414 | 1.524 |
| Native\|Media Agency | 0.406 | 1.548 |
| OOH\|Media Agency | 0.411 | 1.453 |
| Online Video\|Media Agency | 0.398 | 1.577 |
| Owned Social\|Facebook | 0.401 | 1.545 |
| Owned Social\|TikTok | 0.412 | 1.427 |
| Paid Social\|Facebook | 0.39 | 1.612 |
| Paid Social\|Pinterest | 0.395 | 1.477 |
| Paid Social\|TikTok | 0.398 | 1.527 |
| Push\|null | 0.415 | 1.536 |
| SEM\|Google Search | 0.405 | 1.469 |
| SEM\|Microsoft Search | 0.387 | 1.612 |
| Connected TV\|Media Agency | 0.394 | 1.401 |
| Linear TV\|Media Agency | 0.4 | 1.41 |
| Operational Emails\|Iterable_Simon Data | 0.411 | 1.457 |
| SEM\|Google Performance Max | 0.414 | 1.479 |

### 3.5 ZHL Submits — Hill (main set) ([config:1-244](mmm_model/mmm_zhl_submits/config_param.yml#L1-L244))

| Channel\|Network | Shape | Slope |
|---|---|---|
| App\|Apple Search | 0.762 | 2.315 |
| App\|Facebook | 0.921 | 2.01 |
| App\|Google UAC | 0.919 | 2.145 |
| Audio\|Media Agency | 0.88 | 2.475 |
| Audio\|Radio | 0.77 | 2.514 |
| Display\|Media Agency | 0.782 | 1.355 |
| Display\|Video Demand Gen | 1.036 | 2.102 |
| Online Video\|YouTube | 0.812 | 1.249 |
| Email\|Simon Data | 0.786 | 2.49 |
| Email\|Sparkpost | 0.789 | 1.405 |
| Native\|Media Agency | 0.745 | 2.287 |
| OOH\|Media Agency | 0.779 | 2.77 |
| OMP\|OMP | 0.744 | 2.248 |
| Online Video\|Media Agency | 0.684 | 2.258 |
| Operational Emails\|Iterable_Simon Data | 0.752 | 2.444 |
| Owned Social\|Facebook | 0.894 | 2.015 |
| Owned Social\|TikTok | 0.77 | 2.231 |
| Paid Social\|Facebook | 0.818 | 2.674 |
| Paid Social\|Pinterest | 0.757 | 1.992 |
| Paid Social\|TikTok | 0.956 | 2.302 |
| SEM\|Google Performance Max | 0.81 | 1.149 |
| Push\|null | 0.835 | 2.087 |
| SEM\|Google Search | 0.762 | 2.357 |
| SEM\|Microsoft Search | 0.765 | 2.482 |
| Connected TV\|Media Agency | 0.942 | 2.05 |
| Linear TV\|Media Agency | 0.694 | 2.605 |
| Media Solutions\|Facebook | 1.514 | 1.131 |

### 3.6 Hill summary (computed from tables; lower shape = faster saturation)

| KPI | Fastest-saturating (smallest shape) | Slowest-saturating (largest shape) | Steepest curve (max slope) | Gentlest curve (min slope) |
|---|---|---|---|---|
| Visits | Connected TV 0.754 | Push 0.886 | App\|TikTok 2.412 | Connected TV 1.809 |
| FS Submits | **Linear TV 0.009**, App\|Apple Search 0.042 | Operational Emails 1.782, App\|Facebook 1.773 | Email\|Iterable 5.469, App\|Google UAC 5.282 | Linear TV 0.371, Native 0.625 |
| MF Submits | OMP\|homepage 0.368 | OOH 0.437 | App\|TikTok / Email Sparkpost 1.61 | Connected TV 1.243 |
| Rental Visits | SEM\|Microsoft 0.387 | Audio\|Radio 0.428 | App\|Facebook / SEM\|Microsoft 1.612 | Display\|VDG 1.214 |
| ZHL Submits | Online Video\|Media Agency 0.684 | Media Solutions 1.514 | OOH 2.77 | SEM\|GPMax 1.149 |

**Business reading.** Visits/ZHL shapes cluster ~0.75–0.95 (channels reach half-effect near average weekly volume — moderate headroom). MF/Rental shapes cluster ~0.4 (saturate well *below* average weekly volume — little incremental headroom; these KPIs are highly saturated). FS Submits has the widest spread: Linear TV (0.009) is essentially always at max effect, while Operational Emails/App-Facebook (~1.78) keep responding past average volume.

---

## SECTION 4 — Other Transformations (SoV / Atan / Sigmoid)

Order of operations (from [1_…feature_engineering.py](mmm_model/mmm_fs_submits/1_mmm_fs_submits_feature_engineering.py)):
Adstock (line 382) → Mean Scaling (line 645) → **SoV** (line 567) → **Atan** (line 704) → **Sigmoid** (line 787) → **Hill** (line 904).
The column names below already include the adstock suffix because these transforms run *after* adstock.

### 4.1 Sigmoid channels — NONE

`transform_cols_sigmoid: null` in all five KPIs ([fs:25](mmm_model/mmm_fs_submits/config_param.yml#L25), [visits:297](mmm_model/mmm_visits/config_param.yml#L297), [mf:17](mmm_model/mmm_mf_submits/config_param.yml#L17), [rental:21](mmm_model/mmm_rental_visits/config_param.yml#L21), [zhl:642](mmm_model/mmm_zhl_submits/config_param.yml#L642)). `SigmoidTransform` (`1/(1+e^{-x})`) is implemented but unused in production.

### 4.2 Atan channels (`transform_cols_atan`)

Applied via `AtanTransform.arctan` (`math.atan(x)`) — [FeatureEngineering.py:462-502](rapidmmm-main/rapidmmm/FeatureEngineering/FeatureEngineering.py#L462-L502).

| KPI | Atan-transformed columns (post-adstock names) |
|---|---|
| Visits (8) | App\|Google UAC, Display\|Media Agency, Native\|Media Agency (geometric), Paid Social\|Facebook, Paid Social\|TikTok, App\|Apple Search, Display\|Video Demand Gen, Online Video\|Media Agency (geometric) — [config:288-296](mmm_model/mmm_visits/config_param.yml#L288-L296) |
| FS Submits (8) | App\|Google UAC, Online Video\|Media Agency, Native\|Media Agency, Paid Social\|Facebook, Owned Social\|TikTok, Email\|Sparkpost, Email\|Simon Data, SEM\|Google Search — [config:16-24](mmm_model/mmm_fs_submits/config_param.yml#L16-L24) |
| MF Submits (2) | Paid Social\|TikTok, SEM\|Google Search — [config:14-16](mmm_model/mmm_mf_submits/config_param.yml#L14-L16) |
| Rental Visits (4) | Display\|Media Agency, Owned Social\|TikTok, SEM\|Google Search, Paid Social\|Facebook — [config:16-20](mmm_model/mmm_rental_visits/config_param.yml#L16-L20) |
| ZHL Submits (11, +11 OMP) | App\|Google UAC, Display\|Media Agency, Online Video\|Media Agency, Native\|Media Agency, Online Video\|YouTube, Paid Social\|Facebook, Paid Social\|TikTok, Owned Social\|TikTok, Email\|Sparkpost, Email\|Simon Data, SEM\|Google Search — [config:618-641](mmm_model/mmm_zhl_submits/config_param.yml#L618-L641) (plus `transform_cols_atan_omp`) |

### 4.3 SoV (Share-of-Voice) channels (`sov_cols`)

SoV-scaled columns (a market-share style scaling applied at [1_…:567-568](mmm_model/mmm_fs_submits/1_mmm_fs_submits_feature_engineering.py#L567-L568)).

| KPI | SoV columns |
|---|---|
| Visits (1) | Paid Social\|Pinterest_exponential_decay_0.5_length_2 — [config:246-247](mmm_model/mmm_visits/config_param.yml#L246-L247) |
| FS Submits (3 overall + 5 taxonomy) | overall: Paid Social\|Pinterest, Paid Social\|TikTok, Display\|Media Agency — [config:351-360](mmm_model/mmm_fs_submits/config_param.yml#L351-L360) |
| MF Submits (4) | Native\|Media Agency, Paid Social\|TikTok, Online Video\|Media Agency, Paid Social\|Pinterest — [config:333-337](mmm_model/mmm_mf_submits/config_param.yml#L333-L337) |
| Rental Visits (4) | Native\|Media Agency, Paid Social\|TikTok, Online Video\|Media Agency, Paid Social\|Pinterest — [config:295-299](mmm_model/mmm_rental_visits/config_param.yml#L295-L299) |
| ZHL Submits | none (`sov_cols` not present) |

> Note: Visits also defines `region_max_cols` ([config:248-250](mmm_model/mmm_visits/config_param.yml#L248-L250)) — a separate region-max scaling for SEM\|GPMax and Paid Social\|TikTok.

---

## SECTION 5 — Prior Inventory

Priors are read from `artifacts/mmm_<kpi>_priors.csv` and passed as `Model(priors=…)`
([2_…overall_model.py:337-345, 445](mmm_model/mmm_fs_submits/2_mmm_fs_submits_overall_model.py#L337-L345)).

**Critical implementation fact:** in [BayesianModel._prepare_priors](rapidmmm-main/rapidmmm/Model/BayesianModel.py#L90-L118) a prior row is only used when the column name contains `"impressions|"`. Holiday / seasonal / macro / date-flag rows that appear in some CSVs (e.g. the Visits CSV) are **ignored by the model** and fall back to the default `Normal(mean=0, sd=1)`. Optional third column `Sigma_Sd` (→ `σ_β` HalfNormal scale) is absent from every committed CSV, so `Sigma_Sd` defaults to `1.0`.

### 5.1 Visits priors (media rows; non-media rows are vestigial) ([CSV](mmm_model/mmm_visits/artifacts/mmm_visits_priors.csv))

| Media variable | Mean | Sd |
|---|---|---|
| App\|Apple Search | 0.0005 | 0.0001 |
| App\|Facebook | 0 | 0.0001 |
| App\|Google UAC | 0 | 0.0001 |
| Audio\|Media Agency | 0.0002 | 0.0001 |
| Audio\|Radio | **0.8** | 0.0001 |
| Display\|Media Agency | 0.00001 | 0.0001 |
| Display\|Video Demand Gen | 0.00001 | 0.0001 |
| Online Video\|YouTube | 0.2 | 0.0001 |
| Email\|Iterable | 0.01547 | 0.0001 |
| Email\|Simon Data | 0 | 0.0001 |
| Email\|Sparkpost | 0.00925 | 0.0001 |
| Native\|Media Agency | 0 | 0.0001 |
| OOH\|Media Agency | 0.00004 | 0.0001 |
| Online Video\|Media Agency | 0.05213 | 0.0001 |
| Operational Emails\|Iterable_Simon Data | 0 | 0.0001 |
| Owned Social\|Facebook | 0.00162 | 0.0001 |
| Owned Social\|TikTok | 0 | 0.0001 |
| Paid Social\|Facebook | 0.02 | 0.0001 |
| Paid Social\|Pinterest | **2.000** | 0.001 |
| Paid Social\|TikTok | 0.125 | 0.0001 |
| Push\|null | 0.04865 | 0.0001 |
| SEM\|Google Search | 0.1 | 0.0001 |
| SEM\|Google Performance Max | 0.020 | 0.001 |
| SEM\|Microsoft Search | 0.00724 | 0.0001 |
| Connected TV\|Media Agency | 0.03046 | 0.0001 |
| Linear TV\|Media Agency | 0.128 | 0.0001 |
| Media Solutions\|Facebook | 0.13377 | 0.0001 |

### 5.2 FS Submits priors ([CSV](mmm_model/mmm_fs_submits/artifacts/mmm_fs_submits_priors.csv))

| Media variable | Mean | Sd |
|---|---|---|
| App\|Apple Search | 0.02336 | 0.02136 |
| App\|Facebook | 0.04545 | 0.0367 |
| Display\|Media Agency | 0.05167 | 0.07274 |
| Display\|Video Demand Gen | 0.02861 | 0.02643 |
| Email\|Iterable | 0 | 1.0 |
| Email\|Simon Data | 0 | 1.0 |
| Email\|Sparkpost | 0 | 1.0 |
| Native\|Media Agency | 0.05389 | 0.02621 |
| Online Video\|Media Agency | 0.05384 | 0.04816 |
| Operational Emails\|Iterable_Simon Data | 0 | 1.0 |
| Owned Social\|Facebook | 0.00656 | 0.00134 |
| Owned Social\|TikTok | 0 | 1.0 |
| Paid Social\|Facebook | **5.0** | 0.02004 |
| Paid Social\|Pinterest | **10.0** | 0.01377 |
| Paid Social\|TikTok | 0.2 | 0.001 |
| Push\|null | 0 | 1.0 |
| SEM\|Google Search | 0.15917 | 0.0001 |
| SEM\|Google Performance Max | 0.003 | 0.0001 |
| Connected TV\|Media Agency | 0.01649 | 1e-05 |
| Linear TV\|Media Agency | 0.0202 | 1e-05 |
| Media Solutions\|Facebook | 0.27837 | 0.16888 |
| Online Video\|YouTube | 0.2 | 0.0001 |

### 5.3 MF Submits priors ([CSV](mmm_model/mmm_mf_submits/artifacts/mmm_mf_submits_priors.csv))

| Media variable | Mean | Sd |
|---|---|---|
| Display\|Video Demand Gen | 0.0093 | 0.0099 |
| Email\|Simon Data | 0.05 | 0.001 |
| OOH\|Media Agency | 0.0805 | 0.0915 |
| Operational Emails\|Iterable_Simon Data | 0.005 | 0.005 |
| Owned Social\|Facebook | 0.007 | 0.0001 |
| Owned Social\|TikTok | 0.002 | 0.0005 |
| Paid Social\|Pinterest | 0.0001 | 0.0001 |
| Paid Social\|TikTok | 0.0001 | 0.0001 |
| Push\|null | 0.2476 | 0.1045 |
| SEM\|Google Search | 0.2 | 0.01 |
| SEM\|Microsoft Search | 0.1379 | 0.0828 |
| Connected TV\|Media Agency | 0.017 | 0.0005 |
| Linear TV\|Media Agency | 0.0019 | 0.0012 |
| Native\|Media Agency | **0.57** | 0.0001 |
| Online Video\|Media Agency | 0.47 | 0.005 |
| Display\|Media Agency | 0.5 | 0.05 |
| Paid Social\|Facebook | 0.75 | 0.02 |
| SEM\|Google Performance Max | 0.005 | 0.001 |

### 5.4 Rental Visits priors ([CSV](mmm_model/mmm_rental_visits/artifacts/mmm_rental_visits_priors.csv))

| Media variable | Mean | Sd |
|---|---|---|
| App\|Apple Search | 0.001 | 0.0001 |
| App\|Facebook | 0.00112 | 0.0001 |
| App\|Google UAC | 0.0 | 0.05 |
| Audio\|Media Agency | 0.0 | 0.05 |
| Audio\|Radio | 0.02627 | 0.01008 |
| Display\|Media Agency | 0.00732 | 0.00107 |
| Display\|Video Demand Gen | 0.00414 | 0.00035 |
| Email\|Simon Data | 0.14244 | 0.11176 |
| Media Solutions\|Facebook | 0.05239 | 0.0001 |
| Native\|Media Agency | **0.21986** | 0.0001 |
| OOH\|Media Agency | 0.0 | 0.05 |
| Online Video\|Media Agency | 0.002 | 0.0001 |
| Operational Emails\|Iterable_Simon Data | 0.0 | 0.05 |
| Owned Social\|Facebook | 0.001 | 0.0001 |
| Owned Social\|TikTok | 0.001 | 0.0001 |
| Paid Social\|Facebook | 0.00975 | 0.0001 |
| Paid Social\|Pinterest | 0.01196 | 0.00033 |
| Paid Social\|TikTok | 0.4 | 0.0001 |
| Push\|null | 0.0 | 0.05 |
| SEM\|Google Search | 0.05055 | 0.0001 |
| SEM\|Microsoft Search | 0.001 | 0.05 |
| Connected TV\|Media Agency | 0.01 | 0.0001 |
| Linear TV\|Media Agency | 0.001 | 0.05 |
| SEM\|Google Performance Max | 0.005 | 0.001 |

### 5.5 ZHL Submits priors — **NOT PRESENT**

There is **no** `mmm_zhl_submits_priors.csv` in the repo and **no** `2_overall_model` notebook for ZHL. ZHL is built taxonomy-first (`4_…taxonomy_model`, `5_…omp_imps_taxonomy_model`); its prior handling is therefore outside the committed artifacts (see Section 13).

### 5.6 Prior summary & interpretation

| Observation | Detail |
|---|---|
| Strongest "pinned" beliefs | **FS: Paid Social\|Pinterest Mean=10, Paid Social\|Facebook Mean=5** with Sd≈0.01–0.02 → coefficient effectively *fixed*. **Visits: Paid Social\|Pinterest Mean=2 (Sd 0.001), Audio\|Radio Mean=0.8 (Sd 0.0001)**. These are hard-anchored channels (consistent with AOT recalibration / experiment-derived truth). |
| Tightest Sd (near-deterministic) | **1e-05** (FS Connected TV & Linear TV); **0.0001** is the modal Sd across Visits & several Rental rows |
| Weakest / most diffuse beliefs | **Sd = 1.0** (FS: all Email channels, Operational Emails, Owned Social\|TikTok, Push — Mean 0) → essentially "let the data decide, but stay ≥ 0" |
| Largest Sd | 1.0 (FS Email/Push group) |
| Smallest Sd | 1e-05 (FS Connected/Linear TV) |
| Mechanism | All media priors are applied as `TruncatedNormal(Mean, Sd, low=0)` so even a Mean=0 prior cannot produce a negative coefficient. A tiny Sd ⇒ the posterior coefficient is forced to ≈ Mean regardless of data. |

---

## SECTION 6 — Bayesian Model Implementation (code-exact)

Source: [BayesianModel.py](rapidmmm-main/rapidmmm/Model/BayesianModel.py) (`class Model`, NumPyro). Engine: `jax` with `jax_enable_x64=False` (float32) ([line 16](rapidmmm-main/rapidmmm/Model/BayesianModel.py#L16)).

**Likelihood** ([line 225-226](rapidmmm-main/rapidmmm/Model/BayesianModel.py#L225-L226)):
```
σ      ~ HalfNormal(5.0)
obs    ~ Normal(y_hat, σ)         # Gaussian likelihood on the (mean-scaled) KPI
```

**Linear predictor** ([line 218-223](rapidmmm-main/rapidmmm/Model/BayesianModel.py#L218-L223)):
```
y_hat[i] = Σ_k  B[dma_i, k] · X[i, k]   +   α[dma_i]
```

**Priors / hyperpriors** ([lines 177-216](rapidmmm-main/rapidmmm/Model/BayesianModel.py#L177-L216)):
```
# Intercept (Overall model only; Taxonomy ⇒ α = 0)
μ_α          ~ TruncatedNormal(0.0, 1.0, low=0)
σ_α          ~ HalfNormal(5.0)
α[d]         ~ TruncatedNormal(μ_α, σ_α, low=0)         for each DMA d   (expand n_dma)

# Global (population) coefficient means
mB_normal[k] ~ Normal(μ_k, sd_k)                        # non-media  (μ_k=0, sd_k=1 default)
mB_trunc[k]  ~ TruncatedNormal(μ_k, sd_k, low=0)        # media (μ_k, sd_k from priors CSV)

# Per-predictor pooling scale
σ_β[k]       ~ HalfNormal(Sigma_Sd_k)                   # Sigma_Sd defaults to 1.0

# DMA-level partial pooling (one draw per DMA per predictor)
B[d,k] ~ Normal(mB_normal[k], σ_β[k])                   # non-media
B[d,k] ~ TruncatedNormal(mB_trunc[k], σ_β[k], low=0)    # media
```

| Question | Implementation answer |
|---|---|
| Likelihood | Gaussian: `Normal(y_hat, σ)`, `σ ~ HalfNormal(5)` |
| Media coefficient constraint | `TruncatedNormal(..., low=0)` — **media betas are forced ≥ 0** (`nonnegative=True`; mask = column contains `"impressions\|"`) ([lines 92, 150-155, 208-216](rapidmmm-main/rapidmmm/Model/BayesianModel.py#L150-L155)) |
| Control/macro/holiday coefficient | `Normal` (unconstrained, can be negative) |
| Intercept treatment | Per-DMA `α[d] ~ TruncatedNormal(μ_α, σ_α, low=0)`; **only when `modeltype='Overall'`**. `modeltype='Taxonomy'` ⇒ `α = 0` (no intercept) ([lines 190-193, 252](rapidmmm-main/rapidmmm/Model/BayesianModel.py#L190-L193)) |
| Hierarchical structure / DMA pooling | Two-level: global mean `mB_*[k]` + per-DMA deviation governed by `σ_β[k]` ⇒ **partial pooling** across DMAs, per predictor |
| Funnel variable treatment | Funnel (upstream KPI) is **not** a model term inside NumPyro; it is handled post-hoc by `FunnelEffects` (Section 9). Inside the regression it is dropped from X (e.g. MF drops `value\|visits\|visits`) |
| What is learned | `α, μ_α, σ_α, σ, σ_β, mB_raw_normal, mB_raw_trunc, B_normal, B_trunc` |
| What is fixed | adstock params, Hill slope/shape, mean-scaling means, prior Mean/Sd, `Sigma_Sd=1` |
| Posterior export | `az.from_numpyro`; grouped params renamed to `B_<col>`, `mB_<col>`, `σ_β_<col>`, `α`, `μ_α`, `σ`, `σ_α` ([get_inference_data, lines 307-385](rapidmmm-main/rapidmmm/Model/BayesianModel.py#L307-L385)) |

---

## SECTION 7 — Sampling Settings (production values, identical across the 4 overall KPIs)

Source: `2_*_overall_model.py` for each KPI; thresholds from each `config_param.yml`.

| Setting | Value | Reference |
|---|---|---|
| Sampler | **NUTS** (NumPyro `MCMC(NUTS(model_fn))`) | [BayesianModel.py:268-269](rapidmmm-main/rapidmmm/Model/BayesianModel.py#L268-L269) |
| Warmup samples | **1000** | [2_…fs:448](mmm_model/mmm_fs_submits/2_mmm_fs_submits_overall_model.py#L448) (same in visits/mf/rental) |
| Posterior samples | **2000** | [2_…fs:447](mmm_model/mmm_fs_submits/2_mmm_fs_submits_overall_model.py#L447) |
| Chains | **1** (`num_chains=1`; multi-chain explicitly disabled in library) | [2_…fs:459](mmm_model/mmm_fs_submits/2_mmm_fs_submits_overall_model.py#L459); [BayesianModel.py:271-272](rapidmmm-main/rapidmmm/Model/BayesianModel.py#L271-L272) |
| RNG seed | `rng_seed=0` default | [BayesianModel.py:230](rapidmmm-main/rapidmmm/Model/BayesianModel.py#L230) |
| Extra fields tracked | `accept_prob`, `diverging` | [BayesianModel.py:293](rapidmmm-main/rapidmmm/Model/BayesianModel.py#L293) |
| **Acceptance gate** | mean `accept_prob` ∈ **[0.6, 1]** (`threshold_accept_prob`) | [config:56-58](mmm_model/mmm_fs_submits/config_param.yml#L56-L58); [2_…:402](mmm_model/mmm_fs_submits/2_mmm_fs_submits_overall_model.py#L402) |
| **Divergence gate** | divergences ≤ **300** (`= int(2000 × perc_divergence)`, `perc_divergence=0.15`) | [config:55](mmm_model/mmm_fs_submits/config_param.yml#L55); [2_…:366,410](mmm_model/mmm_fs_submits/2_mmm_fs_submits_overall_model.py#L366) |
| Retry policy | up to **3 attempts** (`max_retries=3`); `RuntimeError` if all fail | [2_…:377,386,453-459](mmm_model/mmm_fs_submits/2_mmm_fs_submits_overall_model.py#L377) |

**Diagnostics note (Rhat / ESS):** `az.summary(..., hdi_prob=0.95)` is used for coefficient summaries, which does emit `r_hat` and `ess`, but the **production pass/fail gate is `accept_prob` + divergence count only** — there is no Rhat/ESS threshold check in the notebooks, and with `num_chains=1` Rhat is split-Rhat.

**Stability check** — see Section 7A for the full logic.

---

## SECTION 7A — Model Stability Check (NB9, full logic, code-exact)

Source: `9_*_stability_loop.py` (e.g. [9_mmm_fs_submits_stability_loop.py](mmm_model/mmm_fs_submits/9_mmm_fs_submits_stability_loop.py)). This notebook does **not** retrain anything — it compares the **latest model version against the previous version** and labels each channel-network (Overall) and each `campaign_super × lob × channel × network` (Taxonomy) as `Stable` / `Unstable`, writing the verdicts to Delta tables. It runs **after** the model + response curves are produced.

**Thresholds (widgets):** `overlap_stability_percent = 50`, `point_estimate_percent = 25` ([lines 16-17, 26-27](mmm_model/mmm_fs_submits/9_mmm_fs_submits_stability_loop.py#L16-L27)).

### 7A.1 Version selection & aggregation

`MMMDataLoader._get_latest_versions` pulls the two newest versions by `CAST(SUBSTRING(version,2) AS INTEGER) DESC LIMIT 2` → `[v_latest, v_prev]` ([lines 62-85](mmm_model/mmm_fs_submits/9_mmm_fs_submits_stability_loop.py#L62-L85)). Source tables: `mmm_model_combined_output_overall_level` (Overall) and `mmm_model_combined_output_taxonomy_level` (Taxonomy).

Each version is aggregated to a **return** (a ROAS-like efficiency) and a **return interval** from the contribution HDI bands ([lines 101-127](mmm_model/mmm_fs_submits/9_mmm_fs_submits_stability_loop.py#L101-L127)):

```
return        = predicted / spend
return_lower  = (impressions == 0) ? 0 : predicted_2point5_pct_hdi  / impressions
return_higher = (pred_2.5%==0 and pred_97.5%==0) ? predicted          # fallback
                                                 : predicted_97point5_pct_hdi
                                                 ) / impressions
```
- Overall grouping key: `channel, network`.
- Taxonomy grouping key: `core_campaign_super, core_lob, channel, network` ([line 258](mmm_model/mmm_fs_submits/9_mmm_fs_submits_stability_loop.py#L258)).

### 7A.2 The two stability tests

Current and previous versions are merged on the grouping key, then scored ([`StabilityAnalyzerOverall.merge_and_score`, lines 133-166](mmm_model/mmm_fs_submits/9_mmm_fs_submits_stability_loop.py#L133-L166); taxonomy variant lines 283-319):

**Test 1 — Interval-overlap stability** (do the two versions' return-intervals overlap enough?):
```
overlap_min   = max(return_lower_curr,  return_lower_prev)
overlap_max   = min(return_higher_curr, return_higher_prev)
overlap_range = overlap_max − overlap_min
return_overlap (%) = overlap_range / (return_higher_curr − return_lower_curr) × 100
# overlap as a % of the CURRENT interval width
if overlap_range is NaN or ≤ 0:  return_overlap = −1

Overlap_stability = 'Stable'   if return_overlap > 50
                    'Unstable' if 0 ≤ return_overlap ≤ 50
                    'N/A'      otherwise (e.g. −1, no overlap)
```

**Test 2 — Point-estimate stability** (did the point ROAS move too much?):
```
return_stability_PE_perc = |(return_curr − return_prev) / return_prev| × 100
return_stability_PE      = 'Unstable' if return_stability_PE_perc > 25 else 'Stable'
```

**Final verdict** ([lines 159-162](mmm_model/mmm_fs_submits/9_mmm_fs_submits_stability_loop.py#L159-L162)):
```
Final_Stability = 'Stable' if ('Stable' ∈ [return_stability_PE, Overlap_stability])
                  else return_stability_PE
```
i.e. a channel is **Stable if EITHER test passes**; otherwise it inherits the (Unstable) point-estimate label. So the point-estimate test is the tie-breaker when the overlap test is `N/A`.

### 7A.3 Filtering, outputs, and notification

| Step | Detail | Ref |
|---|---|---|
| Channel filter | Only `App, Audio, Display, Paid Social, SEM, Connected TV, Linear TV, Owned Social` are reported, and rows with `return_stability_PE_perc` NaN are dropped | [line 206](mmm_model/mmm_fs_submits/9_mmm_fs_submits_stability_loop.py#L206), [354](mmm_model/mmm_fs_submits/9_mmm_fs_submits_stability_loop.py#L354) |
| Drop all-zero intervals | Rows where current & previous `return_lower`/`return_higher` are all 0 are removed | [lines 210-215](mmm_model/mmm_fs_submits/9_mmm_fs_submits_stability_loop.py#L210-L215) |
| Overall output table | `mmm_model_output_overall_level_stability` (overwrite by `business_kpi, version_curr, version_prev`) | [lines 236-237](mmm_model/mmm_fs_submits/9_mmm_fs_submits_stability_loop.py#L236-L237) |
| Taxonomy output table | `mmm_model_output_taxonomy_level_stability` | [lines 382-383](mmm_model/mmm_fs_submits/9_mmm_fs_submits_stability_loop.py#L382-L383) |
| Version stamping | `latest_version = v{max}`, `previous_version = v{max−1}` via regex on `version` | [lines 219-227](mmm_model/mmm_fs_submits/9_mmm_fs_submits_stability_loop.py#L219-L227) |
| Prod notification | On `environment == 'prod'`, posts a Slack success message for the version | [lines 387-388](mmm_model/mmm_fs_submits/9_mmm_fs_submits_stability_loop.py#L387-L388) |

**Interview one-liner:** *Stability is a version-over-version ROAS check, not a retrain.* Each channel's efficiency interval (`predicted/impressions` HDI) and point ROAS (`predicted/spend`) from the new run are compared to the prior run; a channel passes if its intervals still overlap by >50% **or** its point ROAS moved ≤25%, at both Overall and Taxonomy levels.

---

## SECTION 8 — Contribution Calculation (code-exact)

Source: `ModelDiagnostics.get_melted_data_for_business_diagnostics` — [ModelDiagnostics.py:256-339](rapidmmm-main/rapidmmm/PostProcessing/ModelDiagnostics.py#L256-L339).

**Coefficient used = posterior MEAN** (from `az.summary`, plus the 2.5%/97.5% HDI for bands) — [ModelDiagnostics.py:73-77, 265-268](rapidmmm-main/rapidmmm/PostProcessing/ModelDiagnostics.py#L73-L77). The final persisted contributions use the **posterior mean (point estimate)**, *not* the median and *not* the full draws. (Full draws exist in `model.posterior_samples` but are only used by `generate_predictions` for `pred`.)

**Media / control contribution (Overall model)** ([line 278-280](rapidmmm-main/rapidmmm/PostProcessing/ModelDiagnostics.py#L278-L280)):
```
predicted_initial = coefficient × value × y_col_mean
```
- `coefficient` = posterior-mean β for that predictor & DMA
- `value` = the transformed, mean-scaled feature value (adstock→scale→…→Hill output)
- `y_col_mean` = the DMA's mean of the KPI (un-does the mean-scaling of y)
- HDI bands: `predicted_2.5%_hdi = coef_hdi_2.5% × value × y_col_mean` (and 97.5%) ([lines 281-286](rapidmmm-main/rapidmmm/PostProcessing/ModelDiagnostics.py#L281-L286))

**Baseline contribution** = the intercept term `α`: the code sets `data["α"] = 1` and melts it as a predictor ([line 269-275](rapidmmm-main/rapidmmm/PostProcessing/ModelDiagnostics.py#L269-L275)), so
```
baseline = coefficient(α) × 1 × y_col_mean
```
`α` only exists for `modeltype='Overall'`; for Taxonomy the intercept row is removed ([line 295](rapidmmm-main/rapidmmm/PostProcessing/ModelDiagnostics.py#L295)).

**Residual** is not a stored coefficient — it is the gap between actual KPI and the sum of contributions (`model_dv` vs `predicted`), surfaced via Actual-vs-Predicted and residual plots ([ModelDiagnostics.py:205-254](rapidmmm-main/rapidmmm/PostProcessing/ModelDiagnostics.py#L205-L254)).

**Taxonomy normalization (sum-to-actual)** ([lines 294-331](rapidmmm-main/rapidmmm/PostProcessing/ModelDiagnostics.py#L294-L331)):
```
pred_ratio  = predicted_initial / pred_sum            # pred_sum = Σ over predictors in (dma, week)
predicted   = y_col_mean × pred_ratio × actual_KPI    # forces Σ contributions = actual KPI
```
plus an error-correction pass for `(dma, week)` cells where `predicted < y_col_mean × actual_KPI`, redistributing by feature `value` share ([lines 314-327](rapidmmm-main/rapidmmm/PostProcessing/ModelDiagnostics.py#L314-L327)).

`channel` is derived from the column name by stripping `B_impressions|` and the adstock suffix ([lines 336-337](rapidmmm-main/rapidmmm/PostProcessing/ModelDiagnostics.py#L336-L337)).

---

## SECTION 9 — Funnel Implementation (code-exact)

Source: [FunnelEffects.funnel_effects](rapidmmm-main/rapidmmm/Utils/FunnelEffects.py#L6-L77); wired in NB2 e.g. [2_…fs:976-978](mmm_model/mmm_fs_submits/2_mmm_fs_submits_overall_model.py#L976-L978).
`nodes = [node1_var, node2_var]`, `nodes_data = {'node1_data': <upstream melted>, 'node2_data': <this-KPI melted>}`.

**Funnel chain (who feeds whom):**

| Downstream KPI (node2) | Upstream KPI (node1) |
|---|---|
| FS Submits | Visits |
| MF Submits | Rental Visits |
| ZHL Submits | Visits + FS Submits (+ app_installs) — handled in ZHL taxonomy NBs |

**The two shares** (within each `dmacode × week_monday`):
```
percent_1 = node1.predicted / node1.predicted_agg     # upstream channel's share of upstream KPI
                                                       # (FunnelEffects.py:21-24)
percent_2 = node2.predicted(var=node1) / node2.predicted_agg
                                                       # node1-KPI's share of downstream KPI
                                                       # (FunnelEffects.py:11-17)
```

**Indirect (Funnel) contribution** ([FunnelEffects.py:30-32](rapidmmm-main/rapidmmm/Utils/FunnelEffects.py#L30-L32)):
```
funnel_perc    = percent_1 × percent_2
predicted_adj  = predicted_nd1 × percent_1
```
where `predicted_nd1` is the downstream-KPI amount attributed to the upstream KPI variable, then **redistributed across the upstream media channels by their share `percent_1`**.

> Worked logic: if Linear TV produced 30% of Visits in a DMA-week (`percent_1 = 0.30`), and the Visits term explains 1,000 FS Submits there (`predicted_nd1 = 1000`), then Linear TV's **indirect** FS-Submit contribution = `1000 × 0.30 = 300`. Its **direct** FS-Submit contribution (if Linear TV is also a paid term in the FS model) stays in `node2_data`. **Total = Direct + Funnel.**

**Direct vs Funnel labeling** ([FunnelEffects.py:73-77](rapidmmm-main/rapidmmm/Utils/FunnelEffects.py#L73-L77)):
- rows where `variable != node1` → `Type = 'Direct Effect'`
- redistributed upstream-media rows → `Type = 'Funnel Effect'`
- spend & impressions are zeroed on funnel rows whose channel already exists as a direct row ([lines 70-71](rapidmmm-main/rapidmmm/Utils/FunnelEffects.py#L70-L71)) so dollars aren't double-counted.

**Validation in NB2** ([2_…fs:1042-1111](mmm_model/mmm_fs_submits/2_mmm_fs_submits_overall_model.py#L1042-L1111)): "Check 4" asserts total Funnel-Effect contribution **must be ≤** the node1 prediction.

**Taxonomy funnel** (`funnel_effects_taxonomy`, [FunnelEffects.py:79-144](rapidmmm-main/rapidmmm/Utils/FunnelEffects.py#L79-L144)) does the same propagation but at `channel|network|...|campaign_super` granularity, capping `percent_2` at 1 ([line 99](rapidmmm-main/rapidmmm/Utils/FunnelEffects.py#L99)).

---

## SECTION 10 — Taxonomy Implementation (code-exact)

**Hierarchy** (`taxo_order`, identical across visits/fs/mf/rental): `channel → network → lob → campaign_super` ([fs config:113-117](mmm_model/mmm_fs_submits/config_param.yml#L113-L117)). The warehouse carries 6 levels (channel, network, lob, tactic, initiative, campaign_super) but the modeled taxonomy uses these 4. `get_spark_ready_df_from_melted` splits the column on `|` into these levels ([ModelDiagnostics.py:367-401](rapidmmm-main/rapidmmm/PostProcessing/ModelDiagnostics.py#L367-L401)).

**It IS a second Bayesian model** — same `rapidmmm` `Model` class with:
- `modeltype='Taxonomy'` ⇒ **no intercept** (`α = 0`) ([4_…fs:590](mmm_model/mmm_fs_submits/4_mmm_fs_submits_taxonomy_model.py#L590))
- `y_col = target_variable` (the **same business KPI** as the overall model) ([4_…fs:584](mmm_model/mmm_fs_submits/4_mmm_fs_submits_taxonomy_model.py#L584))
- `channelgrouping = channel_network` — one taxonomy model is fit **per channel-network** ([4_…fs:292,591](mmm_model/mmm_fs_submits/4_mmm_fs_submits_taxonomy_model.py#L292))

| Question | Answer |
|---|---|
| Bayesian? | Yes — same NumPyro/NUTS `Model`, `modeltype='Taxonomy'` |
| Target variable | The business KPI (`value\|leads\|fs_submits`, etc.), **not** the parent-channel contribution |
| Predictors | The adstock→scaled→Hill transformed impressions of each taxonomy **leaf** (lob × campaign_super splits) within one channel-network |
| Number of leaves per channel-network | `cnt_dict` in config (e.g. FS: SEM\|Google Search → 6, Paid Social\|Facebook → 6, Owned Social → 5) ([fs config:68-88](mmm_model/mmm_fs_submits/config_param.yml#L68-L88)) |
| Normalization | `pred_ratio = predicted_initial / pred_sum`; `predicted = y_col_mean × pred_ratio × actual_KPI` ⇒ leaf contributions **sum to the actual KPI** ([ModelDiagnostics.py:302-313](rapidmmm-main/rapidmmm/PostProcessing/ModelDiagnostics.py#L302-L313)) |
| Contribution preservation across levels | `funnel_effects_taxonomy` uses `percent_2 = leaf.predicted / channel-network.predicted_agg` to split the channel-network total down to leaves while preserving the parent total ([FunnelEffects.py:88-113](rapidmmm-main/rapidmmm/Utils/FunnelEffects.py#L88-L113)) |

ZHL taxonomy adds an **OMP variant** (`adstock_hill_best_params_omp`, `5_…omp_imps_taxonomy_model`) and an `allowed_channels_and_networks` whitelist (channel,network,lob,campaign_super tuples) at [zhl config:266-614](mmm_model/mmm_zhl_submits/config_param.yml#L266-L614).

---

## SECTION 11 — Response Curve Implementation (code-exact)

Source: [ResponseCurveFit](rapidmmm-main/rapidmmm/Model/ResponseCurves.py) ; driven in NB7 ([7_…fs:93-162](mmm_model/mmm_fs_submits/7_mmm_fs_submits_overall_response_curves.py#L93-L162)).

**Curve equation** ([ResponseCurves.py:54-63](rapidmmm-main/rapidmmm/Model/ResponseCurves.py#L54-L63)):
```
y = bottom + (top − bottom) · x^slope / (saturation^slope + x^slope)
```
4 parameters: `top, bottom, saturation, slope`. In production `bottom_param=False` ⇒ **bottom forced to 0** ([7_…fs:111,154](mmm_model/mmm_fs_submits/7_mmm_fs_submits_overall_response_curves.py#L111)).

**x-axis is SPEND, not transformed media** — `x = impressions × CPI`. Overall uses one **universal CPI** = `Σspend / Σimpressions` ([ResponseCurves.py:158-161](rapidmmm-main/rapidmmm/Model/ResponseCurves.py#L158-L161)); DMA uses a **per-DMA CPI** ([lines 220-227](rapidmmm-main/rapidmmm/Model/ResponseCurves.py#L220-L227)). `y = predicted` (the modeled contribution from Section 8). Spend is used so the curve is dollar-denominated for budgeting.

**Fitting method** — `scipy.optimize.curve_fit` ([ResponseCurves.py:78](rapidmmm-main/rapidmmm/Model/ResponseCurves.py#L78)):

| `curve_fit` setting | Value ([get_param, lines 65-81](rapidmmm-main/rapidmmm/Model/ResponseCurves.py#L65-L81)) |
|---|---|
| Initial guess `p0` | `[max(y), min(y), 0.5·(x_last − x_first), 1]` |
| Bounds — top | `[max(y) − 0.5h, max(y) + 0.5h]`, `h = |max(y) − min(y)|` |
| Bounds — bottom | `[min(y) − 0.5h, min(y) + 0.5h]` (then overwritten to 0 when `bottom_param=False`) |
| Bounds — saturation | `[x_first · 0.1, x_last · 10]` |
| Bounds — slope | `[0.01, 100]` |
| Goodness of fit | `r2_score` ([line 99, 258](rapidmmm-main/rapidmmm/Model/ResponseCurves.py#L99)) |

**Overall vs DMA** ([fit_model, lines 156-300](rapidmmm-main/rapidmmm/Model/ResponseCurves.py#L156-L300)):
- `Modellevel='Overall'`: national aggregation by date, single curve, `x_fit` on a `logspace` grid, returns fitted equation + R²; `predict()` available.
- `Modellevel='DMA'`: loops every `dmacode`, fits a curve each, returns a DataFrame `[dmacode, bottom, top, slope, saturation, r_2]`; failures (ValueError/Overflow/RuntimeError) → all-zero row.

NB7 runs **both** `response_curves_channelnetworks_dma` and `response_curves_channelnetworks_overall`, writing to `mmm_response_curves_overall_level` / `..._reporting` Delta tables ([7_…fs:280-588](mmm_model/mmm_fs_submits/7_mmm_fs_submits_overall_response_curves.py#L280-L588)).

---

## SECTION 12 — Interview Cheat Sheet ("facts I can confidently say")

Each statement is directly backed by code/config cited above.

- Zillow's MMM is a **hierarchical Bayesian model fit with NumPyro's NUTS sampler** on JAX (float32). — BayesianModel.py
- Production runs **2000 posterior samples, 1000 warmup, 1 chain**, identical across Visits/FS/MF/Rental. — `2_*_overall_model.py:447-459`
- **Media coefficients are constrained non-negative** via `TruncatedNormal(low=0)`; controls/macro use unconstrained `Normal`. — BayesianModel.py:208-216
- The likelihood is **Gaussian** (`Normal(y_hat, σ)`, `σ ~ HalfNormal(5)`). — BayesianModel.py:225-226
- **DMA coefficients are partially pooled**: a global mean per predictor plus a per-DMA deviation scaled by `σ_β ~ HalfNormal`. — BayesianModel.py:199-216
- The **intercept (`α`) is per-DMA and only in the Overall model**; the Taxonomy model has no intercept. — BayesianModel.py:190-193, 252
- **Adstock and Hill parameters are configuration-driven, fixed, pre-tuned** values in `config_param.yml → adstock_hill_best_params` — not estimated by the model.
- **Adstock is dominated by Delayed adstock**; Geometric appears only twice (Visits Native & Online Video\|Media Agency); Exponential is used selectively (notably SEM\|GPMax in MF/Rental).
- The KPI is **mean-scaled per DMA** before modeling (`MeanScalingRegional`), and contributions are rescaled back with `coefficient × value × y_col_mean`. — FeatureScaling.py, ModelDiagnostics.py:278-280
- **Final contributions use the posterior MEAN** plus the **95% HDI** (2.5/97.5) bands — not the median, not full draws. — ModelDiagnostics.py:265-286
- **Taxonomy contributions are renormalized to sum to the actual KPI** (`pred_ratio` logic). — ModelDiagnostics.py:302-313
- **Funnel effects are computed post-hoc**, not inside the regression: indirect = downstream-KPI-from-upstream × upstream-channel share (`predicted_adj = predicted_nd1 × percent_1`). — FunnelEffects.py:30-32
- The funnel DAG is **Visits → FS Submits** and **Rental Visits → MF Submits**; ZHL consumes Visits + FS Submits as exogenous.
- **Response curves are fit with `scipy.optimize.curve_fit` to a 4-parameter Hill** on **spend** (impressions × CPI), at both Overall and per-DMA levels, with `bottom=0` in production. — ResponseCurves.py
- The **production MCMC acceptance gate is `accept_prob ∈ [0.6, 1]` and divergences ≤ 300**, with up to **3 retries** — Rhat/ESS are computed but not used as the gate. — `2_*_overall_model.py:364-433`
- **Model stability** vs the prior version is judged with `overlap_stability_percent=50` and `point_estimate_percent=25`. — `9_*_stability_loop.py:16-27`
- **Sigmoid saturation is implemented but never used** (`transform_cols_sigmoid: null` in all KPIs). — configs
- Some priors are **hard pins** (FS Paid Social\|Pinterest Mean=10/Facebook Mean=5 with Sd≈0.01–0.02), effectively fixing those coefficients (AOT/experiment-derived). — `mmm_fs_submits_priors.csv`

---

## SECTION 13 — Known Gaps (not in the repository)

| # | Missing item | Why it can't be inferred from this repo | Likely source / artifact needed |
|---|---|---|---|
| 1 | **Adstock parameter generation method** | Only the frozen *results* are in `adstock_hill_best_params`; the search/optimization that chose decay/lag/delay is absent. The NB comment calls them "best params from previous iteration" ([1_…fs:362](mmm_model/mmm_fs_submits/1_mmm_fs_submits_feature_engineering.py#L362)). The library *has* `FeatureEngineeringAdStockGrid` + `FeatureSelectionGridSearch` but no committed run uses them. | A separate tuning notebook / MLflow experiment under `ml_experiment_path` ([1_…fs:21](mmm_model/mmm_fs_submits/1_mmm_fs_submits_feature_engineering.py#L21)); likely the `mmm` GitLab repo |
| 2 | **Hill parameter (shape/slope) tuning method** | Same — only `Saturation_best_params` values are stored, not the fitting procedure | Same tuning notebook / experiment history |
| 3 | **Prior calibration methodology** | The `Mean`/`Sd` in the priors CSVs are given as data; how Mean=10 (Pinterest) or Mean=5 (Facebook) were derived is not in repo | AOT geo-holdout calibration + analyst process; `adjusted_target_aot_value` ([fs config:350](mmm_model/mmm_fs_submits/config_param.yml#L350)) points to AOT |
| 4 | **ZHL Submits priors & overall model** | No `mmm_zhl_submits_priors.csv`, no `2_overall_model` notebook | ZHL is taxonomy/OMP-first; the missing prior artifact/notebook is needed to document ZHL's coefficient priors |
| 5 | **mROAS implementation** | No `mroas`/`marginal`/derivative code anywhere in package or `mmm_model` (only a schema string in `rapidmmm_schema.yml`). Response curves persist `top/slope/saturation` but mROAS is not computed here | `incrementality-layer` GitLab repo (named in [README.md:146](rapidmmm-main/README.md#L146)) and/or the BI layer |
| 6 | **Budget optimization / allocation** | No optimizer, objective, constraints, or solver in repo. `ResponseCurves` docstring only *names* "budget optimization" as the downstream consumer | `incrementality-layer` (consumes `marketing.rapidmmm_gold` curves) |
| 7 | **AOT recalibration logic & values** | Configs carry `aot_recalibration_flag`, `channel_to_recalibrate*`, `adjusted_target_aot_value`, but the experiment numbers and recalibration math originate outside this repo | Always-on-Testing pipeline; partial context in [Always on Testing/](Always%20on%20Testing/) KT notes |
| 8 | **Live data for worked numeric examples** | Every loader reads Delta/Trino tables (`marketing.marketingde_gold.mmm_*`); no sample data is committed | Databricks Unity Catalog (`marketing.*`, `marketing.rapidmmm_gold`) |
| 9 | **`Sigma_Sd` (σ_β scale) per channel** | Not present in any committed priors CSV; code defaults it to 1.0 | Would come from an extended priors artifact if/when used |
| 10 | **Full stability-loop math** | NB9 thresholds (`overlap 50% / point-estimate 25%`) are known, but the complete pass/fail computation was not exhaustively traced here | `9_*_stability_loop.py` (full read) if exact stability formula is required |

---

*End of reference. All values above are transcribed from the cited files; any figure not cited to a file/line is flagged in Section 13 as a gap rather than asserted.*
