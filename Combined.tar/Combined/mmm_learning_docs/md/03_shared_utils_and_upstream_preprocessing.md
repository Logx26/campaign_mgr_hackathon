---
doc_id: 03
title: Shared Utilities and Upstream Preprocessing — The Silver Layer
companion_docs:
  - 00_mmm_ecosystem_overview.md (system map)
  - 01_mmm_methodology_primer.md (methodology — what the silver layer enables)
  - 02_rapidmmm_library_internals.md (the library the preprocessing notebook calls into)
  - 04_data_lineage_and_schemas.md (the schema reference for every silver and gold table)
  - 05_fs_submits_feature_engineering_and_overall_model.md (consumes the silver layer)
---

# 03 — Shared Utilities and Upstream Preprocessing

> **What this doc is.** A walkthrough of the eight files in
> [`mmm_model/shared_utils/`](D:/MMM_Learning/mmm_model/shared_utils/) and
> the upstream pipeline that produces the silver tables every KPI model
> consumes. After reading, you'll be able to look at any
> `%run ../shared_utils/...` line in a KPI notebook and know exactly
> what's invoked, and you'll be able to query any
> `marketing.rapidmmm_silver.mmm_input_preprocessing_*` table and know
> precisely how each column got there.
>
> **The role of this layer.** Everything in `shared_utils/` is **KPI-
> agnostic**. The silver tables produced by the MMM Input Job are read
> by all five KPI jobs without modification — they are the canonical,
> validated, filtered input data. Anything that *is* KPI-specific
> (feature engineering, model fitting, response curves) lives in the
> per-KPI notebooks, not here.

---

## 1. The `shared_utils/` layer at a glance

There are seven Python files plus one YAML config in
[`mmm_model/shared_utils/`](D:/MMM_Learning/mmm_model/shared_utils/):

| File | Role | Job that invokes it |
|---|---|---|
| `common_functions.py` | Cross-KPI Python helpers — date arithmetic, MLflow run hygiene, Delta + metadata write wrapper, dev-environment auto-setup, the MLflow pyfunc model wrapper | Every notebook in every KPI job loads this via `%run ../shared_utils/common_functions` |
| `mmm_input_config.yml` | The whitelist + column-mapping config — single source of truth for "what taxonomy combinations are allowed", "what business metric sources to load", "which macroeconomic variables to smooth", "which exogenous variables enter the modeling dataset" | Read by `mmm_input_data_preprocessing.py`, `mmm_exogeneous_feature_store.py`, and every KPI's NB1/NB2 (for column-mapping lookup) |
| `mmm_input_data_preprocessing.py` | **The workhorse.** Pulls raw marketing + business data, validates the channel-network-LOB-campaign_super taxonomy, pivots to wide modeling format, splits train/holdout, writes six silver tables consumed by every KPI | The "Preprocessing" task in the MMM Input Job |
| `mmm_exogeneous_feature_store.py` | Smooths macroeconomic variables (Google Trends, mortgage rate, econometrics) using exponential moving average, backfills holdout gaps via seasonal week-of-year averages, registers/refreshes the Databricks Feature Store table | The "Feature Store" task in the MMM Input Job |
| `mmm_model_output_table_creation.py` | Creates the empty Gold tables if they don't exist (5 model-output tables + 1 stability table + reporting tables); copies the latest prod data into a dev schema for development bootstrap | Auto-invoked by KPI NB1/NB2 in dev environment via `dbutils.notebook.run(...)` |
| `mmm_week_condition_check.py` | The bi-weekly gate: returns `Execute` on odd ISO weeks, `Skip` on even ones — communicated to downstream tasks via `dbutils.jobs.taskValues` | First task of every Databricks job (Input Job + every KPI job) |
| `mmm_dataset_availability_check.py` | Confirms `mmm_marketing_metrics` and `mmm_business_metrics` have data for the expected date range before any model fitting starts. Uses the `zg_databricks_platform_sdk.availability` package shared across Zillow analytics teams | The "business_data_availability_check" and "marketing_data_availability_check" tasks in the MMM Input Job and every KPI job |
| (implicit) `databricks.yml` | The Databricks Asset Bundle definition — sets cluster types, schedules, parameter defaults — not in this directory but lives at the repo root | Outside this doc's scope |

The pattern that runs through all of these: **they own no business
logic specific to any one KPI.** They define the canonical inputs,
canonical date windows, canonical metadata, canonical environment
bootstrapping — and then step back to let each KPI notebook do its
KPI-specific math. This is why adding a sixth KPI to the system would
require **zero changes** to `shared_utils/` — just a new
`mmm_<new_kpi>/` directory with its own 9-notebook chain.

---

## 2. `common_functions.py` — the cross-KPI toolkit

[`common_functions.py`](D:/MMM_Learning/mmm_model/shared_utils/common_functions.py)
is the 327-line file every notebook loads at startup via
`%run ../shared_utils/common_functions`. The `%run` magic injects every
function defined in that file into the calling notebook's namespace —
so when you see `get_train_holdout_dates(...)` or
`intermediate_and_meta_table_write(...)` inside a KPI notebook with no
import, that's what's happening.

### 2.1 Function inventory

| Function / class | Purpose | Used by |
|---|---|---|
| `add_mapping(file_path, mapping_name, mapping_dict, processing_path=None)` | Writes a named key-value mapping into a YAML file (creates the file if missing). Used to persist column-name mappings that downstream notebooks read back via `get_yaml_value` | Every KPI NB1 / NB2 / NB3 — after creating a Delta table, the original→sanitized column-name mapping is appended to `config_table_mapping.yml` |
| `get_yaml_value(file_path, key)` | Reads a top-level key from a YAML config | Everywhere — by every notebook reading `mmm_input_config.yml` or `config_param.yml` or `config_table_mapping.yml` |
| `get_or_create_experiment(experiment_path, artifacts_path)` | Looks up an MLflow experiment by name; creates it if missing; sets it as the active experiment. Returns the `experiment_id` | Only by `create_or_get_dev_environment_variables` (i.e., in dev only — stage/prod have pre-existing experiments) |
| `clean_active_runs_for_experiment(experiment_path)` | Searches for `RUNNING` runs in the experiment and forcibly deletes them | KPI NB1 of every KPI — clears any stale run state before starting fresh |
| `get_or_create_parent_run(experiment_id, run_name_prefix)` | Finds an existing active parent run (one without a `parentRunId` tag); if none, starts a new one named `<prefix><today-date>` | Every KPI NB1 — establishes the parent MLflow run for the bi-weekly model session, so child runs (overall model, taxonomy models, response curves) can be tagged with `parentRunId` and nested under it |
| `clean_active_child_runs(experiment_id)` | Forcibly closes any active child runs (those with a `parentRunId` tag) | KPI NB2 / NB3 / NB7 / NB8 — clears child-run state at the top of each notebook so a re-run doesn't leak |
| `get_child_run(experiment_id)` | Finds the latest active or finished taxonomy child run; used so NB4's per-channel parallel taxonomy fans-out can reuse the parent's MLflow run | KPI NB4 (taxonomy model) |
| `send_slack_message(message)` | Posts to a hardcoded Slack webhook | Final cell of the MMM Input preprocessing notebook (success message) and KPI NB9 (final stability check completion). Only fires in `environment == 'prod'` |
| **`get_train_holdout_dates(catalog, schema, business_kpi, latest_model_version)`** | Computes the canonical (train_start, train_end, holdout_start, holdout_end, response_curves_start) date 5-tuple based on the previous version's week range. See Section 2.2 | Every notebook that needs to know the modeling date window — i.e., most of them |
| **`intermediate_and_meta_table_write(business_kpi, model_version, df, catalog, schema, table_name, environment, dates_list_used)`** | The canonical Delta-write helper: writes `df` as a Delta table AND appends a metadata row to `mmm_model_job_metadata_detail` (in stage/prod only). See Section 2.3 | Every notebook that writes to silver or gold. There are dozens of call sites across the codebase |
| **`create_or_get_dev_environment_variables(business_kpi, catalog, silver_schema, gold_schema, ml_experiment_path)`** | Bootstraps a developer-specific schema, volume, and MLflow experiment for lab work. Replaces the input schema arguments with `dev_{username}` versions. See Section 2.5 | KPI NB1 / NB2 / etc. — only when `environment == 'development'` |
| **`RapidMMMModelWrapper(mlflow.pyfunc.PythonModel)`** | A `pyfunc` wrapper around a fitted `rapidmmm.Model.BayesianModel.Model` so it can be logged and served via MLflow. See Section 2.4 | KPI NB2 / NB4 — wraps the trained model right before `mlflow.pyfunc.log_model` |

The remaining few helpers (e.g., the YAML date parser, the `is_row_valid`
predicate inside `mmm_input_data_preprocessing.py`) are trivial.

### 2.2 `get_train_holdout_dates` — the canonical date window

This function decides the modeling time window for every bi-weekly run.
The dates it returns are used as filter predicates in every silver-table
read and every model fit. Getting this right is essential to
reproducibility: with the same dates and the same code, you get the
same model.

The algorithm:

1. Read the current min/max `week_monday` from the latest version of
   `mmm_model_combined_output_overall_level` for the given KPI:
   ```sql
   SELECT MIN(week_monday) AS min_week_monday,
          MAX(week_monday) AS max_week_monday
   FROM <catalog>.<gold_schema>.mmm_model_combined_output_overall_level
   WHERE business_kpi = '<KPI>' AND version = '<latest_model_version>'
   ```
   The min is "where the previous model's training window started"; the
   max is "where its holdout window ended."

2. Decide today's "anchor date" — use Pacific Time so the cadence is
   consistent regardless of where the cluster runs:
   ```python
   current_date = datetime.now(pytz.timezone("US/Pacific"))
   ```

3. Determine the **holdout end week** based on the day of the month:
   - If today's day < 15 → use the **last day of the previous month**
   - If today's day ≥ 15 → use the **14th of the current month**

4. Snap that to the previous Monday → `holdout_end_week`. The
   `dateutil.relativedelta(weekday=MO(-1))` operator does this in one
   line.

5. Then:
   ```
   train_end_week        = holdout_start_week - 1 day
   train_start_week      = previous_version's min_week_monday + 2 weeks
   response_curves_start = holdout_end_week - 1 year
   ```

   The `+ 2 weeks` on `train_start_week` is the rolling-window step: each
   bi-weekly run drops the oldest two weeks of training data and adds
   the two newest weeks. The `1 year` lookback for `response_curves_start`
   is the window of data used to fit the response curves (Doc 07).

6. Format all five as `YYYY-MM-DD` strings, return as a tuple.

The two checkpoints in the logic — "use mid-month or month-end" and
"snap to Monday" — are what produce the predictable bi-weekly cadence
without needing a true bi-weekly scheduler. The day-of-month check
synchronizes the date window with the calendar regardless of *which*
Thursday triggers the job.

> **Interview angle — "How do you decide the training window for a
> rolling MMM?"** *"Three rules: (1) The training window slides forward
> by exactly two weeks per bi-weekly run, anchored to the previous
> version's start date plus two weeks — this guarantees the window stays
> a consistent 2 years. (2) The holdout end is calendar-month anchored
> (mid-month or end-of-month depending on which side of the 15th you're
> on), snapped to the previous Monday — this gives Marketing a
> predictable cadence. (3) The response-curves window is 1 year of
> recent data, ending at holdout_end — using the most recent year of
> spend levels for marginal-ROAS estimation. All of this is derived
> from the previous version's min/max week stored in the gold output
> table, so the system is self-bootstrapping after the first run."*

### 2.3 `intermediate_and_meta_table_write` — the canonical Delta write

Every silver/gold table write goes through this one function. It does
three things:

1. **Writes the data.** `df.write.format("delta").mode("overwrite")
   .option("overwriteSchema", "true").saveAsTable(...)` — full overwrite
   of the table content. Schema evolution is enabled so adding/removing
   columns between runs works without manual migration.

2. **Captures job context** from `dbutils.widgets`:
   ```python
   try:
       job_name = dbutils.widgets.get("job_name")
       job_id   = dbutils.widgets.get("job_id")
       run_id   = dbutils.widgets.get("run_id")
   except Exception:
       job_id, job_name, run_id = 'NA', 'NA', 'NA'
   ```
   Wrapped in try/except because interactive notebook runs (no Databricks
   job) don't have these widgets.

3. **Appends a metadata row** to
   `mmm_model_job_metadata_detail` (only in stage/prod). The metadata
   row contains: `business_kpi, model_version, job_id, job_name, run_id,
   table_name, delta_table_version, environment, dates_list_used,
   updated_timestamp`. The `delta_table_version` is the Delta-table
   version number after the write — pulled via `DeltaTable.forName(spark,
   ...).history()`.

The metadata table is the **production audit trail**: any cell in any
output table can be traced back to its producing run via the
`mmm_model_job_metadata_detail` join key `(business_kpi, model_version,
table_name)`. This is what makes the system debuggable two weeks later
("the v62 output looks weird — which job produced it?" → join through
job_metadata → "job_id 27073485392319, run on 2025-08-01 at 06:33").

The function also uses `.option("replaceWhere", ...)` predicate scopes
to make the metadata writes idempotent — re-running the same job
overwrites only its own metadata row, not anyone else's.

### 2.4 `RapidMMMModelWrapper` — the MLflow pyfunc bridge

```python
class RapidMMMModelWrapper(mlflow.pyfunc.PythonModel):
    def __init__(self, model):
        self.model = model

    def predict(self, context, model_input, params=None):
        MoDi = md.ModelDiagnostics(self.model)
        kpi = params.get("kpi")
        MoDi.business_kpi = kpi
        return MoDi.generate_predictions(model_input)
```

A *numpyro* MCMC object is not natively serializable by MLflow — there's
no `predict()` method on `numpyro.infer.MCMC` and no way for MLflow to
know that "to predict, call `Predictive` with the posterior samples and
extract `obs`."

`RapidMMMModelWrapper` solves this by subclassing
`mlflow.pyfunc.PythonModel`, which is MLflow's standard pattern for
wrapping any model with a custom predict path. The wrapper:

- Stores the fitted `Model` object (which holds the posterior samples
  and the `model_fn`).
- Re-creates a `ModelDiagnostics` instance at predict-time and delegates
  to `generate_predictions(model_input)` — this is the
  `numpyro.infer.Predictive` path described in
  [Doc 02 Section 4.7](02_rapidmmm_library_internals.md#47-prediction-at-inference-time).
- Accepts a `kpi` parameter at predict-time so the wrapper knows which
  KPI tag to apply (because the same wrapper class serves every KPI's
  model).

The KPI notebooks then register the wrapped model in Unity Catalog:

```python
wrappedModel = RapidMMMModelWrapper(mdl)
signature = infer_signature(train_data,
    np.array(wrappedModel.predict(None, model_input=train_data, params={'kpi': 'MF Submits'})))
mlflow.pyfunc.log_model("mf_submits_overall_mdl", python_model=wrappedModel, signature=signature)
mlflow.register_model(f"runs:/{run_id}/mf_submits_overall_mdl",
    f"{catalog}.{gold_schema}.mmm_mf_submits_overall_model")
```

After this, the model is loadable from anywhere with `mlflow.pyfunc.
load_model("models:/marketing.rapidmmm_gold.mmm_mf_submits_overall_model
/<version>")` and exposes a Pandas-DataFrame-in, Pandas-DataFrame-out
predict surface — perfect for downstream consumption by the
`incrementality-layer` or by ad-hoc analysts.

### 2.5 `create_or_get_dev_environment_variables` — dev bootstrap

In `development` environment, the schemas, volumes, and ML experiments
don't exist out of the box for every developer. This function:

1. Derives a username from the current Databricks user context:
   ```python
   current_user_full_name = dbutils.notebook.entry_point.getDbutils()\
       .notebook().getContext().userName().get()
   short_username = current_user_full_name.split("@")[0]\
       .replace("-", "_").replace(" ", "_")
   ```

2. Computes a dev experiment path:
   ```python
   ml_experiment_path = f"/Users/{full_name}/[dev {short_username}] _{business_kpi}"
   ```

3. Creates a per-user schema if missing:
   ```python
   spark.sql(f"CREATE SCHEMA IF NOT EXISTS {catalog}.dev_{short_username}")
   spark.sql(f"GRANT USAGE ON SCHEMA ... TO zodiac_mads")
   spark.sql(f"GRANT SELECT ON SCHEMA ... TO zodiac_mads")
   ```

4. Creates a per-user volume for MLflow artifacts and grants read access.

5. Calls `get_or_create_experiment(...)` to ensure the MLflow experiment
   exists.

6. Returns the rewired `(silver_schema, gold_schema, ml_experiment_path,
   experiment_id)` tuple.

The KPI notebooks then use these returned values for all subsequent
table reads/writes — so a developer's lab work writes to
`sandbox_desa.dev_haneshnaidu.<table>` and never touches prod
`marketing.rapidmmm_silver.<table>`.

This is a clean pattern: same code, different parameters per
environment. No `if environment == 'dev'` branches sprinkled across the
KPI notebooks beyond this single bootstrap call.

> **Interview angle — "How do you isolate dev/stage/prod in a Databricks
> ML pipeline?"** *"Three layers. (1) Widget-driven parameter passing —
> every notebook reads catalog, silver_schema, gold_schema, environment
> from `dbutils.widgets`, so the same notebook runs against any
> environment by changing the widget values. (2) A bootstrap helper
> (`create_or_get_dev_environment_variables`) that auto-creates a
> per-user schema and ML experiment in dev so developers don't collide
> on shared tables. (3) Stage and prod are managed via the GitLab CI/CD
> pipeline as service principals (no individual user deploy
> permissions). Combined, the same notebook code runs unmodified in
> all three environments — the only difference is the widget values
> the job passes in."*

---

## 3. `mmm_input_config.yml` — the cross-KPI configuration

This 44 KB YAML is the single source of truth for upstream-layer
decisions. It is **read by the input-preprocessing notebook and the
feature-store notebook** to drive the upstream silver-table build; the
column-mapping sections are **read back by every KPI's NB1/NB2** to
translate sanitized Delta column names back to their original
pipe-separated form.

### 3.1 Top-level keys, by semantic category

```text
mmm_input_config.yml
├── allowed_channels_and_networks          # WHITELIST: list of [channel, network, lob, campaign_super]
│                                          # 4-element lists. Marketing rows with combinations
│                                          # not in this whitelist are dropped before pivot.
│
├── business_metrics_sources               # SOURCES: list of data_name strings to query from
│                                          # mmm_business_metrics — e.g., "econmetricsmsa",
│                                          # "googletrends", "mortgagemetrics", "appinstalls",
│                                          # "leads", "visits", "moodys_unemployment_data",
│                                          # "moodys_consumer_price_data", "rentalsdailylistings",
│                                          # "rentalsmetrics_zillowbrand"
│
├── selected_exogenous_variables           # METRIC FILTER: list of metric names that survive
│                                          # the BusinessMetricsData.select_data_names_for_mmm
│                                          # call — only these metrics enter the modeling dataset
│
├── macro_econ_vars                        # FULL MACRO LIST: all macroeconomic variables
│                                          # available in the input data, in pipe-separated
│                                          # value|data_name|metric form
│
├── macro_econ_vars_to_smooth              # SMOOTHING TARGET: subset of macro_econ_vars
│                                          # that get exponential smoothing applied by
│                                          # mmm_exogeneous_feature_store.py
│
├── taxo_order                             # TAXONOMY ORDER: [channel, network, lob,
│                                          # campaign_super] — defines the column order
│                                          # in the taxonomy pivot
│
├── mmm_input_preprocessing_taxonomy_data         # COLUMN MAPPINGS (one per silver table):
├── mmm_input_preprocessing_overall_data          #   Maps the original pipe-separated names
├── mmm_input_preprocessing_overall_data_rentals  #   to the underscore-sanitized Delta names.
├── mmm_input_preprocessing_overall_spend_data    #   These are written by the preprocessing
├── mmm_input_preprocessing_overall_spend_data_rentals  # notebook via add_mapping() after
└── mmm_input_preprocessing_taxonomy_spend_data         # each Delta table is created.
```

### 3.2 The whitelist mechanic — `allowed_channels_and_networks`

This list is the **gatekeeper** for what enters the modeling dataset.
Each entry is a 4-element list `[channel, network, lob, campaign_super]`
representing a *valid* combination. Examples from the file:

```yaml
allowed_channels_and_networks:
- [App, Apple Search, PA - Customer, Buyer]
- [App, Apple Search, Rentals - Partner, Rental]
- [Linear TV, Media Agency, Multi Product, Brand]
- [SEM, Google Search, ZHL - Customer, Buyer]
- [Push, 'null', 'null', NonMarketing]
- [Operational Emails, Simon Data, Rentals - Customer, Rental]
- ...
```

There are ~150 such 4-tuples. The preprocessing notebook builds a Python
set from this list:

```python
allowed_combinations = set(tuple(x) for x in valid_list)

def is_row_valid(row):
    return (row['channel'], row['network'], row['lob'],
            row['campaign_super']) in allowed_combinations

invalid_rows = MD.data[~MD.data.apply(is_row_valid, axis=1)]
MD.data = MD.data.drop(invalid_rows.index).copy()
```

Rows whose 4-tuple is not in the whitelist are silently dropped (logged
to MLflow with `Invalid_Channel_Network` parameter so audit is possible).

**Why a whitelist instead of a blacklist?** Because the raw marketing
data contains thousands of taxonomy combinations from upstream campaign
trafficking — many of which are typos, deprecated tactics, or noise.
Whitelisting forces the analytics team to *explicitly* opt new
combinations into modeling, which prevents the input data from
silently drifting as marketing teams add tactics. When a new
channel-network-lob-campaign_super combination starts running, it
appears in the `invalid_rows` MLflow log entry, prompting an
intentional config update before that combination contributes to
modeling.

### 3.3 Column-mapping sections — pipe-name to underscore-name lookups

Delta tables don't accept pipe (`|`) or space or hyphen in column names.
The preprocessing notebook sanitizes column names by replacing those
characters with underscores. The original `impressions|App|Apple
Search|PA - Customer|Buyer` becomes
`impressions_App_Apple_Search_PA___Customer_Buyer` (note: three
underscores in the LOB position because `PA - Customer` has the spaces
and hyphen all replaced).

The lossy nature of this transformation means *you can't recover the
original name by string-splitting* — the underscore-separated form is
ambiguous. So the codebase writes a **reverse-mapping dictionary** into
the YAML every time it writes a table:

```python
modified_column_names = [c.replace(" ", "_").replace("|", "_").replace("-", "_") for c in df.columns]
column_name_mapping = dict(zip(df.columns, modified_column_names))
add_mapping(
    file_path='mmm_input_config.yml',
    mapping_name='mmm_input_preprocessing_taxonomy_data',
    mapping_dict=column_name_mapping,
)
```

Then every downstream notebook reads this map back and renames the
Delta columns *back* to their original pipe-separated form before
modeling:

```python
mapping = get_yaml_value('mmm_input_config.yml', 'mmm_input_preprocessing_overall_data_rentals')
reverse_mapping = {v: k for k, v in mapping.items()}
for old_name, new_name in reverse_mapping.items():
    if old_name in data.columns:
        data = data.withColumnRenamed(old_name, new_name)
```

After this, in-memory pandas DataFrames use the original pipe-separated
names — matching the priors CSV, the adstock config, and the channel-
network identifiers used everywhere else.

> **Interview angle — "How do you handle Delta-incompatible characters
> in column names?"** *"We persist a reverse-mapping dictionary alongside
> each Delta write. When writing, we sanitize column names (pipe →
> underscore, space → underscore, hyphen → underscore) and append the
> original→sanitized mapping to a config YAML. When reading downstream,
> we invert the mapping and rename the columns back. This keeps modeling
> code working in the natural pipe-separated taxonomy namespace while
> Delta sees only Delta-legal column names."*

### 3.4 The `taxo_order` constant

```yaml
taxo_order:
- channel
- network
- lob
- campaign_super
```

This four-element list is what `MarketingMetricsData.get_pivoted_impressions_for_mmm`
uses to determine the pivot columns. It's exposed in config (rather
than hardcoded) so a future change in taxonomy order — say adding
`tactic` as a fifth level for some KPIs — requires only a config
change, not a code change. (In practice the system has stayed at 4
levels since v13.)

---

## 4. `mmm_input_data_preprocessing.py` — the workhorse silver builder

This 988-line notebook is **the single most important file in the
shared layer**. It runs once per bi-weekly cycle as the "Preprocessing"
task in the MMM Input Job, and produces the six silver tables that
every KPI notebook reads. Here is what happens, end-to-end.

### 4.1 Inputs

| Source table | What it contains | Cardinality (typical) |
|---|---|---|
| `marketing.marketingde_gold.mmm_marketing_metrics` | Raw marketing impressions, clicks, spend at `dma × week × channel × network × LOB × campaign_super × tactic × initiative` granularity | Tens of millions of rows |
| `marketing.marketingde_gold.mmm_business_metrics` | Raw business KPI events + econometric data + Google Trends + mortgage rates + rentals listings at `dma × week × data_name × metric` granularity | Millions of rows |

Neither source is touched directly by the KPI notebooks — only by this
preprocessing notebook. This means the upstream data team can change
schema in either source without breaking every KPI notebook
simultaneously; the breakage surface is concentrated here.

### 4.2 Outputs — six silver tables

The notebook writes **six** silver tables. Two granularities × Two
KPI-flavors × ... well, it's not a clean grid; let me lay them out:

| Silver table | Granularity | Includes Agent/ZHL/ZGMI/Brand rows? | Consumers |
|---|---|---|---|
| `mmm_input_preprocessing_overall_data` | `(dma × week × channel × network)` impressions + selected exogenous + train_holdout flag | **Yes** — includes everything | Visits NB1, FS Submits NB1 |
| `mmm_input_preprocessing_overall_data_rentals` | Same as above but rows with `campaign_super in ('Agent', 'Elevate', 'Brand')` or `lob in ('ZGMI - Customer', 'ZHL - Customer')` removed | **No** — rentals-only view | Rental Visits NB1, MF Submits NB1 |
| `mmm_input_preprocessing_taxonomy_data` | `(dma × week × channel × network × lob × campaign_super)` impressions + spend + exogenous + train_holdout flag | **Yes** | All KPIs' NB3 (taxonomy model input) |
| `mmm_input_preprocessing_overall_spend_data` | Same as `overall_data` but `spend` columns only | Yes | Visits NB2, FS Submits NB2 (used by `merge_spend_data_w_melted`) |
| `mmm_input_preprocessing_overall_spend_data_rentals` | Same as `overall_data_rentals` but `spend` columns only | No | Rental Visits NB2, MF Submits NB2 |
| `mmm_input_preprocessing_taxonomy_spend_data` | `(dma × week × channel × network × lob × campaign_super)` spend only | Yes | All KPIs' NB4 |

Plus two correlation tables (KPI-tagged but written from this notebook):

| Silver table | Purpose |
|---|---|
| `mmm_visits_corr_input_data_overall` | Pairwise impression correlation matrix from the Visits-flavored overall data — for QC/EDA |
| `mmm_rental_visits_corr_input_data_overall` | Same for the rentals-flavored overall data |

Plus one SQL view that UNIONs all three (Visits/FS, ZHL, Rental Visits)
into one long-form table for the Tableau EDA dashboard:

```sql
CREATE OR REPLACE VIEW vw_mmm_input_preprocessing_overall_data AS
  SELECT ... 'Others' AS kpi_group FROM mmm_input_preprocessing_overall_data
UNION ALL
  SELECT ... 'ZHL' AS kpi_group    FROM mmm_zhl_preprocessing_overall_data
UNION ALL
  SELECT ... 'Rentals' AS kpi_group FROM mmm_input_preprocessing_overall_data_rentals
```

### 4.3 The pipeline, section by section

Here is what the notebook does, in execution order. The numbered
sections map to the major markdown headers in the source file.

#### Section 4.3.1 — Version setup and date window derivation

Reads the `model_version_number` widget (default `"NA"` → auto-
increment). Computes `train_start_week, train_end_week, holdout_start_
week, holdout_end_week, response_curves_start_week` via
`get_train_holdout_dates`. These are then used as filter predicates in
the SQL pulls.

#### Section 4.3.2 — Data count validation

Pulls both source tables with a WHERE clause on date range. Asserts
both have `count() > 0`. Raises with an explicit error if either is
empty — this is the upstream-data-arrived-ok check that runs before any
modeling logic.

#### Section 4.3.3 — Marketing data: extract, clean, validate

```python
MD = MarketingMetricsData(QUERY=marketing_query, time_var='week_monday')
MD.retrieve_data_and_clean()
MD.filter_date_range(start_date=train_start_week, end_date=holdout_end_week)
```

`MarketingMetricsData` (Doc 02 Section 11.1) executes the query, drops non-US
DMAs (`dmacode in {-1, 0}`), fills nulls in channel/network/lob/etc.
with the literal string `"null"`, and applies `treat_channel_output_
levels` (sets taxonomy levels to `"null"` per `channel_outputs.csv`
where the channel doesn't naturally have that level).

The marketing SQL applies three notable in-query filters:

1. `channel != 'OMP'` — OMP (Owned Marketing Pages) is excluded from
   the unified preprocessing because ZHL handles it separately
2. `network not in ('Pardot')` — Pardot data lives only in Email and is
   considered noise
3. Standardization of edge cases — UM Digital → CWW Digital network
   rename, Email with operational tactic → 'Operational Emails' channel

Then in-notebook validation:

- **Whitelist filter** (described in Section 3.2 above) — drops rows whose
  `(channel, network, lob, campaign_super)` is not in
  `allowed_channels_and_networks`. The dropped rows are logged to MLflow
  for audit.
- **Operational Emails network merge** — Iterable and Simon Data are
  collapsed into a single `Iterable_Simon Data` network for the
  Operational Emails channel.
- **Impressions > 0 filter** — rows with zero impressions are dropped
  (a zero-impression row contributes nothing to modeling but inflates
  the row count).

#### Section 4.3.4 — Build the second marketing DataFrame for the rentals variant

The notebook makes a **second** `MarketingMetricsData` instance, `MD1`,
by copying `MD.data` and filtering out:

```python
MD1.data = MD1.data[MD1.data.campaign_super != 'Agent']
MD1.data = MD1.data[MD1.data.campaign_super != 'Elevate']
MD1.data = MD1.data[MD1.data.campaign_super != 'Brand']
MD1.data = MD1.data[MD1.data.lob != 'ZGMI - Customer']
MD1.data = MD1.data[MD1.data.lob != 'ZHL - Customer']
```

This is the "rentals" view: the Rental Visits and MF Submits models
care only about rentals-relevant channels and should not be confounded
by Agent campaign spend, ZHL lending spend, or Multi-Product Brand
campaigns. By producing a separate silver table that pre-filters these
out, the Rental Visits and MF Submits notebooks can read directly
without re-filtering.

#### Section 4.3.5 — Pivot marketing data to wide format

For the **taxonomy** view:
```python
df_pivot_taxonomy = MD.get_pivoted_impressions_for_mmm(
    columns=['channel', 'network', 'lob', 'campaign_super']
)
collapsed_data_taxonomy = MD.unpivot_data_for_mmm(df_pivot_taxonomy)
```

The pivot produces a wide DataFrame indexed by `(dma_regionid, dmacode,
week_monday)` with multi-level columns over `(impressions | spend) ×
(channel × network × lob × campaign_super)`. The unpivot then collapses
the multi-index into pipe-separated single-level column names like
`impressions|App|Apple Search|PA - Customer|Buyer`.

For the **overall** view, columns are just `(channel, network)`:
```python
df_pivot_overall = MD.get_pivoted_impressions_for_mmm(columns=['channel', 'network'])
df_pivot_overall_withoutAgent = MD1.get_pivoted_impressions_for_mmm(columns=['channel', 'network'])
```

So two grain-pivot pairs are produced — taxonomy (4-level) and overall
(2-level), each in two flavors (full / rentals-only).

#### Section 4.3.6 — Business data: extract, clean, select

```python
BD = BusinessMetricsData(QUERY=business_query)
BD.retrieve_data_and_clean()
BD.filter_date_range(start_date=train_start_week, end_date=holdout_end_week)
df_bd_pivot = BD.get_pivoted_data()
mmm_data = BD.unpivot_data_for_mmm(df_bd_pivot)

selected_exogenous_variables = get_yaml_value(config, 'selected_exogenous_variables')
df_bd = BD.select_data_names_for_mmm(mmm_data, selected_data_name=selected_exogenous_variables)
```

The business data pivot produces wide columns like
`value|econmetricsmsa|for_sale_inventory`, `value|googletrends|mortgage_index`,
`value|visits|visits`, `value|leads|fs_submits`,
`value|rentalsmetrics_zillowbrand|rental_visits`, etc.

`select_data_names_for_mmm` filters to only the columns listed in
`selected_exogenous_variables` plus the always-on macroeconomic
indicators. Duplicate-column de-deduplication runs immediately after:

```python
df_bd = df_bd.loc[:, ~df_bd.columns.duplicated()]
df_bd.drop(['value|rentalsmetrics_zillowbrand|MF_visits',
            'value|rentalsmetrics_zillowbrand|SF_visits'],
           axis=1, inplace=True, errors='ignore')
df_bd.rename(columns={'value|rentalsdailylistings|number_daily_listings':
                      'value|rental_metrics|rental_daily_listings'}, inplace=True)
```

The MF_visits and SF_visits drops are because Rental Visits is the
unified target — the MF/SF sub-breakdowns aren't used here.

#### Section 4.3.7 — Merge marketing × business

```python
final_taxonomy = pd.merge(
    collapsed_data_taxonomy, df_bd,
    how='outer',
    left_on=['dma_regionid', 'dmacode', 'week_monday'],
    right_on=['dma_regionid', 'dmacode', 'week_monday']
)
final_overall = pd.merge(collapsed_data_overall, df_bd, ...)
final_overall_withoutAgent = pd.merge(collapsed_data_overall_withoutAgent, df_bd, ...)
```

`how='outer'` is intentional: we want all `(dma, week)` combinations
that appear in either marketing OR business data. If marketing has spend
in a (dma, week) but no business event, we still keep the row (with
NaN in business columns, which becomes 0 after fillna). And vice versa.

After the merge, the three DataFrames are filtered to `week_monday >=
train_start_week` to drop any straggler old rows from the outer-merge.

#### Section 4.3.8 — Train/holdout flag

```python
final_taxonomy["train_holdout"] = np.where(
    final_taxonomy["week_monday"] < holdout_start_week, "Train", "Holdout"
)
```

This is the single column that downstream notebooks use to split train
from holdout. It's set **at the silver layer**, not the feature
engineering layer, so every consumer agrees on which weeks are
training and which are holdout. (If two consumers computed their own
split, they could disagree on a boundary week — keeping it at silver
eliminates that class of bug.)

#### Section 4.3.9 — Sanitize column names and write silver tables

Each of the six tables goes through the same boilerplate:

```python
original_column_names = final_taxonomy.columns
modified_column_names = [c.replace(" ", "_").replace("|", "_").replace("-", "_")
                         for c in final_taxonomy.columns]
column_name_mapping = dict(zip(original_column_names, modified_column_names))

add_mapping(file_path='mmm_input_config.yml',
            mapping_name='mmm_input_preprocessing_taxonomy_data',
            mapping_dict=column_name_mapping)

final_taxonomy.columns = modified_column_names
final_taxonomy_tbl = spark.createDataFrame(final_taxonomy)
intermediate_and_meta_table_write(
    business_kpi='Visits',
    model_version=final_model_version,
    df=final_taxonomy_tbl,
    catalog=output_table_catalog,
    schema=output_table_silver_schema,
    table_name='mmm_input_preprocessing_taxonomy_data',
    environment=environment,
    dates_list_used=dates_list_used,
)
```

The `business_kpi` passed to `intermediate_and_meta_table_write` for
shared tables is just the leading KPI (`'Visits'` or `'Rental Visits'`)
— this is metadata only, used by the audit table.

#### Section 4.3.10 — Compute and store correlation matrices

After writing the overall tables, the notebook computes a pairwise
correlation matrix between all `impressions|*` columns and writes it
to `mmm_visits_corr_input_data_overall` and
`mmm_rental_visits_corr_input_data_overall`. These tables are inputs to
the EDA Tableau dashboard so analysts can spot newly-introduced
multicollinearity at the input level (before it shows up as model
instability later).

#### Section 4.3.11 — Build the UNION view

The final cell creates `vw_mmm_input_preprocessing_overall_data` —
a SQL view that UNIONs the three flavors (Visits/FS, ZHL, Rental Visits)
into a single long-form table tagged by `kpi_group`. This view is the
single endpoint for downstream BI tools that want to see "all the
input data for all the KPIs in one place."

#### Section 4.3.12 — Slack notification

```python
if environment == 'prod':
    send_slack_message(f"✅ The MMM Input Preprocessing Job has been successfully completed for version {final_model_version}")
```

### 4.4 What the silver tables look like

A typical row of `mmm_input_preprocessing_overall_data`:

| Column | Example value |
|---|---|
| `dma_regionid` | 12 |
| `dmacode` | 501 |
| `week_monday` | `2025-09-15` |
| `impressions_App_Apple_Search` | 1238492 |
| `impressions_App_Facebook` | 0 |
| `impressions_SEM_Google_Search` | 4593821 |
| ... (~25 channel-network impression columns) | ... |
| `spend_App_Apple_Search` | 8421.50 |
| ... (~25 spend columns) | ... |
| `value_econmetricsmsa_for_sale_inventory` | 1842.0 |
| `value_googletrends_mortgage_index` | 67.3 |
| `value_visits_visits` | 234829 |
| `value_leads_fs_submits` | 412 |
| ... (~15 exogenous columns) | ... |
| `train_holdout` | `Train` |

The wide pivot format is what the downstream feature-engineering layer
operates on — each channel-network combination is one column, each
exogenous variable is one column.

> **Interview angle — "How do you handle missing data across DMAs and
> weeks?"** *"Three layers. (1) Outer-merge of marketing and business
> data at the silver layer means we never drop a (dma, week) that has
> data in only one source; missing values become NaN at this stage. (2)
> The downstream feature-engineering notebook does an explicit
> `data.fillna(0)` after reading silver — for impressions, zero means
> 'no spend this week' which is the correct interpretation. (3) For
> macroeconomic variables, the exogenous feature store handles missing-
> holdout values by backfilling with seasonal week-of-year averages
> rather than zero, because zero would be a wrong signal for an index
> variable that's supposed to be smoothly varying. We never impute
> impressions or spend — both are observed counts where 0 is
> meaningful — but we do impute macroeconomic indices because they're
> continuous variables where missing-and-zero would be wrong."*

---

## 5. `mmm_exogeneous_feature_store.py` — the macroeconomic smoother

[`mmm_exogeneous_feature_store.py`](D:/MMM_Learning/mmm_model/shared_utils/mmm_exogeneous_feature_store.py)
is the second task in the MMM Input Job. It runs after preprocessing
and produces the **exogenous feature store** that every KPI's NB1
reads.

### 5.1 What it does

Reads `mmm_input_preprocessing_overall_data` (the just-written silver
table), subsets to `(dmacode, week_monday, train_holdout, <macro_econ_vars>)`,
applies exponential smoothing per DMA to each macro variable in
`macro_econ_vars_to_smooth`, and writes the smoothed result to a
**Databricks Feature Store** table:

```text
marketing.rapidmmm_silver.mmm_automation_exogenous_feature_store
```

The feature store is registered with primary keys `(dmacode,
week_monday)` so that downstream consumers (KPI NB1) can do `fs.read_table(...)`
and rely on the schema + primary-key contract being enforced.

### 5.2 The macroeconomic variables

From `mmm_input_config.yml::macro_econ_vars`:

```text
value|econmetricsmsa|for_sale_inventory
value|econmetricsmsa|mean_days_to_pending
value|econmetricsmsa|median_days_to_pending
value|econmetricsmsa|median_list_price
value|econmetricsmsa|median_sale_price
value|econmetricsmsa|new_listings
value|econmetricsmsa|newly_pending_listings
value|econmetricsmsa|percent_listings_with_price_cut
value|econmetricsmsa|sales_count_raw
value|econmetricsmsa|zillow_home_value_index
value|googletrends|branded_index
value|googletrends|competitive_index
value|googletrends|forsale_index
value|googletrends|mortgage_index
value|googletrends|rentals_index
value|googletrends|zillowoffers_index
value|mortgagemetrics|interest_rate
value|moodys_unemployment_data|unemployment_rate
value|moodys_consumer_price_data|consumer_price
value|appinstalls|app_installs
value|rental_metrics|rental_daily_listings
```

These cover four families:

| Family | Variables | Why it matters |
|---|---|---|
| **Housing market econometrics** | `for_sale_inventory`, `median_list_price`, `new_listings`, `zillow_home_value_index`, etc. | When the housing market is hot (low inventory, high prices) FS Submits rise; when it cools, they fall — independent of marketing |
| **Google Trends search interest** | `branded_index`, `competitive_index`, `forsale_index`, `mortgage_index`, `rentals_index` | Consumer search intent acts as a leading indicator of buying intent — captures organic demand the model otherwise would mis-attribute to marketing |
| **Macroeconomic** | `mortgage_interest_rate`, `unemployment_rate`, `consumer_price` (CPI) | Higher mortgage rates suppress home buying; unemployment and inflation affect both buying and renting decisions |
| **App + listings supply** | `app_installs`, `rental_daily_listings` | Supply-side controls — more listings → more conversions; app installs as a proxy for engagement |

### 5.3 The smoothing logic — `variable_smoothing`

For each variable in `macro_econ_vars_to_smooth` (a subset of the full
list — Google Trends indices, econometric indices, Moody's data, and
rental listings all get smoothed; mortgage interest rate and app
installs do not):

```python
def variable_smoothing(data, ma, variable_name, alpha=0.3):
    sm = ma.Smoothing(Type='Exponential')
    # ...
    for dma, df_dma in data.groupby('dmacode'):
        series = df_dma[variable_name]
        # If holdout-period values are missing/zero, backfill them
        # with week-of-year seasonal averages from train data
        holdout_mask = df_dma['train_holdout'] == 'Holdout'
        if (series[holdout_mask].isnull() | (series[holdout_mask] == 0)).any():
            # Compute exponential smoothing on the train-only portion
            # then fill holdout missing values with seasonal averages
            ...
        else:
            final_smoothed = sm.transform(np.array(series), alpha=alpha)
```

The algorithm is:

1. **Sort by `(dmacode, week_monday)`** within each DMA group.
2. **Detect missing-or-zero values in the holdout period.** If any
   exist, run smoothing only on the train period (where data is
   complete), then for each missing holdout week, fill with the
   `week-of-year` seasonal average from the smoothed train series.
3. **If no holdout values are missing**, just apply exponential
   smoothing to the full series.

Why bother with the seasonal backfill? Because the holdout period is
the *most recent 4 weeks*, and macroeconomic data sources sometimes lag
real-time by a week or two — for_sale_inventory might be missing the
most recent week. Zero-filling those weeks would tell the model
"inventory crashed to zero," which is wrong. Backfilling with the
week-of-year seasonal average preserves the level + seasonality
structure of the index.

The smoothing parameter `alpha = 0.3` is hardcoded — exponential
smoothing with $\alpha = 0.3$ puts ~70% weight on prior history per
update. See [Doc 02 Section 8](02_rapidmmm_library_internals.md#81-movingaveragessmoothingtype)
for the EMA formula.

### 5.4 Feature Store registration

```python
fs = FeatureStoreClient()

def register_and_refresh_feature_store(df_spdf, feature_store_table):
    required_columns = {"dmacode", "week_monday"}
    missing = required_columns - set(df_spdf.columns)
    if missing:
        raise ValueError(f"Missing required columns: {missing}")

    try:
        fs.get_table(feature_store_table)
    except Exception:
        fs.create_table(
            name=feature_store_table,
            primary_keys=["dmacode", "week_monday"],
            df=df_spdf,
            description="Macro econ metrics data. Metrics are smoothed as required.",
        )

    fs.write_table(
        name=feature_store_table,
        df=df_spdf,
        mode="merge",  # Upsert: update existing rows, insert new rows
    )
```

The `mode="merge"` upsert is important: each bi-weekly run adds the
two newest weeks of macroeconomic data but **retains** all historical
weeks back to 2023. The feature store table is the cumulative archive,
not a snapshot.

This matters for downstream consumers: a KPI NB1 reads the entire
feature store table back, subsets to its modeling window, and uses
whichever historical macroeconomic context is needed. No re-pull from
source per KPI.

### 5.5 Why a feature store (and not just another silver table)?

Two reasons:

1. **Cross-team reuse.** Other ML teams at Zillow (Forecasting,
   Incrementality) consume the same macroeconomic features. Putting them
   in the Databricks Feature Store creates a discoverable, schema-
   versioned, ACL-controlled artifact that survives team boundaries.

2. **Primary-key contract.** Feature Store enforces `(dmacode,
   week_monday)` as primary keys, so any write that violates the
   uniqueness constraint fails loudly. A regular Delta table would
   silently accept duplicates.

> **Interview angle — "Where does your feature store fit in?"** *"The
> feature store is one specific table —
> `mmm_automation_exogenous_feature_store` — holding pre-smoothed
> macroeconomic features (Google Trends, mortgage rates, housing
> econometrics) at `(dmacode, week_monday)` grain. It's written by the
> upstream MMM Input Job and read by every KPI's feature-engineering
> notebook. We use Databricks Feature Store specifically (rather than a
> plain Delta table) for three things: (1) primary-key enforcement so
> duplicate rows fail loudly, (2) cross-team discoverability via the
> Feature Store UI, and (3) versioned schema so a consumer that read
> the table last week can detect if today's read has a different
> schema. The actual modeling features (adstocked impressions, scaled
> Hill values) live in KPI-specific silver tables, not the feature
> store — those are computed fresh per KPI and don't benefit from
> cross-team sharing."*

---

## 6. `mmm_model_output_table_creation.py` — the gold DDLs

[`mmm_model_output_table_creation.py`](D:/MMM_Learning/mmm_model/shared_utils/mmm_model_output_table_creation.py)
is auto-invoked by KPI NB1/NB2 in development environment via
`dbutils.notebook.run(...)`. In stage/prod, the tables already exist
and this notebook is a no-op (idempotent CREATE TABLE IF NOT EXISTS).

In dev, it:

1. Creates the per-user schema if missing (handled by
   `create_or_get_dev_environment_variables`)
2. Issues `CREATE TABLE IF NOT EXISTS` for the gold tables (DDLs below)
3. Bootstraps the dev tables with the **latest production data** per
   KPI:
   ```sql
   INSERT OVERWRITE <dev_table>
   SELECT a.* FROM marketing.rapidmmm_gold.<table> a
   JOIN (SELECT business_kpi, MAX(p_data_date) AS max_date
         FROM marketing.rapidmmm_gold.<table>
         GROUP BY business_kpi) b
   ON a.business_kpi = b.business_kpi AND a.p_data_date = b.max_date
   ```
   This means a developer in dev gets the same starting state as prod
   — they can re-run any KPI's NB1 and not start from an empty gold
   table.

### 6.1 Gold table summary

| Gold table | Granularity | Written by | Read by | Used for |
|---|---|---|---|---|
| `mmm_model_output_overall_level` | `dma × week × channel × network × model_variable` | KPI NB2 | KPI NB5 (single-variable taxonomy), downstream `incrementality-layer` | Direct-effect-only contributions for the overall (channel × network) view |
| `mmm_model_output_taxonomy_level` | `dma × week × channel × network × campaign_super × lob × tactic × initiative` | KPI NB6 | downstream `incrementality-layer`, Tableau | Direct-effect contributions at the full taxonomy granularity |
| `mmm_model_combined_output_overall_level` | Same as overall + `type` (Direct/Funnel) + `funneleffect_variable` | KPI NB2 (post-funnel-effect) | KPI NB4 (parent KPI context), NB7, NB9, Tableau | The canonical "what each channel drove" table at overall level — includes funnel effects |
| `mmm_model_combined_output_taxonomy_level` | Same as taxonomy + `type` + `funneleffect_variable` | KPI NB6 (post-funnel) | NB4 (parent context), NB8, NB9, Tableau | Same but at taxonomy granularity |
| `mmm_response_curves_overall_level` | `(dmacode, channel, network)` per version | KPI NB7 | `mmm_response_curves_overall_level_reporting`, downstream budget optimizer | Hill curve params: bottom, top, slope, saturation, r_2 |
| `mmm_response_curves_taxonomy_level` | `(dmacode, channel, network, campaign_super)` per version | KPI NB8 | reporting + optimizer | Same at taxonomy level |
| `mmm_response_curves_overall_level_reporting` | `(channel_network, spend)` 150-point grid | KPI NB7 | Tableau dashboards | Sampled curve `spend → predicted` for direct plotting |
| `mmm_response_curves_taxonomy_level_reporting` | `(channel_network, core_campaign_super, spend)` | KPI NB8 | Tableau | Same at taxonomy level |
| `mmm_model_output_overall_level_stability` | `(channel, network, version_curr, version_prev)` | KPI NB9 | Tableau (QC dashboard) | Version-over-version ROI stability flags |
| `mmm_model_output_taxonomy_level_stability` | + campaign_super, lob | KPI NB9 | Tableau (QC) | Same at taxonomy level |
| `mmm_model_job_metadata_detail` | One row per (kpi × version × table × run) | All writes via `intermediate_and_meta_table_write` | Audit / ops | Lineage trail — which job_id wrote which table at which version |
| `mmm_model_output_stat` | `(model_type, channel_network, business_kpi, version)` | KPI NB2 / NB4 | Tableau (QC) | $R^2$, RMSE, MAPE per model |

### 6.2 The append-vs-overwrite pattern

Every model-output table is **append-by-version**: each bi-weekly run
adds rows for the new `vN+1` without touching prior versions. This is
implemented via:

```python
df.write.mode("overwrite").format("delta")\
  .option("replaceWhere", f"business_kpi = '<KPI>' AND version = '<vN+1>'")\
  .saveAsTable(...)
```

The `replaceWhere` predicate means "overwrite only rows matching this
predicate"; rows with other (kpi, version) values are preserved.

The two reporting tables (`_reporting` suffix) are an exception — they
hold only the latest version per KPI, so they're fully overwritten
each run.

---

## 7. The workflow guards — `bi_weekly_check` + `availability_check`

### 7.1 `mmm_week_condition_check.py`

[The 30-line file](D:/MMM_Learning/mmm_model/shared_utils/mmm_week_condition_check.py)
is the **bi-weekly cadence gate**. Databricks doesn't natively support
"every other week" cron, so jobs are scheduled weekly and this task
short-circuits on even weeks.

```python
week_number = int(dbutils.widgets.get("week_number").strip())

if week_number == 100:  # sentinel default → compute from today's date
    pst = pytz.timezone('US/Pacific')
    week_number = datetime.now(pst).isocalendar().week

if week_number % 2 == 1:
    dbutils.jobs.taskValues.set(key="run_mmm_jobs", value="Execute")
else:
    dbutils.jobs.taskValues.set(key="run_mmm_jobs", value="Skip")
```

The result is broadcast to downstream tasks via
`dbutils.jobs.taskValues`. The very next task is an **if/else condition
task** (`mmm_input_bi_weekly_condition_check`) that reads this value
and either proceeds to the rest of the DAG or no-ops the whole job.

### 7.2 `mmm_dataset_availability_check.py`

[The 50-line file](D:/MMM_Learning/mmm_model/shared_utils/mmm_dataset_availability_check.py)
uses the cross-Zillow `zg_databricks_platform_sdk.availability` package:

```python
from zg_databricks_platform_sdk.availability import poke_delta_table_for_availability

poke_delta_table_for_availability(
    catalog=input_table_catalog,
    schema=input_table_schema,
    table=table,           # mmm_business_metrics or mmm_marketing_metrics
    data_start_date=start_date,
    data_end_date=end_date,
    env='prod',
)
```

`poke_delta_table_for_availability` is a Zillow-internal helper that
polls the upstream Delta table's max `p_data_date` and verifies it's
within the expected window. If the upstream data hasn't refreshed by
the time the MMM job kicks off, this task fails loudly — preventing
the MMM job from running on stale data.

The two availability checks (one for `mmm_business_metrics`, one for
`mmm_marketing_metrics`) run in parallel. Both must pass before
preprocessing starts.

> **Interview angle — "How do you ensure upstream data freshness
> before running an ML job?"** *"We use a shared internal package
> (`zg_databricks_platform_sdk.availability`) that polls the upstream
> Delta table's max process_date and asserts it's within an expected
> window. The MMM Input Job has two parallel availability-check tasks
> — one for marketing metrics, one for business metrics — both must
> pass before any preprocessing runs. If either fails, the job halts
> and alerts the data-engineering team. This is a hard dependency: an
> MMM model trained on stale or incomplete data would produce silently
> wrong attributions, and the stability loop downstream would flag
> every channel as 'Unstable' — better to fail fast at the upstream-
> check stage."*

---

## 8. The full MMM Input Job DAG

Stitching the seven tasks together visually:

```mermaid
flowchart TD
    A[mmm_bi_weekly_check<br/>shared_utils/mmm_week_condition_check.py] -->|sets taskValue| B{mmm_input_bi_weekly_<br/>condition_check<br/>if/else task}
    B -->|Execute| C1[business_data_availability_check<br/>shared_utils/mmm_dataset_availability_check.py<br/>table=mmm_business_metrics]
    B -->|Execute| C2[marketing_data_availability_check<br/>shared_utils/mmm_dataset_availability_check.py<br/>table=mmm_marketing_metrics]
    B -->|Skip| Z[no-op]
    C1 --> D[Preprocessing<br/>shared_utils/mmm_input_data_preprocessing.py]
    C2 --> D
    D -->|writes 6 silver tables<br/>+ correlation tables<br/>+ vw_mmm_input view| E[Feature_Store<br/>shared_utils/mmm_exogeneous_feature_store.py]
    E -->|writes feature store| F[done]

    style A fill:#fed
    style B fill:#fed
    style C1 fill:#dff
    style C2 fill:#dff
    style D fill:#dfd
    style E fill:#dfd
    style Z fill:#ddd
```

**Cluster type** for this job: GPU (`Spark 16.2.x-gpu-ml-scala2.12`,
g5.xlarge driver + 1–3 g5.xlarge workers, autoscale). The GPU is
actually unused in the input job — there's no NumPyro fitting here —
but the team uses a single cluster type across both the input job and
the KPI jobs for operational simplicity (one warm cluster spec, one
spin-up cost).

**Schedule**: Every Tuesday 12 PM PST. The KPI jobs run every Thursday
12 PM PST — a 48-hour buffer between input completion and KPI start to
absorb upstream-data delays and allow manual intervention if the input
job needs re-running.

---

## 9. Environment matrix — what changes between dev/stage/prod

Every notebook accepts these widgets (with default values for dev work):

| Widget | Dev default | Stage value | Prod value |
|---|---|---|---|
| `catalog` | `sandbox_desa` | `stage_marketing` | `marketing` |
| `silver_schema` | `mads_team` or `dev_{user}` | `rapidmmm_silver` | `rapidmmm_silver` |
| `gold_schema` | `mads_team` or `dev_{user}` | `rapidmmm_gold` | `rapidmmm_gold` |
| `environment` | `development` | `stage` | `prod` |
| `ml_experiment_path` | `NA` (auto-derived) | `/Workspace/Users/<stage-SP-id>/...` | `/Workspace/Users/<prod-SP-id>/...` |
| `model_version_number` | `NA` (auto-increment) | `NA` | `NA` |
| Date widgets | `9999-12-31` sentinel | `9999-12-31` | `9999-12-31` |

In dev, the `9999-12-31` sentinel for `model_version_number` triggers
the auto-increment-from-gold logic; the date sentinel triggers
`get_train_holdout_dates`. The same code path runs in all three
environments — only the widget values differ.

The single `if environment == 'development':` branch in every notebook
exists to:
- Call `create_or_get_dev_environment_variables(...)` to rewire schemas
- Auto-invoke `mmm_model_output_table_creation` to bootstrap empty dev
  tables

Once those two dev-specific steps are done, the rest of the notebook
runs identically in every environment.

---

## 10. What's shared vs KPI-specific — the responsibility line

The clearest mental model of the system:

| Layer | Owner | Shared vs KPI-specific |
|---|---|---|
| Raw source tables (`marketingde_gold.mmm_*`) | DE team (out of MMM repo) | Fully shared — same upstream sources for all KPIs |
| MMM Input Job (preprocessing + feature store) | `shared_utils/` | **Fully shared** — same silver layer feeds all 5 KPIs |
| The `rapidmmm` Python library | Library team (separate repo) | **Fully shared** — same transforms, model class, attribution helpers used by all KPIs |
| The `common_functions.py` helpers | `shared_utils/` | **Fully shared** — same date logic, Delta-write helper, MLflow wrappers |
| The `mmm_input_config.yml` whitelist + mappings | `shared_utils/` | **Fully shared** — same allowed channels, same exogenous variables for all KPIs |
| Per-KPI configs (`config_param.yml`, `config_table_mapping.yml`) | `mmm_<kpi>/` | **KPI-specific** — adstock params, Hill saturation, transform_cols_atan, channels excluded per KPI |
| Per-KPI priors (`mmm_<kpi>_priors.csv`) | `mmm_<kpi>/artifacts/` | **KPI-specific** — informative priors from each KPI's prior version |
| Per-KPI feature-engineering logic | `mmm_<kpi>/1_*.py` | **KPI-specific** — different target variables, different seasonal patterns, different channel exclusions |
| Per-KPI overall model | `mmm_<kpi>/2_*.py` | **KPI-specific** — different `target_variable`, different funnel-parent, different recalibration |
| Per-KPI taxonomy model | `mmm_<kpi>/4_*.py` | **KPI-specific** — different DE / no-DE channel lists |
| Per-KPI response curves | `mmm_<kpi>/7_*.py`, `8_*.py` | **KPI-specific** — different channels excluded from RC fitting |
| Per-KPI stability | `mmm_<kpi>/9_*.py` | KPI-specific by `business_kpi` filter — but the *logic* is identical across KPIs (the code in NB9 is nearly identical) |
| Gold output tables | `marketing.rapidmmm_gold.*` | **Shared schema, KPI-tagged rows** — all five KPIs write to the same physical tables, partitioned implicitly by `business_kpi` column |

This split is what makes adding a sixth KPI a tractable engineering
task: create a new `mmm_<new_kpi>/` directory, copy the 9 notebooks
from an existing KPI as a template, edit the config files and priors,
register a new Databricks job in `databricks.yml`. **Zero changes to
shared_utils, zero changes to rapidmmm, zero changes to the gold table
DDLs.**

> **Interview angle — "How would you add a new KPI to this system?"**
> *"Six steps. (1) Add the target variable's metric name to
> `mmm_input_config.yml::business_metrics_sources` and
> `selected_exogenous_variables` so the silver layer picks it up. (2)
> Create a new directory `mmm_model/mmm_<new_kpi>/` with its own
> `config_param.yml` (adstock + Hill params per channel),
> `config_table_mapping.yml` (placeholder — gets populated by the first
> run), and `artifacts/mmm_<new_kpi>_priors.csv` (start with
> uninformative priors, refine after the first few runs). (3) Copy the
> 9 notebooks from the closest-matching existing KPI as a template
> (e.g., MF Submits if the new KPI is a lower-funnel rentals event)
> and find-replace the KPI name and target variable. (4) Decide
> funnel-effect linkage: which existing KPI is the parent (if any), and
> wire that into NB2's `nodes` parameter. (5) Add a corresponding job
> definition to `databricks.yml`. (6) Run end-to-end in dev, validate
> the model against AOT if available, iterate on priors. The shared
> infrastructure — input job, library, gold tables, audit metadata —
> requires zero changes."*

---

**Next:** Read [04_data_lineage_and_schemas.md](04_data_lineage_and_schemas.md)
for the complete schema reference of every silver and gold table, or jump to
[05_fs_submits_overall_model_track.md](05_fs_submits_overall_model_track.md)
to see the first KPI notebook consume this silver layer in detail.
