---
doc_id: 04
title: Data Lineage and Schema Catalogue — Every Delta Table in the System
companion_docs:
  - 00_mmm_ecosystem_overview.md (system map — quick reference for table consumers)
  - 02_rapidmmm_library_internals.md (the code that writes these tables)
  - 03_shared_utils_and_upstream_preprocessing.md (the preprocessing notebook that builds the silver layer)
  - 06_fs_submits_taxonomy_chain.md (the per-KPI staging tables in detail)
---

# 04 — Data Lineage and Schema Catalogue

> **What this doc is.** The searchable reference for every Delta table in
> the MMM ecosystem. Ground truth is
> [`All_Tables_Description.csv`](D:/MMM_Learning/All_Tables_Description.csv)
> (560 rows = 19 tables × their columns) and
> [`rapidmmm_schema.yml`](D:/MMM_Learning/mmm_model/mmm_table_changes/rapidmmm_schema.yml)
> (the central schema-description registry). After reading this doc, you
> should be able to name any column and answer: *which table is it in,
> what type, what produces it, what consumes it.*
>
> **How to use it.** Treat Section 6–Section 8 as your lookup tables. Read Section 10–Section 11 for
> the naming conventions you'll need to decode column names. Start at Section 2
> for the end-to-end lineage if you've never seen the system before.

---

## 1. Catalog and schema map

The system spans three Databricks environments. Each environment has a
distinct catalog and a pair of schemas (silver and gold). The same code
runs unchanged across all three — only the catalog/schema widget values
differ.

| Environment | Catalog | Silver schema | Gold schema | Who writes? |
|---|---|---|---|---|
| **Production** | `marketing` | `rapidmmm_silver` | `rapidmmm_gold` | Prod service principal `472826f2-7cfe-41b2-9be0-c4269626eee3` via Databricks jobs |
| **Stage** | `stage_marketing` | `rapidmmm_silver` | `rapidmmm_gold` | Stage service principal `71e8166b-731e-4ebe-aed8-95485167f887` via CI/CD pipeline |
| **Lab / Dev** | `sandbox_desa` | `dev_{username}` or `mads_team` | `dev_{username}` or `mads_team` | Individual developers (notebooks bootstrapped by `create_or_get_dev_environment_variables`) |

**Source tables** (read-only, owned by the upstream DE team) live in
distinct schemas regardless of environment:

| Source table | Catalog.Schema | Owner |
|---|---|---|
| `mmm_marketing_metrics` | `marketing.marketingde_gold` | Marketing DE team |
| `mmm_business_metrics` | `marketing.marketingde_gold` | Marketing DE team |
| `mmm_calendar` | `marketing.marketingde_silver` | Marketing DE team |
| `mmm_regionmapping` | `marketing.marketingde_silver` | Marketing DE team |
| `mmm_holidays` | `marketing.rapidmmm_silver` | This repo (MMM team), one-time load through 2032 |

---

## 2. End-to-end lineage

Every table in the system fits into one of five layers. Here is the
producer-consumer graph from raw upstream to Tableau.

```mermaid
flowchart TB
    subgraph SRC["RAW SOURCES (marketingde_gold, marketingde_silver)"]
        S1[mmm_marketing_metrics]
        S2[mmm_business_metrics]
        S3[mmm_calendar]
        S4[mmm_regionmapping]
        S5[mmm_holidays]
    end

    subgraph SIL_SHARED["SILVER — SHARED (rapidmmm_silver, from MMM Input Job)"]
        P1[mmm_input_preprocessing_overall_data]
        P2[mmm_input_preprocessing_overall_data_rentals]
        P3[mmm_input_preprocessing_taxonomy_data]
        P4[mmm_input_preprocessing_overall_spend_data]
        P5[mmm_input_preprocessing_overall_spend_data_rentals]
        P6[mmm_input_preprocessing_taxonomy_spend_data]
        P7[mmm_automation_exogenous_feature_store]
        P8[mmm_zhl_preprocessing_overall_data]
        PV[vw_mmm_input_preprocessing_overall_data<br/>SQL view]
    end

    subgraph SIL_KPI["SILVER — PER-KPI (rapidmmm_silver, from KPI Job)"]
        K1[mmm_KPI_adstock_transformed_data]
        K2[mmm_KPI_final_data_for_modeling]
        K3[mmm_KPI_overall_model_melted_data]
        K4[mmm_KPI_overall_model_prediction_data]
        K5[mmm_KPI_overall_model_melted_spark_ready]
        K6[mmm_KPI_taxonomy_model_input]
        K7[mmm_KPI_taxonomy_model_output_staging]
        K8[mmm_KPI_combined_taxonomy_output_staging]
        K9[mmm_KPI_taxonomy_single_var_channel]
        K10[mmm_KPI_combined_taxonomy_single_var_channel]
        K11[mmm_KPI_corr_post_fe]
    end

    subgraph GOLD["GOLD — MODEL OUTPUTS (rapidmmm_gold)"]
        G1[mmm_model_output_overall_level<br/>direct effect only]
        G2[mmm_model_combined_output_overall_level<br/>direct + funnel effect]
        G3[mmm_model_output_taxonomy_level<br/>direct effect only]
        G4[mmm_model_combined_output_taxonomy_level<br/>direct + funnel effect]
        G5[mmm_response_curves_overall_level]
        G6[mmm_response_curves_taxonomy_level]
        G7[mmm_response_curves_overall_level_reporting]
        G8[mmm_response_curves_taxonomy_level_reporting]
        G9[mmm_model_output_overall_level_stability]
        G10[mmm_model_output_taxonomy_level_stability]
        G11[mmm_dmamapping]
    end

    subgraph META["METADATA / AUDIT (rapidmmm_silver)"]
        M1[mmm_model_job_metadata_detail]
        M2[mmm_model_output_stat]
    end

    subgraph CONSUMERS["DOWNSTREAM"]
        T1[Tableau Observability Dashboard]
        T2[Tableau EDA / QC Dashboard]
        T3[Budget Allocator<br/>mmmrapid_budget_allocation]
        T4[incrementality-layer<br/>external repo]
    end

    S1 --> P1
    S1 --> P3
    S1 --> P2
    S1 --> P4
    S1 --> P6
    S1 --> P5
    S2 --> P1
    S2 --> P2
    S2 --> P3
    S5 --> K1
    S3 --> K1
    P1 --> P7
    P2 --> K1
    P1 --> K1
    P3 --> K6
    P4 --> K3
    P5 --> K3
    P6 --> K7
    P7 --> K1
    P1 --> PV
    P2 --> PV
    P8 --> PV

    K1 --> K2
    K2 --> K3
    K3 --> K5
    K3 --> K4
    K3 --> G1
    K3 --> G2
    K6 --> K7
    K6 --> K9
    K7 --> K10
    K7 --> G3
    K7 --> G4
    K9 --> G3
    K10 --> G4

    G2 --> G5
    G4 --> G6
    G5 --> G7
    G6 --> G8
    G2 --> G9
    G4 --> G10

    G1 --> T1
    G2 --> T1
    G3 --> T1
    G4 --> T1
    G7 --> T1
    G8 --> T1
    G9 --> T2
    G10 --> T2
    G7 --> T3
    G8 --> T3
    G2 --> T4
    G4 --> T4

    K3 --> M2
    K7 --> M2
    P1 --> M1
    K1 --> M1
    K2 --> M1
    G1 --> M1
    G2 --> M1
    G7 --> M1

    style SRC fill:#fdf
    style SIL_SHARED fill:#dff
    style SIL_KPI fill:#ffd
    style GOLD fill:#dfd
    style META fill:#fed
    style CONSUMERS fill:#ddf
```

**How the diagram reads:**

- **`mmm_KPI_*`** = literal table names with `KPI` replaced per the KPI
  (e.g., `mmm_mf_submits_adstock_transformed_data`,
  `mmm_fs_submits_adstock_transformed_data`). There are 5 sets of these
  per-KPI tables — one set per KPI (Visits, FS Submits, ZHL Submits,
  Rental Visits, MF Submits).
- The four **gold model-output tables** (G1, G2, G3, G4) are
  **physically single tables** with rows for all 5 KPIs, partitioned
  implicitly by the `business_kpi` column.
- The **two response-curve reporting tables** (G7, G8) hold only the
  latest version per KPI (overwritten each run); the canonical
  **`mmm_response_curves_*_level`** tables (G5, G6) hold all historical
  versions.
- The **stability tables** (G9, G10) compare the two most recent
  versions and append per (current, previous) version pair.

---

## 3. Bronze / source tables

The MMM system reads from five upstream tables; it never writes to any
of them. Three of the five are the canonical "source of truth" tables
owned by the Marketing DE team.

### 3.1 `marketing.marketingde_gold.mmm_marketing_metrics`

The canonical marketing facts table at full taxonomy granularity. **22
columns**, hundreds of millions of rows. One row per
`(dma_regionid, dmacode, date, channel, network, lob, tactic,
campaign_super, initiative)` per measurement.

Key columns:

| Column | Type | Meaning |
|---|---|---|
| `dma_regionid` | INT | Internal Zillow region ID (1:1 mapped to dmacode) |
| `dmacode` | INT | Nielsen DMA code (e.g., 501 = NYC) |
| `date` | DATE | Event date (granularity: day) |
| `week_monday` | TIMESTAMP | Monday-anchored week for the event |
| `channel` | STRING | E.g., SEM, Paid Social, Linear TV, Connected TV, App |
| `network` | STRING | Sub-channel platform — e.g., Google Search, Facebook, TikTok |
| `lob` | STRING | Line of Business — e.g., PA - Customer, Rentals - Partner, ZHL - Customer |
| `tactic` | STRING | Campaign tactic (Nonbrand Keywords, Acquisition, iOS, etc.) — **no longer used in 2025 models** |
| `initiative` | STRING | Campaign initiative — **also deprecated for 2025 models** |
| `campaign_super` | STRING | Reporting campaign category — Buyer, Brand, Rental, Agent |
| `core_campaign_super` | STRING | Standardized version of campaign_super used by MMM models |
| `core_campaign_initiative` | STRING | Standardized initiative classification |
| `core_lob` | STRING | Standardized LOB used by MMM models |
| `impressions` | DECIMAL | Total impressions for this (dma × date × taxonomy) cell |
| `clicks` | LONG | Total clicks |
| `spend` | DOUBLE | Total spend in USD |
| `p_data_date` | STRING | Upstream process date (which DE run produced this slice) |
| Other reporting columns | — | `metrics_dma`, `dma`, `reporting_*`, `data_name` (used for routing/auditing) |

The MMM preprocessing notebook reads this with a SQL query that filters
`date >= train_start_week`, excludes `channel = 'OMP'` (ZHL handles
OMP separately), excludes `network = 'Pardot'` (Email-only noise), and
standardizes a few channel/network edge cases (UM Digital → CWW Digital
rename; Operational Email routing).

### 3.2 `marketing.marketingde_gold.mmm_business_metrics`

The canonical business facts table — KPI events + macroeconomic
indicators + Google Trends + mortgage rates in one EAV-shaped table.
**10 columns**. One row per `(dma_regionid, dmacode, date, data_name,
metric)` measurement.

| Column | Type | Meaning |
|---|---|---|
| `dma_regionid` | INT | Same as marketing table |
| `dmacode` | INT | Same |
| `date` | DATE | Event date |
| `week_monday` | TIMESTAMP | Monday week anchor |
| `data_name` | STRING | The data-source family — e.g., `visits`, `leads`, `econmetricsmsa`, `googletrends`, `mortgagemetrics`, `appinstalls`, `moodys_unemployment_data`, `moodys_consumer_price_data`, `rentalsmetrics_zillowbrand`, `rentalsdailylistings` |
| `metric` | STRING | The specific metric within the data_name — e.g., `visits` (within `visits`), `fs_submits` (within `leads`), `for_sale_inventory` (within `econmetricsmsa`), `mortgage_index` (within `googletrends`) |
| `value` | DOUBLE | The numeric measurement |
| `metrics_dma` / `dma` | STRING | DMA name (display) |
| `p_data_date` | STRING | Upstream process date |

The EAV shape means a single table holds KPIs of completely different
kinds — KPI events (counts), macroeconomic indices (continuous values),
search trends (indices) all live as `(data_name, metric, value)`
triples. The preprocessing notebook **pivots** this into wide
`value|<data_name>|<metric>` columns before merging with marketing.

### 3.3 `marketing.marketingde_silver.mmm_calendar`

A day-grain calendar lookup. **8 columns**.

| Column | Type | Meaning |
|---|---|---|
| `calendardate` | DATE | The actual date |
| `day` | STRING | Day-of-month (numeric, stored as string) |
| `month` | INT | Month number 1–12 |
| `year` | INT | 4-digit year |
| `monthyear` | DATE | First day of month |
| `weekstartmonday` | DATE | The Monday anchoring the ISO week containing this date |
| `days` | INT | Count helper from upstream calendar source |
| `p_data_date` | DATE | Process date |

Used by the KPI feature-engineering notebooks to join holidays at the
day-grain and roll them up to week-grain.

### 3.4 `marketing.rapidmmm_silver.mmm_holidays`

A small reference table of US holidays through 2032. **2 columns:
`date` (STRING) + `Name` (STRING)**.

Each row is one (holiday_date, holiday_name) pair, e.g.,
`(2025-12-25, "Christmas Day")`, `(2025-07-04, "Independence Day")`.
Pivoted into one-hot encoded columns per holiday in KPI NB1.

The `holiday_var_list` config key in each KPI's `config_param.yml`
selects which holidays enter the modeling dataset — typically the five
US federal holidays: Christmas Day, Independence Day, Thanksgiving,
New Year's Day, Memorial Day.

### 3.5 `marketing.marketingde_silver.mmm_regionmapping`

A reference table mapping DMA codes to display names — used by
`rapidmmm.PostProcessing.BusinessDiagnostics.get_dma_dict()` for
human-readable plots. Not consumed by any production modeling logic.

---

## 4. Silver preprocessing tables (shared, KPI-agnostic)

These are the six tables produced by the **MMM Input Job**'s
preprocessing task. They are the canonical, validated input to every
KPI model. The KPI notebooks read these and never touch the bronze
source tables.

| Table | Granularity | Columns | Producer | Consumers |
|---|---|---|---|---|
| `mmm_input_preprocessing_overall_data` | `(dma_regionid × dmacode × week_monday × train_holdout)` with one column per (impressions, channel × network) + one per (spend, channel × network) + selected exogenous variables | **71** | `shared_utils/mmm_input_data_preprocessing.py` | Visits NB1, FS Submits NB1, ZHL Submits (via `vw_*`), exogenous feature store |
| `mmm_input_preprocessing_overall_data_rentals` | Same as above but rows with `campaign_super in ('Agent','Brand','Elevate')` or `lob in ('ZGMI - Customer','ZHL - Customer')` removed | similar | Same producer | Rental Visits NB1, MF Submits NB1 |
| `mmm_input_preprocessing_taxonomy_data` | `(dma_regionid × dmacode × week_monday × train_holdout)` × full 4-level taxonomy `(channel × network × lob × campaign_super)` | **146** | Same producer | All KPIs' NB3 (taxonomy model input) |
| `mmm_input_preprocessing_overall_spend_data` | Same overall grain, **spend columns only** | **22** | Same producer | Visits NB2, FS Submits NB2 (used by `merge_spend_data_w_melted`) |
| `mmm_input_preprocessing_overall_spend_data_rentals` | Same, rentals-filtered | similar | Same producer | Rental Visits NB2, MF Submits NB2 |
| `mmm_input_preprocessing_taxonomy_spend_data` | Full taxonomy grain, **spend columns only** | **54** | Same producer | All KPIs' NB4 |

The "wide" structure is the same across all six: index columns
(`dma_regionid, dmacode, week_monday`) plus the metric columns plus the
`train_holdout` flag.

### 4.1 `mmm_input_preprocessing_overall_data` column groups

The 71 columns split into 4 groups:

| Group | Pattern | Count | Examples |
|---|---|---|---|
| **Identity** | — | 4 | `dma_regionid`, `dmacode`, `week_monday`, `train_holdout` |
| **Impressions** | `impressions_<Channel>_<Network>` | ~25 | `impressions_SEM_Google_Search`, `impressions_Linear_TV_Media_Agency`, `impressions_App_Apple_Search` |
| **Spend** | `spend_<Channel>_<Network>` | ~25 | `spend_SEM_Google_Search`, `spend_Linear_TV_Media_Agency` |
| **Exogenous** | `value_<data_name>_<metric>` | ~17 | `value_econmetricsmsa_for_sale_inventory`, `value_googletrends_mortgage_index`, `value_visits_visits`, `value_leads_fs_submits`, `value_mortgagemetrics_interest_rate` |

A typical row carries one full DMA-week snapshot — every channel, every
network, every macro indicator in one fat row.

### 4.2 `mmm_input_preprocessing_taxonomy_data` column groups

The 146 columns scale up because each (channel × network) splits into
multiple (channel × network × LOB × campaign_super) cells:

| Group | Pattern | Count |
|---|---|---|
| **Identity** | — | 4 |
| **Impressions** | `impressions_<Channel>_<Network>_<LOB>_<CampaignSuper>` | ~70 |
| **Spend** | `spend_<Channel>_<Network>_<LOB>_<CampaignSuper>` | ~55 |
| **Exogenous** | Same as overall | ~17 |

The triple underscore in column names like
`impressions_SEM_Google_Search_PA___Customer_Buyer` is the lossy
encoding of `impressions|SEM|Google Search|PA - Customer|Buyer` — the
hyphen and surrounding spaces in `PA - Customer` each become an
underscore. See Section 10 for how the codebase round-trips these names.

### 4.3 `mmm_automation_exogenous_feature_store`

The Databricks Feature Store table written by
`mmm_exogeneous_feature_store.py`. **24 columns**.

| Group | Pattern | Count |
|---|---|---|
| **Identity** | — | 3 (`dmacode`, `week_monday`, `train_holdout`) |
| **Macro econ (raw)** | `value_<data_name>_<metric>` | varies |
| **Macro econ (smoothed)** | `value_<data_name>_<metric>_sm` | varies |

The `_sm` suffix on smoothed variables is the convention. The
`config_param.yml::macro_econ_vars_selected` key in each KPI selects
which of these (smoothed or raw) enter the modeling dataset.

### 4.4 `vw_mmm_input_preprocessing_overall_data` (SQL view)

Not a Delta table — a UNION-ALL SQL view that long-melts the three
flavors of overall data (`Others` = Visits/FS Submits,
`ZHL` = ZHL Submits, `Rentals` = Rental Visits/MF Submits) tagged by
`kpi_group`. Used by the EDA Tableau dashboard for "show me all input
data across all KPIs in one query."

Columns: `dma_regionid, dmacode, week_monday, metric_name, metric_value,
metric_category, channel, kpi_group`.

---

## 5. Silver per-KPI tables (KPI-specific)

Each KPI produces its own set of silver intermediate tables. The
example below uses **MF Submits** as the canonical case; replace
`mf_submits` with the KPI name (`visits`, `fs_submits`, `rental_visits`,
or `zhl_submits`) for the equivalent.

ZHL Submits is the exception — see Section 5.2.

### 5.1 The standard per-KPI silver tables

| Table (with `<kpi>` placeholder) | Granularity / shape | Producer NB | Consumer NB |
|---|---|---|---|
| `mmm_<kpi>_adstock_transformed_data` | `(dma × week × train_holdout)` × adstocked impression columns (one per channel-network, with adstock-suffix in column name like `impressions_SEM_Google_Search_delayed_lag_1_decay_0.0_delay_0`) | NB1 | NB2 (for `get_melted_data_for_business_diagnostics`), NB4 |
| `mmm_<kpi>_final_data_for_modeling` | adstocked + scaled + Hill-transformed impressions + macroeconomic features + holiday dummies + seasonal feature + `train_holdout` flag — the actual input to the Bayesian model | NB1 | NB2 |
| `mmm_<kpi>_corr_post_fe` | Pairwise correlation matrix between final feature columns (long-form: `Var1, Var2, Correlation, Date`) | NB1 | EDA / QC |
| `mmm_<kpi>_overall_model_prediction_data` | Train + holdout DataFrame with `pred` column added (per-DMA-week predictions from the overall model) | NB2 | EDA / model-review notebooks |
| `mmm_<kpi>_overall_model_melted_data` | The "melted" attribution table from `ModelDiagnostics.get_melted_data_for_business_diagnostics` — one row per `(dma × week × feature_variable)` with `coefficient, predicted_initial, predicted, hdi bounds, spend, impressions, channel, adjusted` | NB2 | NB4 (used as node-1 data when computing funnel effects for child KPIs), NB5 |
| `mmm_<kpi>_overall_model_melted_spark_ready` | The same melted data but post-`get_spark_ready_df_from_melted` — has metadata columns (`business_kpi`, `version`, `mcmc_id`, `p_data_date`, etc.) | NB2 | Downstream debugging |
| `mmm_<kpi>_taxonomy_model_input` | Same shape as `final_data_for_modeling` but at full taxonomy grain — adstocked + scaled + Hill at `channel × network × lob × campaign_super` | NB3 | NB4 (×15 parallel taxonomy fits), NB5 |
| `mmm_<kpi>_taxonomy_model_output_staging` | Per-channel-network taxonomy contributions (direct effect only) — written by 15 parallel NB4 invocations via `replaceWhere channel_network = '...'` | NB4 (×15) | NB6 |
| `mmm_<kpi>_combined_taxonomy_output_staging` | Per-channel-network taxonomy contributions with funnel effects applied | NB4 (×15) | NB6 |
| `mmm_<kpi>_taxonomy_single_var_channel` | Direct attribution for channels with only one taxonomy variant (cnt_dict==1) | NB5 | NB6 |
| `mmm_<kpi>_combined_taxonomy_single_var_channel` | Same with funnel effects | NB5 | NB6 |

Plus correlation tables specifically for the input data (produced by
the shared preprocessing notebook, not by per-KPI NB1):
`mmm_visits_corr_input_data_overall`, `mmm_rental_visits_corr_input_data_overall`.

### 5.2 The ZHL Submits exception

ZHL Submits has its own preprocessing layer because of the OMP (Owned
Marketing Pages) impressions split. Its silver tables follow a
different pattern:

| Table | Purpose |
|---|---|
| `mmm_zhl_preprocessing_overall_data` | ZHL-specific input data (not produced by the shared `mmm_input_data_preprocessing.py`) |
| `mmm_zhl_submits_omp_imps_taxonomy_input` | OMP impressions broken out for separate modeling |
| `mmm_zhl_submits_omp_imps_taxonomy_model_output_staging` | Per-OMP-channel taxonomy contributions |

The standard 9-notebook chain doesn't apply to ZHL — it has no separate
`feature_engineering` notebook and no `overall_model` notebook. See
[Doc 08 Section 3](08_other_kpis_comparative.md) for the details.

### 5.3 Total count of per-KPI silver tables

Roughly 11 tables × 5 KPIs = ~55 per-KPI silver tables in production
silver schema, plus the 8 shared silver tables = ~63 total in
`marketing.rapidmmm_silver`.

---

## 6. Gold model-output tables

These are the canonical model outputs — what Tableau and downstream
consumers actually read. All four are **physically single tables** with
rows for every KPI partitioned implicitly by the `business_kpi` column,
and rows for every version partitioned by the `version` column.

### 6.1 `mmm_model_output_overall_level` (direct effect only, overall grain)

**24 columns**. Produced by every KPI NB2.

| Column | Type | Meaning |
|---|---|---|
| `model_dma_id` | LONG | LabelEncoder-mapped integer DMA ID used inside the model |
| `dmacode` | LONG | Nielsen DMA code |
| `week_monday` | TIMESTAMP | Week anchor |
| `model_variable` | STRING | The model feature this row attributes to — channel-network for media, holiday name for holidays, exogenous name for econometrics. Example: `impressions\|SEM\|Google Search` |
| `channel` | STRING | Marketing channel (or `'Others'` for non-channel rows like macroeconomics, intercept, seasonal) |
| `network` | STRING | Sub-channel (or `'Others'`) |
| `model_idv` | DOUBLE | The independent variable value at this `(dma, week, variable)` — the **adstocked + scaled + Hill-transformed** feature value |
| `model_dv` | DOUBLE | The dependent variable value (KPI value) for this `(dma, week)` |
| `coefficient` | DOUBLE | The fitted Bayesian coefficient $\beta_{c,d}$ posterior mean |
| `coef_hdi_2point5_pct` | DOUBLE | 2.5% HDI lower bound on coefficient |
| `coef_hdi_97point5_pct` | DOUBLE | 97.5% HDI upper bound on coefficient |
| `predicted_initial` | DOUBLE | Initial prediction = $\beta \times \text{value} \times \overline{y}$ |
| `predicted_2point5_pct_hdi` | DOUBLE | Lower bound of predicted contribution |
| `predicted` | DOUBLE | Final predicted contribution (after taxonomy error correction for taxonomy models) |
| `predicted_97point5_pct_hdi` | DOUBLE | Upper bound of predicted contribution |
| `spend` | DOUBLE | Dollar spend on this channel × network in this DMA × week |
| `impressions` | DOUBLE | Raw (pre-adstock) impressions on this channel × network |
| `business_kpi` | STRING | KPI tag — `'Visits'`, `'FS Submits'`, `'Rental Visits'`, `'MF Submits'`, `'ZHL Submits'` |
| `modeltype` | STRING | `'Overall'` (always for this table) |
| `mcmc_id` | STRING | Unique MCMC run identifier: `<channel_network><YYYYMMDDHHMMSS>` |
| `version` | STRING | Model version: `vN` |
| `run_time` | STRING | Run timestamp |
| `p_data_date` | DATE | Process date |
| `train_holdout` | STRING | `'Train'` or `'Holdout'` |

### 6.2 `mmm_model_combined_output_overall_level` (direct + funnel, overall grain)

**26 columns** — same as above plus two:

| Column | Type | Meaning |
|---|---|---|
| `type` | STRING | `'Direct Effect'` or `'Funnel Effect'` — set by `FunnelEffects` |
| `funneleffect_variable` | STRING | The parent KPI name on funnel rows (e.g., `'Visits'` for FS Submits' Visits-driven funnel rows); equals the current `business_kpi` on direct rows |

This is the canonical output table — what most Tableau dashboards read.
The `_combined_` variant supersedes the `mmm_model_output_overall_level`
table for any analysis that wants the full attribution picture.

### 6.3 `mmm_model_output_taxonomy_level` (direct, taxonomy grain)

**27 columns** — same as overall plus four taxonomy columns:
`core_campaign_super`, `core_lob`, `tactic`, `initiative`. The `tactic`
and `initiative` columns are always `'NA'` for 2025+ models (see Section 10
for the rename history; they're preserved for backwards compatibility
with pre-2025 model versions).

Produced by KPI NB6 (Taxonomy Output Merge), which UNIONs the
`*_taxonomy_model_output_staging` and `*_taxonomy_single_var_channel`
silver staging tables.

### 6.4 `mmm_model_combined_output_taxonomy_level` (direct + funnel, taxonomy grain)

**29 columns** — taxonomy grain plus `type` + `funneleffect_variable`.
Produced by NB6 from the combined staging tables.

### 6.5 `mmm_response_curves_overall_level`

**15 columns**. Produced by KPI NB7 (Overall Response Curves).

| Column | Type | Meaning |
|---|---|---|
| `dmacode` | DOUBLE | DMA code (NaN for national-level curves where `modellevel='Overall'`) |
| `bottom` | LONG | Hill curve bottom parameter (always 0 in production — `bottom_param=False`) |
| `top` | DOUBLE | Hill curve top parameter — the asymptotic maximum |
| `slope` | DOUBLE | Hill curve slope (shape) parameter |
| `saturation` | DOUBLE | Hill curve half-saturation parameter |
| `r_2` | DOUBLE | $R^2$ of the curve fit against observed predicted-vs-spend points |
| `channel`, `network` | STRING | Channel-network identifier |
| `independentvar` | STRING | `'Spend'` for most channels; `'Impressions'` for Email |
| `modellevel` | STRING | `'Overall'` (national) or `'DMA'` (per-DMA fit) |
| `business_kpi`, `version`, `run_time`, `p_data_date` | metadata |
| `stability_status` | STRING | `'stable'` if the curve evaluates finitely at $100M and $300M spend; `'unstable'` otherwise |

### 6.6 `mmm_response_curves_taxonomy_level`

**19 columns** — same as overall plus `core_campaign_super, core_lob,
tactic, initiative`. The taxonomy variant fits Hill curves at the
`(channel, network, campaign_super)` level rather than just
`(channel, network)`.

### 6.7 `mmm_model_output_overall_level_stability`

**21 columns**. Produced by KPI NB9 (Stability Loop).

| Column | Type | Meaning |
|---|---|---|
| `channel`, `network` | STRING | Channel-network identifier |
| `spend_prev`, `spend_curr` | DOUBLE | Aggregate spend in previous and current versions |
| `impressions_prev`, `impressions_curr` | DOUBLE | Aggregate impressions in both versions |
| `return_lower_prev`, `return_higher_prev` | DOUBLE | HDI bounds on previous version's return (`predicted/impressions`) |
| `return_lower_curr`, `return_higher_curr` | DOUBLE | HDI bounds on current version's return |
| `overlap_range` | DOUBLE | Overlap interval length between curr and prev HDI bands |
| `return_overlap` | DOUBLE | % overlap of the current HDI band that is shared with prev |
| `Overlap_stability` | STRING | `'Stable'` if overlap > 50%, else `'Unstable'`, else `'N/A'` |
| `return_stability_PE` | STRING | `'Stable'` if point-estimate drift ≤ 25%, else `'Unstable'` |
| `Final_Stability` | STRING | `'Stable'` if EITHER overlap OR point-estimate criterion is met |
| `version_curr`, `version_prev` | STRING | The two versions being compared |
| `p_data_date_prev`, `p_data_date_curr` | TIMESTAMP | Process dates of the two versions |
| `business_kpi`, `run_time` | metadata |

### 6.8 `mmm_model_output_taxonomy_level_stability`

**20 columns** — same as overall stability plus `core_campaign_super,
core_lob` (the taxonomy granularity for stability check).

### 6.9 `mmm_dmamapping`

A simple DMA-code → DMA-name lookup with `p_data_date`. Periodically
refreshed; used by reporting for human-readable DMA labels.

---

## 7. Gold reporting tables

These two tables hold pre-computed spend → predicted curves sampled
from the response-curve parameter tables, ready for direct Tableau
plotting. **They hold only the latest version per KPI** (overwritten
each run, not append-by-version).

| Table | Granularity | Producer NB | Consumer |
|---|---|---|---|
| `mmm_response_curves_overall_level_reporting` | `(business_kpi × version × channel_network × spend)` — 150 spend points from 0 to $100M sampled from each fitted Hill curve at the national level | KPI NB7 | Tableau Observability Dashboard, Budget Allocator |
| `mmm_response_curves_taxonomy_level_reporting` | Same with additional `core_campaign_super` column for taxonomy-level curves | KPI NB8 | Tableau, Budget Allocator |

The 150-point grid is generated by sampling the spend axis logarithmically
across `(0, 100M]` and evaluating the fitted Hill curve at each point.
Tableau then plots these as smooth spend-vs-predicted curves with no
runtime computation needed.

---

## 8. Metadata + audit tables

Two silver tables hold the operational metadata that lets you trace
any output back to its producing run.

### 8.1 `mmm_model_output_stat`

**8 columns**. Captures the $R^2$, RMSE, MAPE for each model fit.

| Column | Type | Meaning |
|---|---|---|
| `r2` | DOUBLE | Pearson $R^2$ on the relevant data slice |
| `rmse` | DOUBLE | Root mean squared error |
| `mape` | DOUBLE | Mean absolute percentage error |
| `model_type` | STRING | `'Overall'` or `'Taxonomy'` |
| `channel_network` | STRING | `'Train'`, `'Holdout'`, or per-channel-network identifier for taxonomy models |
| `business_kpi` | STRING | KPI tag |
| `version` | STRING | Model version |
| `run_time` | TIMESTAMP | When the stat was recorded |

For an Overall model, two rows are written per version: one with
`channel_network='Train'` (in-sample stats) and one with
`channel_network='Holdout'` (out-of-sample stats). For a Taxonomy model,
two rows per channel-network are written.

### 8.2 `mmm_model_job_metadata_detail`

**10 columns**. The full audit trail of every table write.

| Column | Type | Meaning |
|---|---|---|
| `business_kpi` | STRING | KPI tag for the run |
| `model_version` | STRING | Model version being written |
| `job_id` | STRING | Databricks job ID |
| `job_name` | STRING | Databricks job name (e.g., `mmm_fs_submits_overall_taxonomy_model_prod`) |
| `run_id` | STRING | Databricks job run ID |
| `table_name` | STRING | Fully-qualified table name written |
| `delta_table_version` | LONG | Delta-table version after this write |
| `environment` | STRING | `'prod'`, `'stage'`, or `'development'` |
| `dates_list_used` | ARRAY | Array of date dicts (`train_start_week`, `train_end_week`, `holdout_start_week`, `holdout_end_week`, `response_curves_start_week`) — captures the exact date window the run used |
| `updated_timestamp` | TIMESTAMP | When this metadata row was written |

This table is the **source of truth for "which job_id produced row X"**.
Any unexpected value in a gold table can be traced via:

```sql
SELECT job_id, job_name, run_id, environment, updated_timestamp
FROM marketing.rapidmmm_silver.mmm_model_job_metadata_detail
WHERE business_kpi = 'FS Submits'
  AND model_version = 'v62'
  AND table_name = 'marketing.rapidmmm_gold.mmm_model_combined_output_overall_level';
```

> **Interview angle — "How do you trace a single number on the
> dashboard back to its source?"** *"Every row in every gold table is
> tagged with `business_kpi, version, mcmc_id, run_time, p_data_date`.
> A dashboard cell traces as: (1) read the cell's `(business_kpi,
> version)` from the gold table query, (2) look up
> `mmm_model_job_metadata_detail` for `(business_kpi, model_version,
> table_name)` to get the Databricks `job_id` and `run_id`, (3) look up
> the Databricks job logs to find the actual notebook execution that
> produced it. The `dates_list_used` array in the metadata captures the
> exact train/holdout window the run used, so a re-run with the same
> `model_version_number` and the same dates would be byte-equivalent
> (modulo MCMC RNG drift)."*

---

## 9. `rapidmmm_schema.yml` — the central schema registry

[`mmm_table_changes/rapidmmm_schema.yml`](D:/MMM_Learning/mmm_model/mmm_table_changes/rapidmmm_schema.yml)
is a dbt-style schema-description file that documents the gold tables.
It is consumed by
[`mmm_table_changes/mmm_tables_metadata_addition.py`](D:/MMM_Learning/mmm_model/mmm_table_changes/mmm_tables_metadata_addition.py)
which writes the descriptions to Unity Catalog as table and column
comments via `ALTER TABLE ... ALTER COLUMN ... COMMENT`.

### 9.1 What it covers

The YAML documents 15 tables — all 11 gold model-output / response-
curve / stability tables, plus `mmm_dmamapping`,
`mmm_model_job_metadata_detail`, `mmm_model_output_overall_funnel_effects`,
`mmm_model_output_taxonomy_funnel_effects` (legacy backups),
`mmmrapid_budget_allocation` (downstream budget allocator output).

For each table, the YAML has:

- A top-level description block with abbreviations dictionary
  (DMA, KPI, HDI, MCMC, SEM, CWW, ROI all defined)
- A list of `columns:`, each with a `name` and `description`

The mmm_table_changes admin scripts use this YAML as the source of
truth — when a schema change happens (column added, renamed, etc.),
the script reads this YAML and applies the documented descriptions to
Unity Catalog.

### 9.2 The mmm_table_changes one-shot admin scripts

There are 12 admin scripts in `mmm_model/mmm_table_changes/` — all
one-shot migrations already applied to production. Brief summary:

| Script | Purpose |
|---|---|
| `mmm_tables_metadata_addition.py` | Reads `rapidmmm_schema.yml` and pushes descriptions to Unity Catalog |
| `mmm_tables_backup.py` | Backs up gold tables before a destructive change |
| `mmm_table_structure_changes.py` | Bulk DDL changes (column adds, drops, renames) |
| `mmm_combined_table_addition.py` | Added the `_combined_*` tables (which superseded the prior `*_funnel_effects` tables) |
| `mmm_tables_campaign_lob_rename.py` | Renamed `campaign_super` → `core_campaign_super`, `lob` → `core_lob` to match upstream taxonomy |
| `mmm_table_p_data_date_change.py` | Changed `p_data_date` type from STRING to DATE in some tables |
| `mmm_taxonomy_changes_update.py` | Schema migration for taxonomy tables |
| `mmm_taxonomy_response_curves_fix.py` | Response curve schema fix |
| `mmm_fs_submits_rental_visits_prod_fix.py` | One-time prod data fix for FS/Rental Visits |
| `mmm_zhl_taxonomy_fix.py` | ZHL-specific taxonomy fix |
| `mmm_zhl_final_table_update.py` | ZHL final table schema update |
| `mmm_rental_visits_final_table_update.py` | Rental Visits final table schema update |

These don't run in any scheduled job — they're triggered manually when
the analytics team needs to migrate the schema. The `rapidmmm_schema.yml`
file is the durable artifact; the scripts are the one-shot vehicles
that applied historical changes.

---

## 10. Column naming conventions

Three conventions you need to internalize to read the codebase.

### 10.1 The pipe-separated "wide column" pattern

Every modeling feature has a structured name with `|` as the separator.
There are four forms:

| Pattern | Meaning | Example |
|---|---|---|
| `value\|<data_name>\|<metric>` | A business or macroeconomic variable | `value\|visits\|visits`, `value\|leads\|fs_submits`, `value\|googletrends\|mortgage_index`, `value\|econmetricsmsa\|for_sale_inventory` |
| `impressions\|<Channel>\|<Network>` | A media impression column at overall grain | `impressions\|SEM\|Google Search`, `impressions\|Linear TV\|Media Agency` |
| `impressions\|<Channel>\|<Network>\|<LOB>\|<CampaignSuper>` | A media impression column at taxonomy grain | `impressions\|SEM\|Google Search\|PA - Customer\|Buyer` |
| `spend\|<Channel>\|<Network>` (or full taxonomy) | A spend column, otherwise identical structure | `spend\|SEM\|Google Search` |

These names are how the **in-memory pandas DataFrames** are keyed.
Every prior CSV (`mmm_*_priors.csv`), every adstock config key
(`config_param.yml::adstock_hill_best_params`), every taxonomy filter
uses these pipe-separated names.

### 10.2 The post-transform "adstock suffix" pattern

After adstock is applied, the column name gains a suffix encoding the
adstock variant and its parameters:

| Adstock variant | Suffix pattern | Example |
|---|---|---|
| Delayed | `_delayed_lag_<L>_decay_<λ>_delay_<δ>` | `impressions\|SEM\|Google Search_delayed_lag_1_decay_0.0_delay_0` |
| Exponential | `_exponential_decay_<λ>_length_<L>` | `impressions\|SEM\|Google Performance Max_exponential_decay_0.89_length_26` |
| Geometric | `_geometric_max_lag_<L>_length_<λ>` | `impressions\|Native\|Media Agency_geometric_max_lag_4_length_0.05` |
| Weibull | `_weibull_shape_<k>_scale_<s>_dist_type_<t>` | (defined but not in production) |
| Lags | `_lags_max_lag_<L>` | (grid search only) |

This is how the codebase encodes adstock parameters into the data
itself — a column carries its own provenance. When `ModelDiagnostics`
strips these suffixes to recover the channel-network name, it uses a
multi-suffix `split` chain to handle all variants:

```python
melted["adjusted"] = [
    i.split('_exponential')[0] if '_exponential' in i else
    i.split('_delayed')[0]     if '_delayed' in i else
    i.split('_geometric')[0]   if '_geometric' in i else
    i.split('_weibull')[0]     if '_weibull' in i else
    i.split('_lag')[0]
    for i in melted["column"]
]
```

### 10.3 The snake_case "Delta-compatible" pattern

Delta tables don't accept `|`, space, or `-` in column names. So
before writing to Delta, the codebase does:

```python
modified = col.replace(" ", "_").replace("|", "_").replace("-", "_")
```

This is **lossy** — `PA - Customer` and `PA___Customer` both round-trip
to the same form when re-read naively. To recover the original name,
the codebase persists a **reverse mapping** in
`mmm_input_config.yml` (for shared silver) or
`config_table_mapping.yml` (for per-KPI silver) every time it writes a
new Delta table.

The pattern that runs through every notebook:

```python
# Writing: create the mapping and persist it
modified = [c.replace(" ", "_").replace("|", "_").replace("-", "_") for c in df.columns]
column_name_mapping = dict(zip(df.columns, modified))
add_mapping(
    file_path='config_table_mapping.yml',
    mapping_name='mmm_<kpi>_<table_name>',
    mapping_dict=column_name_mapping,
)
df.columns = modified
spark.createDataFrame(df).write...

# Reading: invert the mapping to restore original names
mapping = get_yaml_value('config_table_mapping.yml', 'mmm_<kpi>_<table_name>')
reverse_mapping = {v: k for k, v in mapping.items()}
for old_name, new_name in reverse_mapping.items():
    if old_name in df.columns:
        df = df.withColumnRenamed(old_name, new_name)
```

After this rename, in-memory work uses the original pipe-separated
names — which align with the priors CSV, the adstock config, and
everything else.

> **Interview angle — "How do you handle column naming when you have
> two layers — one with structured/encoded names like
> `impressions|SEM|Google Search` and one with Delta-legal sanitized
> names?"** *"We persist a reverse-mapping dictionary alongside each
> Delta write. When writing, we sanitize column names (pipe →
> underscore, space → underscore, hyphen → underscore) and append the
> original→sanitized mapping to a per-KPI YAML registry. When reading,
> we invert the mapping and rename the Delta columns back to the
> pipe-separated form. This keeps the modeling layer's code working in
> the natural pipe-separated namespace while Delta sees only Delta-
> legal column names. Yes the encoding is lossy in principle — but
> because we always persist the round-trip dictionary, no information
> is lost in practice."*

---

## 11. The `p_data_date` / `version` / `business_kpi` metadata convention

Three columns appear on **every** gold table and together enable
replay, comparison, and stability.

### 11.1 `business_kpi`

A string tag (`'Visits'`, `'FS Submits'`, `'ZHL Submits'`, `'Rental
Visits'`, `'MF Submits'`) identifying which KPI this row belongs to.
Every gold table is **physically single** with rows for all five KPIs
co-located, filtered by `business_kpi` in all queries.

### 11.2 `version`

A string of the form `vN` where `N` is a monotonically-incrementing
integer per KPI. The value is computed at the top of each KPI notebook
as `MAX(version_num) + 1` where `version_num` is extracted from
`vN` via regex `r'v(\d+)'`.

### 11.3 `p_data_date`

A date stamp set to `date.today()` at the time of the Delta write. Used
by downstream consumers to find the **latest** data per KPI without
needing to know the current version number:

```sql
SELECT a.*
FROM mmm_model_combined_output_overall_level a
JOIN (SELECT business_kpi, MAX(p_data_date) AS max_date
      FROM mmm_model_combined_output_overall_level
      GROUP BY business_kpi) b
  ON a.business_kpi = b.business_kpi AND a.p_data_date = b.max_date;
```

This idiom appears throughout the codebase. It's the canonical "give me
the latest data per KPI" query.

### 11.4 The three together

| Use case | Filter |
|---|---|
| "Latest data for all KPIs in Tableau" | `p_data_date = MAX(p_data_date) per business_kpi` |
| "Compare v62 vs v63 for FS Submits" | `business_kpi = 'FS Submits' AND version IN ('v62','v63')` |
| "Replay the exact training window of a specific run" | Read `dates_list_used` from `mmm_model_job_metadata_detail` filtered to `(business_kpi, model_version)` |
| "Find every output row produced by a specific Databricks job" | Join gold tables to `mmm_model_job_metadata_detail` on `(business_kpi, model_version)` and filter by `job_id` |

> **Interview angle — "How do you handle data versioning in this kind
> of ML pipeline?"** *"Three layers. (1) Every gold-table row carries
> `business_kpi`, `version` (auto-incremented per KPI per bi-weekly
> run), and `p_data_date` (run timestamp). (2) Writes use Delta
> `replaceWhere business_kpi = ... AND version = ...` so re-running the
> same version overwrites only that slice — never anyone else's. (3) An
> audit table (`mmm_model_job_metadata_detail`) captures the exact
> Databricks job_id, run_id, environment, and date window
> (`dates_list_used`) for every write. Combined, any row in any gold
> table is traceable to the producing Databricks job, replayable by
> re-running with the same `model_version_number` widget, and
> comparable to any other version via simple WHERE clauses."*

> **Interview angle — "Walk me through your data model."** *"Five
> layers. (1) Raw upstream — `mmm_marketing_metrics` (impressions/spend
> by full taxonomy) and `mmm_business_metrics` (KPI events and macro
> indicators) — owned by the DE team. (2) Silver shared — six tables
> produced by the MMM Input Job that pivot the raw long-form data into
> wide modeling-ready format at overall and taxonomy granularities,
> with separate variants for the rentals-only subset. (3) Silver
> per-KPI — adstocked, scaled, Hill-transformed features specific to
> each KPI's model fit, plus staging tables for the 15-way parallel
> taxonomy fan-out. (4) Gold model output — four tables (overall direct,
> overall combined-with-funnel, taxonomy direct, taxonomy combined)
> plus response curves, response-curve reporting, and stability check
> tables. (5) Downstream — Tableau dashboards and the
> `incrementality-layer` repo consume gold. All gold tables are
> partitioned implicitly by `business_kpi` and `version` columns, with
> `p_data_date` as the 'latest data' indicator, and every write is
> traceable via `mmm_model_job_metadata_detail`."*

---

## 12. Quick lookups

### 12.1 "Which table holds the final attribution for FS Submits?"

`marketing.rapidmmm_gold.mmm_model_combined_output_overall_level` (or
`_taxonomy_level` for the breakdown by LOB and campaign_super). Filter
by `business_kpi = 'FS Submits' AND version = '<vN>'`.

### 12.2 "Which table holds the response curve for SEM Google Search?"

`marketing.rapidmmm_gold.mmm_response_curves_overall_level`. Filter by
`business_kpi = 'FS Submits' AND channel = 'SEM' AND network = 'Google
Search' AND modellevel = 'Overall'`. For the Tableau-ready 150-point
sampled curve, use `mmm_response_curves_overall_level_reporting`.

### 12.3 "Did the model become unstable in the latest version?"

`marketing.rapidmmm_gold.mmm_model_output_overall_level_stability`.
Filter by `business_kpi` and `version_curr`. Look at the
`Final_Stability` column.

### 12.4 "What was the prior on the SEM Google Search coefficient for v62?"

Not stored in any Delta table — it's in
`mmm_model/mmm_fs_submits/artifacts/mmm_fs_submits_priors.csv`,
which is captured by the Git tag of the v62 release.

### 12.5 "Which job produced this row?"

Join the gold-table row to `marketing.rapidmmm_silver.mmm_model_job_metadata_detail`
on `(business_kpi, model_version)`, filter by `table_name`, get
`(job_id, run_id, updated_timestamp)`.

### 12.6 "What macroeconomic features were available in v62?"

`marketing.rapidmmm_silver.mmm_automation_exogenous_feature_store` —
the feature store at that point in time. Use Delta Time Travel:

```sql
SELECT * FROM marketing.rapidmmm_silver.mmm_automation_exogenous_feature_store
VERSION AS OF <delta_table_version_at_v62_write_time>;
```

The `delta_table_version` for that point is stored in
`mmm_model_job_metadata_detail` for the v62 row that wrote the feature
store table.

---

**Next:** Read [05_fs_submits_feature_engineering_and_overall_model.md](05_fs_submits_feature_engineering_and_overall_model.md)
to see the silver-to-gold transformation in detail for the FS Submits
KPI — the first end-to-end walk through actual KPI notebook code.
