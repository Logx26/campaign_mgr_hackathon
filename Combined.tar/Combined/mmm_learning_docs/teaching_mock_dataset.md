# Teaching Mock Dataset (reused across all phases)

A deliberately tiny, hand-made dataset so we can watch numbers flow through the
whole MMM pipeline. **2 DMAs × 6 weeks × 3 channels**, plus 2 KPIs and a couple
of exogenous drivers. These are invented numbers, not real Zillow data.

## Dimensions
- **DMAs:** `501` (New York), `803` (Los Angeles)
- **Weeks (Monday-anchored):** W1=2024-01-01, W2=2024-01-08, W3=2024-01-15, W4=2024-01-22, W5=2024-01-29, W6=2024-02-05
- **Channels (channel|network):** `SEM|Google Search` (lower-funnel, fast decay), `Linear TV|Media Agency` (upper-funnel, slow decay + long lag), `Email|Simon Data` (exponential decay)
- **Holiday:** New Year's Day falls in W1 (2024-01-01)

## Raw `mmm_marketing_metrics` (long format) — impressions, DMA 501
| dmacode | week_monday | channel | network | campaign_super | lob | impressions | spend |
|---|---|---|---|---|---|---|---|
| 501 | 2024-01-01 | SEM | Google Search | Buyer | PA | 1000 | 800 |
| 501 | 2024-01-08 | SEM | Google Search | Buyer | PA | 1200 | 950 |
| 501 | 2024-01-15 | SEM | Google Search | Buyer | PA | 1100 | 900 |
| 501 | 2024-01-22 | SEM | Google Search | Buyer | PA | 1300 | 1050 |
| 501 | 2024-01-29 | SEM | Google Search | Buyer | PA | 1250 | 1000 |
| 501 | 2024-02-05 | SEM | Google Search | Buyer | PA | 1400 | 1150 |
| 501 | 2024-01-08 | Linear TV | Media Agency | Brand | Multi Product | 50000 | 40000 |
| 501 | 2024-01-15 | Linear TV | Media Agency | Brand | Multi Product | 50000 | 40000 |
| 501 | 2024-01-01 | Email | Simon Data | Brand | PA | 500 | 0 |
| 501 | 2024-01-15 | Email | Simon Data | Brand | PA | 600 | 0 |
| 501 | 2024-01-29 | Email | Simon Data | Brand | PA | 550 | 0 |
(Weeks with no row = 0 impressions for that channel. DMA 803 ≈ 60% of 501's volume.)

## Raw `mmm_business_metrics` (long format) — KPIs + exogenous, DMA 501
| dmacode | week_monday | data_name | metric | value |
|---|---|---|---|---|
| 501 | 2024-01-01 | visits | visits | 10000 |
| 501 | 2024-01-08 | visits | visits | 14000 |
| 501 | 2024-01-15 | visits | visits | 15000 |
| 501 | 2024-01-22 | visits | visits | 12500 |
| 501 | 2024-01-29 | visits | visits | 12000 |
| 501 | 2024-02-05 | visits | visits | 12800 |
| 501 | 2024-01-01 | leads | fs_submits | 200 |
| 501 | 2024-01-08 | leads | fs_submits | 260 |
| 501 | 2024-01-15 | leads | fs_submits | 280 |
| 501 | 2024-01-22 | leads | fs_submits | 250 |
| 501 | 2024-01-29 | leads | fs_submits | 240 |
| 501 | 2024-02-05 | leads | fs_submits | 255 |
| 501 | (each week) | mortgagemetrics | interest_rate | 7.0 → 7.1 → 7.1 → 6.9 → 6.8 → 6.8 |
| 501 | (each week) | googletrends | forsale_index | 60 → 65 → 70 → 62 → 58 → 60 |

## Target variable per KPI (the `value|data_name|metric` key)
| KPI model | target in mmm_business_metrics |
|---|---|
| Visits | `value\|visits\|visits` |
| FS Submits | `value\|leads\|fs_submits` |
| ZHL Submits | ZHL-specific |
| Rental Visits | `value\|rentalsmetrics_zillowbrand\|rental_visits` |
| MF Submits | `value\|rentalsmetrics_zillowbrand\|fr_bdp_submits` |
